import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Login from "../Screens/AuthFlow/LoginScreen";

const AuthStack = createNativeStackNavigator();

const screens = [
  {
    name: "Login",
    component: Login,
  },
];

const AuthNavigator = () => (
  <AuthStack.Navigator
    screenOptions={{
      headerShown: false,
    }}
  >
    {screens.map((item: { name: string; component: any }, index) => (
      <AuthStack.Screen
        name={item.name}
        component={item.component}
        key={index}
      />
    ))}
  </AuthStack.Navigator>
);

export default AuthNavigator;
