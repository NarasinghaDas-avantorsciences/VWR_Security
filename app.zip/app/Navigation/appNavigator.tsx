import React, { useEffect } from "react";
import {
  CardStyleInterpolators,
  createStackNavigator,
} from "@react-navigation/stack";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  Account,
  Help,
  ApprovalDetails,
  ReceiveDetails,
  News,
  Messages,
  CommunicationCenter,
  StockLevel,
  ReplenishCheckout,
} from "../Screens/AppFlow";
import DrawerNavigator from "./drawerNavigator";
import { SIZES, COLORS } from "../Utils/theme";

const AppStack = createStackNavigator();

const screens = [
  {
    name: "Account",
    component: Account,
    screenOpen: "vertical",
  },
  {
    name: "Help",
    component: Help,
    screenOpen: "vertical",
  },
  {
    name: "News",
    component: News,
    screenOpen: "vertical",
  },
  {
    name: "Messages",
    component: Messages,
    screenOpen: "vertical",
  },
  {
    name: "ApprovalDetails",
    component: ApprovalDetails,
    screenOpen: "horizontal",
  },
  // {
  //   name: "PICountLists",
  //   component: PICountLists,
  //   screenOpen: "horizontal",
  // },
  {
    name: "ReceiveDetails",
    component: ReceiveDetails,
    screenOpen: "horizontal",
  },
  // {
  //   name: "ReplenishCheckout",
  //   component: ReplenishCheckout,
  //   screenOpen: "horizontal",
  // },
];

const bottomSheetScreens = [
  {
    name: "CommunicationCenter",
    component: CommunicationCenter,
  },
  {
    name: "StockLevel",
    component: StockLevel,
  },
];

const AppNavigator = () => {
  const insets = useSafeAreaInsets();

  return (
    <AppStack.Navigator
      screenOptions={{
        headerShown: false,
        cardStyle: {
          backgroundColor: "#FFFFFF",
        },
      }}
    >
      <>
        <AppStack.Screen name="Drawer" component={DrawerNavigator} />
        {screens.map(
          (
            item: { name: string; component: any; screenOpen: string },
            index
          ) => (
            <AppStack.Screen
              options={{
                cardStyleInterpolator:
                  item.screenOpen == "vertical"
                    ? CardStyleInterpolators.forVerticalIOS
                    : CardStyleInterpolators.forHorizontalIOS,
              }}
              name={item.name}
              component={item.component}
              key={index}
            />
          )
        )}

        {bottomSheetScreens.map(
          (item: { name: string; component: any }, index) => (
            <AppStack.Screen
              options={{
                cardStyleInterpolator: CardStyleInterpolators.forVerticalIOS,
                cardStyle: {
                  flex: 1,
                  marginTop: Math.max(insets.top + SIZES.radius),
                  backgroundColor: COLORS.transparentBlack,
                  borderTopLeftRadius: SIZES.radius,
                  borderTopRightRadius: SIZES.radius,
                },
                cardOverlayEnabled: true,
                presentation: "transparentModal",
              }}
              name={item.name}
              component={item.component}
              key={index}
            />
          )
        )}
      </>
    </AppStack.Navigator>
  );
};

export default AppNavigator;
