import { useEffect, useState } from "react";
import jwt_decode from "jwt-decode";

const useTokenExpiration = (userToken: any, thresholdMinutes: number) => {
  const [isTokenAboutToExpire, setIsTokenAboutToExpire] = useState(false);
  const [time, setTime] = useState(0);

  useEffect(() => {
    let tokenCheckInterval: string | number | NodeJS.Timeout | undefined;

    const calculateRemainingTime = (decoded: unknown) => {
      const expInSeconds = decoded?.exp || 0;
      const expInMilliseconds = expInSeconds * 1000;
      const currentTimeInMilliseconds = Date.now();
      const timeDifferenceInMilliseconds =
        expInMilliseconds - currentTimeInMilliseconds;
      const timeDifferenceInMinutes = Math.floor(
        timeDifferenceInMilliseconds / (1000 * 60)
      );
      return timeDifferenceInMinutes;
    };

    const checkToken = () => {
      if (userToken) {
        const decoded = jwt_decode(userToken);
        const remainingTime = calculateRemainingTime(decoded);
        if (remainingTime <= thresholdMinutes) {
          setTime(remainingTime);
          setIsTokenAboutToExpire(true);
        } else {
          setIsTokenAboutToExpire(false);
        }
      }
    };

    checkToken();

    tokenCheckInterval = setInterval(checkToken, 1000 * 1); // Check every minute

    return () => clearInterval(tokenCheckInterval);
  }, [userToken, thresholdMinutes]);
  return {
    visible: isTokenAboutToExpire,
    time,
  };
};

export default useTokenExpiration;
