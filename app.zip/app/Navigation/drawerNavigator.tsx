import React, { useCallback, useState } from "react";
import {
  TouchableOpacity,
  View,
  Platform,
  NativeModules,
  Image,
} from "react-native";
import { DrawerItem, createDrawerNavigator } from "@react-navigation/drawer";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { useDispatch } from "react-redux";
import { isDeviceTablet, checkUserPrivileges } from "../Utils/globalFunction";
import { SIZES, COLORS, FONTS } from "../Utils/theme";
import * as storage from "../Service/AsyncStoreConfig";
import {
  setNavigationData,
  clearNavigationData,
} from "../Redux/Action/navigationRouteAction";
import {
  AvantorHorizontal,
  DashboardIcon,
  ConsumeIcon,
  ReplenishIcon,
  AccountIcon,
  HelpIcon,
  PiCountIcon,
  ReceiveIcon,
  StockCorrectionIcon,
  StockTransferIcon,
  ApprovalIcon,
  CloseWhite,
  icons,
} from "../Utils/images";
import {
  Dashboard,
  Approvals,
  PiCount,
  Receive,
  Replenish,
  StockCorrection,
  StockTransfer,
  Consume,
  OrderRequestApproval,
  PICountLists,
} from "../Screens/AppFlow";
import styles from "./styles";
import { logout } from "../Redux/Action/loginAction";
import { useSelector } from "react-redux";
import CustomText from "../Components/CustomText";
import ReplenishOffline from "../Screens/AppFlow/ReplenishOffline";

import { clearAccountData } from "../Redux/Action/accountAction";
import { setIsShowConfirmationAlert } from "../Redux/Action/userAction";
import { useFocusEffect } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const { StatusBarManager } = NativeModules;
const isTablet = isDeviceTablet();

const Drawer = createDrawerNavigator();

const DrawerNavigator = (props: any) => {
  const { correctStockList } = useSelector(
    (state: any) => state.stockCorrectionReducer
  );
  const { initialRecommendedData } = useSelector(
    (state: any) => state.replenishReducer
  );
  const { confirmationAlertInfo, isOnHand } = useSelector(
    (state: any) => state.userReducer
  );
  const { piCountConfirmedProductsList, piCountPendingProductsList } =
    useSelector((state: any) => state.picontReducer);

  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { userPrivilege } = useSelector((state: any) => state.userReducer);

  const { consumeCount, orderRequestCount, pouCount, hidePOU, approvalCount } =
    useSelector((state: any) => state.approvalsReducer);
  const { top } = useSafeAreaInsets();
  const STATUSBAR_HEIGHT =
    Platform.OS === "ios" ? top : StatusBarManager.HEIGHT;
  const { internet } = useSelector((state: any) => state.loginReducer);
  const [flag, setFlag] = useState(0);
  const setlogout = () => {
    dispatch(clearNavigationData());
    dispatch(clearAccountData());
    dispatch(logout(true));
  };

  const getActiveRouteState = (route: any) => {
    if (
      !route.routes ||
      route.routes.length === 0 ||
      route.index >= route.routes.length
    ) {
      return route;
    }

    const childActiveRoute = route?.routes[route.index] as NavigationState;
    return getActiveRouteState(childActiveRoute)?.name ?? "";
    // return getActiveRouteState(childActiveRoute);
  };

  useFocusEffect(
    useCallback(() => {
      let props = confirmationAlertInfo?.data?.props;
      if (!confirmationAlertInfo?.isShow) {
        switch (confirmationAlertInfo?.data?.navigationScreen) {
          case "Dashboard":
            dispatch(setNavigationData("Dashboard"));
            props.navigation.getParent("Drawer").closeDrawer();
            props.navigation.navigate("Dashboard");
            break;

          case "Consume":
            dispatch(setNavigationData("Consume"));
            props.navigation.getParent("Drawer").closeDrawer();
            props.navigation.navigate("Consume");
            break;

          case "Replenish":
            dispatch(setNavigationData("Replenish"));
            props.navigation.getParent("Drawer").closeDrawer();
            let data = [];
            storage.getItem("replenish_offline_data").then((res: any) => {
              if (res?.length) {
                const dataJSON = JSON.parse(res);
                data = dataJSON;
              } else data = [];
              !data?.length && internet
                ? props.navigation.navigate("Replenish")
                : props.navigation.navigate("ReplenishOffline");
            });

          case "Receive":
            dispatch(setNavigationData("Receive"));
            props.navigation.getParent("Drawer").closeDrawer();
            props.navigation.navigate("Receive");
            break;

          case "StockCorrection":
            dispatch(setNavigationData("StockCorrection"));
            props.navigation.getParent("Drawer").closeDrawer();
            props.navigation.navigate("StockCorrection");
            break;

          case "PiCount":
            dispatch(setNavigationData("PiCount"));
            props.navigation.getParent("Drawer").closeDrawer();
            props.navigation.navigate("PiCount");
            break;

          case "Approvals":
            dispatch(setNavigationData("Approvals"));
            props.navigation.getParent("Drawer").closeDrawer();
            props.navigation.navigate("Approvals");
            break;

          case "StockTransfer":
            dispatch(setNavigationData("StockTransfer"));
            props.navigation.getParent("Drawer").closeDrawer();
            props.navigation.navigate("StockTransfer");
            break;

          case "Help":
            props.navigation.getParent("Drawer").closeDrawer();
            props.navigation.navigate("Help");
            break;

          case "Account":
            dispatch(setNavigationData("Account"));
            props.navigation.getParent("Drawer").closeDrawer();
            props.navigation.navigate("Account");
            break;

          default:
            break;
        }
      }
    }, [confirmationAlertInfo])
  );

  const isCheckNavData = async (navScreen: string, props: any) => {
    let isEnable = false;
    if (isOnHand && correctStockList?.length > 0) {
      dispatch(
        setIsShowConfirmationAlert({
          isShow: true,
          data: { navigationScreen: navScreen, props: props },
        })
      );
    }
    let count = 0;
    await AsyncStorage.multiGet([
      "stockTransferCount",
      "stockCorrectionCount",
      "replenishCount",
      "receiveCount",
      "consumeCount",
      "ApprovalsCount",
    ]).then((blockData) => {
      blockData &&
        blockData?.map((v: any, i: number) => {
          if (Number(v[1]) > 0) {
            count = count + 1;
          }
        });
    });

    if (
      // (!isOnHand && initialRecommendedData?.length > 0) ||
      correctStockList?.length > 0 ||
      piCountConfirmedProductsList?.length > 0 ||
      piCountPendingProductsList?.length > 0 ||
      (confirmationAlertInfo && confirmationAlertInfo?.consumeCount > 0) ||
      (confirmationAlertInfo &&
        confirmationAlertInfo?.stockTransferCount > 0) ||
      count > 0
    ) {
      dispatch(
        setIsShowConfirmationAlert({
          isShow: true,
          data: { navigationScreen: navScreen, props: props },
        })
      );
    } else {
      setFlag(flag + 1);
      isEnable = true;
      await dispatch(
        setIsShowConfirmationAlert({
          isShow: false,
          data: { navigationScreen: navScreen, props: props },
        })
      );
      dispatch(setNavigationData(navScreen));
      await props.navigation.getParent("Drawer").closeDrawer();
      props.navigation.navigate(navScreen);
      // props.navigation.getParent("Drawer").closeDrawer();
    }
  };

  const CustomDrawer = (props: any) => (
    <View style={{ flex: 1 }}>
      {/* Header */}
      <View
        style={{
          paddingBottom: hp(1.3),
          backgroundColor: COLORS.scienceBlue,
          flexDirection: "row",
          alignItems: isTablet ? "flex-end" : "center",
          justifyContent: isTablet ? "space-between" : "space-around",
          paddingHorizontal: isTablet ? SIZES.radius : 0,
          ...(!isTablet && {
            paddingTop: STATUSBAR_HEIGHT + hp(2.175),
          }),
          ...(isTablet && {
            height: hp(8.37),
          }),
        }}
      >
        {isTablet ? (
          <AvantorHorizontal height={hp(4)} width={wp(62)} />
        ) : (
          <AvantorHorizontal />
        )}

        <TouchableOpacity
          style={{
            alignItems: "center",
            justifyContent: "center",
            height: isTablet ? hp(4) : hp(3),
            width: 45,
          }}
          onPress={() => props.navigation.getParent("Drawer").closeDrawer()}
        >
          {isTablet ? (
            <CloseWhite height={hp(2)} width={hp(3.5)} />
          ) : (
            <CloseWhite />
          )}
        </TouchableOpacity>
      </View>

      {/* Contents */}
      <View>
        {/* Dashboard */}
        <DrawerItem
          style={[
            styles.drawerContent,
            { marginTop: hp(2), marginBottom: -hp(0.5) },
          ]}
          label={Strings["dashboard"] ? Strings["dashboard"] : "Dashboard"}
          icon={() => (
            <DashboardIcon
              width={isTablet ? hp(3.5) : hp(2)}
              height={isTablet ? hp(3.5) : hp(2)}
            />
          )}
          labelStyle={[
            styles.drawerLabel,
            { marginLeft: isTablet ? 0 : -wp(5) },
          ]}
          onPress={async () => {
            const activeRoute =
              props.state && getActiveRouteState(props?.state);
            if (activeRoute == "Dashboard") {
              await props.navigation.getParent("Drawer").closeDrawer();
            } else {
              isCheckNavData("Dashboard", props);

              // dispatch(setNavigationData("Dashboard"));
              // await props.navigation.getParent("Drawer").closeDrawer();
              // props.navigation.navigate("Dashboard");
            }
          }}
          allowFontScaling={false}
        />

        {/* Consume */}
        {checkUserPrivileges(userPrivilege, "consume.scanner") && (
          <DrawerItem
            allowFontScaling={false}
            style={[styles.drawerContent]}
            label={Strings["consume"] ? Strings["consume"] : "Consume"}
            // label={"kjhj"}
            icon={() => (
              <ConsumeIcon
                width={isTablet ? hp(3.5) : hp(2)}
                height={isTablet ? hp(3.5) : hp(2)}
              />
            )}
            labelStyle={[
              styles.drawerLabel,
              { marginLeft: isTablet ? 0 : -wp(5) },
            ]}
            onPress={async () => {
              const activeRoute =
                props.state && getActiveRouteState(props?.state);
              if (activeRoute == "Consume") {
                await props.navigation.getParent("Drawer").closeDrawer();
              } else {
                if (confirmationAlertInfo != undefined) {
                  isCheckNavData("Consume", props);
                } else {
                  dispatch(setNavigationData("Consume"));
                  await props.navigation.getParent("Drawer").closeDrawer();
                  props.navigation.navigate("Consume");
                }
              }
            }}
          />
        )}

        {/* Replenish */}
        {checkUserPrivileges(userPrivilege, "replenish.scanner") && (
          <DrawerItem
            allowFontScaling={false}
            style={[styles.drawerContent]}
            label={Strings["replenish"] ? Strings["replenish"] : "Replenish"}
            icon={() => (
              <ReplenishIcon
                width={isTablet ? hp(3.5) : hp(2)}
                height={isTablet ? hp(3.5) : hp(2)}
              />
            )}
            labelStyle={[
              styles.drawerLabel,
              { marginLeft: isTablet ? 0 : -wp(5) },
            ]}
            onPress={async () => {
              const activeRoute =
                props.state && getActiveRouteState(props?.state);
              if (activeRoute == "Replenish") {
                await props.navigation.getParent("Drawer").closeDrawer();
              } else {
                if (confirmationAlertInfo != undefined) {
                  isCheckNavData("Replenish", props);
                } else {
                  dispatch(setNavigationData("Replenish"));
                  await props.navigation.getParent("Drawer").closeDrawer();
                  let data = [];
                  await storage
                    .getItem("replenish_offline_data")
                    .then((res: any) => {
                      if (res?.length) {
                        const dataJSON = JSON.parse(res);
                        data = dataJSON;
                      } else data = [];
                      !data?.length && internet
                        ? props.navigation.navigate("Replenish")
                        : props.navigation.navigate("ReplenishOffline");
                    });
                }
              }
            }}
          />
        )}

        {/* Receive */}
        {checkUserPrivileges(userPrivilege, "receive.scanner") && (
          <DrawerItem
            disabled={!internet}
            allowFontScaling={false}
            style={[styles.drawerContent]}
            label={Strings["receive"] || "receive"}
            icon={() =>
              internet ? (
                <ReceiveIcon
                  width={isTablet ? hp(3.5) : hp(2)}
                  height={isTablet ? hp(3.5) : hp(2)}
                />
              ) : (
                <Image source={icons.ReceiveICon} style={styles.offlineIcon} />
              )
            }
            labelStyle={[
              styles.drawerLabel,
              { marginLeft: isTablet ? 0 : -wp(5) },
              !internet && {
                color: "#53565A",
              },
            ]}
            pressColor={!internet ? "white" : undefined}
            onPress={async () => {
              const activeRoute =
                props.state && getActiveRouteState(props?.state);
              if (activeRoute == "Receive") {
                await props.navigation.getParent("Drawer").closeDrawer();
              } else {
                if (!!internet) {
                  if (confirmationAlertInfo != undefined) {
                    // !!internet && isCheckNavData("Receive", props);
                    isCheckNavData("Receive", props);
                  } else {
                    dispatch(setNavigationData("Receive"));
                    await props.navigation.getParent("Drawer").closeDrawer();
                    props.navigation.navigate("Receive");
                  }
                }
              }
            }}
          />
        )}

        {/* StockCorrection */}
        {checkUserPrivileges(userPrivilege, "stock.correction(scanner)") && (
          <DrawerItem
            disabled={!internet}
            allowFontScaling={false}
            style={[styles.drawerContent]}
            label={
              Strings["stock.correction"]
                ? Strings["stock.correction"]
                : "Stock Correction"
            }
            icon={() =>
              internet ? (
                <StockCorrectionIcon
                  width={isTablet ? hp(3.5) : hp(2)}
                  height={isTablet ? hp(3.5) : hp(2)}
                />
              ) : (
                <Image
                  source={icons.stockcorrection}
                  style={styles.offlineIcon}
                />
              )
            }
            pressColor={!internet ? "white" : undefined}
            labelStyle={[
              styles.drawerLabel,
              { marginLeft: isTablet ? 0 : -wp(5) },
              !internet && {
                color: "#53565A",
              },
            ]}
            onPress={async () => {
              const activeRoute =
                props.state && getActiveRouteState(props?.state);
              if (activeRoute == "StockCorrection") {
                await props.navigation.getParent("Drawer").closeDrawer();
              } else {
                if (!!internet) {
                  if (confirmationAlertInfo != undefined) {
                    // !!internet && isCheckNavData("StockCorrection", props);
                    isCheckNavData("StockCorrection", props);
                  } else {
                    dispatch(setNavigationData("StockCorrection"));
                    await props.navigation.getParent("Drawer").closeDrawer();
                    props.navigation.navigate("StockCorrection");
                  }
                }
              }
            }}
          />
        )}

        {/* PiCount */}
        {checkUserPrivileges(userPrivilege, "show.scanner.PI.Count") && (
          <DrawerItem
            disabled={!internet}
            allowFontScaling={false}
            style={[styles.drawerContent]}
            label={Strings["pi.count"] || "PI Count"}
            icon={() =>
              internet ? (
                <PiCountIcon
                  width={isTablet ? hp(3.5) : hp(2)}
                  height={isTablet ? hp(3.5) : hp(2)}
                />
              ) : (
                <Image source={icons.piCountIcon} style={styles.offlineIcon} />
              )
            }
            labelStyle={[
              styles.drawerLabel,
              { marginLeft: isTablet ? 0 : -wp(5) },
              !internet && {
                color: "#53565A",
              },
            ]}
            pressColor={!internet ? "white" : undefined}
            onPress={async () => {
              const activeRoute =
                props.state && getActiveRouteState(props?.state);
              if (activeRoute == "PiCount") {
                await props.navigation.getParent("Drawer").closeDrawer();
              } else {
                if (!!internet) {
                  if (confirmationAlertInfo != undefined) {
                    // !!internet && isCheckNavData("PiCount", props);
                    isCheckNavData("PiCount", props);
                  } else {
                    dispatch(setNavigationData("PiCount"));
                    await props.navigation.getParent("Drawer").closeDrawer();
                    props.navigation.navigate("PiCount");
                  }
                }
              }
            }}
          />
        )}

        {/* Approvals */}
        {checkUserPrivileges(userPrivilege, "approval.scanner") && (
          // approvalCount > 0 &&
          <TouchableOpacity
            disabled={!internet}
            style={[
              styles.drawerCustomContainer,
              {
                paddingLeft: isTablet ? wp(2.5) : wp(4.5),
              },
            ]}
            onPress={async () => {
              const activeRoute =
                props.state && getActiveRouteState(props?.state);
              if (activeRoute == "Approvals") {
                await props.navigation.getParent("Drawer").closeDrawer();
              } else {
                if (!!internet) {
                  if (confirmationAlertInfo != undefined) {
                    // !!internet && isCheckNavData("Approvals", props);

                    isCheckNavData("Approvals", props);
                  } else {
                    dispatch(setNavigationData("Approvals"));
                    await props.navigation.getParent("Drawer").closeDrawer();
                    props.navigation.navigate("Approvals");

                    // props.navigation.navigate("ApprovalDetails");
                  }
                }
              }
            }}
          >
            <View
              style={[
                styles.approvalContainer,
                {
                  // justifyContent: isTablet ? "space-between" : "space-around",
                },
              ]}
            >
              {internet ? (
                <ApprovalIcon
                  width={isTablet ? hp(3.5) : hp(2)}
                  height={isTablet ? hp(3.5) : hp(2)}
                />
              ) : (
                <Image source={icons.approvalIcon} style={styles.offlineIcon} />
              )}

              <CustomText
                style={[
                  styles.drawerCustomText,
                  !internet && {
                    color: "#53565A",
                  },
                ]}
              >
                {Strings["approval"] ? Strings["approval"] : "Approval"}
              </CustomText>
            </View>
            {internet && (
              <View
                style={[
                  styles.approvalCount,

                  approvalCount >= 10 && {
                    height: hp(4.5),
                    width: hp(4.5),
                  },
                  approvalCount >= 100 && {
                    height: hp(5),
                    width: hp(5),
                  },
                  approvalCount >= 1000 && {
                    height: hp(5.5),
                    width: hp(5.5),
                  },
                ]}
              >
                <CustomText
                  style={{
                    fontSize: FONTS.h2,
                    color: COLORS.scienceBlue,
                    fontWeight: "600",
                  }}
                >
                  {approvalCount}
                </CustomText>
              </View>
            )}
          </TouchableOpacity>
        )}

        {/* StockTransfer */}
        {checkUserPrivileges(userPrivilege, "stock.transfer.scanner") && (
          <DrawerItem
            disabled={!internet}
            allowFontScaling={false}
            style={[styles.drawerContent]}
            label={Strings["stock.transfer.scanner"] ?? "Stock Transfer"}
            icon={() =>
              internet ? (
                <StockTransferIcon
                  width={isTablet ? hp(3.5) : hp(2)}
                  height={isTablet ? hp(3.5) : hp(2)}
                />
              ) : (
                <Image
                  source={icons.stockcorrection}
                  style={styles.offlineIcon}
                />
              )
            }
            pressColor={!internet ? "white" : undefined}
            labelStyle={[
              styles.drawerLabel,
              { marginLeft: isTablet ? 0 : -wp(5) },
              !internet && {
                color: "#53565A",
              },
            ]}
            onPress={async () => {
              const activeRoute =
                props.state && getActiveRouteState(props?.state);

              if (activeRoute == "StockTransfer") {
                await props.navigation.getParent("Drawer").closeDrawer();
              } else {
                if (!!internet) {
                  if (confirmationAlertInfo != undefined) {
                    // !!internet && isCheckNavData("StockTransfer", props);
                    !!internet && isCheckNavData("StockTransfer", props);
                  } else {
                    dispatch(setNavigationData("StockTransfer"));
                    await props.navigation.getParent("Drawer").closeDrawer();
                    props.navigation.navigate("StockTransfer");
                  }
                }
              }
            }}
          />
        )}
        {/* Help */}
        <DrawerItem
          allowFontScaling={false}
          style={[styles.drawerContent]}
          label={Strings["help"] ? Strings["help"] : "Help"}
          icon={() => (
            <HelpIcon
              width={isTablet ? hp(3.5) : hp(2)}
              height={isTablet ? hp(3.5) : hp(2)}
            />
          )}
          labelStyle={[
            styles.drawerLabel,
            { marginLeft: isTablet ? 0 : -wp(5) },
          ]}
          onPress={async () => {
            const activeRoute =
              props.state && getActiveRouteState(props?.state);
            if (activeRoute == "Help") {
              await props.navigation.getParent("Drawer").closeDrawer();
            } else {
              if (confirmationAlertInfo != undefined && !!internet) {
                isCheckNavData("Help", props);
              } else {
                props.navigation.navigate("Help");
              }
            }
            // props.navigation.navigate("Help");
          }}
        />

        <TouchableOpacity
          disabled={!internet}
          style={[
            styles.drawerCustomContainer,
            {
              paddingLeft: isTablet ? wp(2.5) : wp(4.5),
              marginTop: hp(1.5),
            },
          ]}
          onPress={() => {
            isCheckNavData("Account", props);
          }}
        >
          <View style={[styles.accountContainer]}>
            {internet ? (
              <AccountIcon
                width={isTablet ? hp(3.5) : hp(2)}
                height={isTablet ? hp(3.5) : hp(2)}
              />
            ) : (
              <Image
                source={icons.AccountICon}
                style={{
                  height: isTablet ? hp(3.5) : hp(2),
                  width: isTablet ? hp(3.5) : hp(2),
                  tintColor: "#53565A",
                  alignItems: "center",
                }}
              />
            )}

            <CustomText
              style={[
                styles.drawerCustomText,
                !internet && {
                  color: "#53565A",
                },
                {
                  width: "100%",
                },
              ]}
            >
              {Strings["ime.account"] ? Strings["ime.account"] : "Account"}
            </CustomText>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            {
              alignSelf: "flex-end",
              padding: SIZES.base,
              borderWidth: 1,
              borderColor: COLORS.blue,
              alignItems: "center",
              marginRight: wp(3),
              width: "27.5%",
            },
            !internet && {
              borderColor: "#53565A",
              backgroundColor: "#f7f7f9",
            },
          ]}
          onPress={() => setlogout()}
          disabled={!internet}
        >
          <CustomText
            style={[
              styles.logoutTextStyle,
              !internet && {
                color: "#53565A",
              },
            ]}
          >
            {Strings["logout"] ? Strings["logout"] : "Logout"}
          </CustomText>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <Drawer.Navigator
      id="Drawer"
      drawerContent={(props) => <CustomDrawer {...props} />}
      screenOptions={{
        swipeEnabled: false,
        drawerPosition: "left",
        headerShown: false,
        drawerType: "front",
        drawerStyle: {
          width: SIZES.width * 0.8,
          backgroundColor: COLORS.white,
        },
      }}
    >
      <Drawer.Screen name="Dashboard" component={Dashboard} />
      <Drawer.Screen name="Consume" component={Consume} />
      <Drawer.Screen name="Replenish" component={Replenish} />
      <Drawer.Screen name="ReplenishOffline" component={ReplenishOffline} />
      <Drawer.Screen name="Receive" component={Receive} />
      <Drawer.Screen name="StockCorrection" component={StockCorrection} />
      <Drawer.Screen name="PiCount" component={PiCount} />
      <Drawer.Screen name="Approvals" component={Approvals} />
      <Drawer.Screen name="StockTransfer" component={StockTransfer} />
      <Drawer.Screen
        name="OrderRequestApproval"
        component={OrderRequestApproval}
      />
      <Drawer.Screen name="PICountLists" component={PICountLists} />
    </Drawer.Navigator>
  );
};

export default DrawerNavigator;
