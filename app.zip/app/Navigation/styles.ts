import { logout } from "./../Redux/Action/loginAction";
import { StyleSheet } from "react-native";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../Utils/theme";
import { isDeviceTablet } from "../Utils/globalFunction";
const isTablet = isDeviceTablet();

export default StyleSheet.create({
  splash: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  selectedMain: {
    height: "100%",
    maxWidth: 160,
    width: wp(24),
    justifyContent: "space-evenly",
    alignItems: "center",
  },
  barStyle: {
    backgroundColor: COLORS.white,
    width: wp(100),
    height: hp(9.5),
    shadowColor: COLORS.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    maxHeight: 200,
    borderTopEndRadius: hp(2),
    borderTopLeftRadius: hp(2),
  },
  image: {
    alignSelf: "center",
    height: hp(3),
    width: wp(24),
    resizeMode: "contain",
  },
  barTitle: {
    fontSize: FONTS.h1_5,
    color: COLORS.white,
    fontFamily: FONTFAMILY.averta_regular,
  },

  // Drawer
  drawerLabel: {
    fontSize: FONTS.h2_3,
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_semibold,
    fontWeight: "500",
  },
  drawerIcon: {
    width: hp(2),
    height: hp(2),
  },
  drawerContent: {
    marginVertical: -hp(0.05),
  },
  drawerCustomContainer: {
    flexDirection: "row",
    alignItems: "center",
    // justifyContent: "space-between",
    paddingRight: wp(4.5),
  },
  drawerCustomText: {
    fontSize: FONTS.h2_3,
    color: COLORS.scienceBlue,
    fontWeight: "500",
    marginLeft: wp(3.5),
    fontFamily: FONTFAMILY.averta_semibold,
    width: "70%",

  },
  approvalContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    marginVertical: hp(1.5),
    width: "85%",
  },
  approvalCount: {
    borderColor: COLORS.scienceBlue,
    borderWidth: 1.5,
    borderRadius: wp(3.5),
    alignItems: "center",
    justifyContent: "center",
    height: hp(2.75),
    width: hp(3.5),
  },
  accountContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "67.5%",
  },
  logoutTextStyle: {
    fontSize: FONTS.h2,
    color: COLORS.scienceBlue,
    fontWeight: "600",
  },
  logoutContainer: {
    flex: 1,
    width: "27.5%",
    padding: SIZES.base,
    borderWidth: 1,
    borderColor: COLORS.blue,
    alignItems: "center",
  },
  offlineIcon:{
    height: isTablet ? hp(3.5) : hp(2),
    width: isTablet ? hp(3.5) : hp(2),
    tintColor: "#53565A",
    alignItems: "center",
  }
});
