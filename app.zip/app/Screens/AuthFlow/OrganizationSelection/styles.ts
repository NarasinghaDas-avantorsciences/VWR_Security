import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";
export default StyleSheet.create({
  container: {
    flex: 1,
  },
  linear: {
    flex: 1,
    justifyContent: "center",
    paddingVertical: hp(5),
    paddingHorizontal: wp(5),
  },
  subContainer: {
    backgroundColor: COLORS.white,
    borderRadius: wp(2),
    paddingHorizontal: wp(4),
    shadowColor: "rgba(0,0,0,0.15)",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 1,
    shadowRadius: 14,
  },
  logoStyle: {
    resizeMode: "contain",
    width: wp(82),
    height: hp(6),
    marginVertical: hp(1),
  },
  resetText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    textAlign: 'center'
  },
  resetButton: {
    alignSelf: "center",
    width: wp(40)
  },
  loginButton: {
    height: hp(6.5),
    width: wp(40)
  },
  loginButtonText: {
    fontSize: FONTS.h1_9,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: hp(2),
    alignItems: 'center'
  },
  mainStyle: {
    width: wp(83),
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginVertical: wp(3),
  },
  inputStyle: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h1_9,
    color: COLORS.gray,
    left: -wp(2),
    marginRight: wp(4),
    fontFamily: FONTFAMILY.averta_regular,
  },
  inputMainStyle: {
    height: hp(5),
    top: 0,
    borderColor: COLORS.abbey,
  },
  bottomSheetContainer: {
    borderTopLeftRadius: hp(1),
    borderTopRightRadius: hp(1),
  },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginLeft: wp(30),
    alignItems: "center",
  },
  headerText: {
    fontSize: FONTS.h2_3,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.doveGray,
    textAlign: "center",
  },
  closeBtn: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.blue,
    paddingLeft: wp(6),
    fontFamily: FONTFAMILY.averta_regular,
  },
  searchMain: {
    width: "90%",
    alignSelf: "center",
  },
  listMain: {
    width: "90%",
    alignSelf: "center",
  },
  itemMain: {
    borderBottomWidth: 0.4,
    borderBottomColor: COLORS.alto,
    paddingVertical: hp(1.3),
    flexDirection: "row",
  },
  itemTitle: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_8,
    color: COLORS.abbey,
  },
});
