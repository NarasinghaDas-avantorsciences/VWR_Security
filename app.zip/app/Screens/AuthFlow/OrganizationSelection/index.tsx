import React, { useRef, useState } from "react";
import { View, TouchableOpacity, ScrollView, StatusBar } from "react-native";
import Text from '../../../Components/CustomText'
//@ts-ignore
import LinearGradient from "react-native-linear-gradient";
import { ArrowDown, LogoHorizontal, TickIcon } from "../../../Utils/images";
import { hp, wp } from "../../../Utils/globalFunction";
import CheckButton from "../../../Components/Auth/CheckButton";
import EmptyDivider from "../../../Components/Common/EmptyDivider";
import FlatButton from "../../../Components/Common/FlatButton";
import styles from "./styles";
import { setLogin } from "../../../Redux/Action/loginAction";
import { useDispatch, useSelector } from "react-redux";
import { BottomSheetComponent, Loader, SearchBar, TextInputComponent } from "../../../Components";
import { emailValadation } from "../../../Utils/validation";
import { SafeAreaView } from "react-native-safe-area-context";
import Toast from "react-native-toast-message";
import * as storage from "../../../Service/AsyncStoreConfig";
import { FONTFAMILY } from "../../../Utils/theme";

const Login = () => {
  const [isRemember, setIsRemember] = useState(false);
  const { loader } = useSelector((state: any) => state.loginReducer);
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const refRBSheet_list: any = useRef();
  const [sel_str, setSel_str] = useState('')
  const [selected, setSelected] = useState<any>(null);


  const login = () => {

  };
  const successCallBack = () => {

  };

  const mockData = {
    stock_room: "Safety Supplies - 95654 - Master Regular Orders",
    org_name: "Avantor Sciences - Bridgewater, NJ - Special Projects",
    footerLables: ["Notifications modal", "Notification demo"],
  };

  const stockroom = [
    {
      title: "Consignment",
    },
    {
      title: "EHS Stokeroom",
    },
    {
      title: "Safety Supplies - 95654 - Master Regular Orders",
    },
    {
      title: "Master Regular",
    },
    {
      title: "Order according to inventory count PoU",
    },
    {
      title: "PoU Regular",
    },
    {
      title: "Master Regular Copy",
    },
    {
      title: "Metrics Reporting",
    },
  ];
  const organization = [
    {
      title: "Avantor Sciences - Bridgewater, NJ - Special Projects",
    },
    {
      title: "Avantor Sciences - San Diego, CA 64258 - Regular",
    },
    {
      title: "Avantor Sciences - Charlotte, NC - 59844",
    }
  ];

  const getTitle = () => {
    if (sel_str == "org") {
      return strings["organization"];
    } else if (sel_str == "stockroom") {
      return strings["stockroom"];
    }
  };

  const onSelectCat = (str: string) => {
    setSel_str(str);
    refRBSheet_list.current.open();
  };

  const __renderItem = (item: any, index: number) => (
    <TouchableOpacity
      onPress={() => {
        setSelected(index);
      }}
      key={index}
      style={[
        styles.itemMain,
        selected === index && {
          justifyContent: "space-between",
          alignItems: "center",
        },
      ]}
    >
      <Text
        style={[
          styles.itemTitle,
          { width: "85%" },
          selected === index && {
            color: "#53565A",
            fontFamily: FONTFAMILY.averta_semibold,
          },
        ]}
      >
        {item?.title}
      </Text>
      {selected === index && (
        <TickIcon
          height={hp(2)}
          width={hp(2)}
          fill={COLORS.scienceBlue}
          style={{
            marginRight: wp(2),
          }}
        />
      )}
    </TouchableOpacity>
  );


  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={["#00D649", "#2EC4FF"]}
        style={styles.linear}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
      >
        <View style={styles.subContainer}>
          <LogoHorizontal
            style={styles.logoStyle}
            height={hp(6)}
            width={wp(82)}
          />
          <TextInputComponent
            title={strings["vcm.report.pi.organization"]}
            onPressRightIcon={() => onSelectCat("org")}
            onPressLeftIcon={() => console.log("left icon pressed")}
            RightIcon={ArrowDown}
            value={mockData.org_name}
            editable={false}
            main={styles.mainStyle}
            inputStyle={styles.inputStyle}
            inputMain={styles.inputMainStyle}
          />

          <TextInputComponent
            title={strings["stockroom"]}
            onPressRightIcon={() => onSelectCat("stockroom")}
            onPressLeftIcon={() => console.log("left icon pressed")}
            RightIcon={ArrowDown}
            value={mockData.stock_room}
            editable={false}
            main={styles.mainStyle}
            inputStyle={styles.inputStyle}
            inputMain={styles.inputMainStyle}
          />

          <EmptyDivider height={hp(1)} />
          <CheckButton
            label= {strings["ime.scanner.remember.me.selection"] ?? "Remember selection"} 
            value={isRemember}
            onChange={setIsRemember}
          />

          <View style={styles.buttonContainer}>
            <TouchableOpacity style={styles.resetButton}>
              <Text style={styles.resetText}>{strings["cancel"]}</Text>
            </TouchableOpacity>
            <FlatButton
              text={strings["ime.continue"]}
              onPress={() => login()}
              disabled={false}
              container={styles.loginButton}
              textStyle={styles.loginButtonText}
            />
          </View>

        </View>

        <BottomSheetComponent
          customStyles={{ container: styles.bottomSheetContainer }}
          bottomSheetRef={refRBSheet_list}
          height={hp(80)}>
          <View style={styles.headerContainer}>
            <Text style={styles.headerText}>{getTitle()}</Text>
            <Text
              style={styles.closeBtn}
              onPress={() => refRBSheet_list.current.close()}
            >
              {strings["close"]}
            </Text>
          </View>
          <SearchBar
            search={""}
            onSearch={undefined}
            containerStyle={styles.searchMain}
            placeholder="Search"
          />
          <ScrollView style={styles.listMain}>
            {sel_str == 'stockroom' && stockroom?.map((item, index) => __renderItem(item, index))}
            {sel_str == 'org' && organization?.map((item, index) => __renderItem(item, index))}
          </ScrollView>
        </BottomSheetComponent>

      </LinearGradient>
      <Loader show={loader} />
    </SafeAreaView>
  );
};

export default Login;
