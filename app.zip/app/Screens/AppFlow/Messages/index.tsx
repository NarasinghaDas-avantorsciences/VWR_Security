import React, { useEffect, useState } from "react";
import { Alert, Linking, TouchableOpacity, View, Platform } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { WebView } from "react-native-webview";
import Toast from "react-native-toast-message";
import {
  putMessagesRead,
  putNotificationRead,
  putNewsRead,
  downloadConsumeReceipt,
  getNewsCount,
  getNotificationCount,
} from "../../../Redux/Action/communicationActions";
import styles from "./styles";
import { Header, Loader } from "../../../Components";
import { COLORS, FONTS, SIZES } from "../../../Utils/theme";
import CustomText from "../../../Components/CustomText";

import ReactNativeBlobUtil from "react-native-blob-util";
import { htmlContent } from "../../../Constants/HtmlContent";

const Messages = (props: any) => {
  const { item, headerTitle } = props.route.params;
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const [isLoading, setIsLoading] = useState(false);
  useEffect(() => {
    setIsLoading(false);
    if (item?.status != 2) {
      markNewsAsRead();
    }
  }, []);

  const onPressSaveRecipt = async (base64Data: string) => {
    try {
      let fPath = Platform.select({
        ios: ReactNativeBlobUtil.fs.dirs.DocumentDir,
        android: ReactNativeBlobUtil.fs.dirs.DownloadDir,
      });

      fPath = `${fPath}/pdfFileName.pdf`;
      if (Platform.OS === "ios") {
        await ReactNativeBlobUtil.fs.writeFile(fPath, base64Data, "base64");
      } else {
        await ReactNativeBlobUtil.fs.writeFile(fPath, base64Data, "base64");
      }

      if (Platform.OS === "android") {
        setTimeout(() => {
          ReactNativeBlobUtil.android.actionViewIntent(
            fPath ?? "",
            "application/pdf"
          );
        }, 200);
      } else {
        ReactNativeBlobUtil.ios.previewDocument(fPath ?? "");
      }
    } catch (error) {
      console.log("error", error);
    }
  };

  const markNewsAsRead = async () => {
    //  let = (headerTitle == Strings["ime.news.and.updates"]) ?
    switch (headerTitle) {
      case Strings["ime.news.and.updates"]:
        await dispatch(
          putNewsRead(item?.id, (val: boolean) => {
            if (val) {
              item.status = 2;
              item.markedAsRead = true;
              dispatch(getNewsCount());
            }
          })
        );
      case Strings["ime.scanner.Get.Notified"]:
        await dispatch(
          putNotificationRead(item?.id, (val: boolean) => {
            if (val) {
              item.status = 2;
              item.markedAsRead = true;
              dispatch(getNotificationCount());
            }
          })
        );
      await dispatch(getNotificationCount());
      case Strings["ime.messages"]:
        await dispatch(
          putMessagesRead(item?.id, (val: boolean) => {
            if (val) {
              item.status = 2;
              item.markedAsRead = true;
              dispatch(getMessagesCount());
            }
          })
        );
      default:
        break;
    }
  };

  const getHtmlData = (itemBody: string) => {
    // Your additional HTML content to be inserted
    let htmlData = htmlContent;
    const additionalContent = itemBody;

    // Find the div with id "Text5" and insert the additional content
    const modifiedHtml = htmlData.replace(
      '<div id="Text5" class="mktoText" mktoname="Content text"></div>',
      `<div id="Text5" class="mktoText" mktoname="Content text">${additionalContent}</div>`
    );
    return modifiedHtml;
  };

  const source = {
    html: item?.body?.includes("html") ? item?.body : getHtmlData(item?.body),
  };
  const callDownloadReceiptApi = (transID: string) => {
    if (transID.length > 0) {
      setIsLoading(true);
      dispatch(
        downloadConsumeReceipt(
          transID,
          async (base64string: string) => {
            if (base64string.length > 0) {
              await onPressSaveRecipt(base64string);
            } else {
              Toast.show({
                type: "alertToast",
                text1: Strings["ime.attention"],
                text2: "Error occured while fetching the pdf",
                position: "bottom",
                bottomOffset: SIZES.padding * 2,
              });
            }
            setIsLoading(false);
          },
          (error: any) => {
            console.log("base64string error", JSON.stringify(error?.response));
            setIsLoading(false);
            Toast.show({
              type: "alertToast",
              text1: Strings["ime.attention"],
              text2:
                error?.error_description ??
                "Error occured while fetching the pdf",
              position: "bottom",
              bottomOffset: SIZES.padding * 2,
            });
          }
        )
      );
    }
  };

  return (
    <View style={styles.container}>
      <Header
        title={headerTitle}
        container={{ backgroundColor: COLORS.white }}
        onLeftIconPress={() => null}
        onRightIconPress={() => props.navigation.goBack()}
        statusBar={true}
        statusBarColor={"white"}
        iconLeft={false}
        iconRight={true}
        RightIcon={() => (
          <CustomText
            style={{
              fontSize: FONTS.h2,
              color: COLORS.scienceBlue,
              fontWeight: "500",
            }}
          >
            {Strings["close"]}
          </CustomText>
        )}
      />
      {item?.body ? (
        <WebView
          originWhitelist={["*"]}
          source={source}
          automaticallyAdjustContentInsets={false}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          decelerationRate="normal"
          startInLoadingState={true}
          scalesPageToFit={true}
          mixedContentMode="always"
          onShouldStartLoadWithRequest={(request) => {
            if (Platform.OS === "android") {
              let transactionId = "";
              let splitArray = item?.body.split(".htm?"); //.htm?
              if (splitArray.length > 1) {
                const hrefArray = splitArray[1].split(">");
                splitArray = hrefArray[0].split("&");
                //const hrefString = hrefArray[0]
                for (var i = 0; i < splitArray.length; i++) {
                  if (splitArray[i].includes("transactionId=")) {
                    transactionId = splitArray[i].replace("transactionId=", "");
                  }
                }
                request?.url !== "about:blank#blocked"
                  ? Linking.openURL(request?.url)
                  : transactionId.length > 0 &&
                  callDownloadReceiptApi(transactionId);
                return false;
              } else {
                return true;
              }
            } else {
              if (request.url != "about:blank") {
                //transactionId=293&orgId=198334
                let transactionId = "";
                let splitArray: string[] = request.url.split(".htm?");
                if (splitArray.length > 1) {
                  splitArray = splitArray[1].split("&");

                  for (var i = 0; i < splitArray.length; i++) {
                    if (splitArray[i].includes("transactionId=")) {
                      transactionId = splitArray[i].replace(
                        "transactionId=",
                        ""
                      );
                    }
                  }
                }
                if (transactionId.length > 0) {
                  callDownloadReceiptApi(transactionId);
                  return false;
                } else if (request?.url !== "about:blank#blocked") {
                  Linking.openURL(request?.url)
                  return false;
                }
                return true;

              } else return true;
            }
          }}
          onError={(syntheticEvent) => {
            const { nativeEvent } = syntheticEvent;
            console.log("WebView error: ", nativeEvent);
          }}
          onLoadEnd={(event) => {
            setTimeout(() => {
              console.log("onLoadEnd");
              setIsLoading(false);
            }, 100);
          }}
          onLoadStart={(event) => {
            setIsLoading(true);
          }}
          overScrollMode={"never"}
        />
      ) : (
        <View style={{ marginHorizontal: SIZES.padding }}>
          <CustomText style={{ ...FONTS.title, color: COLORS.scienceBlue }}>
            {item.subject}
          </CustomText>
          <CustomText
            style={{
              ...FONTS.body,
              color: COLORS.black,
              marginVertical: SIZES.radius,
            }}
          >
            {item.description}
          </CustomText>
        </View>
      )}
      {/* Loader */}
      <Loader show={isLoading} />
    </View>
  );
};

export default Messages;
function getMessagesCount(): any {
  throw new Error("Function not implemented.");
}
