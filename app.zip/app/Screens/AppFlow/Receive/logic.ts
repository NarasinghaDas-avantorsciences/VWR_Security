const fetchReceiveAllList = async (
  dispatch: any,
  receiveAllOrderList: any,
  offset: number
) => {
  await dispatch(
    receiveAllOrderList(offset)
  );
};

const fetchReceiveReadyList = async (
  dispatch: any,
  receiveReadyOrderList: any,
  offset: number
) => {
  await dispatch(
    receiveReadyOrderList(offset)
  );
};

const fetchReceivePartialList = async (
  dispatch: any,
  receiveReadyOrderList: any,
  offset: number
) => {
  await dispatch(
    receiveReadyOrderList(offset)
  );
};

const fetchReceivePendingList = async (
  dispatch: any,
  receiveReadyOrderList: any,
  offset: number
) => {
  await dispatch(
    receiveReadyOrderList(offset)
  );
};

export {
  fetchReceiveAllList,
  fetchReceiveReadyList,
  fetchReceivePartialList,
  fetchReceivePendingList,
};
