import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  animatedSearchContainer: {
    // width: "90%",
    marginLeft: wp(1),
  },
  tabContainer: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-around",
    borderBottomColor: COLORS.gray3,
  },
  tabContentContainer: {
    flexDirection: "row",
    borderBottomWidth: 2,
    paddingTop: hp(3),
    paddingBottom: hp(0.5),
    borderBottomColor: COLORS.white,
    paddingHorizontal: wp(1.5),
  },
  tabTitleText: {
    textTransform: "capitalize",
    paddingTop: SIZES.width <= 360 ? 5 : 0,
    paddingBottom: -2,
    fontSize: hp(1.7),
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    paddingHorizontal: wp(0.3),
  },
  emptyContainer: { alignItems: "center", justifyContent: "center" },
  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },
  unSelectedText: {
    color: COLORS.gray,
    fontFamily: FONTFAMILY.averta_regular,
    textTransform: "capitalize",
    paddingTop: SIZES.width <= 360 ? 5 : 0,
    paddingBottom: -2,
    fontSize: hp(1.7),
    paddingHorizontal: wp(0.3),
  },
  flatListContainer: { flexGrow: 1 },
  flatListContent: { paddingBottom: hp(2) },
  searchBarContainerStyle: { paddingHorizontal: wp(3) },
});
