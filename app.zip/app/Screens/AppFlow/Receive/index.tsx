import React, { useCallback, useEffect, useRef, useState } from "react";
import { View, FlatList, Pressable, Keyboard, BackHandler } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import Text from "../../../Components/CustomText";
import {
  Header,
  Subheader,
  SearchBar,
  OrderListItem,
  Loader,
  ScannerButton,
  AnimatedSearch,
} from "../../../Components";
import { COLORS } from "../../../Utils/theme";
import styles from "./styles";
import { useFocusEffect } from "@react-navigation/native";
import {
  fetchReceiveAllList,
  fetchReceivePartialList,
  fetchReceivePendingList,
  fetchReceiveReadyList,
} from "./logic";
import {
  clearReceiveSearch,
  getReceiveData,
  getReceiveOrderDetails,
  receiveAllOrderList,
  receivePartialOrderList,
  receivePendingOrderList,
  receiveReadyOrderList,
  setLoader,
} from "../../../Redux/Action/receiveAction";
import { useDebounceHook } from "../../../Hooks";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import ConfirmationAlert from "../../../Components/ConfirmationPopup";
import * as storage from "../../../Service/AsyncStoreConfig";
import { wp } from "../../../Utils/globalFunction";
import TabButton from "../../../Components/TabButton";

const Receive = (props: any) => {
  const dispatch = useDispatch<any>();
  const [search, setSearch] = useState("");
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const {
    isLoading,
    partialReceive,
    readyToReceive,
    pendingDelivery,
    searchListCount,
    allOrderList,
    readyOrderList,
    partialOrderList,
    pendingOrderList,
    receiveDataList,
  } = useSelector((state: any) => state.receiveReducer);
  const [selectedIndex, setSelectedIndex] = useState(1);
  const [allOffset, setAllOffset] = useState(0);
  const [readyOffset, setReadyOffset] = useState(0);
  const [partialOffset, setPartialOffset] = useState(0);
  const [pendingOffset, setPendingOffset] = useState(0);
  const [offsetValue, setOffsetValue] = useState(0);
  const { confirmationAlertInfo } = useSelector(
    (state: any) => state.userReducer
  );
  const debouncedSearchTerm = useDebounceHook(search, 800);
  const scrollRef = useRef<any>();
  const receiveTitle: any = {
    all: strings["all"],
    ready: strings["ready"] ? strings["ready"] : "Ready",
    partial: strings["store.availability.status.partial"],
    pending: strings["scanner.pending"]
      ? strings["scanner.pending"]
      : "Pending",
  };

  useFocusEffect(
    useCallback(() => {
      initialCall();
      props.route.params?.fromScreen == "Dashboard" && setSelectedIndex(1);
      // fetchReceiveAllList(dispatch, receiveAllOrderList, allOffset);
      dispatch(setIsShowConfirmationAlert({}));
    }, [])
  );
  useEffect(() => {
    if (debouncedSearchTerm.length > 0) {
      dispatch(clearReceiveSearch());
      dispatch(getReceiveData(offsetValue, selectedIndex, debouncedSearchTerm));
    }
  }, [debouncedSearchTerm]);

  useEffect(() => {
    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );
    return () => backHandler.remove();
  }, []);
  const backAction = () => {
    props.navigation.navigate("Dashboard");
    return true;
  };

  useFocusEffect(
    useCallback(() => {
      setSearch("");
      setOffsetValue(0);
    }, [selectedIndex])
  );

  const tabs = [
    {
      name: receiveTitle.all,
      id: 1,
      count: readyToReceive + partialReceive + pendingDelivery,
    },
    {
      name: receiveTitle.ready,
      id: 2,
      count: readyToReceive,
    },
    {
      name: receiveTitle.partial,
      id: 3,
      count: partialReceive,
    },
    {
      name: receiveTitle.pending,
      id: 4,
      count: pendingDelivery,
    },
  ];

  const initialCall = () => {
    dispatch(setLoader(true));
    fetchReceiveAllList(dispatch, receiveAllOrderList, allOffset);
    fetchReceiveReadyList(dispatch, receiveReadyOrderList, readyOffset);
    fetchReceivePartialList(dispatch, receivePartialOrderList, partialOffset);
    fetchReceivePendingList(dispatch, receivePendingOrderList, pendingOffset);
  };

  const getListData = (id: number) => {
    const defaultKey = 1;
    const listMap: any = {
      1: fetchReceiveAllList(dispatch, receiveAllOrderList, allOffset),
      2: fetchReceiveReadyList(dispatch, receiveReadyOrderList, readyOffset),
      3: fetchReceivePartialList(
        dispatch,
        receivePartialOrderList,
        partialOffset
      ),
      4: fetchReceivePendingList(
        dispatch,
        receivePendingOrderList,
        pendingOffset
      ),
    };
    return listMap[id] ?? listMap[defaultKey];
  };

  const getTabs = () => {
    return (
      <View
        style={styles.tabContainer}
        accessible={true}
        accessibilityLabel="receive-tabs"
      >
        {/* <TabButton
          options={tabs}
          onPress={async (v: any) => {
            console.error({ v });
            getListData(v.id);

            setSearch("");
            await dispatch(clearReceiveSearch());
            setSelectedIndex(v.id);
            Keyboard.dismiss();
          }}
        /> */}
        {tabs.map((v, i) => {
          return (
            <Pressable
              accessible={true}
              accessibilityLabel={`${v.name}-receive-tab-btn`}
              key={i}
              onPress={async () => {
                setSearch("");
                await dispatch(clearReceiveSearch());
                // getListData(v.id);
                setSelectedIndex(v.id);
                Keyboard.dismiss();
                scrollRef.current.scrollToOffset({ animated: true, offset: 0 });
              }}
              style={[
                styles.tabContentContainer,
                {
                  borderBottomColor:
                    selectedIndex == v.id ? COLORS.scienceBlue : COLORS.white,
                },
              ]}
            >
              <Text
                accessible={true}
                accessibilityLabel={`${v.name}-receive-tab-count`}
                style={
                  selectedIndex == v.id
                    ? styles.tabTitleText
                    : styles.unSelectedText
                }
              >
                {v.count}
              </Text>
              <Text
                accessible={true}
                accessibilityLabel={`${v.name}-receive-tab-title`}
                style={
                  selectedIndex == v.id
                    ? styles.tabTitleText
                    : styles.unSelectedText
                }
              >
                {v.name}
              </Text>
            </Pressable>
          );
        })}
      </View>
    );
  };

  const renderOrderListItem = ({ item, index }: any) => {
    return (
      <OrderListItem
        key={`${item?.id}`}
        item={item}
        color={
          item?.uiStatus == "GREEN"
            ? "green"
            : item?.uiStatus == "YELLOW"
            ? "yellow"
            : "red"
        }
        onPressListItem={async () => {
          await dispatch(
            getReceiveOrderDetails(item, () => {
              dispatch(setLoader(false));
              props.navigation.navigate("ReceiveDetails", {
                itemData: item,
                selectedTab: selectedIndex,
              });
            })
          );
        }}
      />
    );
  };

  const _renderComponent = (orderList: any, onEndReached: any) => {
    return orderList?.length ? (
      <FlatList
        accessible={true}
        accessibilityLabel="receive-listItems"
        style={styles.flatListContainer}
        contentContainerStyle={styles.flatListContent}
        data={orderList}
        keyExtractor={(item, index) => `${item?.id}-${index}`}
        renderItem={renderOrderListItem}
        onEndReachedThreshold={0.05}
        onEndReached={onEndReached}
        ref={scrollRef}
        onScroll={() => Keyboard.dismiss()}
      />
    ) : (
      <View />
    );
  };

  const renderNoDataFound = () => (
    <View
      style={styles.emptyContainer}
      accessible={true}
      accessibilityLabel="render-Nodata-container"
    >
      <Text
        style={styles.emptyText}
        accessible={true}
        accessibilityLabel="render-Nodata-text"
      >
        {strings["no.records.found"]}
      </Text>
    </View>
  );

  const getTabData = () => {
    switch (selectedIndex) {
      case 1:
        return (
          <>
            {allOrderList?.length > 0
              ? _renderComponent(allOrderList, async () => {
                  if (
                    (readyToReceive + partialReceive + pendingDelivery) / 10 >
                    allOffset
                  ) {
                    await fetchReceiveAllList(
                      dispatch,
                      receiveAllOrderList,
                      allOffset + 1
                    );
                    setAllOffset(allOffset + 1);
                  }
                })
              : allOrderList?.length == 0
              ? renderNoDataFound()
              : null}
          </>
        );
      case 2:
        return (
          <>
            {readyOrderList?.length > 0
              ? _renderComponent(readyOrderList, async () => {
                  if (readyToReceive / 10 > readyOffset + 1) {
                    await fetchReceiveReadyList(
                      dispatch,
                      receiveReadyOrderList,
                      readyOffset + 1
                    );
                    setReadyOffset(readyOffset + 1);
                  }
                })
              : readyOrderList?.length == 0
              ? renderNoDataFound()
              : null}
          </>
        );
      case 3:
        return (
          <>
            {partialOrderList?.length > 0
              ? _renderComponent(partialOrderList, async () => {
                  if (partialReceive / 10 > partialOffset + 1) {
                    await fetchReceivePartialList(
                      dispatch,
                      receivePartialOrderList,
                      partialOffset + 1
                    );
                    setPartialOffset(partialOffset + 1);
                  }
                })
              : partialOrderList?.length == 0
              ? renderNoDataFound()
              : null}
          </>
        );
      case 4:
        return (
          <>
            {pendingOrderList?.length > 0
              ? _renderComponent(pendingOrderList, async () => {
                  if (pendingDelivery / 10 > pendingOffset + 1) {
                    await fetchReceivePendingList(
                      dispatch,
                      receivePendingOrderList,
                      pendingOffset + 1
                    );
                    setPendingOffset(pendingOffset + 1);
                  }
                })
              : pendingOrderList == 0
              ? renderNoDataFound()
              : null}
          </>
        );
      default:
        break;
    }
  };

  const renderData = () => {
    return (
      <>
        {search.length > 0
          ? _renderComponent(receiveDataList, async () => {
              if (searchListCount / 10 > offsetValue + 1) {
                await dispatch(
                  getReceiveData(
                    offsetValue + 1,
                    selectedIndex,
                    debouncedSearchTerm
                  )
                );
                setOffsetValue(offsetValue + 1);
              }
            })
          : getTabData()}
      </>
    );
  };
  const resetProductData = (value) => {
    dispatch(setLoader(value));
  };

  return (
    <View
      style={styles.container}
      accessible={true}
      accessibilityLabel="receive-container"
    >
      <Header
        title={strings["receive"]}
        onLeftIconPress={() => {
          Keyboard.dismiss();
          props.navigation.getParent("Drawer").openDrawer();
        }}
        statusBar={true}
        statusBarColor={"blue"}
        iconLeft={true}
        iconRight={true}
      />

      <Subheader />
      {getTabs()}
      {/* <SearchBar
        idLabel="Receive"
        search={search}
        onSearch={(text: string) => {
          resetProductData(text != "");
          setSearch(text);
        }}
        placeholder={
          strings["Search orders and products"]
            ? strings["Search orders and products"]
            : "Search orders and products"
        }
        containerStyle={styles.searchBarContainerStyle}
        onBarcodeDetected={(barcode) => {
          resetProductData(!!barcode);
          setSearch(barcode);
        }}
        from="receive"
      /> */}
      <View style={styles.animatedSearchContainer}>
        <AnimatedSearch
          idLabel={"Receive"}
          search={search}
          onSearch={(text: string) => {
            resetProductData(!!text);
            setOffsetValue(0);
            setSearch(text);
          }}
          containerStyle={[styles.searchBarContainerStyle]}
          cancelBtnStyle={{ paddingRight: wp(5) }}
          placeholder={
            strings["ime.scanner.search.stockroom.products"] ??
            "Search stockroom products"
          }
          clearText={() => {
            setSearch("");
            // Keyboard.dismiss();
          }}
          onBarcodeDetected={(barcode) => {
            // resetProductData(!!barcode);
            setSearch(barcode.replace(/[\x00-\x1F\x7F]/g, ""));
          }}
          onCancel={() => {
            setSearch("");
            Keyboard.dismiss();
          }}
          from="receive"
        />
      </View>
      {renderData()}
      <ScannerButton
        onBarcodeDetected={(barcode) => {
          // resetProductData(!!barcode);
          setSearch(barcode);
        }}
      />
      <ConfirmationAlert
        onTapNo={() => {}}
        onTapYes={() =>
          dispatch(
            setIsShowConfirmationAlert({
              isShow: false,
              data: confirmationAlertInfo?.data,
            })
          )
        }
        onBack={() => console.warn("AJJJJJ")}
      />
      <Loader show={isLoading} />
    </View>
  );
};

export default Receive;
