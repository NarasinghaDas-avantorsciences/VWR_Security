import React from "react";
import { View, TouchableOpacity } from "react-native";
import styles from "./styles";
import { COLORS } from "../../../../Utils/theme";
import {
  ArrowLeft,
  TickGreen,
  Partial,
  Pending,
} from "../../../../Utils/images";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import Text from "../../../../Components/CustomText";
import { getCurrencySymbol } from "../../../../Utils/globalFunction";
const status = (screen: number, item: any) => {
  if (screen == 1) {
    return item?.consumeApprovalStatus;
  } else if (screen == 2) {
    return item?.orderApprovalStatus;
  } else {
    return item?.pouOrderApprovalStatus;
  }
};

const RenderItem = ({
  item,
  onChangeBtnPress,
  screen,
  disabled,
  showPrice,
  key,
  currency
}: any) => (
  <TouchableOpacity
    onPress={() => {
      onChangeBtnPress();
    }}
    style={styles.itemMain}
    disabled={disabled}
    accessible={true}
    accessibilityLabel={
      screen == 1
        ? "consume-request-approval-detail" + `${key}`
        : screen == 2
        ? "order-request-approval-detail" + `${key}`
        : "pou-order-request-approval-detail" + `${key}`
    }
  >
    <View style={styles.itemInner}>
      {item?.type == "partial" ? (
        <Partial height={hp(2.4)} width={hp(2.4)} />
      ) : item?.type == "out" ? (
        <Pending height={hp(2.4)} width={hp(2.4)} />
      ) : (
        <TickGreen height={hp(2.4)} width={hp(2.4)} />
      )}
      <View style={{ marginLeft: wp(2) }}>
        <Text style={styles.itemTitle}>
          {item?.firstName + " " + item?.lastName}
        </Text>
        <Text style={styles.itemText}>{item?.loginId}</Text>
        {showPrice && <Text style={styles.itemText}>{getCurrencySymbol(currency)+item?.totalPrice}</Text>}
        <Text style={styles.itemText}>
          {item?.itemsCount || item?.itemCount} items
        </Text>
        <Text style={styles.itemText}>{item?.createdOn}</Text>
        <View
          style={[
            styles.statusMain,
            item?.type == "partial" && {
              borderColor: COLORS.partialBorder,
              backgroundColor: COLORS.partial,
            },
            item?.type == "out" && {
              borderColor: COLORS.maroon,
              backgroundColor: COLORS.lightRed,
              width: wp(30),
            },
          ]}
        >
          <Text
            style={[
              styles.status,
              item?.type == "partial" && { color: COLORS.ginger },
              item?.type == "out" && { color: COLORS.darRed },
            ]}
          >
            {status(screen, item)}
            {/* Ready To Be Approved */}
          </Text>
        </View>
      </View>
    </View>
    <ArrowLeft height={hp(2.4)} width={hp(2.4)} style={styles.arrow} />
  </TouchableOpacity>
);

export default RenderItem;
