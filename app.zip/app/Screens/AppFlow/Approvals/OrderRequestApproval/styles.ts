import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  emptyContainer: { alignItems: 'center', justifyContent: 'center' },
  emptyText: { color: COLORS.lightGray, fontFamily: FONTFAMILY.averta_semibold, marginTop: wp(8) },

  itemMain: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: COLORS.alto,
    width: "95%",
    alignSelf: "flex-end",
    paddingVertical: hp(2),
  },
  itemInner: {
    flexDirection: "row",
  },
  itemTitle: {
    fontSize: FONTS.h1_8,
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    paddingBottom: hp(0.5),
  },
  itemText: {
    fontSize: FONTS.h1_6,
    color: COLORS.abbey,
    paddingVertical: hp(0.5),
  },
  statusMain: {
    backgroundColor: COLORS.aquaSpring,
    width: wp(40),
    paddingVertical: hp(0.6),
    borderRadius: hp(5),
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(33, 150, 83, 0.3)",
    paddingHorizontal: wp(2),
    marginTop: hp(0.6),
  },
  status: {
    color: COLORS.eucalyptus,
    fontSize: FONTS.h1_5,
  },
  arrow: {
    alignSelf: "center",
    margin: wp(4),
  },
  serachMain: {
    width: "90%",
    alignSelf: "center",
  },

  tabContainer: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-around",
    // paddingVertical: hp(2),
    borderBottomColor: COLORS.gray3,
    // borderBottomWidth: 2,
  },
  tabContentContainer: {
    flexDirection: "row",
    borderBottomWidth: 2,
    paddingTop: hp(3),
    paddingBottom: hp(0.5),
    borderBottomColor: COLORS.white,
    paddingHorizontal: wp(1.5),
  },
  tabTitleText: {
    textTransform: "capitalize",
    paddingTop: SIZES.width <= 360 ? 5 : 0,
    paddingBottom: -2,
    fontSize: hp(1.7),
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    paddingHorizontal: wp(0.3),
  },
  unSelectedText: {
    color: COLORS.gray,
    fontFamily: FONTFAMILY.averta_regular,
    textTransform: "capitalize",
    paddingTop: SIZES.width <= 360 ? 5 : 0,
    paddingBottom: -2,
    fontSize: hp(1.7),
    paddingHorizontal: wp(0.3),
  },
});
