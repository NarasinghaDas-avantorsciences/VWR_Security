import React, { useState, useRef, useEffect } from "react";
import {
  TouchableOpacity,
  View,
  ScrollView,
  Image,
  Platform,
  KeyboardAvoidingView,
  BackHandler,
  Keyboard,
} from "react-native";
import RNHTMLtoPDF from "react-native-html-to-pdf";
import ReactNativeBlobUtil from "react-native-blob-util";
import styles from "./styles";
import {
  Header,
  Subheader,
  Footer,
  ListItemCheckButton,
  ListItem,
  ProductDetails,
  Loader,
  ClearSelectionAlert,
  TextInputComponent,
  BottomSheetComponent,
  SearchBar,
} from "../../../../Components";
import {
  WhiteLeftArrow,
  DefaultProductImage,
  Locked,
  ArrowDown,
  TickIcon,
} from "../../../../Utils/images";
import ItemDetails from "./itemDetail";
import {
  COLORS,
  FONTFAMILY,
  FONTS,
  ICONSIZE,
  SIZES,
} from "../../../../Utils/theme";
import Status from "../../../../Constants/StatusValues/status";
import { Search } from "../../../../Utils/images";
import { useSelector, useDispatch } from "react-redux";
import {
  getProductDetails,
  setProductLoader,
} from "../../../../Redux/Action/searchAction";
import {
  getConsumeList,
  getCount,
  getOrderList,
  getPOUCount,
  getPOUList,
  onComsueApprove,
  onPouApprove,
} from "../../../../Redux/Action/approvalsAction";
import ReplenishCheckoutScreen from "../../ReplenishCheckoutScreen";
import Toast from "react-native-toast-message";
import { ToastComponent } from "../../../../Components/Toast";
import {
  hp,
  wp,
  isReceiveProductFreezed,
  getConsumePickTicket,
  getPouPickTicket,
} from "../../../../Utils/globalFunction";
import {
  addCostCenterDeptLogic,
  fillRequestQtyLogic,
  handleScreen1Logic,
  handleScreen2Logic,
  handleScreen3Logic,
} from "./logic";
import Text from "../../../../Components/CustomText";
import ConfirmationAlert from "../../../../Components/ConfirmationPopup";
import { setIsShowConfirmationAlert } from "../../../../Redux/Action/userAction";
import * as storage from "../../../../Service/AsyncStoreConfig";
import { getCurrencySymbol } from "../../../../Utils/globalFunction";
import { getUserPrice, resetPriceState } from "../../../../Redux/Action/replenishAction";

const ApprovalDetails = (props: any) => {
  const { data, selectedItem, screen } = props.route?.params;
  const dispatch = useDispatch<any>();
  const [confirmationModel, setConfirmationModal] = useState(false);
  const [pickedProducts, setPickedProducts] = useState<any>([]);
  const productBottomSheetRef = useRef<any>();
  const [selectedIndex, setSelectedIndex] = useState(1);
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { dateFormat, stockRoomDetail, confirmationAlertInfo } = useSelector(
    (state: any) => state.userReducer
  );
  const { productDetails, productDetailsLoading } = useSelector(
    (state: any) => state.searchReducer
  );
  const { loader } = useSelector((state: any) => state.approvalsReducer);
  const [visibleCheckout, setVisibleCheckout] = useState(false);
  const [batchQty, setBatchQty] = useState<any>([]);
  const [checkoutData, setCheckoutData] = useState<any>([]);
  const [comment, setComment] = useState<any>([]);
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const costCenterRef = useRef<any>();
  const [selectedCostCenter, setselectedCostCenter] = useState<any>([]);
  const [selectedDept, setSelectedDept] = useState<any>([]);
  const [selectType, setSelectType] = useState<any>(1);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [costCenterList, setCostCenterList] = useState<any>([]);
  const [deptList, setDeptList] = useState<any>([]);
  const [products, setProducts] = useState(
    screen == 1
      ? __filterProductsState(data?.consumeDetails)
      : screen == 3 && selectedItem?.pouOrderApprovalStatus == "Not Available"
      ? data?.orderApprovalLineDTO
      : __filterProductsState(data?.orderApprovalLineDTO)
  );
  // console.log("outt--", data?.orderApprovalLineDTO)
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  const [searckKey, setSearchKey] = useState("");
  const [totalPrice, setTotalPrice] = useState<any>(0);
  const { currency } = useSelector((state: any) => state.userReducer);

  const [single, setsingleProducts] = useState(
    screen == 1
      ? __filterProductsState(data?.consumeDetails)
      : screen == 3 && selectedItem?.pouOrderApprovalStatus == "Not Available"
      ? data?.orderApprovalLineDTO
      : __filterProductsState(data?.orderApprovalLineDTO)
  );

  function __filterProductsState(products: any) {
    if (screen == 2) {
      const data = products?.filter((item: any) =>
        checkStatus(item?.orderLineDTO?.approvalStatus)
      );
      return data;
    } else if (screen == 1) {
      const data = products?.filter(
        (item: any) =>
          item?.approvalStatus == "Open" ||
          item?.approvalStatus == "Partially Closed"
      );
      return data;
    } else if (screen == 3) {
      const data = products?.filter((item: any, index) => {
        let extractedNumber;
        extractedNumber =
          item?.orderLineDTO?.orderedQtyForDisplay?.match(/-?\d+/);
        const numberValue = extractedNumber ? parseInt(extractedNumber[0]) : 0;
        return (
          (item?.orderLineDTO?.approvalStatus == "Direct" ||
            item?.orderLineDTO?.approvalStatus == "Closed" ||
            item?.orderLineDTO?.approvalStatus == "Partially Closed") &&
          numberValue > 0
        );
      });
      return data;
    } else {
      return [];
    }
  }

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      () => {
        setKeyboardVisible(true); // or some other action
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      "keyboardDidHide",
      () => {
        setKeyboardVisible(false); // or some other action
      }
    );

    return () => {
      keyboardDidHideListener.remove();
      keyboardDidShowListener.remove();
    };
  }, []);

  const checkLength = () => {
    {
      if (screen == 2) {
        const data = products?.filter((item: any) =>
          checkStatus(item?.orderLineDTO?.approvalStatus)
        );
        return data?.length;
      } else if (screen == 1) {
        const data = products?.filter(
          (item: any) =>
            item?.approvalStatus == "Open" ||
            item?.approvalStatus == "Partially Closed"
        );
        return data?.length;
      } else if (screen == 3) {
        if (
          selectedItem?.consumeApprovalStatus == "out of stock" ||
          selectedItem?.pouOrderApprovalStatus == "Not Available"
        ) {
          return products?.length;
        } else {
          return products?.filter(
            (item: any) =>
              item?.orderLineDTO?.approvalStatus == "Direct" ||
              item?.orderLineDTO?.approvalStatus == "Closed" ||
              item?.orderLineDTO?.approvalStatus == "Partially Closed"
          ).length;
        }
      } else {
        return null;
      }
    }
  };

  const Tabs = [
    {
      name: Strings["ime.pending"],
      count: checkLength() || 0,
      id: 1,
    },
    {
      name: "Picked",
      count: pickedProducts?.length ? pickedProducts?.length : 0,
      id: 2,
    },
  ];

  const totalQty = (id: string) => {
    const used = batchQty.reduce(
      (accumulator: number, i: { [x: string]: any }) => {
        if (i?.id == id) {
          const total = accumulator + Number(i["qty"]);
          return total;
        } else {
          return accumulator;
        }
      },
      0
    );
    return used;
  };

  useEffect(() => {
    setTotalPrice(getPrice());
  }, [batchQty, pickedProducts, products]);

  const getPrice = () => {
    let selectedProducts = selectedIndex == 1 ? products : pickedProducts;
    selectedProducts = selectedProducts?.filter((item) => item?.isSelected);
    let allQtyPrice = 0;

    selectedProducts.forEach((selectedProduct) => {
      allQtyPrice =
        allQtyPrice +
        selectedProduct?.product?.purchasePrice *
          totalQty(selectedProduct?.product?.id);
    });
    return allQtyPrice;
  };

  // useEffect(() => {
  //   const backHandler = BackHandler.addEventListener(
  //     "hardwareBackPress",
  //     backAction
  //   );
  //   return () => backHandler.remove();
  // }, []);
  // const backAction = () => {
  //   props.navigation.goBack();
  //   return true;
  // };

  useEffect(() => {
    const backAction = async () => {
      let asyncData;
      await storage.getItem("ApprovalsCount").then((res) => {
        asyncData = res;
      });

      if (Number(asyncData) > 0) {
        dispatch(
          setIsShowConfirmationAlert({
            isShow: true,
            data: confirmationAlertInfo?.data,
          })
        );
      } else {
        props.navigation.goBack();
      }
      return true;
    };

    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );

    return () => backHandler.remove();
  }, []);

  useEffect(() => {
    if (screen != 1) {
      setDeptList(data?.departments);
      setCostCenterList(data?.costcenter);
    }
    toggleAllPendingProductSelection();
  }, []);
  useEffect(() => {
    addCostCenterDept();
    addIntialComments();
  }, []);
  const addIntialComments = () => {
    const cmnt = [];
    for (let i = 0; i < products?.length; i++) {
      const item = products[i];
      if (item?.orderLineDTO?.comments) {
        cmnt.push({
          comment: item?.orderLineDTO?.comments,
          id: item?.product.id,
          index: 0,
          itemIndex: i,
        });
      }
    }
    setComment([...comment, ...cmnt]);
  };

  const __renderCheck = () => (
    <TickIcon
      height={hp(2)}
      width={hp(2)}
      fill={COLORS.scienceBlue}
      style={{
        marginRight: wp(2),
      }}
    />
  );

  const addCostCenterDept = () => {
    const dataObj = addCostCenterDeptLogic(
      selectedIndex,
      products,
      pickedProducts,
      data,
      screen
    );
    setselectedCostCenter(dataObj.selectedCostCenter);
    setSelectedDept(dataObj?.selectedDept);
  };

  function filterComment(i, index, id) {
    const data = comment?.filter((item) => item?.index == i && item?.id == id);
    return data?.length ? data[0]?.comment : "";
  }

  const getBgAndBorderColor = (status: String) => {
    return status == Status.PARTIALLY_AVAILABLE
      ? {
          borderColor: COLORS.partialBorder,
          backgroundColor: COLORS.partial,
        }
      : status == Status.OUT_OF_STOCK && {
          borderColor: COLORS.maroon,
          backgroundColor: COLORS.lightRed,
          width: wp(30),
        };
  };

  const showToast = (text1: string, text2: string, bottom = false) => {
    Keyboard.dismiss();
    Toast.show({
      type: "alertToast",
      text1: text1,
      text2: text2,
      position:
        isKeyboardVisible && Platform.OS == "android" ? "bottom" : "bottom",
      bottomOffset: SIZES.padding * 2,
    });
  };

  const onPressPrintPickPicket = async (data: any) => {
    const pdfOptions = {
      html:
        screen == 1
          ? getConsumePickTicket(data, dateFormat)
          : getPouPickTicket(data, dateFormat),
      fileName: `file`,
      directory: "Documents",
    };
    const file = await RNHTMLtoPDF.convert(pdfOptions);
    if (file?.filePath) {
      if (Platform.OS === "android") {
        ReactNativeBlobUtil.android.actionViewIntent(
          file?.filePath,
          "application/pdf"
        );
      } else {
        ReactNativeBlobUtil.ios.previewDocument(file?.filePath);
      }
    }
  };

  const onApproveToast = (data: any) => {
    Toast.show({
      type: "alertApprovalsBottomToast",
      text1: Strings["request.approved"],
      text2: "The consumption request has been approved",
      props: {
        buttonTitle: Strings["ime.print.pick.ticket"],
        onPress: () => onPressPrintPickPicket(data),
      },
      position: "bottom",
    });
  };

  const HeaderItem = ({ name, email, date, status, count, total }) => {
    return (
      <View
        accessibilityLabel="approve-details-mainheaderview"
        style={styles.headerItemContainer}
      >
        <View>
          <Text
            accessibilityLabel="approve-details-headerItem-headerName"
            style={[styles.headerName]}
          >
            {name}
          </Text>
          <Text
            accessibilityLabel="approve-details-headerItem-headerMail"
            style={styles.headerMail}
          >
            {email}
          </Text>
          <Text
            accessibilityLabel="approve-details-headerItem-headerDate"
            style={styles.headerMail}
          >
            {date}
          </Text>
          <View
            accessibilityLabel="approve-details-view-status"
            style={[
              {
                ...styles.headerStatusContainer,
                ...getBgAndBorderColor(status),
              },

              status?.type == 2 && {
                borderColor: COLORS.partialBorder,
                backgroundColor: COLORS.partial,
                width: wp(50),
              },
            ]}
          >
            <Text
              accessibilityLabel="approve-details-headerItem-status"
              style={[
                { ...styles.headerStatus },
                status?.type == 2 && {
                  color: COLORS.ginger,
                },
              ]}
            >
              {status?.status}
            </Text>
          </View>
        </View>
        <View
          accessibilityLabel="approve-details-headerItem-ViewCount"
          style={styles.priceContainer}
        >
          <Text
            style={styles.headerCount}
            accessibilityLabel="approve-details-headerItem-headerCount"
          >
            {count} items
          </Text>
          {stockRoomDetail?.isApprovalIndividual && (
            <Text
              style={styles.headerTotal}
              accessibilityLabel="approve-details-headerItem-headerTotal"
            >
              {total}
            </Text>
          )}
        </View>
      </View>
    );
  };

  const itemSeparator = () => {
    return <View style={styles.separator} />;
  };

  const itemFooter = () => {
    return <View style={styles.itemFooter} />;
  };

  function filterQty(i, index, id) {
    const data = batchQty?.filter((item) => item?.index == i && item?.id == id);
    return data?.length ? data[0]?.qty : 0;
  }

  useEffect(() => {
    fillRequestQtyLogic(
      selectedIndex,
      products,
      pickedProducts,
      screen,
      stockRoomDetail,
      (res) => setBatchQty(res)
    );
  }, []);

  function status(item: any) {
    if (screen == 1) {
      if (item?.consumeApprovalStatus == "Ready To Be Approved") {
        return {
          status: item?.consumeApprovalStatus,
          type: 1,
        };
      } else if (item?.consumeApprovalStatus == "Partially Available") {
        return {
          status: item?.consumeApprovalStatus,
          type: 2,
        };
      }
    } else if (screen == 2) {
      if (item?.orderApprovalStatus == "Ready To Be Approved") {
        return {
          status: item?.orderApprovalStatus,
          type: 1,
        };
      } else if (item?.orderApprovalStatus == "Partially Approved") {
        return {
          status: item?.orderApprovalStatus,
          type: 2,
        };
      }
    } else {
      if (item?.pouOrderApprovalStatus == "Available") {
        return {
          status: item?.pouOrderApprovalStatus,
          type: 1,
        };
      } else if (item?.pouOrderApprovalStatus == "Partial Available") {
        return {
          status: item?.pouOrderApprovalStatus,
          type: 2,
        };
      }
    }
  }
  const __selectedCostCenter = (item) => {
    const data = selectedCostCenter?.filter(
      (i) => i?.productId == item?.product?.id
    );
    return data?.length ? data[0] : {};
  };

  const __selectedDept = (item) => {
    const data = selectedDept?.filter((i) => i?.productId == item?.product?.id);
    return data?.length ? data[0] : {};
  };
  const SelectCost = (item) => (
    <View>
      <TextInputComponent
        title={strings["cost.center"]}
        onPressRightIcon={() => {
          screen == 1 && setCostCenterList(item?.costCentersList);
          setSelectType(1);
          if (screen == 1) {
            item?.costCentersList?.length && costCenterRef.current.open();
          } else {
            costCenterRef.current.open();
          }

          setSelectedProduct(item?.product?.id);
        }}
        RightIcon={ArrowDown}
        value={
          __selectedCostCenter(item)?.costCenterName == "Select Cost Center"
            ? null
            : __selectedCostCenter(item)?.costCenterName
        }
        placeholder={strings["select.cost.center"] || "select.cost.center"}
        editable={false}
        main={[styles.costCenterInput]}
        inputStyle={styles.inputStyle}
        inputMain={styles.inputMain}
        required={stockRoomDetail?.isCostCenterMandatory}
        disabled={isOutOfStock()}
        disableRightIcon={isOutOfStock()}
      />
    </View>
  );

  const SelectDept = (item) => (
    <View>
      <TextInputComponent
        title={strings["department"]}
        onPressRightIcon={() => {
          // setDepartments(item?.departmentsList)
          setSelectType(2);
          screen == 1 && setDeptList(item?.departmentsList);
          setSelectedProduct(item?.product?.id);
          if (screen == 1) {
            item?.departmentsList?.length && costCenterRef.current.open();
          } else {
            costCenterRef.current.open();
          }
        }}
        RightIcon={ArrowDown}
        required={stockRoomDetail?.isDepartmentMandatory}
        value={
          __selectedDept(item)?.departmentName == "Select Department"
            ? null
            : __selectedDept(item)?.departmentName
        }
        placeholder={
          strings["ime.select.department"] || "ime.select.department"
        }
        editable={false}
        main={[styles.costCenterInput]}
        inputStyle={styles.inputStyle}
        inputMain={styles.inputMain}
        disabled={isOutOfStock()}
        disableRightIcon={isOutOfStock()}
      />
    </View>
  );

  const checkTick = (item: { skGuid: any }) => {
    let data;
    if (selectType == 1) {
      data = selectedCostCenter?.filter(
        (i: { productId: any; id: any }) =>
          i?.productId == selectedProduct &&
          (item?.skGuid == i?.id || item?.id == i?.id)
      );
    } else {
      data = selectedDept?.filter(
        (i: { productId: any; id: any }) =>
          i?.productId == selectedProduct &&
          (item?.skGuid == i?.id || item?.id == i?.id)
      );
    }
    return data?.length && data[0]?.id ? true : false;
  };
  const _renderItemList = (item: any, index: number) => {
    return (
      <>
        {index == 0 && (
          <TouchableOpacity
            accessible={true}
            accessibilityLabel="list-btn-item"
            onPress={() => {
              costCenterRef.current.close();
              if (selectType == 1) {
                const dataindex = selectedCostCenter.findIndex(
                  (i: any) => i?.productId == selectedProduct
                );
                let data = Object.assign([], selectedCostCenter);
                data[dataindex] = {
                  ...data[dataindex],
                  id: null,
                  costCenterName: "",
                };
                setselectedCostCenter([...data]);
              } else {
                const dataindex = selectedDept.findIndex(
                  (i: any) => i?.productId == selectedProduct
                );
                let data = Object.assign([], selectedDept);
                data[dataindex] = {
                  ...data[dataindex],
                  id: "",
                  departmentName: null,
                };
                setSelectedDept([...data]);
              }
            }}
            key={index}
            style={[styles.itemMain]}
          >
            <Text
              style={[
                {
                  fontSize: FONTS.h1_8,
                  color: COLORS.abbey,
                  fontFamily: FONTFAMILY.averta_regular,
                },
              ]}
              accessible={true}
              accessibilityLabel="name-list"
            >
              {selectType == 1
                ? strings["select.cost.center"]
                : strings["ime.select.department"]}
            </Text>
          </TouchableOpacity>
        )}

        <TouchableOpacity
          accessible={true}
          accessibilityLabel="list-btn-item"
          onPress={() => {
            costCenterRef.current.close();
            if (selectType == 1) {
              const dataindex = selectedCostCenter.findIndex(
                (i: any) => i?.productId == selectedProduct
              );
              let data = Object.assign([], selectedCostCenter);
              data[dataindex] = {
                ...data[dataindex],
                id: screen == 3 ? item?.id : item?.skGuid,
                costCenterName: item?.costCenterName,
              };
              setselectedCostCenter([...data]);
            } else {
              const dataindex = selectedDept.findIndex(
                (i: any) => i?.productId == selectedProduct
              );
              let data = Object.assign([], selectedDept);
              data[dataindex] = {
                ...data[dataindex],
                id: screen == 1 ? item?.skGuid : item?.id,
                departmentName: item?.departmentName,
              };
              setSelectedDept([...data]);
            }
          }}
          key={index}
          style={[styles.itemMain]}
        >
          <Text
            style={[
              {
                fontSize: FONTS.h1_8,
                color: COLORS.abbey,
                fontFamily: checkTick(item)
                  ? FONTFAMILY.averta_bold
                  : FONTFAMILY.averta_regular,
              },
            ]}
            accessible={true}
            accessibilityLabel="name-list"
          >
            {selectType == 1 ? item?.costCenterName : item?.departmentName}
          </Text>
          {checkTick(item) && __renderCheck()}
        </TouchableOpacity>
      </>
    );
  };

  const searchData = () => {
    const data = selectType == 1 ? costCenterList : deptList;
    if (searckKey?.length) {
      if (selectType == 1) {
        return data?.filter(
          (item) =>
            item?.costCenterName
              ?.toLowerCase()
              ?.includes(searckKey?.toLowerCase()) || item?.skGuid == searckKey
        );
      } else {
        return data?.filter(
          (item) =>
            item?.departmentName
              ?.toLowerCase()
              ?.includes(searckKey?.toLowerCase()) || item?.skGuid == searckKey
        );
      }
    } else {
      return data;
    }
  };
  const searchBarCode = (barcode: any) => {
    const data = selectType == 1 ? costCenterList : deptList;
    if (selectType == 1) {
      const dataArray = data?.filter(
        (item: { costCenterName: string; id: any; skGuid: number }) =>
          item?.costCenterName
            ?.toLowerCase()
            ?.includes(barcode?.toLowerCase()) ||
          item?.id == barcode ||
          item?.skGuid == barcode
      );
      dataArray?.length
        ? setSearchKey(dataArray[0]?.costCenterName)
        : setSearchKey(barcode);
    } else {
      const dataArray = data?.filter(
        (item: { departmentName: string; id: any; skGuid: number }) =>
          item?.departmentName
            ?.toLowerCase()
            ?.includes(barcode?.toLowerCase()) ||
          item?.id == barcode ||
          item?.skGuid == barcode
      );
      dataArray?.length
        ? setSearchKey(dataArray[0]?.departmentName)
        : setSearchKey(barcode);
    }
  };

  const getTabs = () => {
    const tabList = Tabs;
    return (
      <View style={styles.tabContainer}>
        {tabList.map((v, i) => {
          return (
            <TouchableOpacity
              key={`${i}`}
              activeOpacity={0.4}
              onPress={() => setSelectedIndex(v.id)}
              style={[
                styles.tabContentContainer,
                {
                  borderBottomColor:
                    selectedIndex == v.id ? COLORS.scienceBlue : COLORS.white,
                },
              ]}
              disabled={selectedIndex == 1 && pickedProducts?.length == 0}
            >
              <Text
                style={
                  selectedIndex == v.id
                    ? styles.tabTitleText
                    : styles.unSelectedText
                }
              >
                {v.count}
              </Text>
              <Text
                style={
                  selectedIndex == v.id
                    ? styles.tabTitleText
                    : styles.unSelectedText
                }
              >
                {" " + v.name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  };

  const isAllPendingProductsSelected = () => {
    return filterProducts().every(
      (product: { isSelected: any }) => product.isSelected
    );
  };
  const isAllPickedProductsSelected = () => {
    return pickedProducts.every((product) => product.isSelected);
  };

  const toggleAllPendingProductSelection = () => {
    const value = isAllPendingProductsSelected();
    setProducts(
      filterProducts().map((item: any, index: any) => ({
        ...item,
        isSelected: isReceiveProductFreezed(item?.product) ? false : !value,
      }))
    );
  };

  const toggleAllPickedProductSelection = () => {
    const value = isAllPickedProductsSelected();
    setPickedProducts(
      pickedProducts.map((item, index) => ({
        ...item,
        isSelected: isReceiveProductFreezed(item?.product) ? false : !value,
      }))
    );
  };

  const onPickedItemCheckPressed = (index: number) => {
    let productsArray = [...pickedProducts];
    productsArray[index].isSelected = !productsArray[index].isSelected;
    setPickedProducts(productsArray);
  };

  const onPendingItemCheckPressed = (index: number) => {
    const product = products[index];
    setProducts((prevProducts: any) => {
      const updatedProducts = [...prevProducts];
      updatedProducts[index] = {
        ...updatedProducts[index],
        isSelected: !updatedProducts[index].isSelected,
      };
      return updatedProducts;
    });
  };
  const onPendingItemQTYchange = (index: number, status: any) => {
    setProducts((prevProducts: any) => {
      const updatedProducts = [...prevProducts];
      updatedProducts[index] = {
        ...updatedProducts[index],
        isSelected: status,
      };
      return updatedProducts;
    });
  };
  const onPickedItemQTYchange = (index: number, status: any) => {
    setPickedProducts((prevProducts: any) => {
      const updatedProducts = [...prevProducts];
      updatedProducts[index] = {
        ...updatedProducts[index],
        isSelected: status,
      };
      return updatedProducts;
    });
  };

  const onSavePressed = (index: any) => {
    const productsData = index == 3 ? pickedProducts : products;
    const data1 = productsData.filter(
      (item: { isSelected: boolean }) => item.isSelected === true
    );
    let data = onSaveCheck(productsData);
    const isDept = data?.filter((item: { dept: any }) => item?.dept);
    const isCost = data?.filter((item: { cost: any }) => item?.cost);
    data = data?.filter((item: { isVal: any }) => item?.isVal);
    if (isDept?.length && screen != 2) {
      showToast(
        Strings["alert.select.vsr.product"],
        strings["ime.department.field.is.required"],
        true
      );
      return;
    }
    if (isCost?.length && screen != 2) {
      showToast(
        Strings["alert.select.vsr.product"],
        strings["ime.cost.center.field.is.required"],
        true
      );
      return;
    }
    if (data?.length == data1?.length) {
      if (screen == 2) {
        onapprovePressed();
      } else {
        setProducts(
          products.filter((item: { isSelected: boolean }) => !item.isSelected)
        );
        let picked = [
          ...pickedProducts,
          ...products.filter(
            (item: { isSelected: boolean }) => item.isSelected === true
          ),
        ];
        if (picked?.length) {
          if (index == 3) {
            onapprovePressed();
          } else {
            const prv = products.filter(
              (item: { isSelected: boolean }) => !item.isSelected
            )?.length;
            setSelectedIndex(prv == 0 ? 2 : index);
            setPickedProducts(picked);
          }
        }
      }
    } else {
      showToast(
        Strings["ime.scanner.error.occured.msg"],
        // "Quantity cannot be empty or greater than the available quantity",
        screen == 3
          ? "Please enter less than or equal to requested Ordered Quantity"
          : strings["ime.alert.quant.cannot.greater.avail.quant"]
      );
    }
  };

  // const onSavePressed = (index: any) => {
  //   const productsData = index == 3 ? pickedProducts : products;
  //   const data1 = productsData.filter(
  //     (item: { isSelected: boolean }) => item.isSelected === true
  //   );
  //   let data = onSaveCheck(productsData);
  //   const isDept = data?.filter((item: { dept: any }) => item?.dept);
  //   const isCost = data?.filter((item: { cost: any }) => item?.cost);
  //   data = data?.filter((item: { isVal: any }) => item?.isVal);
  //   if (isDept?.length && screen != 2) {
  //     showToast(
  //       Strings["alert.select.vsr.product"],
  //       strings["ime.department.field.is.required"],
  //       true
  //     );
  //     return;
  //   }
  //   if (isCost?.length && screen != 2) {
  //     showToast(
  //       Strings["alert.select.vsr.product"],
  //       strings["ime.cost.center.field.is.required"],
  //       true
  //     );
  //     return;
  //   }
  //   if (data?.length == data1?.length) {
  //     if (screen == 2) {
  //       onapprovePressed();
  //     } else {
  //       if (single?.length > 1) {
  //         setProducts(
  //           products.filter((item: { isSelected: boolean }) => !item.isSelected)
  //         );
  //       }
  //       let picked;
  //       if (single?.length == 1 && pickedProducts?.length == 1) {
  //         picked = [
  //           ...products.filter(
  //             (item: { isSelected: boolean }) => item.isSelected === true
  //           ),
  //         ];
  //       } else {
  //         picked = [
  //           ...pickedProducts,
  //           ...products.filter(
  //             (item: { isSelected: boolean }) => item.isSelected === true
  //           ),
  //         ];
  //       }
  //       if (picked?.length) {
  //         if (index == 3) {
  //           onapprovePressed();
  //         } else {
  //           const prv = products.filter(
  //             (item: { isSelected: boolean }) => !item.isSelected
  //           )?.length;
  //           // setSelectedIndex(prv == 0 ? 2 : index);
  //           setSelectedIndex(index);

  //           setPickedProducts(picked);
  //         }
  //       }
  //     }
  //   } else {
  //     showToast(
  //       Strings["ime.scanner.error.occured.msg"],
  //       // "Quantity cannot be empty or greater than the available quantity",
  //       screen == 3
  //         ? "Please enter less than or equal to requested Ordered Quantity"
  //         : strings["ime.alert.quant.cannot.greater.avail.quant"]
  //     );
  //   }
  // };

  const onSaveCheck = (products: any[]) => {
    let selectedProducts = products.filter(
      (item: { isSelected: boolean }) => item.isSelected === true
    );

    selectedProducts.forEach((selectedProduct: any, index: number) => {
      if (
        stockRoomDetail?.isCostCenterMandatory &&
        !__selectedCostCenter(selectedProduct)?.id &&
        screen != 2
      ) {
        selectedProducts[index] = {
          ...selectedProducts[index],
          cost: true,
        };
        return selectedProducts;
      }
      if (
        stockRoomDetail?.isDepartmentMandatory &&
        !__selectedDept(selectedProduct)?.id &&
        screen != 2
      ) {
        selectedProducts[index] = {
          ...selectedProducts[index],
          dept: true,
        };
        return selectedProducts;
      }

      let requestQty = 0;
      const condation1 =
        selectedProduct?.orderLineDTO?.product?.batchManagementEnabled == 1 ||
        selectedProduct?.orderLineDTO?.product?.expiryDateManagementenabled ==
          1 ||
        selectedProduct?.product?.batchManagementEnabled == 1 ||
        selectedProduct?.product?.expiryDateManagementenabled == 1;
      const condation2 =
        stockRoomDetail?.isBatchManagementEnabled ||
        stockRoomDetail?.isExpiryManagementEnabled;

      const batches =
        screen == 1
          ? selectedProduct?.requestBatch
          : selectedProduct?.masterProduct?.batches?.filter(
              (obj: any) => obj?.availableQty
            );
      if (condation1 && condation2 && batches?.length && screen !== 2) {
        for (let e = 0; e < batches?.length; e++) {
          if (Number(filterQty(e, index, selectedProduct?.product?.id))) {
            requestQty =
              Number(requestQty) +
              Number(filterQty(e, index, selectedProduct?.product?.id));
          }
        }
      } else {
        requestQty = filterQty(0, index, selectedProduct.product?.id);
      }
      if (screen == 2) {
        if (requestQty > 0) {
          selectedProducts[index] = {
            ...selectedProducts[index],
            isVal: true,
          };
        } else {
          selectedProducts[index] = {
            ...selectedProducts[index],
            isVal: false,
          };
        }
      } else {
        const check =
          selectedProduct?.masterProduct?.batches?.length &&
          selectedProduct?.masterProduct?.batches?.filter(
            (obj: any) => obj?.availableQty
          )?.length;
        let numberValuePOU = null;
        if (screen == 3 && check) {
          let extractedNumberPOU: any;
          extractedNumberPOU =
            selectedProduct?.orderLineDTO?.orderedQtyForDisplay?.match(/-?\d+/);
          numberValuePOU = extractedNumberPOU
            ? parseInt(extractedNumberPOU[0])
            : 0;
        }
        const availableQty =
          screen == 1
            ? selectedProduct?.product?.availableQty
            : numberValuePOU || selectedProduct?.masterProduct?.availableQty;
        if (requestQty > 0 && requestQty <= availableQty) {
          selectedProducts[index] = {
            ...selectedProducts[index],
            isVal: true,
          };
        } else {
          selectedProducts[index] = {
            ...selectedProducts[index],
            isVal: false,
          };
        }
      }
    });

    return selectedProducts;
  };
  const getSelectedProductCount = (products: never[]) => {
    let count = products.filter(
      (product: { isSelected: any }) => product.isSelected
    )?.length;
    storage.setItem("ApprovalsCount", JSON.stringify(count));
    return count;
  };

  const reloadData = () => {
    if (screen == 1) {
      let url = `?limit=${10}&sortBy=createdDate:desc`;
      dispatch(getConsumeList(url, Strings["ime.consume.request.approval"]));
    } else if (screen == 2) {
      let url = `?limit=${10}&sortBy=createdDate:desc`;
      dispatch(getOrderList(url, Strings["ime.order.request.approval"]));
    } else {
      let url = `?limit=${10}&sortBy=createdDate:desc`;
      dispatch(getPOUList(url, Strings["ime.pou.order.request.approval"]));
    }
  };

  const onapprovePressed = () => {
    if (screen == 1) {
      handleScreen1Logic(
        pickedProducts,
        dispatch,
        onComsueApprove,
        props,
        selectedCostCenter,
        selectedDept,
        onApproveToast,
        getCount,
        batchQty,
        showToast,
        reloadData,
        stockRoomDetail,
        Strings
      );
    } else if (screen == 2) {
      handleScreen2Logic(
        products,
        batchQty,
        comment,
        showToast,
        dispatch,
        getUserPrice,
        setCheckoutData,
        setVisibleCheckout,
        Strings
      );
    } else {
      handleScreen3Logic(
        pickedProducts,
        selectedItem,
        dispatch,
        onPouApprove,
        showToast,
        reloadData,
        props,
        getPOUCount,
        onApproveToast,
        batchQty,
        selectedCostCenter,
        selectedDept,
        comment,
        stockRoomDetail,
        Strings
      );
    }
  };

  const checkSelected = () => {
    if (selectedIndex == 1 || screen == 2) {
      const data = products?.filter((item) => item?.isSelected);
      return data?.length ? true : false;
    } else {
      const data = pickedProducts?.filter((item) => item?.isSelected);
      return data?.length ? true : false;
    }
  };

  const __renderSheet = () => (
    <BottomSheetComponent
      customStyles={{
        borderTopLeftRadius: hp(1),
        borderTopRightRadius: hp(1),
      }}
      bottomSheetRef={costCenterRef}
      height={hp(52)}
      didCloseModal={() => setSearchKey("")}
      // onOpen={() => onChangeUserSearch("")}
    >
      <View
        style={styles.headerContainer}
        accessible={true}
        accessibilityLabel="user-list-sheet-header-container"
      >
        <View />
        <Text style={styles.headerText}>
          {selectType == 1 ? strings["cost.center"] : strings["department"]}
        </Text>
        <TouchableOpacity
          accessible={true}
          accessibilityLabel="user-list-sheet-close-btn"
          style={styles.secondaryPressableContainer}
          onPress={() => costCenterRef.current.close()}
        >
          <Text
            style={styles.closeBtn}
            accessible={true}
            accessibilityLabel="close-btn"
          >
            {strings["close"]}
          </Text>
        </TouchableOpacity>
      </View>
      <SearchBar
        search={searckKey || ""}
        onSearch={(text: string) => setSearchKey(text)}
        containerStyle={{
          width: "90%",
          alignSelf: "center",
        }}
        placeholder={Strings["search"]}
        onBarcodeDetected={(barcode: any) => searchBarCode(barcode)}
        from="org"
      />
      <ScrollView>
        {!searchData()?.length && (
          <Text
            style={[
              {
                fontSize: FONTS.h1_8,
                color: COLORS.abbey,
                fontFamily: FONTFAMILY.averta_semibold,
                alignSelf: "center",
                marginTop: hp(2),
              },
            ]}
            accessible={true}
            accessibilityLabel="name-list"
          >
            No data found
          </Text>
        )}

        {selectType == 1
          ? searchData()?.map((item, index) => _renderItemList(item, index))
          : searchData()?.map((item, index) => _renderItemList(item, index))}
      </ScrollView>
    </BottomSheetComponent>
  );

  function checkStatus(status: any) {
    const trimmedStatus = status
      ? status?.replace(/\s/g, "")?.toLowerCase()
      : "";
    if (
      trimmedStatus == "open" ||
      trimmedStatus == "partiallyclosed" ||
      trimmedStatus == "partiallyrejected" ||
      trimmedStatus == "partiallyapproved"
    ) {
      return true;
    } else {
      return false;
    }
  }

  const renderSignleProduct = (item, index) => {
    return (
      <View key={`${item?.id}-${index}`} style={styles.listItemContainer}>
        <ListItem
          leftIcon={
            item?.product?.imageURL ? (
              <Image
                source={{
                  uri: item?.product?.imageURL.replace("http://", "https://"),
                }}
                style={styles.leftIcon}
                resizeMode={"contain"}
              />
            ) : (
              <DefaultProductImage width={wp(18)} height={wp(18)} />
            )
          }
          headerContent={
            <View style={styles.headerContentContainer}>
              <Text style={styles.product_code}>{item?.product.catalogNo}</Text>
              <TouchableOpacity
                onPress={async () => {
                  await dispatch(
                    getProductDetails(
                      screen == 3 ? item?.masterProduct.id : item?.product.id
                    )
                  );
                  await dispatch(setProductLoader(false));
                  productBottomSheetRef?.current?.open();
                }}
              >
                <Text style={styles.product_name} numberOfLines={2}>
                  {item?.product.description}
                </Text>
              </TouchableOpacity>
              <Text style={styles.variant}>({item?.product.uomId})</Text>
              {screen !== 2 && (
                <View style={styles.labelContainer}>
                  {isBatchEnabled(item) && (
                    <View style={styles.labelSubContainer}>
                      <Text style={styles.label}>
                        {Strings["ime.batch.controlled"]}
                      </Text>
                    </View>
                  )}
                  {isExpBatchEnabled(item) && (
                    <View style={styles.labelSubContainer}>
                      <Text style={styles.label}>
                        {Strings["ime.expiry.date.controlled"]}
                      </Text>
                    </View>
                  )}
                </View>
              )}
            </View>
          }
          rightIcon={
            isReceiveProductFreezed(
              screen == 3 && isOutOfStock()
                ? item?.masterProduct
                : item?.product
            ) ? (
              <Locked />
            ) : (
              <ListItemCheckButton
                isSelected={item.isSelected}
                onChangeBtnPress={() => onPendingItemCheckPressed(index)}
              />
            )
          }
          customStyles={{
            contentHeaderStyle: {
              alignItems: "center",
            },
          }}
        >
          <View style={{ width: "92%", alignSelf: "center" }}>
            {screen != 2 && SelectCost(item)}
            {screen != 2 && SelectDept(item)}
          </View>
          <ItemDetails
            item={item}
            index={index}
            type={1}
            batchQty={batchQty}
            Strings={Strings}
            screen={screen}
            setBatchQty={setBatchQty}
            comment={comment}
            setComment={setComment}
            showComment={stockRoomDetail?.isCommentsEnabled}
            stockRoomDetail={stockRoomDetail}
            onPendingItemQTYchange={(index, status) =>
              onPendingItemQTYchange(index, status)
            }
            showToast={showToast}
            isOutOfStock={isOutOfStock()}
            // singleProduct={pickedProducts?.length == 1 && single?.length == 1}
          />
        </ListItem>
        {itemSeparator()}
        {index + 1 == products?.length && itemFooter()}
      </View>
    );
    // };
  };
  const isOutOfStock = () => {
    if (
      selectedItem?.consumeApprovalStatus == "out of stock" ||
      selectedItem?.pouOrderApprovalStatus == "Not Available"
    ) {
      return true;
    } else {
      return false;
    }
  };

  const __filterProducts = () => {
    if (screen == 2) {
      const data = products?.filter((item: any) =>
        checkStatus(item?.orderLineDTO?.approvalStatus)
      );
      return data;
    } else if (screen == 1) {
      const data = products?.filter(
        (item: any) =>
          item?.approvalStatus == "Open" ||
          item?.approvalStatus == "Partially Closed"
      );
      return data;
    } else if (screen == 3) {
      if (isOutOfStock()) {
        return products;
      } else {
        const data = products?.filter(
          (item: any) =>
            item?.orderLineDTO?.approvalStatus == "Direct" ||
            item?.orderLineDTO?.approvalStatus == "Closed" ||
            item?.orderLineDTO?.approvalStatus == "Partially Closed"
        );
        //console.log("data",data)
        return data;
      }
    } else {
      return [];
    }
  };

  const filterProducts = () => {
    if (screen == 2) {
      return products?.filter((item: any) =>
        checkStatus(item?.orderLineDTO?.approvalStatus)
      );
    } else if (screen == 1) {
      return products?.filter((item: any) => item?.approvalStatus != "Closed");
    } else if (screen == 3) {
      return products?.filter((item: any) => {
        let extractedNumber =
          item?.orderLineDTO?.orderedQtyForDisplay?.match(/\d+/);
        const numberValue = extractedNumber ? parseInt(extractedNumber[0]) : 0;
        return numberValue;
      });
    }
  };

  const RenderComponent = () => {
    return (
      <ScrollView
        style={styles.rendercomponentContainer}
        showsVerticalScrollIndicator={true}
      >
        {/* {checkLength() ? (
          <View style={styles.toolsContainer}>
            <Search height={ICONSIZE.h2} width={ICONSIZE.h2} />

            <ListItemCheckButton
              title={
                isAllPendingProductsSelected()
                  ? Strings["ime.scanner.deselect.all"] ?? "Deselect All"
                  : Strings["select.all"] ?? "Select All"
              }
              maincontainerStyle={styles.checkAndTitleContainer}
              isSelected={isAllPendingProductsSelected()}
              onChangeBtnPress={() => toggleAllPendingProductSelection()}
            />
          </View>
        ) : null} */}

        {/* {checkLength() ? (
          <HeaderItem
            name={selectedItem?.firstName + " " + selectedItem?.lastName}
            email={selectedItem?.loginId}
            date={selectedItem?.createdOn}
            status={status(selectedItem)}
            count={selectedItem["itemCount"] || selectedItem?.itemsCount}
            total={"$" + totalPrice?.toFixed(2)}
          />
        ) : null} */}
        {__filterProducts()?.map((item, index) =>
          renderSignleProduct(item, index)
        )}

        {!checkLength() && !isOutOfStock() ? (
          <Text
            accessibilityLabel="approve-details-headerItem-headerName"
            style={[
              styles.headerName,
              {
                marginTop: hp(5),
                width: wp(100),
                textAlign: "center",
              },
            ]}
          >
            No Data Found
          </Text>
        ) : null}
      </ScrollView>
    );
  };
  const isBatchEnabled = (item: any) => {
    const data =
      (item?.orderLineDTO?.product?.batchManagementEnabled == 1 ||
        item?.product?.batchManagementEnabled == 1) &&
      stockRoomDetail?.isBatchManagementEnabled;
    return data;
  };
  const isExpBatchEnabled = (item: any) => {
    const data =
      (item?.orderLineDTO?.product?.expiryDateManagementenabled == 1 ||
        item?.product?.expiryDateManagementenabled == 1) &&
      stockRoomDetail?.isExpiryManagementEnabled;
    return data;
  };

  const RenderPickedComponent = () => (
    <ScrollView
      style={styles.rendercomponentContainer}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.toolsContainer}>
        <Search height={ICONSIZE.h2} width={ICONSIZE.h2} />
        <ListItemCheckButton
          title={
            isAllPickedProductsSelected()
              ? Strings["ime.scanner.deselect.all"] ?? "Deselect All"
              : Strings["ime.select.all"] ?? "Select All"
          }
          maincontainerStyle={styles.checkAndTitleContainer}
          isSelected={isAllPickedProductsSelected()}
          onChangeBtnPress={() => toggleAllPickedProductSelection()}
        />
      </View>
      <HeaderItem
        name={selectedItem?.firstName + " " + selectedItem?.lastName}
        email={selectedItem?.loginId}
        date={selectedItem?.createdOn}
        status={status(selectedItem)}
        count={selectedItem["itemCount"] || selectedItem?.itemsCount}
        total={getCurrencySymbol(currency) + totalPrice?.toFixed(2)}
      />
      {pickedProducts?.map((item: any, index: number) => (
        <View key={`${item?.id}-${index}`} style={styles.listItemContainer}>
          <ListItem
            leftIcon={
              item?.orderLineDTO?.product?.imageURL ? (
                <Image
                  source={{
                    uri: item?.orderLineDTO?.product?.imageURL.replace(
                      "http://",
                      "https://"
                    ),
                  }}
                  style={styles.leftIcon}
                  resizeMode={"contain"}
                />
              ) : (
                <DefaultProductImage width={wp(18)} height={wp(18)} />
              )
            }
            headerContent={
              <View style={styles.headerContentContainer}>
                <Text style={styles.product_code}>
                  {item?.product.catalogNo}
                </Text>
                <TouchableOpacity
                  onPress={async () => {
                    productBottomSheetRef.current.open();
                    await dispatch(
                      getProductDetails(
                        screen == 3 ? item?.masterProduct.id : item?.product.id
                      )
                    );
                    await dispatch(setProductLoader(false));
                  }}
                >
                  <Text style={styles.product_name} numberOfLines={2}>
                    {item?.product.description}
                  </Text>
                </TouchableOpacity>

                <Text style={styles.variant}>({item?.product.uomId})</Text>
                <View style={styles.labelContainer}>
                  {isBatchEnabled(item) && (
                    <View style={styles.labelSubContainer}>
                      <Text style={styles.label}>
                        {Strings["ime.batch.controlled"]}
                      </Text>
                    </View>
                  )}
                  {isExpBatchEnabled(item) && (
                    <View style={styles.labelSubContainer}>
                      <Text style={styles.label}>
                        {Strings["ime.expiry.date.controlled"]}
                      </Text>
                    </View>
                  )}
                </View>
              </View>
            }
            rightIcon={
              isReceiveProductFreezed(item?.product) ? (
                <Locked />
              ) : (
                <ListItemCheckButton
                  isSelected={item.isSelected}
                  onChangeBtnPress={() => onPickedItemCheckPressed(index)}
                />
              )
            }
            customStyles={{
              contentHeaderStyle: {
                alignItems: "center",
              },
            }}
          >
            <View style={{ width: "92%", alignSelf: "center" }}>
              {screen != 2 && SelectCost(item)}
              {screen != 2 && SelectDept(item)}
            </View>
            <ItemDetails
              item={item}
              index={index}
              type={2}
              batchQty={batchQty}
              Strings={Strings}
              screen={screen}
              setBatchQty={setBatchQty}
              comment={comment}
              setComment={setComment}
              showComment={stockRoomDetail?.isCommentsEnabled}
              stockRoomDetail={stockRoomDetail}
              onPendingItemQTYchange={(index, status) =>
                onPickedItemQTYchange(index, status)
              }
              showToast={showToast}
              isOutOfStock={isOutOfStock()}
              singleProduct={false}
            />
          </ListItem>
          {itemSeparator()}
          {index + 1 == pickedProducts?.length && itemFooter()}
        </View>
      ))}
    </ScrollView>
  );

  const getTabData = () => {
    switch (selectedIndex) {
      case 1:
        return <>{RenderComponent()}</>;
      case 2:
        return <>{RenderPickedComponent()}</>;

      default:
        break;
    }
  };
  const headerBackClicked = () => {
    let count =
      selectedIndex == 1
        ? getSelectedProductCount(products)
        : getSelectedProductCount(pickedProducts);
    if (count > 0) {
      dispatch(
        setIsShowConfirmationAlert({
          isShow: true,
          data: confirmationAlertInfo?.data,
        })
      );
    } else {
      props.navigation.goBack();
    }
  };
  if (visibleCheckout)
    return (
      <ReplenishCheckoutScreen
        setNavigatedRoute={() => {}}
        data={checkoutData}
        isSelectedAll={true}
        onClose={() => setVisibleCheckout(false)}
        approval={true}
        clearState={() => setCheckoutData([])}
        orderId={selectedItem?.orderId}
      />
    );
  else {
    return (
      <View style={styles.container}>
        <Header
          title={props.route?.params?.type}
          LeftIcon={() => <WhiteLeftArrow />}
          onLeftIconPress={() => headerBackClicked()}
          statusBar={true}
          statusBarColor={"blue"}
          iconLeft={true}
          iconRight={true}
        />
        <Subheader
          distance={10}
          rowContainer={styles.rowContainer}
          mainContainer={{
            borderBottomWidth: 0.7,
            borderColor: COLORS.scienceBlue,
          }}
        />
        {screen !== 2 && getTabs()}
        {Platform.OS == "ios" ? (
          <KeyboardAvoidingView
            style={{ height: hp(80) }}
            behavior={Platform.OS == "ios" ? "padding" : "padding"}
          >
            {getTabData()}
          </KeyboardAvoidingView>
        ) : (
          <KeyboardAvoidingView style={{ height: hp(80) }}>
            {getTabData()}
          </KeyboardAvoidingView>
        )}

        <Footer
          mainButtonDisabled={isOutOfStock() || isOutOfStock()}
          count={
            selectedIndex == 1
              ? getSelectedProductCount(products)
              : getSelectedProductCount(pickedProducts)
          }
          mainbuttonTitle={
            selectedIndex == 1 && screen != 2
              ? Strings["save"] || "save"
              : Strings["approve"] || "approve"
          }
          mainButtonStyle={[
            styles.footerMainButtonStyle,
            !checkSelected() &&
              !isOutOfStock() && {
                opacity: 0.5,
                backgroundColor: COLORS.gray,
              },
          ]}
          mainButtonTextStyle={styles.footerMainButtonTextStyle}
          tertiaryButtonTitle={
            selectedIndex == 1
              ? Strings["ime.scanner.clear"] ?? "Clear"
              : Strings["cancel"]
          }
          tertiaryryButtonDisabled={
            isOutOfStock()
              ? true
              : selectedIndex == 1
              ? !products?.length
              : !pickedProducts?.length
          }
          mainContainerStyle={styles.footerContainerStyle}
          onChangePrimaryBtnPress={() =>
            selectedIndex == 1 ? onSavePressed(1) : onSavePressed(3)
          }
          onChangeSecondaryBtnPress={() => {}}
          onChangeTertiaryBtnPress={() => {
            if (selectedIndex == 2 || screen == 2) {
              setConfirmationModal(true);
            } else {
              setProducts(
                products.map((item: any, index) => ({
                  ...item,
                  isSelected: false,
                }))
              );
            }
          }}
        />
        <ToastComponent />

        <ProductDetails
          itemDetailsRef={productBottomSheetRef}
          productDetailsList={productDetails}
        />
        <ClearSelectionAlert
          isShow={confirmationModel}
          didCloseModal={() => {
            setConfirmationModal(false);
          }}
          outlinedButtonTitle={"Cancel"}
          didOutlinedButtonClicked={() => setConfirmationModal(false)}
          mainButtonTitle={"Yes"}
          didMainButtonTitleClicked={async () => {
            if (screen == 2) {
              props?.navigation?.goBack();
              dispatch(resetPriceState());
            } else {
              setProducts([...products, ...pickedProducts]);
              setPickedProducts([]);
              setConfirmationModal(false);
              setSelectedIndex(1);
            }
          }}
          // didMainButtonTitleClicked={async () => {
          //   if (screen == 2) {
          //     props?.navigation?.goBack();
          //   } else {
          //     if (single?.length > 1) {
          //       setProducts([...products, ...pickedProducts]);
          //     } else {
          //       fillRequestQtyLogic(
          //         selectedIndex,
          //         single,
          //         pickedProducts,
          //         screen,
          //         stockRoomDetail,
          //         (res) => setBatchQty(res)
          //       );
          //       setProducts([...single]);
          //     }
          //     setPickedProducts([]);
          //     setConfirmationModal(false);
          //     setSelectedIndex(1);
          //   }
          // }}
          orderTitle={Strings["ime.scanner.Clear.this.order"]}
          orderDesc={
            Strings["ime.scanner.All.products.in.this.order.will.be.removed."]
          }
        />
        {__renderSheet()}
        <Loader show={productDetailsLoading || loader} />
        <ConfirmationAlert
          onTapNo={() => {
            dispatch(
              setIsShowConfirmationAlert({
                isShow: false,
                data: confirmationAlertInfo?.data,
              })
            );
          }}
          onTapYes={() => {
            dispatch(
              setIsShowConfirmationAlert({
                isShow: false,
                data: confirmationAlertInfo?.data,
              })
            );
            props.navigation.goBack();
          }}
          onBack={() => {}}
        />
      </View>
    );
  }
};

export default ApprovalDetails;
