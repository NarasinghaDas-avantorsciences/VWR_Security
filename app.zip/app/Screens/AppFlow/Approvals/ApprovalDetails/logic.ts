const addCostCenterDeptLogic = (
  selectedIndex: number,
  products: any,
  pickedProducts: any,
  data: any,
  screen: number
) => {
  let arrCost: { productId: any; id: any; costCenterName: any }[] = [];
  let arrDept = [];
  const mainItem = selectedIndex === 1 ? products : pickedProducts;
  for (let i = 0; i < mainItem?.length; i++) {
    if (screen == 1) {
      console.log("-----");
      const costObj = mainItem[i]?.costCentersList?.filter(
        (item: { skGuid: any; costCenterName: any }) =>
          item?.skGuid == mainItem[i]?.costcenterId ||
          item?.costCenterName == mainItem[i]?.costCenterName
      );
      const deptObj = mainItem[i].departmentsList?.filter(
        (item: { skGuid: any; departmentName: any }) =>
          item?.skGuid == mainItem[i]?.departmentId ||
          item?.departmentName == mainItem[i]?.departmentName
      );
      console.log("deptObj", deptObj);
      const costCenter = {
        productId: mainItem[i]?.product?.id,
        id: costObj?.length ? costObj[0]?.skGuid : null,
        costCenterName: costObj?.length ? costObj[0]?.costCenterName : "",
      };
      const dept = {
        productId: mainItem[i]?.product?.id,
        id: deptObj?.length ? deptObj[0]?.skGuid : null,
        departmentName: deptObj?.length ? deptObj[0]?.departmentName : "",
      };
      arrCost.push(costCenter);
      arrDept.push(dept);
    } else if (data?.departments?.length || data?.costcenter?.length) {
      const costObj = data?.costcenter?.filter(
        (item: { id: any }) =>
          item?.id == mainItem[i]?.orderLineDTO?.costcenterId
      );

      const deptObj = data?.departments?.filter(
        (item: { id: any }) =>
          item?.id == mainItem[i]?.orderLineDTO?.departmentId
      );

      const costCenter = {
        productId: mainItem[i]?.product?.id,
        id: costObj?.length ? costObj[0]?.id : null,
        costCenterName: costObj?.length ? costObj[0]?.costCenterName : "",
      };

      const dept = {
        productId: mainItem[i]?.product?.id,
        id: deptObj?.length ? deptObj[0]?.id : null,
        departmentName: deptObj?.length ? deptObj[0]?.departmentName : "",
      };
      arrCost.push(costCenter);
      arrDept.push(dept);
    }
  }
  return { selectedCostCenter: arrCost, selectedDept: arrDept };
};

function checkStatus(status: any) {
  const trimmedStatus = status ? status?.replace(/\s/g, "")?.toLowerCase() : "";
  if (
    trimmedStatus == "open" ||
    trimmedStatus == "partiallyclosed" ||
    trimmedStatus == "partiallyrejected" ||
    trimmedStatus == "partiallyapproved"
  ) {
    return true;
  } else {
    return false;
  }
}

const __filterProducts = (screen: number, products: any) => {
  if (screen == 2) {
    const data = products?.filter((item: any) =>
      checkStatus(item?.orderLineDTO?.approvalStatus)
    );
    return data;
  } else if (screen == 1) {
    const data = products?.filter(
      (item: any) =>
        item?.approvalStatus == "Open" ||
        item?.approvalStatus == "Partially Closed"
    );
    return data;
  } else if (screen == 3) {
    const data = products?.filter((item: any) => {
      let extractedNumber;
      extractedNumber =
        item?.orderLineDTO?.orderedQtyForDisplay?.match(/-?\d+/);
      const numberValue = extractedNumber ? parseInt(extractedNumber[0]) : 0;
      return (
        (item?.orderLineDTO?.approvalStatus == "Direct" ||
          item?.orderLineDTO?.approvalStatus == "Closed" ||
          item?.orderLineDTO?.approvalStatus == "Partially Closed") &&
        numberValue > 0
      );
    });

    return data;
  } else {
    return [];
  }
};
const fillRequestQtyLogic = (
  selectedIndex: number,
  products: any,
  pickedProducts: any,
  screen: number,
  stockRoomDetail: any,
  setBatchQty: (
    arg0: { index: number; itemIndex: number; qty: any; id: any }[]
  ) => void
) => {
  let arr = [];
  const mainItem =
    selectedIndex === 1 ? __filterProducts(screen, products) : pickedProducts;

  for (let i = 0; i < mainItem?.length; i++) {
    const condation1 =
      screen == 3
        ? mainItem[i]?.masterProduct?.batchManagementEnabled == 1 ||
          mainItem[i]?.masterProduct?.expiryDateManagementenabled == 1
        : mainItem[i]?.orderLineDTO?.product?.batchManagementEnabled == 1 ||
          mainItem[i]?.orderLineDTO?.product?.expiryDateManagementenabled ==
            1 ||
          mainItem[i]?.product?.batchManagementEnabled == 1 ||
          mainItem[i]?.product?.expiryDateManagementenabled == 1;

    const condation2 =
      stockRoomDetail?.isBatchManagementEnabled ||
      stockRoomDetail?.isExpiryManagementEnabled;
    const batchItem =
      screen === 1
        ? mainItem[i]?.requestBatch?.length
          ? mainItem[i]?.requestBatch
          : mainItem[i]?.product?.batches
        : mainItem[i]?.masterProduct?.batches?.filter(
            (obj: any) => obj?.availableQty
          );

    console.log(
      "chec----",
      condation1,
      condation2,
      screen != 2,
      batchItem?.length
    );
    if (condation1 && condation2 && screen != 2 && batchItem?.length) {
      console.log("here----");
      for (let e = 0; e < batchItem?.length; e++) {
        const data = {
          index: e,
          itemIndex: i,
          qty: Number(batchItem[e]?.approvedQty)
            ? Number(batchItem[e]?.requestedQty) -
              Number(batchItem[e]?.approvedQty)
            : Number(batchItem[e]?.requestedQty),
          value: Number(batchItem[e]?.approvedQty)
            ? Number(batchItem[e]?.requestedQty) -
              Number(batchItem[e]?.approvedQty)
            : Number(batchItem[e]?.requestedQty),
          id: mainItem[i]?.product?.id || mainItem[i]?.id,
        };
        batchItem[e]?.requestedQty && arr.push(data);
      }
    } else {
      console.log("here----1");

      let extractedNumber;
      extractedNumber =
        screen == 2
          ? mainItem[i]?.orderLineDTO?.remainingQtyForDisplay?.match(/\d+/)
          : screen == 3
          ? mainItem[i]?.orderLineDTO?.orderedQtyForDisplay?.match(/\d+/)
          : "";
      const numberValue = extractedNumber ? parseInt(extractedNumber[0]) : null;

      const data = {
        index: 0,
        itemIndex: i,
        // qty:
        //   screen === 1
        //     ? mainItem[i]?.requestQuantity
        //     : screen === 2
        //     ? numberValue
        //     : mainItem[i]?.orderLineDTO?.orderedQty,
        qty:
          screen === 1
            ? Number(mainItem[i]?.requestQuantity)
              ? Number(mainItem[i]?.requestQuantity) -
                Number(mainItem[i]?.approvedQuantity)
              : 0
            : numberValue,
        value:
          screen === 1
            ? Number(mainItem[i]?.requestQuantity)
              ? Number(mainItem[i]?.requestQuantity) -
                Number(mainItem[i]?.approvedQuantity)
              : 0
            : numberValue,
        id: mainItem[i]?.product?.id || mainItem[i]?.id,
      };
      screen === 1
        ? mainItem[i]?.requestQuantity && arr.push(data)
        : mainItem[i]?.orderLineDTO?.orderedQty && arr.push(data);
    }
  }
  setBatchQty([...arr]);
  return arr; // Return the array for testing purposes
};

const prepareData = (selectedProduct: any, index: number, batchQty: any) => {
  let batchProductDetails = [];
  var requestQty = 0;
  if (selectedProduct?.requestBatch?.length) {
    for (let e = 0; e < selectedProduct?.requestBatch?.length; e++) {
      if (Number(filterQty(batchQty, e, index, selectedProduct?.product?.id))) {
        batchProductDetails.push({
          requestBatchId: selectedProduct.requestBatch[e].id,
          batchRequestQty: filterQty(
            batchQty,
            e,
            index,
            selectedProduct?.product?.id
          ),
        });
        requestQty =
          Number(requestQty) +
          Number(filterQty(batchQty, e, index, selectedProduct?.product?.id));
      }
    }
  } else {
    for (let e = 0; e < selectedProduct?.product?.batches?.length; e++) {
      if (Number(filterQty(batchQty, e, index, selectedProduct?.product?.id))) {
        batchProductDetails.push({
          requestBatchId: "",
          batchRequestQty: filterQty(
            batchQty,
            e,
            index,
            selectedProduct?.product?.id
          ),
          batchPrdLnkId: selectedProduct.product?.batches[e].id,
          isNonRequestBatch: true,
        });
        requestQty =
          Number(requestQty) +
          Number(filterQty(batchQty, e, index, selectedProduct?.product?.id));
      }
    }
  }

  return {
    consumeDetailsId: selectedProduct.id,
    costCenterId: selectedProduct.costCenterId
      ? selectedProduct.costCenterId
      : __selectedCostCenter(selectedProduct, selectedProduct)?.id,
    departmentId: selectedProduct.departmentId
      ? selectedProduct.departmentId
      : __selectedDept(selectedProduct, selectedProduct)?.id,
    requestQty: requestQty,
    batchProductDetails: batchProductDetails,
  };
};

function filterQty(batchQty: any[], i: number, index: number, id: any) {
  const data = batchQty?.filter((item) => item?.index == i && item?.id == id);
  return data?.length ? data[0]?.qty : 0;
}
function filterComment(comment: any[], i: number, index: any, id: undefined) {
  const data = comment?.filter((item) => item?.index == i && item?.id == id);
  return data?.length ? data[0]?.comment : "";
}

const handleApproveSuccess = (
  res: any,
  reloadData: () => void,
  dispatch: any,
  props: any,
  onApproveToast: any,
  getCount: any
) => {
  console.log("resresres", res);
  onApproveToast(res);
  // dispatch(toggleApprovalToast(true));
  setTimeout(() => {
    reloadData();
    dispatch(getCount());
    if (props.route?.params?.route === "notification") {
      props.navigation.navigate("OrderRequestApproval", {
        type: props.route?.params?.type,
      });
    } else {
      props.navigation.goBack();
    }
  }, 5000);
};

const handleApproveError = (
  ERROR: any,
  showToast: {
    (message: string, options: any): void;
    (arg0: any, arg1: string): void;
  },
  Strings: any
) => {
  console.log("ERROR", ERROR?.response?.data);
  showToast(
    Strings["ime.scanner.error.occured.msg"],
    ERROR?.response?.data?.errorMessage
  );
};
const __selectedCostCenter = (
  item: { product: { id: any } },
  selectedCostCenter: any[] | undefined
) => {
  const data =
    selectedCostCenter?.length &&
    selectedCostCenter?.filter((i) => i?.productId == item?.product?.id);
  return data?.length ? data[0] : {};
};
const __selectedDept = (
  item: { product: { id: any } },
  selectedDept: any[] | undefined
) => {
  const data =
    selectedDept?.length &&
    selectedDept?.filter((i) => i?.productId == item?.product?.id);
  return data?.length ? data[0] : {};
};

const handleScreen1Logic = (
  pickedProducts: any[],
  dispatch: any,
  onComsueApprove: any,
  props: any,
  selectedCostCenter: any,
  selectedDept: any,
  onApproveToast: (data: any) => void,
  getCount: any,
  batchQty: any[],
  showToast: (message: string, options: any) => void,
  reloadData: () => void,
  stockRoomDetail: any,
  Strings: { [x: string]: string }
) => {
  let selectedProducts = pickedProducts.filter(
    (item) => item.isSelected === true
  );
  if (selectedProducts.length === 0) {
    showToast(
      Strings["alert.select.vsr.product"],
      Strings["alert.select.product"]
    );
    return;
  }
  const body: any[] = [];

  selectedProducts.forEach((selectedProduct, index) => {
    const condation1 =
      selectedProduct?.product?.batchManagementEnabled == 1 ||
      selectedProduct?.product?.expiryDateManagementenabled == 1;

    const condation2 =
      stockRoomDetail?.isBatchManagementEnabled ||
      stockRoomDetail?.isExpiryManagementEnabled;

    if (
      condation1 &&
      condation2 &&
      (selectedProduct?.requestBatch?.length ||
        selectedProduct?.product?.batches)
    ) {
      const data = prepareData(selectedProduct, index, batchQty);
      body.push(data);
    } else {
      const data = {
        consumeDetailsId: selectedProduct.id,
        costCenterId: selectedProduct.costCenterId
          ? selectedProduct.costCenterId
          : __selectedCostCenter(selectedProduct, selectedCostCenter)?.id,
        departmentId: selectedProduct.departmentId
          ? selectedProduct.departmentId
          : __selectedDept(selectedProduct, selectedDept)?.id,
        requestQty: filterQty(batchQty, 0, index, selectedProduct.product?.id),
        batchProductDetails: [],
      };
      body.push(data);
    }
  });
  console.log("body----", body);
  dispatch(
    onComsueApprove(
      body,
      (res: any) => {
        handleApproveSuccess(
          res?.data?.consumeDetails,
          reloadData,
          dispatch,
          props,
          onApproveToast,
          getCount
        );
      },
      (ERROR: any) => {
        handleApproveError(ERROR, showToast, Strings);
      }
    )
  );
};

const preparePOUData = (
  selectedProduct: any,
  index: number,
  batchQty: any[]
) => {
  let masterBatchIds = [];
  var masterBatchQtys = [];
  let batches = {};
  var requestQty = 0;

  const batchData = selectedProduct?.masterProduct?.batches?.filter(
    (obj: any) => obj?.availableQty
  );

  for (let e = 0; e < batchData?.length; e++) {
    if (filterQty(batchQty, e, index, selectedProduct.product?.id) > 0) {
      masterBatchIds.push(batchData[e].id);
      masterBatchQtys.push(
        filterQty(batchQty, e, index, selectedProduct.product?.id)
      );
      batches = {
        ...batches,
        [batchData[e].id]: filterQty(
          batchQty,
          e,
          index,
          selectedProduct.product?.id
        ),
      };
      requestQty =
        Number(requestQty) +
        Number(filterQty(batchQty, e, index, selectedProduct?.product?.id));
    }
  }
  return {
    masterBatchIds: masterBatchIds,
    masterBatchQtys: masterBatchQtys,
    batches: batches,
    requestQty,
  };
};

function handleScreen3Logic(
  pickedProducts: any[],
  selectedItem: any,
  dispatch: (arg0: any) => void,
  onPouApprove: (
    arg0: {},
    arg1: (res: any) => void,
    arg2: (ERROR: any) => void
  ) => any,
  showToast: (arg0: string, arg1: string) => void,
  reloadData: () => void,
  props: any,
  getPOUCount: any,
  onApproveToast: any,
  batchQty: any,
  selectedCostCenter: any,
  selectedDept: any,
  comment: any,
  stockRoomDetail: any,
  Strings: { [x: string]: string }
) {
  let selectedProducts = pickedProducts.filter(
    (item) => item.isSelected === true
  );
  if (selectedProducts.length === 0) {
    showToast(
      Strings["alert.select.vsr.product"],
      Strings["alert.select.product"]
    );
    return;
  }

  const slaveProductId: any[] = [];
  const masterProductId: any[] = [];
  const orderQty: number[] = [];
  const comments: any[] = [];
  const costCenterIds: any[] = [];
  const departmentIds: any[] = [];
  let masterBatchIds: any[] = [];
  let masterBatchQtys: any[] = [];
  let masterBatchProductsMap = {};

  selectedProducts.forEach((selectedProduct, index) => {
    const condation1 =
      selectedProduct?.orderLineDTO?.product?.batchManagementEnabled == 1 ||
      selectedProduct?.orderLineDTO?.product?.expiryDateManagementenabled ==
        1 ||
      selectedProduct?.product?.batchManagementEnabled == 1 ||
      selectedProduct?.product?.expiryDateManagementenabled == 1 ||
      selectedProduct?.masterProduct?.batchManagementEnabled == 1 ||
      selectedProduct?.masterProduct?.expiryDateManagementenabled == 1;
    const condation2 =
      stockRoomDetail?.isBatchManagementEnabled ||
      stockRoomDetail?.isExpiryManagementEnabled;
    if (
      condation1 &&
      condation2 &&
      selectedProduct?.masterProduct?.batches?.filter(
        (obj: any) => obj?.availableQty
      )?.length
    ) {
      console.log("inside batach");
      const key = `BATCH_PRODUCT_QTY_ID_MAP${selectedProduct?.masterProduct?.id}`;
      const dataobj = preparePOUData(selectedProduct, index, batchQty);
      slaveProductId.push(selectedProduct?.product?.id);
      masterProductId.push(selectedProduct?.masterProduct?.id);
      orderQty.push(dataobj?.requestQty);
      comments.push(
        filterComment(comment, 0, index, selectedProduct.product?.id)
      );
      __selectedCostCenter(selectedProduct, selectedCostCenter)?.id &&
        costCenterIds.push(
          __selectedCostCenter(selectedProduct, selectedCostCenter)?.id
        );
      __selectedDept(selectedProduct, selectedDept)?.id &&
        departmentIds.push(__selectedDept(selectedProduct, selectedDept)?.id);
      dataobj?.masterBatchIds?.map((item) => masterBatchIds.push(item));
      dataobj?.masterBatchQtys?.map((item) => masterBatchQtys.push(item));
      // masterBatchIds = dataobj?.masterBatchIds;
      // masterBatchQtys = dataobj?.masterBatchQtys;
      masterBatchProductsMap = {
        ...masterBatchProductsMap,
        [key]: {
          ...dataobj.batches,
        },
      };
    } else {
      slaveProductId.push(selectedProduct?.product?.id);
      masterProductId.push(selectedProduct?.masterProduct?.id);
      orderQty.push(
        filterQty(batchQty, 0, index, selectedProduct?.product?.id)
      );
      comments.push(
        filterComment(comment, 0, index, selectedProduct.product?.id)
      );
      __selectedCostCenter(selectedProduct, selectedCostCenter)?.id &&
        costCenterIds.push(
          __selectedCostCenter(selectedProduct, selectedCostCenter)?.id
        );
      __selectedDept(selectedProduct, selectedDept)?.id &&
        departmentIds.push(__selectedDept(selectedProduct, selectedDept)?.id);
    }
  });

  const pouLineDto = {
    orderId: selectedItem?.orderId,
    internalOrderNo: selectedItem?.internalOrderNo,
    slaveProductId,
    masterProductId,
    orderQty,
    comments,
    costCenterIds,
    departmentIds,
    masterBatchIds,
    masterBatchQtys,
    masterBatchProductsMap,
  };

  const body = {
    orderId: [selectedItem?.orderId],
    internalOrderNo: [selectedItem?.internalOrderNo],
    reasonCode: "",
    pouLineDto: [pouLineDto],
  };
  console.log("body pou ", body);
  dispatch(
    onPouApprove(
      body,
      (res) => {
        handleApproveSuccess(
          res?.data?.pouOrderApproveDto,
          reloadData,
          dispatch,
          props,
          onApproveToast,
          getPOUCount
        );
      },
      (ERROR) => {
        handleApproveError(ERROR, showToast, Strings);
      }
    )
  );
}

function prepareReplenishProductData(
  selectedProduct: any,
  index: number,
  batchQty: any[],
  comment: any[]
) {
  return {
    comment: filterComment(comment, 0, index, selectedProduct.product?.id),
    id: selectedProduct.product?.id,
    qty: filterQty(batchQty, 0, index, selectedProduct.product?.id),
    type: selectedProduct?.orderLineDTO?.productType?.toUpperCase(),
  };
}

// Main function to handle screen 2 logic
function handleScreen2Logic(
  products: any[],
  batchQty: any[],
  comment: any[],
  showToast: (arg0: string, arg1: string) => void,
  dispatch:any,
  getUserPrice:any,
  setCheckoutData: (arg0: any[]) => void,
  setVisibleCheckout: (arg0: boolean) => void,
  Strings: { [x: string]: string }
) {
  const body: any[] = [];
  let selectedProducts = products.filter((item) => item.isSelected === true);
  if (selectedProducts.length === 0) {
    showToast(
      Strings["alert.select.vsr.product"],
      Strings["alert.select.product"]
    );
    return;
  }
  selectedProducts.forEach((selectedProduct, index) => {
    const replenishProduct = prepareReplenishProductData(
      selectedProduct,
      index,
      batchQty,
      comment
    );
    const data = {
      ...selectedProduct.product,
      availableQty: filterQty(batchQty, 0, index, selectedProduct.product?.id),
      replenishProducts: [replenishProduct],
      comments: replenishProduct.comment,
    };
    body.push(data);
  });
 
  const orderCheckoutPrice = body?.map((item: { id: any, availableQty?: any }) => ({
    id: item.id,
    qty: item.availableQty,
  }));
 dispatch(getUserPrice(orderCheckoutPrice));
  setCheckoutData(body);
  setVisibleCheckout(true);
}

export {
  addCostCenterDeptLogic,
  fillRequestQtyLogic,
  handleScreen1Logic,
  handleScreen2Logic,
  handleScreen3Logic,
};
