import React from "react";
import { Text, View, TextInput } from "react-native";
import styles from "./styles";
import { QtyController } from "../../../../Components";
import { COLORS, SIZES } from "../../../../Utils/theme";
import { hp } from "../../../../Utils/globalFunction";

const ProductDetailsItems = ({ title, value }) => {
  return (
    <View style={styles.productDetailsItemsContainer}>
      <Text style={styles.productDetailsItemsTitle}>{title}</Text>
      <Text style={styles.productDetailsItemsValue}>{value}</Text>
    </View>
  );
};

const ItemDetails = ({
  item,
  index,
  type,
  batchQty,
  Strings,
  screen,
  setBatchQty,
  comment,
  setComment,
  showComment = true,
  stockRoomDetail,
  onPendingItemQTYchange,
  showToast,
  isOutOfStock,
  singleProduct = false,
}: any) => {
  //item?.masterProduct.id
  const condation1 =
    screen == 3
      ? item?.masterProduct?.batchManagementEnabled == 1 ||
        item?.masterProduct?.expiryDateManagementenabled == 1
      : item?.orderLineDTO?.product?.batchManagementEnabled == 1 ||
        item?.orderLineDTO?.product?.expiryDateManagementenabled == 1 ||
        item?.product?.batchManagementEnabled == 1 ||
        item?.product?.expiryDateManagementenabled == 1;
  const condation2 =
    stockRoomDetail?.isBatchManagementEnabled ||
    stockRoomDetail?.isExpiryManagementEnabled;

  function filterQty(i, index, id) {
    const data = batchQty?.filter((item) => item?.index == i && item?.id == id);
    console.log("data", data[0]?.value - data[0]?.qty);
    return data?.length
      ? singleProduct
        ? data[0]?.value - data[0]?.qty
        : data[0]?.qty
      : 0;
  }
  function filterValue(i, index, id) {
    const data = batchQty?.filter(
      (item: { index: any; id: any }) => item?.index == i && item?.id == id
    );
    return data?.length ? data[0]?.value : 0;
  }
  function filterQtyLength(i, index, id) {
    const data = batchQty?.filter((item) => item?.index == i && item?.id == id);
    return data;
  }
  function filterComment(i, index, id) {
    const data = comment?.filter((item) => item?.index == i && item?.id == id);
    return data?.length ? data[0]?.comment : "";
  }

  function onChangeQty(i, index, item, v) {
    if (Number(v) == 0 && Number(used) == 1) {
      onPendingItemQTYchange(index, false);
    } else {
      onPendingItemQTYchange(index, true);
    }

    if (filterQtyLength(i, index, item?.product.id)?.length) {
      const dataindex = batchQty.findIndex((childitem: any) => {
        return childitem?.id == item?.product.id && childitem?.index == i;
      });
      let data = Object.assign([], batchQty);
      data[dataindex] = {
        ...data[dataindex],
        qty: v,
      };
      console.log("data", data[dataindex]);

      setBatchQty([...data]);
    } else {
      setBatchQty([
        ...batchQty,
        {
          index: i,
          itemIndex: index,
          qty: Number(v),
          id: item?.product.id,
        },
      ]);
    }
  }

  const used = batchQty.reduce((accumulator, i) => {
    if (i?.id === item?.product.id && i?.itemIndex === index) {
      const total = accumulator + Number(i["qty"]);
      return total;
    } else {
      return accumulator;
    }
  }, 0);

  const extractedNumber =
    screen == 2 ? item?.orderLineDTO.remainingQtyForDisplay.match(/\d+/) : "";
  const numberValue = extractedNumber ? parseInt(extractedNumber[0]) : null;
  let leftQty: number | undefined;

  if (screen == 2) {
    leftQty = (numberValue ? numberValue : item?.product?.availableQty) - used;
  } else if (screen == 1) {
    const hasApprovedBatch =
      item?.requestBatch?.length && condation1 && condation2;
    const checkAvl = item?.requestQuantity
      ? Number(item?.requestQuantity) - Number(item?.approvedQuantity)
      : item?.product?.availableQty;
    leftQty =
      (hasApprovedBatch ? item?.product?.availableQty : checkAvl) - used;
  } else {
    let extractedNumber;
    extractedNumber = item?.orderLineDTO?.orderedQtyForDisplay?.match(/\d+/);
    const numberValue = extractedNumber ? parseInt(extractedNumber[0]) : null;
    const hasAvailableBatches = item?.masterProduct?.batches?.some(
      (obj) => obj?.availableQty
    );
    leftQty =
      (hasAvailableBatches
        ? item?.masterProduct?.availableQty
        : numberValue || item?.masterProduct?.availableQty) - used;
  }

  let extractedNumberPOU: any;
  extractedNumberPOU = item?.orderLineDTO?.orderedQtyForDisplay?.match(/-?\d+/);
  const numberValuePOU = extractedNumberPOU
    ? parseInt(extractedNumberPOU[0])
    : 0;

  const ext = {
    marginVertical: hp(1),
    alignSelf: "center",
  };

  const __renderBatch = (batch: any, i: number) => {
    return (
      <View key={batch?.id}>
        {i == 0 && screen != 1 && showComment && __renderComment(ext)}
        <View style={styles.productDetailsContainer}>
          <ProductDetailsItems
            title={Strings["ime.batch.number"]}
            value={batch?.batchNo || batch?.batchProduct?.batchNo}
          />
          <ProductDetailsItems
            title={Strings["expiry.date"]}
            value={batch?.expiryDate || batch?.batchProduct?.expiryDate}
          />
        </View>
        <View style={styles.productDetailsContainer}>
          <ProductDetailsItems
            title={Strings["ime.avail.qty"]}
            value={
              screen == 1 ? batch?.availableQty || 0 : batch?.availableQty || 0
            }
          />
          <View
            style={[styles.cmtnqtyContainer, { marginTop: -SIZES.padding }]}
          >
            <QtyController
              limit={
                screen == 3 && numberValuePOU
                  ? Number(numberValuePOU) - Number(used)
                  : leftQty
              }
              onChange={(v: String) => {
                // if (batch?.batchProduct?.availableQty) {
                onChangeQty(i, index, item, Number(v));
                // }
              }}
              titleStyle={styles.qtyTitleStyle}
              inputValue={filterQty(i, index, item?.product.id)}
              disable={item?.product?.freeze || isOutOfStock}
              approval={true}
              // availableQty={batch?.requestedQty || batch?.availableQty}
              availableQty={
                batch?.approvedQty
                  ? Number(batch?.requestedQty) - Number(batch?.approvedQty)
                  : screen == 3
                  ? numberValuePOU && numberValuePOU <= batch?.availableQty
                    ? Number(numberValuePOU) - Number(used)
                    : batch?.requestedQty || batch?.availableQty
                  : batch?.requestedQty || batch?.availableQty
              }
              showToast={showToast}
              resetValue={filterValue(i, index, item?.product.id) || 0}
            />
          </View>
        </View>
      </View>
    );
  };
  const __renderComment = (extStyle = {}) => (
    <View style={styles.cmtnqtyContainer}>
      <Text style={styles.productDetailsItemsTitle}>
        {Strings["chemical.location.comments"]}
      </Text>
      <TextInput
        allowFontScaling={false}
        style={[styles.comment, extStyle]}
        placeholderTextColor={COLORS.alto}
        onChangeText={(text) => {
          if (filterComment(0, index, item?.product.id)) {
            const dataindex = comment.findIndex(
              (childitem: any) =>
                childitem?.id == item?.product.id && childitem?.index == 0
            );
            let data = Object.assign([], comment);
            data[dataindex] = {
              ...data[dataindex],
              comment: text,
            };
            setComment([...data]);
          } else {
            setComment([
              ...comment,
              {
                comment: text,
                id: item?.product.id,
                index: 0,
                itemIndex: index,
              },
            ]);
          }
        }}
        value={filterComment(0, index, item?.product.id)}
      />
    </View>
  );

  let extractedNumber2;
  extractedNumber2 = item?.orderLineDTO?.remainingQtyForDisplay?.match(/\d+/);
  const numberValue2 = extractedNumber2 ? parseInt(extractedNumber2[0]) : null;

  const __renderSingle = () => (
    <View style={styles.quantityContainer}>
      {screen !== 1 && showComment && __renderComment()}
      {screen != 1 && showComment && <View />}
      <View
        style={[
          styles.cmtnqtyContainer,
          { marginTop: SIZES.base },
          screen == 1 && {
            justifyContent: "flex-start",
            alignSelf: "flex-start",
            width: "100%",
          },
        ]}
      >
        <QtyController
          limit={leftQty}
          onChange={(v: String) => {
            if (Number(v) > 0) {
              onPendingItemQTYchange(index, true);
            } else {
              onPendingItemQTYchange(index, false);
            }
            if (filterQtyLength(0, index, item?.product.id)?.length) {
              const dataindex = batchQty.findIndex(
                (childitem: any) =>
                  childitem?.id == item?.product.id && childitem?.index == 0
              );
              let data = Object.assign([], batchQty);
              data[dataindex] = {
                ...data[dataindex],
                qty: v,
              };
              setBatchQty([...data]);
            } else {
              setBatchQty([
                ...batchQty,
                {
                  index: 0,
                  itemIndex: index,
                  qty: v,
                  id: item?.product.id,
                },
              ]);
            }
          }}
          titleStyle={styles.qtyTitleStyle}
          inputValue={filterQty(0, index, item?.product.id)}
          disable={item?.product?.freeze || isOutOfStock || singleProduct}
          approval={true}
          availableQty={
            screen == 1
              ? item?.requestQuantity
                ? item?.remainingQty || item?.requestQuantity
                : item?.product?.availableQty
              : screen == 3
              ? numberValuePOU
                ? numberValuePOU
                : item?.masterProduct.availableQty
              : numberValue2 || item?.product?.availableQty
          }
          showToast={showToast}
          resetValue={filterValue(0, index, item?.product.id)}
          screen={screen}
        />
      </View>
    </View>
  );

  const __renderBatchItems = () => {
    if (condation1 && condation2) {
      if (screen == 1) {
        console.log("check------123",
        item?.requestBatch?.length
        )
        if (item?.requestBatch?.length) {
          console.log("here---")
          if (item?.requestBatch?.length) {
            return item?.requestBatch.map((batch: any, i: any) =>
              Number(batch?.requestedQty) - Number(batch?.approvedQty)
                ? __renderBatch(batch, i)
                : null
            );
          } else {
            return __renderSingle();
          }
        } else {
          console.log("chec-----",
          item?.product?.batches?.length
          )
          if (item?.product?.batches?.length) {
            return item?.product?.batches?.map(
              (batch: any, i: any) =>
                __renderBatch(batch, i)
            );
          } else {
            return __renderSingle();
          }
        }
      } else if (screen == 2) {
        return __renderSingle();
      } else if (screen == 3) {
        if (
          item?.masterProduct?.batches?.length &&
          item?.masterProduct?.batches?.filter((obj: any) => obj?.availableQty)
            ?.length
        ) {
          return item?.masterProduct?.batches
            ?.filter((obj: any) => obj?.availableQty)
            .map((batch: any, i: any) => __renderBatch(batch, i));
        } else {
          return __renderSingle();
        }
      }
    } else {
      return __renderSingle();
    }
  };
  //console.log("itemitemitem---",item)
  return (
    <View style={styles.itemDetailsContainer}>
      <View style={styles.productDetailsContainer}>
        <ProductDetailsItems
          title={Strings["copy.move.vendor"]}
          value={item?.product?.vendorName}
        />
        <ProductDetailsItems
          title={Strings["ime.location"]}
          value={item?.product?.locationName}
        />
      </View>
      <View style={styles.productDetailsContainer}>
        <ProductDetailsItems
          title={Strings["ime.avail.qty"]}
          // value={
          //   screen == 1
          //     ? item?.product?.availableQtyForDisplay
          //     : screen == 3
          //     ? item?.masterProduct.availableQtyForDisplay
          //     :item?.product?.availableQtyForDisplay
          // }
          value={
            screen == 1
              ? `${item?.product?.availableQty} ${
                  item?.product?.uomManagementEnabled
                    ? item?.product?.stockRoomUOMUnit || ""
                    : ""
                }`
              : screen == 3
              ? `${item?.masterProduct.availableQty} ${
                  item?.masterProduct?.uomManagementEnabled
                    ? item?.masterProduct?.stockRoomUOMUnit || ""
                    : ""
                }`
              : `${item?.product?.availableQty} ${
                  item?.product?.uomManagementEnabled
                    ? item?.product?.stockRoomUOMUnit || ""
                    : ""
                }`
          }
        />
        <ProductDetailsItems
          title={Strings["OpenQty"] ? Strings["OpenQty"] : "OpenQty"}
          value={
            screen == 2
              ? item?.orderLineDTO?.remainingQtyForDisplay
              : screen == 3
              ? item?.orderLineDTO?.orderedQtyForDisplay
              : `${item?.remainingQty || item?.requestQuantity} ${
                  item?.product?.uomManagementEnabled
                    ? item?.product?.stockRoomUOMUnit || ""
                    : ""
                }`
          }
        />
      </View>
      {__renderBatchItems()}
    </View>
  );
};

export default ItemDetails;
