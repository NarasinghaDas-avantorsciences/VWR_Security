import React, { useState, useCallback, useEffect } from "react";
import { TouchableOpacity, View, FlatList, Text } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { useFocusEffect } from "@react-navigation/native";
import moment from "moment";
import { Header, Loader, NotificationComponent } from "../../../Components";
import { COLORS, FONTS } from "../../../Utils/theme";
import { Messages, News, Notifications } from "../../../Utils/images";
import {
  getNotificationList,
  getMessageList,
  getNewsList,
  clearAllCommunicationCenterData,
} from "../../../Redux/Action/communicationActions";
import styles from "./styles";
import CustomText from "../../../Components/CustomText";
const CommunicationCenter = (props: any) => {
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const limit = 10;
  const [newsOffSet, setNewsOffSet] = useState(0);
  const [notificationOffSet, setNotificationOffSet] = useState(0);
  const [messageOffSet, setMessageOffSet] = useState(0);
  const { dateFormat, timeFormat } = useSelector(
    (state: any) => state.userReducer
  );
  const [timeString, setTimeString] = useState("h:mm:ss A");

  const {
    notificationList,
    notificationCount,
    messagesList,
    messagesCount,
    newsList,
    newsCount,
    loader,
  } = useSelector((state: any) => state.communicationReducer);
  useEffect(() => {
    dispatch(clearAllCommunicationCenterData());
    setNotificationOffSet(0);
    setMessageOffSet(0);
    setNewsOffSet(0);
    if (messagesCount > 0) {
      setSelectedIndex(0);
    } else if (notificationCount > 0) {
      setSelectedIndex(1);
    } else if (newsCount > 0) {
      setSelectedIndex(2);
    }
    getData();
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (timeFormat?.toUpperCase() == "24Hours".toUpperCase())
        setTimeString("H:mm:ss");
      else setTimeString("h:mm:ss A");
    }, [])
  );

  const getData = async () => {
    await Promise.all([
      dispatch(
        getNotificationList(
          notificationOffSet * 10,
          notificationList?.data ?? []
        )
      ),
      dispatch(getMessageList(messageOffSet * 10, messagesList?.data ?? [])),
      dispatch(getNewsList(newsOffSet * 10, newsList?.data ?? [])),
    ]);
  };

  const onEndScrolling = async (tabIndex: number) => {
    var offset = 0;
    switch (tabIndex) {
      case 0:
        // console.log(messagesList?.data)
        let actuallCount = messagesList?.totalCount ?? 0;

        if (actuallCount > messagesList?.data?.length) {
          offset = messageOffSet + 1;
          await dispatch(getMessageList(offset * 10, messagesList?.data ?? []));
          setMessageOffSet(offset);
        } else {
          return;
        }
        break;
      case 1:
        let notificationFullCount = notificationList?.totalCount ?? 0;

        if (notificationFullCount > notificationList?.data?.length) {
          offset = notificationOffSet + 1;
          await dispatch(
            getNotificationList(offset * 10, notificationList?.data ?? [])
          );
          setNotificationOffSet(offset);
        } else {
          return;
        }
        break;
      case 2:
        let newsFullCount = newsList?.totalCount ?? 0;

        if (newsFullCount > newsList?.data?.length) {
          offset = newsOffSet + 1;
          await dispatch(getNewsList(offset * 10, newsList?.data ?? []));
          setNewsOffSet(offset);
        } else {
          return;
        }
        break;
    }
  };

  const MessageScreen = () => (
    <>
      {messagesList?.count == 0 ? (
        <View
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          <CustomText style={{ ...FONTS.title }}>
            {Strings["ime.scanner.No.messages.found"] ?? "No messages found"}
          </CustomText>
        </View>
      ) : (
        <FlatList
          onEndReached={() => onEndScrolling(0)}
          style={styles.flatlistContainer}
          data={messagesList?.data}
          keyExtractor={(item) => `${item?.id}`}
          renderItem={({ item, index }) => (
            <NotificationComponent
              icon={
                <Messages
                  fill={item?.status == 2 ? COLORS.gray : COLORS.scienceBlue}
                />
              }
              item={item}
              onPress={() => {
                props.navigation.navigate("Messages", {
                  item: item,
                  headerTitle: Strings["ime.messages"],
                });
              }}
              dateFormate={`${dateFormat?.date}, ${timeString}`}
            />
          )}
        />
      )}
    </>
  );

  const NotificationScreen = () => (
    <>
      {notificationList?.count == 0 ? (
        <View
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          <CustomText style={{ ...FONTS.title }}>
            No Notification found
          </CustomText>
        </View>
      ) : (
        <FlatList
          onEndReached={() => onEndScrolling(1)}
          style={styles.flatlistContainer}
          data={notificationList?.data}
          keyExtractor={(item) => `${item?.id}`}
          renderItem={({ item, index }) => (
            <NotificationComponent
              icon={
                <Notifications
                  fill={item?.markedAsRead ? COLORS.gray : COLORS.scienceBlue}
                />
              }
              item={item}
              onPress={() => {
                props.navigation.navigate("Messages", {
                  item: item,
                  headerTitle: Strings["ime.scanner.Get.Notified"],
                });
              }}
              dateFormate={`${dateFormat?.date}, ${timeString}`}
              // onPress={async () => {
              //   await dispatch(putNotificationRead(item?.id));
              //   props.navigation.navigate("ApprovalDetails");
              // }}
            />
          )}
        />
      )}
    </>
  );

  const NewsScreen = () => (
    <>
      {newsList?.count == 0 ? (
        <View
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          <CustomText style={{ ...FONTS.title }}>No news found</CustomText>
        </View>
      ) : (
        <FlatList
          onEndReached={() => onEndScrolling(2)}
          style={styles.flatlistContainer}
          data={newsList?.data}
          keyExtractor={(item) => `${item?.id}`}
          onEndReachedThreshold={0.05}
          renderItem={({ item, index }) => (
            <NotificationComponent
              icon={
                <News
                  fill={item?.status == 2 ? COLORS.gray : COLORS.scienceBlue}
                />
              }
              item={item}
              onPress={() =>
                props.navigation.navigate("News", {
                  item: item,
                  headerTitle: Strings["ime.news.and.updates"],
                })
              }
              dateFormate={`${dateFormat?.date}, ${timeString}`}
            />
          )}
        />
      )}
    </>
  );

  const tabs = [
    {
      name:
        Strings["ime.messages"]?.length > 10
          ? Strings["ime.messages"].substring(0, 10) + ".."
          : Strings["ime.messages"],
      id: 0,
      count: messagesCount == undefined ? 0 : messagesCount,
    },
    {
      name:
        (Strings["ime.scanner.Get.Notified"] ?? "Notifications")?.length > 14
          ? (Strings["ime.scanner.Get.Notified"] ?? "Notifications").substring(
              0,
              14
            ) + ".."
          : Strings["ime.scanner.Get.Notified"] ?? "Notifications",
      id: 1,
      count: notificationCount == undefined ? 0 : notificationCount,
    },
    {
      name:
        Strings["ime.news.and.updates"].length > 15
          ? Strings["ime.news.and.updates"].substring(0, 15) + ".."
          : Strings["ime.news.and.updates"],
      id: 2,
      count: newsCount == undefined ? 0 : newsCount,
    },
  ];
  const getTabs = () => {
    return (
      <View
        style={styles.tabContainer}
        accessible={true}
        accessibilityLabel="CommunicationCenter-tabs"
      >
        {tabs.map((v, i) => {
          return (
            <TouchableOpacity
              accessible={true}
              accessibilityLabel={`${v.name}-CommunicationCenter-tab-btn`}
              key={i}
              onPress={() => {
                setSelectedIndex(v.id);
              }}
              style={[
                styles.tabContentContainer,
                {
                  borderBottomColor:
                    selectedIndex == v.id ? COLORS.scienceBlue : COLORS.white,
                },
              ]}
            >
              <Text
                accessible={true}
                accessibilityLabel={`${v.name}-CommunicationCenter-tab-count`}
                style={
                  selectedIndex == v.id
                    ? styles.tabTitleText
                    : styles.unSelectedText
                }
              >
                {v.count}
              </Text>
              <Text
                accessible={true}
                accessibilityLabel={`${v.name}-CommunicationCenter-tab-title`}
                style={
                  selectedIndex == v.id
                    ? styles.tabTitleText
                    : styles.unSelectedText
                }
              >
                {v.name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Header
        title={Strings["communication.center"] ?? "Communication Center"}
        container={{ backgroundColor: COLORS.white }}
        onLeftIconPress={() => null}
        onRightIconPress={() => {
          dispatch(clearAllCommunicationCenterData());
          props.navigation.goBack();
        }}
        statusBar={false}
        statusBarColor={"white"}
        iconLeft={false}
        iconRight={true}
        titleStyle={{ color: COLORS.gray }}
        RightIcon={() => (
          <CustomText
            style={{
              ...FONTS.body,
              fontSize: FONTS.h2_1,
              color: COLORS.scienceBlue,
            }}
          >
            {Strings.close}
          </CustomText>
        )}
      />
      {getTabs()}
      {selectedIndex == 0 && MessageScreen()}
      {selectedIndex == 1 && NotificationScreen()}
      {selectedIndex == 2 && NewsScreen()}

      {/* Loader */}
      <Loader show={loader} />
    </View>
  );
};

export default CommunicationCenter;
