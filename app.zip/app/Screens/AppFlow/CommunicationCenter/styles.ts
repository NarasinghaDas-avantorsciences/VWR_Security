import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  tabContainer: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-around",
    borderBottomColor: COLORS.gray3,
  },
  tabContentContainer: {
    flexDirection: "row",
    borderBottomWidth: 2,
    paddingTop: hp(3),
    paddingBottom: hp(0.5),
    borderBottomColor: COLORS.white,
    paddingHorizontal: wp(1.5),
  },
  tabTitleText: {
    textTransform: "capitalize",
    paddingTop: SIZES.width <= 360 ? 5 : 0,
    paddingBottom: -2,
    fontSize: hp(1.7),
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    paddingHorizontal: wp(0.3),
  },
  unSelectedText: {
    color: COLORS.gray,
    fontFamily: FONTFAMILY.averta_regular,
    textTransform: "capitalize",
    paddingTop: SIZES.width <= 360 ? 5 : 0,
    paddingBottom: -2,
    fontSize: hp(1.7),
    paddingHorizontal: wp(0.3),
  },
  notificationContainer: {
    paddingRight: SIZES.padding,
    paddingVertical: SIZES.padding,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "center",
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray2,
  },
  contentContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  titleText: {
    ...FONTS.title,
    marginBottom: SIZES.base,
    width: SIZES.width * 0.8,
  },
  subjectText: {
    ...FONTS.body,
    color: COLORS.gray,
    marginBottom: SIZES.base,
    width: SIZES.width * 0.8,
  },
  timeText: {
    ...FONTS.body2,
    color: COLORS.gray,
  },
  flatlistContainer: {
    flexGrow: 1,
    marginBottom: SIZES.padding * 2,
    marginLeft: SIZES.padding,
  },
});
