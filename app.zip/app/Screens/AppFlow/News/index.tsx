import React, { useEffect } from "react";
import { View } from "react-native";
import { WebView } from "react-native-webview";
import { useDispatch, useSelector } from "react-redux";
import {
  getNewsCount,
  putNewsRead,
} from "../../../Redux/Action/communicationActions";
import styles from "./styles";
import { Header } from "../../../Components";
import { COLORS, FONTS, SIZES } from "../../../Utils/theme";
import CustomText from "../../../Components/CustomText";
import { Linking } from "react-native";

const News = (props: any) => {
  const { item } = props.route.params;
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);

  useEffect(() => {
    if (item?.status != 2) {
      markNewsAsRead();
    }
  });

  const markNewsAsRead = async () => {
    await dispatch(
      putNewsRead(item?.id, (val: boolean) => {
        if (val) {
          item.status = 2;
          item.markedAsRead = true;
          dispatch(getNewsCount());
        }
      })
    );
    await dispatch(getNewsCount());
  };

  const source = {
    html: item?.body,
  };

  return (
    <View style={styles.container}>
      <Header
        title={Strings["ime.news.and.updates"]}
        container={{ backgroundColor: COLORS.white }}
        onLeftIconPress={() => null}
        onRightIconPress={() => props.navigation.goBack()}
        statusBar={true}
        statusBarColor={"white"}
        iconLeft={false}
        iconRight={true}
        RightIcon={() => (
          <CustomText
            style={{
              fontSize: FONTS.h2,
              color: COLORS.scienceBlue,
              fontWeight: "500",
            }}
          >
            {Strings["close"]}
          </CustomText>
        )}
      />
      {item?.body ? (
        <WebView
          originWhitelist={["*"]}
          source={source}
          automaticallyAdjustContentInsets={false}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          decelerationRate="normal"
          startInLoadingState={true}
          scalesPageToFit={true}
          onShouldStartLoadWithRequest={(request) => {
            console.log("REQUEST URL: ", request);
            if (request.url !== "about:blank") {
              Linking.openURL(request.url);
              return false;
            } else return true;
          }}
        />
      ) : (
        <View style={{ marginHorizontal: SIZES.padding }}>
          <CustomText style={{ ...FONTS.title, color: COLORS.scienceBlue }}>
            {item.subject}
          </CustomText>
          <CustomText
            style={{
              ...FONTS.body,
              color: COLORS.black,
              marginVertical: SIZES.radius,
            }}
          >
            {item.description}
          </CustomText>
        </View>
      )}
    </View>
  );
};

export default News;
