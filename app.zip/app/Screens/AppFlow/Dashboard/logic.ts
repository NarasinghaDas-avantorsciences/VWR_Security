import { ApiConfig } from "../../../Service/Api";
import {
  getOutOfStock,
  getRunningLowStock,
  getOutOfProductList,
  clearStockLevelData,
  getRunningLowProductList,
} from "../../../Redux/Action/dashboardAction";
import {
  getOrgDetails,
  getOrgLevelCurrencyData,
  getStockroomDetail,
  setSelectedOrgandStockRoom,
} from "../../../Redux/Action/userAction";
import { getAccountDetails } from "../../../Redux/Action/accountAction";
import * as storage from "../../../Service/AsyncStoreConfig";
import { Alert } from "react-native";
import { pushNotificationAction } from "../../../Redux/Action/pushNotificationAction";

const getDashboardKPIsLogic = async (
  userToken: any,
  org: any,
  dispatch: (arg0: any) => void
) => {
  new ApiConfig().setToken(userToken, org);
  dispatch(getOutOfStock());
  dispatch(getRunningLowStock());
  dispatch(getStockroomDetail());
  dispatch(clearStockLevelData());
  dispatch(getOutOfProductList(0, []));
  dispatch(getRunningLowProductList(0, []));
};

const applyPushNotification = async (
  userId: string,
  setShowModal: any,
  dispatch: (arg0: any) => void,
  setShowPushLoader: any,
  Strings: any,
  internet: boolean
) => {
  //if (!internet) return;
  dispatch(
    pushNotificationAction(
      userId,
      true,
      true,
      true,
      true,
      async (data: boolean) => {
        if (data) {
          await storage.setItem(
            "show_notification_modal",
            JSON.stringify(true)
          );
          await storage.setItem(
            "enabled_push_notification",
            JSON.stringify(true)
          );
          await storage.setItem(
            "out_of_stock_notification_enabled",
            JSON.stringify(true)
          );
          await storage.setItem(
            "approvals_notification_enabled",
            JSON.stringify(true)
          );
          await storage.setItem(
            "running_low_notification_enabled",
            JSON.stringify(true)
          );
          setShowPushLoader(false);
          setShowModal(false);
        } else {
          setShowModal(false);
          setShowPushLoader(false);
          // if(internet){
          //   Alert.alert(
          //     Strings["ime.attention"],
          //     "Unable to register device token to server , please try again.",
          //     [
          //       {
          //         text: Strings["ok"],
          //         onPress: () => console.log("OK Pressed"),
          //       },
          //     ]
          //   );
          // }
        }
      }
    )
  );
};

export { getDashboardKPIsLogic, applyPushNotification };
