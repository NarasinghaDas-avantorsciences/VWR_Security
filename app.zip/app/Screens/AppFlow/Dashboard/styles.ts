import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
    width: "100%",
    alignItems: "center",
  },
  emptyContainer: { alignItems: "center", justifyContent: "center" },
  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },
  animatedSearchContainer: {
    width: "100%",
    marginLeft: wp(1),
  },
  searchContainer: {
    borderWidth: 0,
    backgroundColor: "#F5F5F5",
  },
  subHeaderContainer: {
    width: "100%",
    borderBottomColor: COLORS.alto,
    borderBottomWidth: 1,
    marginBottom: hp(1.25),
  },
  searchBarContainer: {
    paddingHorizontal: wp(3),
    marginTop: wp(0.5),
    marginBottom: wp(1.25),
  },
  mainSearchContainer: {
    marginBottom: hp(2),
  },
  kpiContainer: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "center",
    marginTop: hp(1),
    marginBottom: hp(0.7),
  },
  footerContainer: {
    flexDirection: "row",
    paddingHorizontal: wp(3),
    paddingVertical: hp(2),
  },
  flatlist: {
    paddingVertical: hp(1),
  },
  modalHeaderText: {
    ...FONTS.heading,
    color: COLORS.scienceBlue,
    marginBottom: SIZES.tip,
  },
  modalBodyText: {
    ...FONTS.title,
    fontFamily: FONTFAMILY.averta_regular,
    textAlign: "center",
    color: COLORS.black,
    marginVertical: SIZES.radius,
  },
  modalMainButton: {
    width: SIZES.width * 0.9 - SIZES.padding * 2,
    marginTop: SIZES.base,
  },
  modalSecondaryButton: {
    padding: SIZES.padding,
    width: SIZES.width * 0.9 - SIZES.padding * 2,
    alignItems: "center",
  },
  modalSecondaryButtonText: { ...FONTS.title, color: COLORS.gray },
  modalFooterText: {
    ...FONTS.body2,
    color: COLORS.gray,
    textAlign: "center",
    marginTop: SIZES.tip,
  },

  leftIconContainer: { marginRight: wp(4) },

  dataContainer: { paddingBottom: hp(10), marginHorizontal: 16 },

  leftIcon: { width: wp(20), height: wp(20) },

  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },

  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },

  qtyInfoContainer: { paddingVertical: hp(0.8), alignSelf: "flex-start" },

  itemSubHeaderStyle: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
  },

  itemContainerStyle: {
    marginVertical: hp(1.8),
    borderBottomWidth: 1,
    paddingBottom: hp(1),
    borderColor: COLORS.whiteSmoke,
  },

  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  itemChildContainer: {
    width: wp(45),
    marginVertical: wp(0.5),
    paddingVertical: 8,
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },
  cardRowContainer: {
    flexDirection: "row",
    flex: 1,
  },
});
