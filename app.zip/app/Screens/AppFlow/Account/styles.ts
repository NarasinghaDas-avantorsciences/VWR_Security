import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY } from "../../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  logountButton: {
    flex: 1,
    alignSelf: 'flex-end',
    margin: wp(6),
    borderWidth: 1,
    padding: wp(1.8),
    paddingVertical: wp(2.2),
    borderColor: COLORS.scienceBlue
  },
  title: {
    flex: 1,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_semibold,
    // position: "relative",
    color: COLORS.scienceBlue,
    textAlign: "center",
  },
  titleText: {
    fontSize: FONTS.h2_2,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.doveGray,
    fontWeight: '600'
  },
  contentText: {
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
    color: COLORS.doveGray,
    paddingVertical: wp(1),
    fontWeight: '400'

  },
  innerContainer: {
    paddingHorizontal: wp(5),
    paddingTop: wp(5)
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  unChecked: {
    width: wp(4.5),
    height: wp(4.5),
    borderWidth: 0.5,
    borderColor: COLORS.gray2,
    borderRadius: 4
  },
  marginTop: {
    marginTop: wp(3)
  },
  border: {
    borderBottomWidth: 0.7,
    borderBottomColor: COLORS.gray2,
    paddingTop: wp(3),
    paddingVertical: wp(2),
    marginHorizontal: wp(4),
    paddingHorizontal: wp(1)
  }
});
