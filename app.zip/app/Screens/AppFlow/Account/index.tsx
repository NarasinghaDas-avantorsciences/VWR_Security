import React, { useState, useEffect, useCallback } from "react";
import {
  TouchableOpacity,
  ScrollView,
  View,
  Alert,
  BackHandler,
} from "react-native";
import styles from "./styles";
import { Header } from "../../../Components";
import { COLORS, FONTS } from "../../../Utils/theme";
import { ToggleSwitch, Loader } from "../../../Components";
import { useSelector, useDispatch } from "react-redux";
import { clearAccountData, getAccountDetails } from "../../../Redux/Action/accountAction";
import * as storage from "../../../Service/AsyncStoreConfig";
import { SafeAreaView } from "react-native-safe-area-context";
import { setBiometrics } from "../../../Redux/Action/loginAction";
import CustomText from "../../../Components/CustomText";
import { logout } from "../../../Redux/Action/loginAction";
import { pushNotificationAction } from "../../../Redux/Action/pushNotificationAction";
import { hasNotificaitonPermission, requestUserPermissionBool } from "../../../Service/PushNotificationServiceHandler";
import { clearNavigationData } from "../../../Redux/Action/navigationRouteAction";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import ConfirmationAlert from "../../../Components/ConfirmationPopup";
import { useFocusEffect } from "@react-navigation/native";
import { orgRoomValue, stockRoomValue } from "../../../Components/Subheader/logic";
import { ModalToast } from "../../../Components/ModalToast";

const Account = (props: any) => {
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const userData = useSelector((state: any) => state.userReducer);
  const { confirmationAlertInfo } = useSelector(
    (state: any) => state.userReducer
  );
  const [isShowToastRef, setIsShowToast] = useState(false);
  const { languageList } = useSelector((state: any) => state.languageReducer);
  const profileData = useSelector((state: any) => state.accountReducer?.data);
  const [isChecked, setIsChecked] = useState(true);
  const [showLoader, setShowLoader] = useState(false);
  const [isApprovalOn, setIsApprovalOn] = useState(false);
  const [isKPIOn, setIsKPIOn] = useState(false);
  const [isRunningLowOn, setIsRunningLowOn] = useState(false);
  const [isBiometricsEnabled, setBioMetrics] = useState(false);
  const [langDesc, setLanguageDesc] = useState("");
  const { biometricsAvailable } = useSelector(
    (state: any) => state.loginReducer
  );
  const { org, selectedTitle, selectedSubTitle, selectedOrgId, selectedRoom } =
    useSelector((state: any) => state.userReducer);
  const [selectedRoomChild, setSelectedChildRoom] = useState<any>(null);
  const stockRoomsData = useSelector(
    (state: any) => state.userReducer?.stockRooms
  );

  useEffect(() => {
    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );
    return () => backHandler.remove();
  }, []);

  useFocusEffect(
    useCallback(() => {
      dispatch(setIsShowConfirmationAlert({}));
      getOrg()
    }, [])
  );

  const getOrg = () => {
    let dat = {};
    storage.getItem("org").then((res: any) => {
      const orgData = JSON.parse(res);
      const currentstockRooms = stockRoomsData;
      for (let i = 0; i < currentstockRooms?.stockroomHierarchy?.length; i++) {
        if (
          currentstockRooms?.stockroomHierarchy[i]?.id == orgData?.stockroomId
        ) {
          dispatch({
            type: "SUBTITLE",
            value: currentstockRooms?.stockroomHierarchy[i]?.stockroomName,
          });
          dat = {
            ...dat,
            selectedRoom: currentstockRooms?.stockroomHierarchy[i]?.id,
          };
        } else {
          for (
            let k = 0;
            k <
            currentstockRooms?.stockroomHierarchy[i]?.childStockroom?.length;
            k++
          ) {
            if (
              currentstockRooms?.stockroomHierarchy[i]?.childStockroom[k]?.id ==
              orgData?.stockroomId
            ) {
              dispatch({
                type: "SUBTITLE",
                value:
                  currentstockRooms?.stockroomHierarchy[i]?.childStockroom[k]
                    ?.stockroomName,
              });
              setSelectedChildRoom(k);
              dat = {
                ...dat,
                selectedRoom: currentstockRooms?.stockroomHierarchy[i]?.id,
                selectedRoomChild: k,
              };
            }
          }
        }
      }
    });
  };

  const backAction = () => {
    props.navigation.navigate("Dashboard");
    return true;
  };

  enum SwithchType {
    approve,
    kpi,
    running,
  }

  useEffect(() => {
    setShowLoader(true);
    intializeNotificationSwitches();
    getStoreData();
    selectedLAng();
  }, []);



  async function intializeNotificationSwitches() {
    let runningLowEnbl = (await storage.getItem(
      "running_low_notification_enabled"
    )) as string;
    const isRunningLowEnbl = JSON.parse(runningLowEnbl);
    setIsRunningLowOn(isRunningLowEnbl);

    const apprvlsEnbl = (await storage.getItem(
      "approvals_notification_enabled"
    )) as string;
    const isApprvlsEnbl = JSON.parse(apprvlsEnbl);
    setIsApprovalOn(isApprvlsEnbl);

    const OutStckEnbl = (await storage.getItem(
      "out_of_stock_notification_enabled"
    )) as string;
    const isOutStckEnbl = JSON.parse(OutStckEnbl);
    setIsKPIOn(isOutStckEnbl);

    const hasOsPermission = await hasNotificaitonPermission();
    // if (
    //   (isApprvlsEnbl || isOutStckEnbl || isRunningLowEnbl) &&
    //   !hasOsPermission
    // ) {
    //   Alert.alert(
    //     Strings["ime.attention"],
    //     "Push notifiation has been disable in your device. Please turn it on to recive further notifications",
    //     [
    //       {
    //         text: Strings["ok"],
    //         onPress: () => console.log("OK Pressed"),
    //       },
    //     ]
    //   );
    // }
    setShowLoader(false);
  }

  const toggleBioMetrics = async (value: boolean) => {
    setBioMetrics(value);
    dispatch(setBiometrics(value));
    await storage.setItem("biometrics", JSON.stringify(value));
  };

  const getStoreData = async () => {
    const biometrics = await storage.getItem("biometrics");
    const isBiometricsEnabled = JSON.parse(biometrics);
    setBioMetrics(isBiometricsEnabled);
  };

  async function checkEnablePushNotificaiton() {
    const isEnablednotification = await storage.getItem(
      "enabled_push_notification") as string;
    const boolEnabledNotificationValue = JSON.parse(isEnablednotification) as boolean;

    const hasOsPermission = await hasNotificaitonPermission();
    if (!boolEnabledNotificationValue) {
      if (hasOsPermission) {
        return true;
      } else if (await requestUserPermissionBool()){
        return true
      }else{
        return false
      }
    } else if (hasOsPermission) {
      return true;
    } else {
      return false
    }
  }


  function notificationToggleChanged(type: SwithchType, value: boolean) {
    setShowLoader(true);
    let approvalOn = isApprovalOn;
    let KPIOn = isKPIOn;
    let runningLow = isRunningLowOn;
    console.log(approvalOn, KPIOn, runningLow);
    switch (type) {
      case SwithchType.approve:
        approvalOn = value;
        break;
      case SwithchType.kpi:
        KPIOn = value;
        break;
      case SwithchType.running:
        runningLow = value;
        break;
    }
   storage.setItem(
      "enabled_push_notification",
      JSON.stringify(true)
    );
    dispatch(
      pushNotificationAction(
        profileData?.id,
        approvalOn,
        runningLow,
        KPIOn,
        true,
        async (data: boolean) => {
          setShowLoader(false);
          if (data) {
            switch (type) {
              case SwithchType.approve:
                await storage.setItem(
                  "approvals_notification_enabled",
                  JSON.stringify(value)
                );
                break;
              case SwithchType.kpi:
                await storage.setItem(
                  "out_of_stock_notification_enabled",
                  JSON.stringify(value)
                )
                break;
              case SwithchType.running:
                await storage.setItem(
                  "running_low_notification_enabled",
                  JSON.stringify(value)
                );
                break;
            }
          } else {
            switch (type) {
              case SwithchType.approve:
                setIsApprovalOn(!value);
                break;
              case SwithchType.kpi:
                setIsKPIOn(!value);
                break;
              case SwithchType.running:
                setIsRunningLowOn(!value);
                break;
            }
          }
        }
      )
    );
  }
  const selectedLAng = () => {
    storage.getItem("language").then((res) => {
      if (res) {
        for (let i = 0; i < languageList.length; i++) {
          if (languageList[i]?.languageName == res?.replace("/labels", ""))
            setLanguageDesc(languageList[i].languageDescription);
        }
      }
    });
  };
  const setlogout = () => {
    dispatch(clearNavigationData());
    dispatch(clearAccountData());
    dispatch(logout(true));
  };
  useEffect(() => {
    if (!!profileData) {
      setIsChecked(profileData.licenseAgreed);
    }
  }, [profileData]);

  return (
    <SafeAreaView
      style={styles.container}
      edges={["left", "right"]}
      accessible={true}
      accessibilityLabel="account-safearea-container"
    >
      <Header
        idLabel="my-account"
        title={Strings["my.account"]}
        container={{ backgroundColor: COLORS.white }}
        onLeftIconPress={() => null}
        onRightIconPress={() => props.navigation.goBack()}
        statusBar={true}
        statusBarColor={"white"}
        iconLeft={false}
        iconRight={true}
        RightIcon={() => (
          <CustomText
            style={{
              fontSize: FONTS.h2,
              color: COLORS.scienceBlue,
              fontWeight: "500",
            }}
            accessibilityLabel="account-right-icon-txt"
          >
            {Strings["close"]}
          </CustomText>
        )}
      />
      <ScrollView>
        <View
          style={styles.innerContainer}
          accessible={true}
          accessibilityLabel="account-inner-container"
        >
          <View style={styles.marginTop}>
            <CustomText
              style={styles.titleText}
              accessibilityLabel="account-loggedin-text"
            >
              {Strings["scanner.logged.in.as"] ?? "Logged in as"}
            </CustomText>
            <CustomText
              style={styles.contentText}
              accessibilityLabel="account-loggedin-id"
            >
              {profileData?.loginId}
            </CustomText>
          </View>
          <View style={styles.marginTop}>
            <CustomText
              style={styles.titleText}
              accessibilityLabel="account-first-name"
            >
              {Strings["ime.first.name"]}
            </CustomText>
            <CustomText
              style={styles.contentText}
              accessibilityLabel="account-first-name-value"
            >
              {profileData?.firstName}
            </CustomText>
          </View>
          <View style={styles.marginTop}>
            <CustomText
              style={styles.titleText}
              accessibilityLabel="account-last-name"
            >
              {Strings["ime.last.name"]}
            </CustomText>
            <CustomText
              style={styles.contentText}
              accessibilityLabel="account-last-name-value"
            >
              {profileData?.lastName}
            </CustomText>
          </View>
          <View style={styles.marginTop}>
            <CustomText
              style={styles.titleText}
              accessibilityLabel="account-organization"
            >
              {Strings["organization"]}
            </CustomText>
            <CustomText
              style={styles.contentText}
              accessibilityLabel="account-organization-value"
            >
              {orgRoomValue(org, selectedOrgId)}
            </CustomText>
            {/* <Text style={styles.contentText}>{userData?.org}</Text> */}
          </View>
          <View style={styles.marginTop}>
            <CustomText
              style={styles.titleText}
              accessibilityLabel="account-stockroom"
            >
              {Strings["stockroom"]}
            </CustomText>
            <CustomText
              style={styles.contentText}
              accessibilityLabel="account-stockroom-value"
            >
              {stockRoomValue(selectedRoomChild, stockRoomsData, selectedRoom)}
            </CustomText>
          </View>
          <View style={styles.marginTop}>
            <CustomText
              style={styles.titleText}
              accessibilityLabel="account-stockroom"
            >
              {Strings["language"]}
            </CustomText>
            <CustomText
              style={styles.contentText}
              accessibilityLabel="account-stockroom"
            >
              {!!langDesc ? langDesc : "English (North America)"}
            </CustomText>
            <CustomText
              style={[
                styles.contentText,
                { fontSize: FONTS.h1_6, paddingTop: 0 },
              ]}
              accessibilityLabel="account-stockroom-value"
            >
              {Strings["ime.scanner.myaccount.lang.msg"]}
            </CustomText>
          </View>
        </View>
        {biometricsAvailable && (
          <View style={styles.innerContainer}>
            <CustomText
              style={styles.titleText}
              accessibilityLabel="account-privacy"
            >
              {Strings["ime.scanner.Privacy"] ?? "Privacy"}
            </CustomText>
            <View style={styles.flexRow}>
              <CustomText
                style={styles.contentText}
                accessibilityLabel="account-login-biometrics"
              >
                {Strings["ime.scanner.Login.with.biometrics"] ??
                  "Login with biometrics"}
              </CustomText>
              <ToggleSwitch
                isEnabled={isBiometricsEnabled}
                onValueChange={(value) => {
                  toggleBioMetrics(value);
                }}
              />
            </View>
          </View>
        )}

        <View style={styles.innerContainer}>
          <CustomText
            style={styles.titleText}
            accessibilityLabel="account-push-notification"
          >
            {Strings["ime.scanner.Push.Notification"] ?? "Push Notification"}
          </CustomText>
          <CustomText
            style={styles.contentText}
            accessibilityLabel="account-push-notification-description"
          >
            {Strings["ime.scanner.push.notification.info"]}
          </CustomText>
        </View>
        <View style={[styles.innerContainer, styles.flexRow, styles.border]}>
          <CustomText
            style={styles.contentText}
            accessibilityLabel="account-approvals"
          >
            {Strings["ime.scanner.approvals"] ?? "Approvals"}
          </CustomText>
          <ToggleSwitch
            isEnabled={isApprovalOn}
            onValueChange={async () => {
              if (!isApprovalOn) {
                if (!(await checkEnablePushNotificaiton())) {
                  setIsShowToast(true)
                  setTimeout(() => setIsShowToast(false), 2000)
                  return
                }
              }
              let value = isApprovalOn
              setIsApprovalOn(!isApprovalOn)
              notificationToggleChanged(SwithchType.approve, !value);
              //Linking.openSettings();
            }}
          />
        </View>
        <View style={[styles.innerContainer, styles.flexRow, styles.border]}>
          <CustomText
            style={styles.contentText}
            accessibilityLabel="account-kpi-outofstock"
          >
            {Strings["ime.scanner.KPI.Out.of.Stock"] ?? "KPI - Out of Stock"}
          </CustomText>
          <ToggleSwitch
            isEnabled={isKPIOn}
            onValueChange={async () => {
              if (!isKPIOn) {
                if (!(await checkEnablePushNotificaiton())) {
                  setIsShowToast(true)
                  setTimeout(() => setIsShowToast(false), 2000)
                  return
                }
              }
              let value = isKPIOn
              setIsKPIOn(!isKPIOn)
              notificationToggleChanged(SwithchType.kpi, !value);
            }}
          />
        </View>
        <View style={[styles.innerContainer, styles.flexRow]}>
          <CustomText
            style={styles.contentText}
            accessibilityLabel="account-kpi-runninglow"
          >
            {Strings["ime.scanner.KPI.Running.Low"] ?? "Running Low"}
          </CustomText>
          <ToggleSwitch
            isEnabled={isRunningLowOn}
            onValueChange={async () => {
              if (!isRunningLowOn) {
                if (!(await checkEnablePushNotificaiton())) {
                  setIsShowToast(true)
                  setTimeout(() => setIsShowToast(false), 2000)
                  return
                }
              }

              let value = isRunningLowOn
              setIsRunningLowOn(!isRunningLowOn)
              notificationToggleChanged(SwithchType.running, !value);
            }}
          />
        </View>
        <TouchableOpacity
          onPress={setlogout}
          accessible={true}
          accessibilityLabel="logout_button"
          style={styles.logountButton}
        >
          <CustomText
            style={[styles.title]}
            accessibilityLabel="logout_button_label"
          >
            {Strings["logout"]}
          </CustomText>
        </TouchableOpacity>
      </ScrollView>
      <Loader show={showLoader} />
      {/* Toast */}
      <ModalToast
        isShow={isShowToastRef}
        onClose={() => setIsShowToast(false)}
        title={Strings["ime.attention"]}
        discription={'Push notifiation has been disable in your device. Please turn it on to recive further notifications'}
      />
      <ConfirmationAlert
        onTapNo={() => { }}
        onTapYes={() =>
          dispatch(
            setIsShowConfirmationAlert({
              isShow: false,
              data: confirmationAlertInfo?.data,
            })
          )
        }
        onBack={() => console.warn("AJJJJJ")}
      />
    </SafeAreaView>
  );
};

export default Account;
