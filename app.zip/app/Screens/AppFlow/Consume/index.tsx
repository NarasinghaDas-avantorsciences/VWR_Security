import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  View,
  BackHandler,
  TouchableOpacity,
  Platform,
  Keyboard,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import {
  useFocusEffect,
  useIsFocused,
  useNavigation,
} from "@react-navigation/native";
import RNHTMLtoPDF from "react-native-html-to-pdf";
import ReactNativeBlobUtil from "react-native-blob-util";
import Text from "../../../Components/CustomText";
import { HalfLoader, Loader } from "../../../Components/Loader";
import * as storage from "../../../Service/AsyncStoreConfig";
import {
  BottomSheetComponent,
  ConsumeParentBottomView,
  Footer,
  Header,
  Subheader,
  ClearSelectionAlert,
  ConsumeMaxConsumptionQtyPopup,
  ProductDetails,
  ScannerButton,
  OutlinedButton,
} from "../../../Components";
import {
  getConsumeReceipt,
  isDeviceTablet,
  isProductFreezed,
  hp,
} from "../../../Utils/globalFunction";
import {
  getProductDetails,
  getProductList,
  setProductLoader,
  emptyProductData,
  getOfflineProducts,
  setProductBatchLoader,
  getProductBatchDetails,
  getProductListFromBarcode,
} from "../../../Redux/Action/searchAction";
import { Toast } from "react-native-toast-message/lib/src/Toast";

import {
  getCostCentersList,
  getUserPrice,
  getUsersList,
  resetPriceState,
  setCostCentersList,
} from "../../../Redux/Action/replenishAction";
import {
  consumeStock,
  getDepartments,
  requestConsumeStock,
  setDepartments,
  setLoader,
} from "../../../Redux/Action/consumeAction";
import { onConsumeLogic, onPrimaryButtonPressLogic } from "./logic";
import { logout } from "../../../Redux/Action/loginAction";
import { saveDataToStorage } from "../../../Components/Subheader/logic";
import { Cross } from "../../../Utils/images";
import { SIZES } from "../../../Utils/theme";
import styles from "./styles";
import toaststyles from "../../../Components/Toast/styles";
import OfflineToast from "../../../Components/Offline";
import OfflineConsumeView from "./OfflineConsumeView";
import { useDebounceHook } from "../../../Hooks";
import OnlineConsumeView from "./OnlineConsumeView";
import { clearNavigationData } from "../../../Redux/Action/navigationRouteAction";
import { clearAccountData } from "../../../Redux/Action/accountAction";
import CustomToast from "./Toast";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import ConfirmationAlert from "../../../Components/ConfirmationPopup";
const Consume = (props: any) => {
  const isTablet = isDeviceTablet();
  const navigation = useNavigation();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { userPrice, isLoading } = useSelector((state: any) => state.replenishReducer);
  const [searchKey, setSearchKey] = useState("");
  const bottomSheetRef = useRef<any>(null);
  const toastBottomSheetRef = useRef<any>(null);
  const bottomSheetRefDetails = useRef<any>(null);
  const innerProductDetailsRef = useRef<any>(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const [childState, setChildState] = useState(null);
  const [defOfflineProducts, setDefOfflineProducts] = useState([]);
  const [offlineProducts, setOfflineProducts] = useState([]);
  const [offlineDuplicateProducts, setOfflineDuplicateProducts] =
    useState(null);
  const [isDataUpdating, setIsDataUpdating] = useState(false);

  const [currentOfflineProductsIndex, setCurrentOfflineProductsIndex] =
    useState(null);
  const [matchFoundProducts, setMatchFoundProducts] = useState([]);
  const [offlineBatchProducts, setOfflineBatchProducts] = useState([]);
  const [isBatchSaved, setIsBatchSaved] = useState(false);
  const [matchNotFoundProducts, setMatchNotFoundProducts] = useState([]);
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [isOrderView, setOrderView] = useState(false);
  const [orderData, setOrderData] = useState([]);
  const [orderPreviewData, setOrderPreviewData] = useState([]);
  const [consumeLoader, setConsumeLoader] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isConsumeView, setIsConsumeView] = useState(false);
  const [isVisibleClearOrder, setIsVisibleClearOrder] = useState(false);
  const [clearModalData, setClearModalData] = useState({
    title: "",
    buttonTitle: "",
    desc: "",
    buttonPress: () => {},
  });
  const [isShowWarn, setIsShowWarn] = useState(false);
  const [isShowAlert, setIsShowAlert] = useState(false);
  const [isVisibleMaxconsumptionPopup, setIsVisibleMaxconsumptionPopup] =
    useState(false);
  const dispatch = useDispatch<any>();

  const { internet } = useSelector((state: any) => state.loginReducer);
  const { productDetails, productDetailsLoading, loader, productBatchDetails } =
    useSelector((state: any) => state.searchReducer);
  const { confirmationAlertInfo } = useSelector(
    (state: any) => state.userReducer
  );
  const { data } = useSelector((state: any) => state.accountReducer);
  const [pageSize, setPageSize] = useState(10);
  const [page, setPage] = useState(1);
  const {
    stockRoomDetail,
    org_details,
    dateFormat,
    timeFormat,
    consumePrivilege,
    consumeCustomPrivilage,
    userSelectPrivilege,
  } = useSelector((state: any) => state.userReducer);
  const { userDataList, costCenterList: costCentersList } = useSelector(
    (state: any) => state.replenishReducer
  );
  const productsData = useSelector(
    (state: any) => state.searchReducer?.searchList
  );
  const profileData = useSelector((state: any) => state.accountReducer?.data);
  const { departments } = useSelector((state: any) => state.consumeReducer);
  const [userList, setUserList] = useState([]);
  const [costCenterList, setCostCenterList] = useState([]);
  const [departmentList, setDeapartmentList] = useState([]);
  const [userValue, setUserValue] = useState("");
  const [costValue, setCostValue] = useState("");
  const [depratmentValue, setDepartmentValue] = useState("");
  const isFocused = useIsFocused();
  const [refresh, doRefresh] = useState(false);
  const [offlineCollection, showOfflineCollection] = useState(false);
  const debouncedSearchTerm = useDebounceHook(searchKey, 800);

  const [toastData, setToastData] = useState(null);
  const [newCostArray, setNewCostArray] = useState([]);
  const [newDepArray, setNewDeptArray] = useState([]);
  const [pdfFilePath, setPdfFilePath] = useState("");
  useEffect(() => {
    const unsubscribe = props.navigation.addListener("focus", () => {});
    if (isFocused) {
      resetData();
    }

    if (pdfFilePath.length > 0) {
      setConsumeLoader(false);
      setTimeout(() => {
        ReactNativeBlobUtil.ios.previewDocument(pdfFilePath);
      }, 200);
      setPdfFilePath("");
    }

    return unsubscribe;
  }, [isFocused]);

  const resetData = () => {
    getStorageData();
    setIsSuccess(false);
    setToastData(null);
    setOrderData([]);
    setOrderPreviewData([]);
    setOrderView(false);
    setIsConsumeView(false);
    setUserList([]);
    setCostCenterList([]);
    setDeapartmentList([]);
    setNewCostArray([]);
    setNewDeptArray([]);
    setUserValue("");
    setSearchKey("");
    setCostValue("");
    setDepartmentValue("");
    setIsShowAlert(false);
    setIsShowWarn(false);
    setIsVisibleMaxconsumptionPopup(false);
    dispatch(emptyProductData());
    dispatch(setCostCentersList());
    dispatch(setDepartments());
    dispatch(resetPriceState());
  };
  useEffect(() => {
    doRefresh(!refresh);
  }, []);

  useEffect(() => {
    if (!internet) {
      showOfflineCollection(true);
      setOfflineDuplicateProducts(null);
      setMatchFoundProducts([]);
      setMatchNotFoundProducts([]);
      setOfflineBatchProducts([]);
      setIsBatchSaved(false);
      if (orderData?.length) {
        props.navigation.goBack();
      }
    } else {
      if (!offlineProducts?.length) {
        showOfflineCollection(false);
      }
    }
  }, [internet]);
  const getStorageData = async () => {
    try {
      setOfflineProducts([]);
      setDefOfflineProducts([]);
      setCurrentOfflineProductsIndex(null);
      setOfflineDuplicateProducts(null);
      setMatchFoundProducts([]);
      setOfflineBatchProducts([]);
      setMatchNotFoundProducts([]);
      setIsBatchSaved(false);
      setIsDataUpdating(false);

      await storage.getItem("consume_offline_data").then((res: any) => {
        if (res?.length) {
          const dataJSON = JSON.parse(res);
          if (dataJSON?.length) {
            setOfflineProducts([...dataJSON]);
            setDefOfflineProducts([...dataJSON]);
          } else showOfflineCollection(!internet);
        } else showOfflineCollection(!internet);
      });
    } catch (error) {}
  };
  useEffect(() => {
    if (!!offlineProducts.length) {
      showOfflineCollection(true);
    }
  }, [offlineProducts]);
  useEffect(() => {}, [defOfflineProducts]);
  useEffect(() => {
    if (!!isConsumeView) {
      dispatch(getUsersList());
    }
  }, [isConsumeView]);
  useFocusEffect(
    useCallback(() => {
      dispatch(setIsShowConfirmationAlert({}));
    }, [])
  );
  // useEffect(() => {
  //   const handleBackPress = () => {
  //     setIsConsumeView(false);
  //     props.navigation.goBack();
  //     return true; // Return true to indicate that the event has been handled
  //   };
  //   BackHandler.addEventListener("hardwareBackPress", handleBackPress);
  //   return () => {
  //     BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
  //   };
  // }, []);

  useEffect(() => {
    const backAction = async () => {
      let asyncData;
      await storage.getItem("consumeCount").then((res) => {
        asyncData = res;
      });

      if (Number(asyncData) > 0 || searchKey?.length > 0) {
        dispatch(
          setIsShowConfirmationAlert({
            isShow: true,
            data: confirmationAlertInfo?.data,
          })
        );
      } else {
        setIsConsumeView(false);
        props.navigation.goBack();
      }
      return true;
    };
    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );
    return () => backHandler.remove();
  }, []);

  useEffect(() => {
    if (searchKey == "" && orderData?.length) {
      setOrderView(true);
    } else {
      setOrderView(false);
      setIsConsumeView(false);
      setOrderPreviewData([]);
    }
    if (debouncedSearchTerm) {
      dispatch(emptyProductData());
      setPage(1);
      dispatch(getProductList(debouncedSearchTerm));
    }
  }, [debouncedSearchTerm]);
  useEffect(() => {
    if (userValue !== "") {
      getConstCenters();
      getAllDepartment();
    }
  }, [userValue]);

  useEffect(() => {
    if (userSelectPrivilege) {
      if (userDataList?.length) {
        let usersArray = [];
        userDataList.map((item, index) => {
          usersArray.push({
            id: item.id,
            title: item.firstName + " " + item.lastName,
            selected:
              userDataList?.length == 1 ? true : item.id == profileData?.id,
            //  userDataList?.length == 1,
          });
        });
        setUserList(usersArray);
        let user = userDataList.filter(
          (item, index) => item?.id == profileData?.id
        )[0];
        setUserValue(
          userDataList?.length == 1
            ? userDataList[0].firstName + " " + userDataList[0].lastName
            : !!user
            ? user?.firstName + user?.lastName
            : ""
        );
      }
    } else {
      let usersArray = [];
      usersArray.push({
        id: profileData?.id,
        title: profileData?.firstName + " " + profileData?.lastName,
        selected: true,
      });
      setUserList(usersArray);

      setUserValue(profileData?.firstName + profileData?.lastName);
    }
  }, [userDataList]);
  useEffect(() => {
    if (costCentersList?.length) {
      let ccArray = [];
      costCentersList.map((item, index) => {
        ccArray.push({
          id: item.id,
          title: item.costCenterName,
          selected: costCentersList?.length == 1,
        });
      });
      setCostCenterList(ccArray);
      setCostValue(
        costCentersList?.length == 1 ? costCentersList[0].costCenterName : ""
      );
    } else {
      setCostCenterList([]);
      setCostValue("");
    }
  }, [costCentersList]);
  useEffect(() => {
    if (departments?.length) {
      let dptArray = [];
      departments.map((item, index) => {
        dptArray.push({
          id: item.id,
          title: item.departmentName,
          selected: departments?.length == 1,
        });
      });
      setDeapartmentList(dptArray);
      setDepartmentValue(
        departments?.length == 1 ? departments[0].departmentName : ""
      );
    } else {
      setDeapartmentList([]);
      setDepartmentValue("");
    }
  }, [departments]);
  const getConstCenters = () => {
    const user = userList?.filter((item) => item.selected)[0];
    setCostCenterList([]);
    setCostValue("");
    !!user && dispatch(getCostCentersList({ id: user?.id }));
  };
  const checkifBatchEnabled = (item) => {
    let value = false;
    let product = item;
    if (
      !!stockRoomDetail?.isBatchManagementEnabled &&
      !!product?.batchManagementEnabled
    ) {
      value = true;
    }
    return value;
  };
  const checkifExpiryEnabled = (item) => {
    let value = false;
    let product = item;
    if (
      !!stockRoomDetail?.isExpiryManagementEnabled &&
      !!product?.expiryDateManagementenabled
    ) {
      value = true;
    }
    return value;
  };
  const getAllDepartment = () => {
    const user = userList?.filter((item) => item.selected)[0];
    setDeapartmentList([]);
    !!user && dispatch(getDepartments({ id: user?.id }));
  };
  const getSelectedProducts = () => {
    return orderData?.filter((dat) => dat.selected);
  };
  const checkifTheItemExistInOrder = (id: any, barcode?: any) => {
    if (!!offlineCollection) {
      return offlineProducts?.some((item) => item.catalogNo == barcode);
    } else return orderData?.some((item) => item.id == id);
  };
  const checkifTheBatchItemExistInOrder = (value: any, batchId?: any) => {
    return orderData.some((item) => {
      if (
        item.catalogNo == value ||
        item.vendorCatalogNo == value ||
        item.custCatalogNo == value
      ) {
        return item.batches.some((batch) => batch.id === batchId);
      }
      return false;
    });
  };
  const onChildStateUpdate = (child) => {
    setChildState(child);
  };
  const removeBatchItem = async (prdt: any) => {
    let offlineBatch = [...offlineBatchProducts];
    let index = offlineBatch.findIndex((item) => item.id == prdt.id);
    offlineBatch.splice(index, 1);
    setOfflineProducts(offlineBatch);
    setOfflineBatchProducts(offlineBatch);
    let isAllUpdated = offlineBatch?.every(
      (item) => item.batchSaved
    ); /**Check if all the batch products are updated or not */
    if (isAllUpdated) setIsBatchSaved(true);
    bottomSheetRef.current.close();
    if (offlineBatch?.length == 0) {
      if (matchFoundProducts?.length) {
        setIsConsumeView(true);
        showOfflineCollection(false);
        setDefOfflineProducts?.(false);
        setOrderPreviewData?.(matchFoundProducts);
        setOrderData?.(matchFoundProducts);
      } else {
        navigation.navigate("Dashboard");
      }
    }
  };
  const confirmOnlineAddBatch = () => {
    const { comments, actualQty, id, batches } = childState;
    let order = [...orderData];
    /**
     * Check if the batch product already added into the item, then add the new batch to the order under the same product
     */
    let orderDataIndex = orderData.findIndex(
      (item) => item.id === selectedItem.id
    );
    let item = { ...selectedItem };
    item.selected = true;
    item.actualQty = actualQty != null ? actualQty : 0;

    if (batches?.length) {
      if (orderDataIndex != -1) {
        item.actualQty =
          parseFloat(orderData[orderDataIndex].actualQty) +
          parseFloat(actualQty);
        item.batches = [...orderData[orderDataIndex].batches, batches[0]];
        console.warn("oder 2 ", item.batches);
      } else {
        item.batches = batches.filter((i, j) => i.actualQty > 0);
      }
    }
    if (orderDataIndex == -1) {
      if (order.length > 0) {
        order.reverse();
        order.push(item);
        order.reverse();
      } else order.push(item);
    } else {
      order.splice(orderDataIndex, 1, item);
    }
    let data = null;
    order.find((item) => {
      if (
        stockRoomDetail?.isMaximumConsumptionEnabled &&
        item?.maxConsumptionQuantity != null
      )
        if (!stockRoomDetail.isOverConsume) {
          if (item?.actualQty > item?.maxConsumptionQuantity) {
            data = { showWarn: true, showAlert: false };
          }
        } else data = { showWarn: false, showAlert: true };
    });
    if (!!data) setIsShowWarn(data.showWarn);

    setOrderData(order);
    setChildState(null);
    dispatch(emptyProductData());
    setSearchKey("");
    setOrderView(true);
    const consumePriceData = order?.map((item: { id: any,actualQty?:any }) => ({
      id: item.id,
      qty: item.actualQty, 
    }));
    dispatch(getUserPrice(consumePriceData));
  };
  const mergeAndRemoveDuplicates = (array1, array2) => {
    const mergedArray = [...array1, ...array2];

    const uniqueItems = mergedArray.reduce((acc, item) => {
      const exists = acc.some((existingItem) => existingItem.id === item.id);
      if (!exists) {
        acc.push(item);
      }
      return acc;
    }, []);

    return uniqueItems;
  };

  const confirmOfflineAddBatch = async () => {
    /**Getting the updated batches for the selected item and replace with the batch product item where id is same and updatethe batchproduct array*/

    const { actualQty, id, batches } = childState;
    let offlineBtPrdt = await mergeAndRemoveDuplicates(
      offlineBatchProducts,
      []
    );
    let item = selectedItem;
    item.selected = true;
    item.batchSaved = true;
    item.actualQty = actualQty != null ? actualQty : 0;
    if (batches?.length) {
      item.batches = batches;
    }
    let index = offlineBtPrdt.findIndex((item) => item.id == id);
    offlineBtPrdt.splice(index, 1, item);

    setOfflineBatchProducts(offlineBtPrdt);
    setChildState(null);
    let isAllUpdated = offlineBtPrdt?.every(
      (item) => item.batchSaved
    ); /**Check if all the batch products are updated or not */
    if (isAllUpdated) setIsBatchSaved(true);
  };
  const onPressConfirm = () => {
    if (offlineCollection) {
      confirmOfflineAddBatch();
    } else if (
      isShowAlert &&
      childState.actualQty > selectedItem.maxConsumptionQuantity &&
      selectedItem.maxConsumptionQuantity != null
    ) {
      setIsVisibleMaxconsumptionPopup(true);
    } else {
      confirmOnlineAddBatch();
    }
  };

  const onPressConsume = () => {
    onConsumeLogic(
      selectedProducts,
      showToast,
      consumeSuccessCallBack,
      stockRoomDetail,
      userValue,
      costValue,
      depratmentValue,
      orderData,
      dateFormat,
      checkifBatchEnabled,
      checkifExpiryEnabled,
      consumeCustomPrivilage,
      data?.userType,
      isShowAlert,
      setIsShowAlert,
      setIsVisibleMaxconsumptionPopup,
      Strings
    );
  };
  const onPressRequest = () => {
    onConsumeLogic(
      selectedProducts,
      showToast,
      consumeSuccessCallBack,
      stockRoomDetail,
      userValue,
      costValue,
      depratmentValue,
      orderData,
      dateFormat,
      checkifBatchEnabled,
      checkifExpiryEnabled,
      consumeCustomPrivilage,
      data?.userType,
      isShowAlert,
      setIsShowAlert,
      setIsVisibleMaxconsumptionPopup,
      Strings
    );
  };
  const consumeToast = (
    type: string = "alertToast",
    text1: string,
    text2: string,
    duration = 4000,
    onHideToast: any,
    onPressBtn: any,
    buttonTitle: any
  ) => {
    setToastData({
      text1,
      text2,
      onHideToast,
      onPressBtn,
      buttonTitle,
    });
    toastBottomSheetRef.current.open();
    setTimeout(() => {
      toastBottomSheetRef.current.close();
    }, duration);
  };
  const resetOfflineData = async () => {
    await saveDataToStorage("consume_offline_data", []);
  };
  const consumeSuccessCallBack = async (params: any) => {
    setIsSuccess(true);
    let userId = userList?.find((item) => item.selected)?.id;
    params["userId"] = userId;
    setConsumeLoader(true);
    if (consumeCustomPrivilage == "request" && data?.userType != "SUPER_USER") {
      dispatch(
        requestConsumeStock(
          params,
          async (data: any) => {
            resetOfflineData();
            setConsumeLoader(false);
            showToast(
              Strings["ime.scanner.REQUEST.STOCK.CONSUME"],
              Strings["ime.scanner.Successfully.requested.products"],
              3000,
              () => {
                checkoutComplete();
              }
            );
          },
          async (label: any) => {
            setConsumeLoader(false);
          }
        )
      );
    } else {
      dispatch(
        consumeStock(
          params,
          async (data: any) => {
            resetOfflineData();
            setConsumeLoader(false);
            consumeToast(
              "alertApprovalsBottomToast",
              Strings["ime.scanner.STOCK.CONSUMED"],
              Strings["ime.scanner.Your.products.were.consumed.successfully."],
              6000,
              () => {
                checkoutComplete();
              },
              () => {
                onPressSaveRecipt({
                  res: data,
                  consumedProducts: getSelectedProducts(),
                  departmentName: depratmentValue,
                  costCenterName: costValue,
                  customerShipNo: stockRoomDetail?.customerShipNo,
                  soldTo: stockRoomDetail?.soldTo,
                  dateFormat: dateFormat,
                  timeFormatString:
                    timeFormat?.toUpperCase() == "24Hours".toUpperCase()
                      ? "H:mm:ss"
                      : "h:mm:ss A",
                });
              },
              Strings["ime.save.receipt"] ?? "Save Receipt"
            );
          },
          async (label: any) => {
            setConsumeLoader(false);
          }
        )
      );
    }
  };
  const setlogout = () => {
    dispatch(clearNavigationData());
    dispatch(clearAccountData());
    dispatch(logout());
  };
  const checkoutComplete = () => {
    setConsumeLoader(false);
    setOrderData([]);
    setIsConsumeView(false);
    setOrderPreviewData([]);
    if (consumePrivilege && data?.userType != "SUPER_USER") {
      setlogout();
    } else {
      navigation.navigate("Dashboard");
    }
  };
  const onPressSaveRecipt = async (data: any) => {
    try {
      const pdfOptions = {
        html: getConsumeReceipt(
          data,
          org_details.orgName,
          stockRoomDetail.stockroomName,
          org_details.showPrice && stockRoomDetail?.isConsumeShowPrice
        ),
        fileName: `pdf_${data.res[0]?.transactionId}`,
        directory: "Documents",
      };
      const file = await RNHTMLtoPDF.convert(pdfOptions);
      if (file?.filePath) {
        if (Platform.OS === "android") {
          setTimeout(() => {
            ReactNativeBlobUtil.android.actionViewIntent(
              file?.filePath,
              "application/pdf"
            );
          }, 800);
        } else {
          setConsumeLoader(true);
          //ReactNativeBlobUtil.ios.previewDocument(file?.filePath ?? "");
          setPdfFilePath(file?.filePath ?? "");
          if (Platform.OS == "ios") {
            setTimeout(() => {
              toastBottomSheetRef.current.close();
            }, 100);
          }
        }
      }
    } catch (error) {}
  };
  const onPressClearOrder = async () => {
    if (!!offlineCollection) {
      await saveDataToStorage("consume_offline_data", []);
      setOfflineProducts([]);
      setDefOfflineProducts([]);
      setCurrentOfflineProductsIndex(null);
      setOfflineDuplicateProducts(null);
      setMatchFoundProducts([]);
      setOfflineBatchProducts([]);
      setMatchNotFoundProducts([]);
      showOfflineCollection(false);
      setIsBatchSaved(false);
    } else {
      setOrderView(false);
      setIsConsumeView(false);
    }
    setIsVisibleClearOrder(false);
    navigation.goBack();
  };
  const onPressYes = () => {
    setIsShowAlert(false);
    setIsShowWarn(false);
    setIsVisibleMaxconsumptionPopup(false);
    !!selectedItem && !!childState && confirmOnlineAddBatch();
  };
  const onPressNo = () => {
    setIsShowAlert(false);
    setIsShowWarn(false);
    setIsVisibleMaxconsumptionPopup(false);
  };

  const _renderProductDetails = (itemDetailsRef: any) => (
    <ProductDetails
      itemDetailsRef={itemDetailsRef}
      productDetailsList={productDetails}
      isShowPrice={stockRoomDetail?.isConsumeIndividual}
    />
  );

  const getBatchValidation = () => {
    let availableQtyDisalbed = childState?.batches?.every((item) => {
      return parseInt(item?.availableQty) == 0;
    });

    let actualQtyDisabled = false;
    childState?.batches?.some((item) => {
      let qty = !!item?.actualQty ? parseInt(item?.actualQty) : 0;
      if (qty != 0) {
        actualQtyDisabled = !!checkIfQtyExceeded(qty);
        return true;
      } else actualQtyDisabled = true;
    });
    return availableQtyDisalbed || actualQtyDisabled || !childState?.batches;
  };
  const tapOnFooterMainBtn = async () => {
    await onPrimaryButtonPressLogic(
      selectedProducts,
      showToast,
      isConsumeView,
      onPressConsume,
      setIsConsumeView,
      dateFormat,
      checkifBatchEnabled,
      checkifExpiryEnabled,
      stockRoomDetail,
      isShowAlert,
      setIsShowAlert,
      setIsVisibleMaxconsumptionPopup,
      consumeCustomPrivilage,
      onPressRequest,
      data?.userType,
      setOrderPreviewData,
      Strings
    );
  };

  const errorCallBack = (err) => {
    if (err?.errorMessage) {
      Toast.show({
        type: "alertToast",
        text1: err?.errorMessage,
      });
    } else {
      Toast.show({
        type: "alertToast",
        text1: Strings["ime.attention"],
        text2: "Error occured while fetching the batch",
      });
    }
  };
  const onPressBatchProductItem = async (item: any, batchId: any) => {
    dispatch(setProductBatchLoader(true));
    await dispatch(
      getProductBatchDetails(
        item?.id ?? "",
        (data: any) => {
          dispatch(setProductBatchLoader(false));
          console.log(data);
          let batches = [];
          batches = data.filter((i: any) => i.id == batchId);
          console.log(batches);
          item["batches"] = batches;
          if (batches?.length) {
            setChildState(null);
            setSelectedItem(item);
            bottomSheetRef?.current?.open();
          }
        },
        (error: any) => {
          dispatch(setProductBatchLoader(false));
          errorCallBack(error);
        }
      )
    );
  };
  const checkIfQtyExceeded = () => {
    if (
      stockRoomDetail?.isMaximumConsumptionEnabled &&
      selectedItem?.maxConsumptionQuantity != null
    )
      if (stockRoomDetail.isOverConsume) {
        return false;
      } else
        return childState?.actualQty > selectedItem?.maxConsumptionQuantity;
    else false;
  };
  const checkIfQtyExceededForSelectedProducts = () => {
    let flag = false;
    selectedProducts?.forEach((item) => {
      if (
        stockRoomDetail?.isMaximumConsumptionEnabled &&
        item?.maxConsumptionQuantity != null &&
        !stockRoomDetail.isOverConsume &&
        item?.actualQty > item?.maxConsumptionQuantity
      ) {
        flag = true;
        return;
      }
    });
    return flag;
  };

  const showToast = (
    text1: string,
    text2: string,
    duration: any,
    onHideToast?: any,
    onPressBtn?: any
  ) => {
    // Toast.show({
    //   type: "alertToast",
    //   text1: text1,
    //   text2: text2,
    //   position: "bottom",
    //   bottomOffset: SIZES.padding * 2,
    //   visibilityTime: duration,
    //   onHide: onHideToast,
    // });
    setToastData({
      text1,
      text2,
      onHideToast,
    });
    toastBottomSheetRef.current.open();
    setTimeout(
      () => {
        toastBottomSheetRef.current.close();
      },
      !!duration ? duration : 1800
    );
  };
  const getConsumeToastView = () => {
    return (
      <View style={toaststyles.main}>
        <View style={toaststyles.inner}>
          <View>
            <Text style={toaststyles.bottomTitle}>{toastData?.text1}</Text>
            <Text style={toaststyles.des}>{toastData?.text2}</Text>
            <View style={toaststyles.buttonContainers}>
              <OutlinedButton
                title={toastData?.buttonTitle}
                onChangeBtnPress={() => {
                  toastData?.onPressBtn();
                }}
                mainContainerStyle={toaststyles.outlineBtnContainer}
                mainTextStyle={toaststyles.buttonTitle}
              />
            </View>
          </View>
          <TouchableOpacity
            onPress={() => {
              toastBottomSheetRef.current.close();
            }}
          >
            <Cross height={hp(1.7)} width={hp(1.7)} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  const getAlertToast = () => {
    return (
      <View style={toaststyles.main}>
        <View style={toaststyles.inner}>
          <View style={{ flex: 1 }}>
            <Text style={toaststyles.tite}>{toastData?.text1}</Text>
            <Text style={toaststyles.des}>{toastData?.text2}</Text>
          </View>
          <TouchableOpacity
            onPress={() => {
              toastBottomSheetRef.current.close();
            }}
          >
            <Cross height={hp(1.7)} width={hp(1.7)} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  const resetProductData = async (value) => {
    dispatch(setProductLoader(value));
    dispatch(emptyProductData());
  };

  const consumeButtonTitle = consumeLoader ? (
    <HalfLoader />
  ) : consumeCustomPrivilage == "request" && data?.userType != "SUPER_USER" ? (
    Strings["request"]
  ) : (
    Strings["consume"]
  );
  const selectedProducts = getSelectedProducts();
  const userId = userList?.find((item) => item.selected)?.id;

  useFocusEffect(
    useCallback(() => {
      // resetData();
      dispatch(
        setIsShowConfirmationAlert({
          isShow: false,
          data: confirmationAlertInfo?.data,
          consumeCount: selectedProducts?.length,
        })
      );
    }, [selectedProducts?.length])
  );

  const getCount = () => {
    let count = selectedProducts?.length;
    storage.setItem("consumeCount", JSON.stringify(count));
    // if (Number(count) <= 0) {
    //   storage.removeData("consumeCount");
    // } else {
    //   storage.setItem("consumeCount", JSON.stringify(count));
    // }
    return count;
  };
  const isConsume = !(
    consumeCustomPrivilage == "request" && data?.userType != "SUPER_USER"
  );
  const isDisabled = () => {
    // return productDetailsLoading ||
    // isProductFreezed(selectedItem) ||
    return isConsume && selectedItem?.batches?.length
      ? getBatchValidation()
      : !childState?.actualQty ||
          childState?.actualQty == 0 ||
          checkIfQtyExceeded();
  };
  const batchFetchSuccess = (data: any, batchId: any) => {
    onPressBatchProductItem(data, batchId);
  };
  const getProductFromApi = async (searchKey: any, pageSize: any) => {
    dispatch(
      getProductListFromBarcode(
        searchKey,
        pageSize,
        async (res: any) => {
          // if (res?.data[0]?.catalogNo == searchKey) {
          if (
            res?.data[0]?.catalogNo == searchKey ||
            res?.data[0]?.vendorCatalogNo == searchKey ||
            res?.data[0]?.custCatalogNo == searchKey
          ) {
            // renderItemFromBarcode(res?.data[0]);
            setChildState?.(null);
            await setSelectedItem(res?.data[0]);
            bottomSheetRef?.current?.open();
            dispatch(setLoader(false));
          } else {
            Toast.show({
              type: "alertToast",
              text1: Strings["ime.scanner.error.occured.msg"],
              text2: "Product does not exist!",
              position: "bottom",
              bottomOffset: SIZES.padding * 2,
            });
            dispatch(setLoader(false));
          }
        },
        (res: any) => {
          dispatch(setLoader(false));

          console.log(res);
        }
      )
    );
  };
  const batchFetchFailed = () => {};
  return (
    <View
      accessible={true}
      accessibilityLabel={"main_cointainer"}
      style={styles.container}
    >
      <Header
        title={Strings?.["consume"]}
        onLeftIconPress={() => {
          Keyboard.dismiss();
          props.navigation.getParent("Drawer").openDrawer();
        }}
        statusBar={true}
        statusBarColor={"blue"}
        iconLeft={true}
        iconRight={true}
      />
      {!internet && (
        <View
          style={{
            alignItems: "center",
          }}
        >
          <OfflineToast login={false} />
        </View>
      )}
      <Subheader />
      {defOfflineProducts.length > 0 || offlineCollection ? (
        <OfflineConsumeView
          isConsume={isConsume}
          from="consume"
          setSearchKey={setSearchKey}
          setIsShowWarn={setIsShowWarn}
          setOrderData={setOrderData}
          setChildState={setChildState}
          getStorageData={getStorageData}
          setIsBatchSaved={setIsBatchSaved}
          isBatchSaved={isBatchSaved}
          setProducts={setOfflineProducts}
          setOrderPreviewData={setOrderPreviewData}
          products={offlineProducts}
          navigation={navigation}
          currentIndex={currentOfflineProductsIndex}
          setCurrentIndex={setCurrentOfflineProductsIndex}
          setIsVisibleClearOrder={setIsVisibleClearOrder}
          showOfflineCollection={showOfflineCollection}
          checkifTheItemExistInOrder={checkifTheItemExistInOrder}
          showToast={showToast}
          setOrderView={setOrderView}
          setIsConsumeView={setIsConsumeView}
          matchFoundProducts={matchFoundProducts}
          offlineDuplicateProducts={offlineDuplicateProducts}
          setOfflineDuplicateProducts={setOfflineDuplicateProducts}
          offlineBatchProducts={offlineBatchProducts}
          matchNotFoundProducts={matchNotFoundProducts}
          setMatchNotFoundProducts={setMatchNotFoundProducts}
          setMatchFoundProducts={setMatchFoundProducts}
          setOfflineBatchProducts={setOfflineBatchProducts}
          setClearModalData={setClearModalData}
          onPressClearOrder={onPressClearOrder}
          checkifBatchEnabled={checkifBatchEnabled}
          checkifExpiryEnabled={checkifExpiryEnabled}
          setSelectedItem={setSelectedItem}
          bottomSheetRef={bottomSheetRef}
          setIsDataUpdating={setIsDataUpdating}
          setDefOfflineProducts={setDefOfflineProducts}
          defOfflineProducts={defOfflineProducts}
        />
      ) : (
        <OnlineConsumeView
          checkifTheBatchItemExistInOrder={checkifTheBatchItemExistInOrder}
          setOrderView={setOrderView}
          setIsConsumeView={setIsConsumeView}
          batchFetchSuccess={batchFetchSuccess}
          batchFetchFailed={batchFetchFailed}
          isConsume={isConsume}
          uSerPriceData={userPrice}
          isOrderView={isOrderView}
          isConsumeView={isConsumeView}
          setUserValue={setUserValue}
          userValue={userValue}
          userList={userList?.sort((a, b) => {
            return a.title.localeCompare(b.title);
          })}
          showToast={showToast}
          userDataList={userDataList}
          setCostValue={setCostValue}
          costValue={costValue}
          costCenterList={costCenterList}
          userId={userId}
          newCostArray={newCostArray}
          setCostCenterList={setCostCenterList}
          setNewCostArray={setNewCostArray}
          costCentersList={costCentersList}
          setDepartmentValue={setDepartmentValue}
          depratmentValue={depratmentValue}
          departmentList={departmentList}
          newDepArray={newDepArray}
          setNewDeptArray={setNewDeptArray}
          offlineCollection={offlineCollection}
          orderPreviewData={orderPreviewData}
          bottomSheetRefDetails={bottomSheetRefDetails}
          setDeapartmentList={setDeapartmentList}
          searchKey={searchKey}
          setSearchKey={setSearchKey}
          checkifBatchEnabled={checkifBatchEnabled}
          checkifExpiryEnabled={checkifExpiryEnabled}
          pageSize={pageSize}
          productsData={productsData}
          checkifTheItemExistInOrder={checkifTheItemExistInOrder}
          setChildState={setChildState}
          setSelectedItem={setSelectedItem}
          bottomSheetRef={bottomSheetRef}
          selectedItem={selectedItem}
          selectedItemId={selectedItemId}
          setIsShowWarn={setIsShowWarn}
          setIsShowAlert={setIsShowAlert}
          setUserList={setUserList}
          orderData={orderData}
          setOrderData={setOrderData}
          departments={departments}
          setPage={setPage}
          page={page}
        />
      )}
      {isShowWarn && checkIfQtyExceededForSelectedProducts() && (
        <Text style={styles.warningText}>
          {stockRoomDetail?.maxConsumptionText}
        </Text>
      )}
      {!offlineCollection && !defOfflineProducts.length && isOrderView && (
        <Footer
          mainButtonDisabled={
            consumeLoader ||
            (!!isConsumeView && !selectedProducts?.length) ||
            checkIfQtyExceededForSelectedProducts()
          }
          mainbuttonTitle={
            isConsumeView ? consumeButtonTitle : Strings["im.next"]
          }
          secondaryButtonTitle={Strings["ime.scanner.clear"] ?? "Clear"}
          secondaryButtonDisabled={!orderData.length}
          count={getCount()}
          mainButtonStyle={null}
          mainButtonTextStyle={null}
          onChangePrimaryBtnPress={() => tapOnFooterMainBtn()}
          onChangeSecondaryBtnPress={() => {
            setIsShowAlert(false);
            setIsShowWarn(false);
            setIsVisibleMaxconsumptionPopup(false);
            setIsVisibleClearOrder(true);
            setClearModalData({
              title: Strings["ime.scanner.Clear.this.order"],
              buttonTitle: Strings["ime.scanner.Clear.Order"],
              desc: Strings[
                "ime.scanner.All.products.in.this.order.will.be.removed."
              ],
              buttonPress: onPressClearOrder,
            });
          }}
          mainContainerStyle={styles.footerMainContainer}
          outlinedBtnTextStyle={styles.outlinedBtnText}
          outlinedBtnContainerStyle={styles.outlinedBtnContainer}
        />
      )}
      <ProductDetails
        itemDetailsRef={bottomSheetRefDetails}
        productDetailsList={productDetails}
        closeModal={() => {
          bottomSheetRefDetails.current.close();
        }}
        isShowPrice={stockRoomDetail?.isConsumeIndividual}
      />
      <BottomSheetComponent
        bottomSheetRef={bottomSheetRef}
        height={SIZES.height - (isTablet ? SIZES.padding : SIZES.padding * 2)}
        dragFromTopOnly={true}
      >
        <ConsumeParentBottomView
          isConsume={isConsume}
          styles={styles}
          offlineCollection={offlineCollection}
          selectedItem={selectedItem}
          selectedItemId={selectedItemId}
          innerProductDetailsRef={innerProductDetailsRef}
          dispatch={dispatch}
          getProductDetails={getProductDetails}
          setProductLoader={setProductLoader}
          checkifBatchEnabled={checkifBatchEnabled}
          checkifExpiryEnabled={checkifExpiryEnabled}
          setSelectedItem={setSelectedItem}
          bottomSheetRefDetails={bottomSheetRefDetails}
          isProductFreezed={isProductFreezed}
          onChildStateUpdate={onChildStateUpdate}
          setIsShowWarn={setIsShowWarn}
          setIsVisibleMaxconsumptionPopup={setIsVisibleMaxconsumptionPopup}
          onPressConfirm={onPressConfirm}
          isDisabled={isDisabled()}
          setIsShowAlert={setIsShowAlert}
          isShowWarn={isShowWarn}
          bottomSheetRef={bottomSheetRef}
          removeBatchItem={removeBatchItem}
        />
        {_renderProductDetails(innerProductDetailsRef)}
      </BottomSheetComponent>
      <ClearSelectionAlert
        isShow={isVisibleClearOrder}
        didCloseModal={() => {
          setIsVisibleClearOrder(false);
        }}
        outlinedButtonTitle={Strings["ime.cancel"]}
        mainButtonTitle={clearModalData?.buttonTitle}
        didMainButtonTitleClicked={clearModalData?.buttonPress}
        didOutlinedButtonClicked={() => setIsVisibleClearOrder(false)}
        orderTitle={clearModalData?.title}
        orderDesc={clearModalData?.desc}
      />

      <ConsumeMaxConsumptionQtyPopup
        isShow={isVisibleMaxconsumptionPopup}
        didCloseModal={() => {
          setIsVisibleClearOrder(false);
        }}
        outlinedButtonTitle={Strings["no"]}
        mainButtonTitle={Strings["yes"]}
        didMainButtonTitleClicked={onPressYes}
        didOutlinedButtonClicked={onPressNo}
        orderTitle={""}
        orderDesc={stockRoomDetail?.maxConsumptionText}
      />
      {!defOfflineProducts.length && !offlineCollection && (
        <ScannerButton
          scanBatch={true}
          mainButtonStyle={
            isOrderView ? styles.scannerBtnOrder : styles.scannerBtn
          }
          onBarcodeDetected={async (barcode) => {
            let bcodes = barcode.split("*UI#");
            if (bcodes.length === 1) {
              // await resetProductData(!!bcodes[0]);
              setIsShowAlert(false);
              setIsShowWarn(false);
              // setSearchKey(bcodes[0]);
              // dispatch(getProductList(bcodes[0], pageSize));
              await getProductFromApi(bcodes[0], pageSize);
            } else {
              setSearchKey("");
              setIsConsumeView(false);
              setOrderView(false);
              /**Check if the batch already added */
              if (!checkifTheBatchItemExistInOrder(bcodes[0], bcodes[1])) {
                dispatch(setProductBatchLoader(true));

                const data = await new Promise((resolve, reject) => {
                  dispatch(
                    getOfflineProducts(
                      bcodes[0],
                      async (res: any, productId: string) => {
                        resolve(res);
                      },
                      (res: any, productId: string) => {
                        reject(res);
                      }
                    )
                  );
                });
                if (data?.[0]) {
                  batchFetchSuccess(data[0], bcodes[1]);
                } else {
                  dispatch(setProductBatchLoader(false));

                  batchFetchFailed();
                }
              } else {
                showToast(
                  Strings["ime.scanner.error.occured.msg"],
                  Strings["ime.scanner.Item.already.exists.in.the.order"],
                  3000,
                  () => {}
                );
              }
            }
          }}
        />
      )}
      {/* Your other components */}
      <CustomToast
        bottomSheetRef={toastBottomSheetRef}
        dragFromTopOnly={false}
        onClose={toastData?.onHideToast}
      >
        {isSuccess
          ? consumeCustomPrivilage == "request" &&
            data?.userType != "SUPER_USER"
            ? getAlertToast()
            : getConsumeToastView()
          : getAlertToast()}
      </CustomToast>

      <ConfirmationAlert
        onTapNo={() => {}}
        onTapYes={async () => {
          console.warn("SETTING");
          await storage.removeData("consumeCount");

          resetData();
          dispatch(
            setIsShowConfirmationAlert({
              isShow: false,
              data: confirmationAlertInfo?.data,
            })
          );
          setIsConsumeView(false);
          navigation.navigate("Dashboard");
          // props.navigation.goBack();
        }}
        onBack={() => {}}
      />
      <Loader show={isDataUpdating || loader || productBatchDetails || isLoading} />
    </View>
  );
};
export default Consume;
