import {
  ScrollView,
  View,
  TouchableOpacity,
  FlatList,
  Alert,
  BackHandler,
} from "react-native";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { Cross, OfflineEdit, OfflineDelete } from "../../../Utils/images";
import { COLORS, FONTFAMILY, FONTS } from "../../../Utils/theme";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import Text from "../../../Components/CustomText";
import {
  ConsumeBatchListItem,
  Footer,
  ListItem,
  QtyController,
  ScannerButton,
  TextInputComponent,
} from "../../../Components";
import { useDispatch, useSelector } from "react-redux";
import {
  getOfflineProducts,
  getProductBatchDetails,
  setProductBatchLoader,
} from "../../../Redux/Action/searchAction";
import styles from "./OfflineConsumeViewStyle";
import { addItemsToOrderList } from "../../../Redux/Action/replenishAction";
import { saveDataToStorage } from "../../../Components/Subheader/logic";
import { useFocusEffect, useIsFocused } from "@react-navigation/native";
import {
  onDeleteItemLogic,
  onNextProcessLogic,
  onPressProcessLogic,
  onSyncPressLogic,
  onUpdateItemLogic,
  updateItemQtyLogic,
  updateProductItemLogic,
} from "./logic";
import { getBatches } from "../../../Redux/Action/stockTransfer";
import AddBatch from "../../../Components/ConsumeAddBatch";
import { setProductLoader } from "../../../Redux/Action/consumeAction";

interface OfflineConsumeView {
  products: any;
  setProducts: any;
  setIsBatchSaved: any;
  setOrderPreviewData?: any;
  currentIndex: any;
  setCurrentIndex: any;
  getStorageData: any;
  setIsVisibleClearOrder: any;
  isConsume: any;
  showOfflineCollection: any;
  showToast: any;
  checkifTheItemExistInOrder: any;
  matchFoundProducts: any;
  matchNotFoundProducts: any;
  offlineBatchProducts: any;
  setMatchNotFoundProducts: any;
  setMatchFoundProducts: any;
  setOfflineBatchProducts: any;
  setClearModalData: any;
  onPressClearOrder: any;
  checkifBatchEnabled: any;
  checkifExpiryEnabled: any;
  from: any;
  isBatchSaved: any;
  offlineDuplicateProducts: any;
  setOfflineDuplicateProducts: any;
  setSelectedItem?: any;
  bottomSheetRef?: any;
  setChildState?: any;
  setIsShowWarn?: any;
  setSearchKey?: any;
  navigation?: any;
  setOrderData?: any;
  setIsConsumeView?: any;
  setOrderView?: any;
  setIsDataUpdating?: any;
  setDefOfflineProducts?: any;
  defOfflineProducts?: any;
}

const OfflineConsumeView = (props: OfflineConsumeView) => {
  const {
    products,
    setProducts,
    setIsBatchSaved,
    offlineDuplicateProducts,
    setOfflineDuplicateProducts,
    setOrderPreviewData,
    setOrderData,
    currentIndex,
    setCurrentIndex,
    getStorageData,
    setIsVisibleClearOrder,
    isConsume,
    showOfflineCollection,
    checkifTheItemExistInOrder,
    matchFoundProducts,
    matchNotFoundProducts,
    offlineBatchProducts,
    setMatchNotFoundProducts,
    setMatchFoundProducts,
    setOfflineBatchProducts,
    setClearModalData,
    onPressClearOrder,
    checkifBatchEnabled,
    checkifExpiryEnabled,
    setSelectedItem,
    bottomSheetRef,
    isBatchSaved,
    setChildState,
    from,
    setIsShowWarn,
    navigation,
    showToast,
    setIsConsumeView,
    setSearchKey,
    setOrderView,
    setIsDataUpdating,
    setDefOfflineProducts,
    defOfflineProducts,
  } = props;
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const SYNC_COMPLETE = strings["ime.scanner.Sync.Complete"];
  const PRODUCT_MATCH = strings["ime.scanner.Product.Match"];
  const BATCH_DETAILS_SAVED = strings["ime.scanner.Batch.Details.Saved"];
  const SYNCING_OFFLINE_DATA = strings["ime.scanner.Syncing.Offline.Data"];
  const FOUND_INAVLID_PRODUCT_MESSAGE =
    strings[
      "ime.scanner.Some.entries.require.additional.information.Tap.Process.to.review.these.entries.now"
    ];
  const FOUND_DUPLICATE_PRODUCT_MESSAGE =
    "Inventory Manager has found duplicate scanned products.";
  const FOUND_VALID_BATCH_PRODUCT_MESSAGE =
    strings[
      "ime.scanner.Inventory.Manager.found.a.match.but.the.item.requires.additional.information."
    ];
  const FOUND_VALID_PRODUCT_MESSAGE =
    from == "consume"
      ? strings[
          "ime.scanner.Inventory.Manager.has.synced.offline.data.Tap.Next.to.proceed.with.the.Consume.Process"
        ]
      : strings[
          "ime.scanner.Inventory.Manager.found.a.match.Tap.Next.to.proceed.with.the.Replenish.Process"
        ];
  const SYNC_IN_PROGRESS_MESSAGE =
    strings[
      "ime.scanner.Inventory.Manager.is.currently.syncing.offline.data.Some.entries.may.require.additional.information"
    ];
  const PROCESS_BUTTON_TITLE = strings["ime.scanner.Process"];
  const SYNC_BUTTON_TITLE = strings["ime.scanner.Sync"];
  const NEXT_BUTTON_TITLE = "Next";

  const [totalCount, setTotal] = useState(0);
  const [removedCount, setRemovedTotal] = useState(0);
  const [processView, setProcessView] = useState(false);
  const [batchArray, setBatchArray] = useState([]);
  const [qty, setQty] = useState([]);

  const [isLoop, setIsLoop] = useState(false);
  const [issyncing, setIssyncing] = useState(false);
  const [editView, setEditView] = useState(false);
  const [selectedItemIndexForEdit, setSelectedItemIndexForEdit] = useState(0);
  const [showProcessModal, setshowProcessModal] = useState(false);
  const isFocused = useIsFocused();
  let isBackPressed = false;
  let selectedIndex = 1;
  let prodarray = [];

  const [modalData, setModalData] = useState({
    title: "",
    message: "",
    buttonTitle: SYNC_BUTTON_TITLE,
    onClick: () => {
      onSyncPress();
    },
  });
  const { internet } = useSelector((state: any) => state.loginReducer);
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);

  const resetData = async () => {
    /**Resetting all the data from this component to initial value  */
    setIssyncing(false);
    setProcessView(false);
    setEditView(false);
    setTotal(0);
    setModalData({
      title: SYNCING_OFFLINE_DATA,
      message: SYNC_IN_PROGRESS_MESSAGE,
      buttonTitle: SYNC_BUTTON_TITLE,
      onClick: onSyncPress,
    });
    setshowProcessModal(false);
    if (
      !issyncing &&
      (matchNotFoundProducts.length ||
        matchFoundProducts.length ||
        offlineDuplicateProducts ||
        offlineBatchProducts.length)
    ) {
      /**Redirect to the dashbaord while the network was disconnected when the above mentioed array has items in it. Items present in the any of these arrays means that the sync proces has been completed and processed the data once */
      // navigation.navigate("Dashboard");
    }
    /**Reset the state only if the sync process is ongoing while the network was disconnected */
  };
  const handleBackButtonPress = () => {
    isBackPressed = true;
  };
  useEffect(() => {
    BackHandler.addEventListener("popstate", handleBackButtonPress);

    return () => {
      BackHandler.removeEventListener("popstate", handleBackButtonPress);
    };
  }, []);

  useEffect(() => {
    if (!internet) {
      /**Handle if the network is turned off */
      if (issyncing) {
        /**if network is turned off and the syncing process is ongoing , then  just reset the scanned list without any redirection*/
        resetData();
        getStorageData();
        setTotal(0);
        setIsLoop(false);
        setRemovedTotal(0);
        setIssyncing(false);
        setEditView(false);
        setProcessView(false);
        setModalData({
          title: SYNCING_OFFLINE_DATA,
          message: SYNC_IN_PROGRESS_MESSAGE,
          buttonTitle: SYNC_BUTTON_TITLE,
          onClick: onSyncPress,
        });
        setshowProcessModal(false);
      } else {
        /**If network turned off and syncing has been completed, then we need to move to the dashboard */
        setIsLoop(false);
        // getStorageData();
        // resetData();
        if (currentIndex != null) navigation.goBack();
      }
    }
  }, [internet]);
  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {});
    if (isFocused) {
      setTotal(0);
      setIsLoop(false);
      setRemovedTotal(0);

      setIssyncing(false);
      setEditView(false);
      setProcessView(false);
      setIsDataUpdating(false);
      setModalData({
        title: SYNCING_OFFLINE_DATA,
        message: SYNC_IN_PROGRESS_MESSAGE,
        buttonTitle: SYNC_BUTTON_TITLE,
        onClick: onSyncPress,
      });
      setshowProcessModal(false);
    }
    return unsubscribe;
  }, [isFocused]);

  const setBatchView = async () => {
    /**To display the batch listing screen */
    setshowProcessModal(false);
    onPressProcess("batch");
  };

  const selectedProducts = products?.length
    ? products?.filter((item: any, index: any) => item?.selected)
    : [];
  const itemFooter = () => {
    return (
      <View
        accessible={true}
        accessibilityLabel={"consume_offline_item_footer"}
        style={styles.itemFooter}
      />
    );
  };
  const updateItemQty = async (val: any, index: any) => {
    updateItemQtyLogic(
      products,
      setProducts,
      val,
      index,
      saveDataToStorage,
      from,
      matchNotFoundProducts
    );
  };
  const updateQtyForDuplicates = async (
    val: any,
    parentIndex: any,
    itemIndex: any
  ) => {
    /**It updates the Qty for the original item in the duplicate list */
    let array = [...offlineDuplicateProducts];
    array[parentIndex][itemIndex].actualQty = val;
    array[parentIndex][itemIndex].selectedQty = val;

    setOfflineDuplicateProducts(array);
  };
  const updateProductItem = (val: any, index: any) => {
    updateProductItemLogic(products, setProducts, val, index);
  };
  const toggleSelectItem = (index: any) => {
    let updatedProducts = [...products];
    updatedProducts[index].selected = !updatedProducts[index].selected;
    updatedProducts[index].isSelected = !updatedProducts[index].isSelected;
    setProducts(updatedProducts);
  };
  const checkIfAllSelected = () => {
    return products?.every((item: any) => item.selected);
  };
  const errorCallBack = (err: any) => {
    // if (err?.errorMessage) {
    //   Toast.show({
    //     type: "alertToast",
    //     text1: err?.errorMessage,
    //   });
    // } else {
    //   Toast.show({
    //     type: "alertToast",
    //     text1: "Attention",
    //     text2: "Error occured while fetching the batch",
    //   });
    // }
  };
  const toggleSelectAll = (isAllSelected: any) => {
    const updatedProducts = products?.map((item: any) => ({
      ...item,
      selected: !isAllSelected,
      isSelected: !isAllSelected,
    }));
    setProducts(updatedProducts);
  };

  const processSelectedProducts = async (array: any) => {
    /**Calling the search function  */
    array.reverse();
    for (const [index, item] of array.entries()) {
      if (isBackPressed) {
        setIsLoop(false);
        break;
      } else {
        setIsLoop(true);
        try {
          await searchProduct(item, index);
        } catch (err) {}
      }
    }
  };

  const setFoundData = async (
    item: any,
    isFound: boolean,
    isBatchFound?: boolean,
    res?: any
  ) => {
    /**Once the execution of the item from the list has been completed, that response has to be set to the state arrays as per condition */
    await new Promise((resolve) => setTimeout(resolve, 300));
    const updatedItem = {
      ...res,
      actualQty: item.actualQty,
      selectedQty: item.actualQty,
      selected: true,
      isSelected: true,
      batchSaved: false,
      handled: false,
    };
    if (isBatchFound) {
      /**
       * If the scanned item was a batch  product it has to be set to state array -> offlineBatchProducts
       * */
      if (item.batchCode) {
        /**
         * If batchCode exists in the item means the scanned item is a barcode of a specific batch
         * Then we need to create a new key "scannedBatch" and add to the offlineBatchProducts
         */
        const scannedBatch = updatedItem.batches.find(
          (batch: any) => batch.id === item.batchCode
        );
        if (scannedBatch) {
          scannedBatch.actualQty = item.actualQty;
          scannedBatch.selectedQty = item.actualQty;
          updatedItem.scannedBatch = scannedBatch;
          updatedItem.handled = true;
        }
        setOfflineBatchProducts((prev: any) => [...prev, updatedItem]);
      } else setOfflineBatchProducts((prev: any) => [...prev, updatedItem]);
    } else if (isFound) {
      /**
       * When the scanned item is valid non-batch item, we need to set the item to the state array -> matchFoundProducts
       */
      if (from != "consume") {
        /**
         * When it is in offline replenish, we need to manually add the updated batch array fetching from the backend
         */
        let batchesFromAPI;
        await delete updatedItem.batches;

        await dispatch(
          getBatches(res?.id, (data: any) => {
            batchesFromAPI = data?.data ?? [];
          })
        );
        delete updatedItem.batches;

        updatedItem["new_batches"] = batchesFromAPI;
        setMatchFoundProducts((prev: any) => [...prev, updatedItem]);
      } else {
        /**Delete the batches key from the valid products */
        delete updatedItem.batches;
        setMatchFoundProducts((prev: any) => [...prev, updatedItem]);
      }
    } else {
      /**if the scanned item is not found set the state aray => matchNotFoundProducts */
      setMatchNotFoundProducts((prev) => [...prev, item]);
    }
    await removeItemFromList(item);
  };
  useFocusEffect(
    useCallback(() => {
      /**
       * Update the global variable whenever the products array is updated
       */
      prodarray = [...products];
    }, [products])
  );
  const removeItemFromList = async (product: any) => {
    /**
     * After setting the data to the specific state arrays, remove each item fromt he products array
     */
    try {
      let dataItems = products;
      let dataIndex = dataItems.findIndex(
        (item) =>
          item.catalogNo == product.catalogNo ||
          item.catalogNo == product.vendorCatalogNo ||
          item.catalogNo == product.custCatalogNo
      );
      if (dataIndex != -1) dataItems.splice(dataIndex, 1);
      setRemovedTotal((prev) => prev + 1);
      if (dataItems.length == 0) {
        /**
         * All the items has been addressed and handled
         * Syncing function has to be reset
         */
        setIsLoop(false);
        setCurrentIndex(0);
        setIssyncing(false);
        // setProcessView(false);
        setshowProcessModal(false);
      }
      setProducts(dataItems);
    } catch (error) {}
  };
  const searchProduct = async (item: any, index: any) => {
    /**
     * Search for the each scanned item in the backend and get the response
     */
    if (item.isSelected) {
      /**
       * The API has to be called only for the selected items
       * Set the current index for selected items and Increment the index for selected items.
       */
      setCurrentIndex(selectedIndex);
      selectedIndex++;

      const data = await new Promise((resolve, reject) => {
        dispatch(
          getOfflineProducts(
            item.batchCode ? item.productCode : item.catalogNo,
            async (res: any, productId: string) => {
              resolve(res);
            },
            (res: any, productId: string) => {
              reject(res);
            }
          )
        );
      });
      if (data?.[0]) {
        /**
         * Valid response from the backend
         */
        if (!!data[0]?.freeze)
          setFoundData(item, false); /**locked one =>invalid product*/
        else if (
          isConsume &&
          from == "consume" &&
          (checkifBatchEnabled(data[0]) || checkifExpiryEnabled(data[0]))
        ) {
          setFoundData(
            item,
            true,
            true,
            data[0]
          ); /**batch enabled =>valid product but batch product*/
        } else
          setFoundData(
            item,
            true,
            false,
            data[0]
          ); /**non-batch =>valid product*/
      } else {
        setFoundData(item, false); /**not found product->invalid */
      }
    } else {
      /**
       * Skiping the deselcted items
       */
      await removeItemFromList(item);
    }
  };

  const memProducts = useMemo(() => {
    return !!offlineDuplicateProducts && !!processView
      ? offlineDuplicateProducts
      : products;
  }, [products]);

  let productArray =
    !!offlineDuplicateProducts && !!processView
      ? offlineDuplicateProducts
      : products;

  const onSyncPress = useCallback(() => {
    /**
     * Syncing process
     */
    let array = prodarray;

    const selectedPdt = array?.filter(
      (item: any, index: any) => item?.selected
    );
    if (array?.length == 0) {
      showOfflineCollection(false);

      showToast(
        Strings["ime.scanner.error.occured.msg"],
        Strings["ime.scanner.select.one.product.msg"]
      );
      setCurrentIndex(null);
      setIssyncing(false);
    } else if (selectedPdt?.some((item: any) => item.actualQty == 0)) {
      showToast(
        Strings["ime.scanner.error.occured.msg"],
        Strings["ime.scanner.quantity.zero.available.quantity.msg"]
      );
      setCurrentIndex(null);
      setIssyncing(false);
    } else {
      setTotal(selectedPdt.length);
      setCurrentIndex(selectedIndex); // Set the current index for selected items.
      setIssyncing(true);
      setMatchNotFoundProducts([]);
      setOfflineDuplicateProducts(null);
      setshowProcessModal(true);
    }
  }, [memProducts]);

  const onPressProcess = async (type: string) => {
    setIsShowWarn?.(false);
    /**
     * Invalid products found while syncing. we need to edit the invalid products and do the syncing process again in the loop
     * Keep the match found products as it is and append to it if new valid product is found
     *
     */
    await onPressProcessLogic(
      type,
      products,
      setProducts,
      matchNotFoundProducts,
      mergeAndRemoveDuplicates,
      {
        title: "",
        message: "",
        buttonTitle: NEXT_BUTTON_TITLE,
        onClick: onNextPress,
      },
      setProcessView,
      setshowProcessModal,
      setModalData,
      offlineBatchProducts,
      offlineDuplicateProducts,
      setOfflineBatchProducts
    );
    // setMatchNotFoundProducts([]);
  };
  const mergeAndRemoveDuplicates = (
    array1: any,
    array2: any,
    array3: any,
    isProcess?: boolean
  ) => {
    /**
     * To get the unique array removeing all the repeating items
     */
    let mergedArray = [];
    if (isProcess) {
      mergedArray = [...array1, ...array2, ...array3].filter(
        (item) => !item.scannedBatch
      );
      let updatedProducts = [...matchFoundProducts];
      let filtered = [...array1, ...array2, ...array3].filter(
        (item) => !!item.scannedBatch
      );
      setMatchFoundProducts([...updatedProducts, ...filtered]);
    } else {
      mergedArray = [...array1, ...array2, ...array3];
    }

    const uniqueItems = mergedArray.reduce((acc, item) => {
      const existingItemIndex = acc.findIndex(
        (accItem) => accItem.id === item.id
      );

      if (existingItemIndex === -1) {
        const newItem = { ...item };

        if (newItem.availableQty >= 0) {
          if (newItem.batches?.length) {
            newItem.batches = newItem.batches.filter(
              (batch) => batch.actualQty > 0 && batch.availableQty > 0
            );
            if (newItem.scannedBatch) {
              console.warn("newItem", newItem.scannedBatch);

              newItem.batches = [newItem.scannedBatch];
              delete newItem.scannedBatch;
            }
          }
          acc.push(newItem);
        }
      } else {
        const existingItem = acc[existingItemIndex];
        if (item.scannedBatch) {
          const scannedBatchId = item.scannedBatch.id;
          const isBatchIdExisting = existingItem.batches.some(
            (batch) => batch.id === scannedBatchId
          );
          if (!isBatchIdExisting) {
            console.warn("KKKKK", item.scannedBatch);
            existingItem.batches.push(item.scannedBatch);
            delete item.scannedBatch;
          }
        }
      }

      return acc;
    }, []);

    return uniqueItems;
  };

  const processUpdatedDuplicateItems = async () => {
    /**
     * this fucntion is called when the "Next" button is called for duplicate items,=> It is not the final step instead we need to
     * update the original values to the state accordingly after handling the quatities for the duplicate items
     */
    let validProducts = [...matchFoundProducts];
    let batchProducts = [...offlineBatchProducts];
    offlineDuplicateProducts?.forEach((subArray, index) => {
      const lastItem = subArray[subArray.length - 1];
      if (lastItem.batches && lastItem.batches.length > 0) {
        /**
         * Resetting the batch array with updated values
         * */
        let batches = lastItem.batches.filter(
          (item, index) => item.availableQty > 0
        );
        delete lastItem.batches;
        if (!lastItem.handled) {
          /**
           * If the handled ==true => the item has already been handled and no need to display in the batch management screen
           * It will be considered as the valid product and set the matchFoundProducts
           */
          batchProducts.push({ ...lastItem, batches });
        } else {
          validProducts.push({ ...lastItem, batches });
        }
      } else {
        /**
         * If the item does not have the batches key => add it to the  valid products
         */
        validProducts.push(lastItem);
      }
    });
    if (batchProducts.length) {
      /**
       * removing the "batches" ffrom each batch enabled items so that those can be given to the next batch managemnet screen and
       * can be updated with latest batches from the API.
       *
       * The batch enabled products which does not have batches array indicated, those has to be displayed in the batch management screen
       * and should be saved with latest batches from the API
       */
      batchProducts = batchProducts
        .filter(
          (item) => checkifExpiryEnabled(item) || checkifBatchEnabled(item)
        )
        .map(({ batches, ...rest }) => rest);
    }
    console.warn(batchProducts);
    console.warn(validProducts);
    /**
     * 1.Resetting the valid product with latest values
     * 2.set the batch array only if it is consume
     * 3.Reset the duplicate array to null since we have already handled
     */

    setMatchFoundProducts(validProducts);
    isConsume && from == "consume" && setOfflineBatchProducts(batchProducts);
    setOfflineDuplicateProducts(null);
  };

  const onNextPress = async () => {
    /**
     * this fucntion is called when "Next" button is called
     */
    if (!!offlineDuplicateProducts) {
      /**
       * when there is duplicated products and the Next is pressed, then this is not the final step
       * We need to handle the duplicate products
       *
       */
      processUpdatedDuplicateItems();
    } else {
      /**
       * The final step
       * 1.finding the unique items
       * 2.Resetting the state arrays
       * 3.Redirect tot he consume / replenish with the final data
       *
       *
       * Given a loader to notify the user that some process is going on
       *
       *
       */

      let updatedMatchFoundProducts = [];

      if (
        matchFoundProducts?.length &&
        !offlineBatchProducts?.length &&
        !products?.length
      ) {
        // Case where only matchFoundProducts?.length has a value
        updatedMatchFoundProducts = matchFoundProducts;
      } else if (
        !matchFoundProducts?.length &&
        offlineBatchProducts?.length &&
        !products?.length
      ) {
        // Case where only offlineBatchProducts?.length has a value
        updatedMatchFoundProducts = mergeAndRemoveDuplicates(
          offlineBatchProducts,
          [],
          []
        );
      } else if (
        !matchFoundProducts?.length &&
        !offlineBatchProducts?.length &&
        products?.length
      ) {
        // Case where only products has a value
        updatedMatchFoundProducts = products;
      } else {
        // Case where more than one array has a value, call the merge function
        updatedMatchFoundProducts = await mergeAndRemoveDuplicates(
          matchFoundProducts,
          offlineBatchProducts,
          products
        ).reverse();
      }

      if (updatedMatchFoundProducts.length) {
        onNextProcessLogic(
          setCurrentIndex,
          updatedMatchFoundProducts,
          setProcessView,
          setshowProcessModal,
          setProducts,
          setMatchFoundProducts,
          setMatchNotFoundProducts,
          setOfflineBatchProducts,
          showOfflineCollection,
          from,
          replenishCallBack,
          setOrderView,
          setIsConsumeView,
          setOrderData,
          setOrderPreviewData,
          setSearchKey,
          from == "consume" ? setIsDataUpdating : undefined,
          setDefOfflineProducts
        );
      }
    }
  };
  const replenishCallBack = async (updatedMatchFoundProducts: any) => {
    /**
     * final step in the replenish offline
     * Process the data and  redirect to the online replenish screen
     *
     * Given a loader to notify the user that some process is going on
     */

    setIsDataUpdating(true);

    let sampleData = updatedMatchFoundProducts?.map((item) => ({
      ...item,
      selected: item?.freeze == true ? false : true,
      type: "STOCKED",
      batches: item.new_batches?.length ? item.new_batches : item.batches,
    }));
    await dispatch(addItemsToOrderList(sampleData, [], "array"));
    from !== "consume" && (await saveDataToStorage("offlineData", sampleData));
    setIsDataUpdating(false);

    navigation.navigate("Replenish", { fromScreen: "ReplenishOffline" });
  };
  const getDetailsView = (item: any, index: any) => {
    return !!processView && !!editView && selectedItemIndexForEdit == index ? (
      <View style={styles.editContainer}>
        <TextInputComponent
          titleStyle={styles.itemHeaderContent}
          title={strings["ime.scanner.Product.Number"] ?? "Product Number"}
          onPressRightIcon={() => {}}
          RightIcon={null}
          value={item?.catalogNo}
          editable={true}
          onChangeText={(value) => {
            updateProductItem(value, index);
          }}
          main={[styles.productTxtContainerStyle]}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
          returnKeyType="go"
        />
        <TouchableOpacity
          disabled={!item.catalogNo}
          accessible={true}
          accessibilityLabel={"consume_order_view_selection_button"}
          style={[
            styles.updateButton,
            {
              backgroundColor: item.catalogNo
                ? COLORS.scienceBlue
                : COLORS.abbey,
            },
          ]}
          onPress={() => {
            onUpdateItem();
          }}
        >
          <Text style={styles.updateButtonText}>{Strings["update"]}</Text>
        </TouchableOpacity>
      </View>
    ) : (
      <View style={{}}>
        <Text
          allowFontScaling={false}
          accessibilityLabel={"consume_order_view_description"}
          style={styles.itemHeaderContent}
        >
          {strings["ime.scanner.Product.Number"] ?? "Product Number"}
        </Text>
        <Text
          allowFontScaling={false}
          accessibilityLabel={"consume_order_view_catalog_number"}
          style={styles.catalogNumber}
        >
          {item?.catalogNo}
        </Text>
      </View>
    );
  };
  const onClickEditItem = (index: any) => {
    setSelectedItemIndexForEdit(index);
    setEditView(true);
  };
  const onUpdateItem = () => {
    onUpdateItemLogic(setEditView, setModalData, onSyncPress, {
      title: SYNCING_OFFLINE_DATA,
      message: SYNC_IN_PROGRESS_MESSAGE,
      buttonTitle: NEXT_BUTTON_TITLE,
      onClick: () => onNextPress(),
    });
  };
  const onDeleteItem = (index: number) => {
    /**
     * This is called for the invalid products
     *
     * It removed the item from the array
     */

    setIsVisibleClearOrder(false);
    let array = [...products];
    array.splice(index, 1);
    setProducts(array);
    if (array?.length == 0) {
      /**
       * Once the array becomes empty after deleting all the invalid items, check if there is any items in the state arrays,
       * If yes => we need to process those items and move to next screens
       * if no => there no product to be handled, clear the local storage and redirect to the dashboard
       *
       */
      if (
        processView &&
        !matchFoundProducts.length &&
        !offlineBatchProducts.length
      ) {
        onPressClearOrder?.();
      } else {
        setProcessView(false);
        setProducts([]);
        setMatchNotFoundProducts([]);
        checkduplicates();
      }
    }
  };
  const onDeletePressed = (index: any) => {
    setClearModalData({
      title: strings["ime.scanner.Remove.Invalid.Product"],
      buttonTitle: Strings["remove"],
      desc: strings["ime.scanner.The.selected.product.number.will.be.removed."],
      buttonPress: () => onDeleteItem(index),
    });
    setIsVisibleClearOrder(true);
  };
  const validateQty = () => {
    return !offlineDuplicateProducts?.every((subArray) => {
      return subArray.every((item) => item?.actualQty > 0);
    });
  };

  useEffect(() => {
    if (currentIndex != null) {
      if (!offlineDuplicateProducts) {
        /**
         * Once all the duplicate items has been handled it comes here.
         */
        if (matchFoundProducts.length || offlineBatchProducts.length) {
          /**
           * when the deplicate items becomes null and there are items in matchFoundProducts and offlineBatchProducts
           * then the priority goes the offlineBatchProducts=> redirect to the batch management screen
           * when the batch array becomes empty then set the valid product view (redirecting to the online screens)
           */
          if (
            offlineBatchProducts?.some((item, index) => item.handled == false)
          ) {
            setBatchView();
          } else {
            setValidView();
          }
        } else {
        }
      } else {
        /**
         * Duplicate management screen has to be displayed.
         * Resetting the button to "Next" and processview to true
         *
         **/
        setProcessView(true);
        setModalData({
          title: SYNC_COMPLETE,
          message: FOUND_VALID_PRODUCT_MESSAGE,
          buttonTitle: NEXT_BUTTON_TITLE,
          onClick: onNextPress,
        });
      }
    }
  }, [offlineDuplicateProducts]);

  const setValidView = () => {
    /**
     * Valid view => all the items has been addressed and just need to redirect to the online screens
     *
     */
    setModalData({
      title: SYNC_COMPLETE,
      message: FOUND_VALID_PRODUCT_MESSAGE,
      buttonTitle: NEXT_BUTTON_TITLE,
      onClick: onNextPress,
    });
    setshowProcessModal(true);
    setProcessView(false);
    setEditView(false);
    onNextPress();
  };
  const isAllSelcted = checkIfAllSelected();

  let validProductsFound =
    matchFoundProducts?.length >
    0; /**If valid and non products directly go to order page **/
  let invalidProductsFound =
    matchNotFoundProducts?.length >
    0; /**If found go to process data ->invalid products section   **/
  let duplicatesFound =
    !!offlineDuplicateProducts; /**If found go to process data ->Duplicate Scanned Products section   **/
  let validBatchProductsFound =
    offlineBatchProducts?.length >
    0; /**If found go to process data ->invalid products section   **/
  let processLabel =
    products?.length == 0
      ? ""
      : isBatchSaved
      ? ""
      : `${strings["processing"]} ${currentIndex} of ${totalCount} records...`;
  let isDisabled =
    /**
     * isDisabled is used to disabled the footer button
     * The footer button can be SYNC,PROCESS,NEXT
     * PROCESS was used for the redirection to the batch / oinvalid screen. right now it is redirecting automatically
     *
     * 1. SYNC
     * -------
     *    internet is turned on, there are selected items in the screen =>enable
     *    in all other conditions=> disable
     *
     * 2. NEXT
     * ----------
     *    a) Duplicate screen
     *    -------------------
     *       internet is turned on, all the original items has actual qty > 0=>enable
     *       else=> disable
     *    b) Batch screen
     *    ----------------
     *        internet is turned on, If all the batch items have been saved => enabled
     *        else => disable
     */
    !internet ||
    !!issyncing ||
    processView ||
    (modalData.buttonTitle == SYNC_BUTTON_TITLE && products?.length == 0
      ? true
      : (modalData.buttonTitle == NEXT_BUTTON_TITLE &&
          !validBatchProductsFound) ||
        modalData.buttonTitle == PROCESS_BUTTON_TITLE
      ? false
      : selectedProducts?.length == 0);
  isDisabled = validBatchProductsFound && isBatchSaved ? false : isDisabled;
  isDisabled = duplicatesFound && processView ? validateQty() : isDisabled;

  const processViewTitle =
    /**
     * this is the title to be displayed in each screen
     * "Invalid Product Numbers" => Invlaid screen
     * "Duplicate Scanned Products" => duplciate items screen
     * "strings["ime.scanner.batch.expiry.controlled"]"=> Batch screen
     * "no_title" => all valid products
     */
    processView
      ? invalidProductsFound
        ? "Invalid Product Numbers"
        : duplicatesFound
        ? "Duplicate Scanned Products"
        : !issyncing &&
          (validBatchProductsFound
            ? strings["ime.scanner.batch.expiry.controlled"]
            : "no_title")
      : "";
  useEffect(() => {
    if (
      offlineBatchProducts.length == 0 &&
      processViewTitle === "no_title" &&
      !offlineDuplicateProducts
    ) {
      /**
       *After processing all the itemsin the invalid, duplicate and batch
       * **/
      // setValidView();
    }
  }, [offlineBatchProducts, processViewTitle]);

  const groupItemsById = (arr, additionalItemRequired?: boolean) => {
    const grouped = {};

    arr.forEach((item) => {
      if (!grouped[item.id]) {
        grouped[item.id] = [];
      }
      grouped[item.id].push(item);
    });
    if (additionalItemRequired)
      Object.values(grouped).forEach((group) => {
        const id = group[0].id;
        const duplicateItem = {
          ...group[0],
          actualQty: 0,
          selectedQty: 0,
          handled: false,
        };
        group.push(duplicateItem);
      });

    return Object.values(grouped);
  };

  const identifyDuplicatesAndUniques = (groupedItems) => {
    /**
     * Finding the duplicate items from the grouped array where sub array length is greater than 1
     * and saving acc. to the duplciate or unique array
     */
    const duplicate = {
      validProducts: [],
      validBatchProducts: [],
    };

    const unique = {
      validProducts: [],
      validBatchProducts: [],
    };

    groupedItems.forEach((group) => {
      if (group.length > 1) {
        const allHaveBatch = group.every((item) => item.scannedBatch);

        if (allHaveBatch) {
          unique.validProducts.push(...group);
        } else {
          const hasBatch = group.some((item) => item.scannedBatch);
          const isBatch =
            checkifBatchEnabled(group[0]) || checkifExpiryEnabled(group[0]);
          if (hasBatch || isBatch) {
            duplicate.validBatchProducts.push(...group);
          } else {
            duplicate.validProducts.push(...group);
          }
        }
      } else {
        const isBatch =
          checkifBatchEnabled(group[0]) || checkifExpiryEnabled(group[0]);
        if (isBatch) {
          unique.validBatchProducts.push(...group);
        } else {
          unique.validProducts.push(...group);
        }
      }
    });
    console.log("{ duplicate, unique }", { duplicate, unique });
    return { duplicate, unique };
  };
  const checkduplicates = () => {
    /**If no invalid products then check if there is duplicate items exists */

    const arr = [...matchFoundProducts, ...offlineBatchProducts];
    const groupedItems = groupItemsById(arr);
    const { duplicate, unique } = identifyDuplicatesAndUniques(groupedItems);
    if (
      duplicate.validProducts?.length ||
      duplicate.validBatchProducts.length
    ) {
      console.warn("dup", duplicate, "uni", unique);
      setMatchFoundProducts(unique?.validProducts);
      isConsume &&
        from == "consume" &&
        setOfflineBatchProducts(unique?.validBatchProducts);
      let mergedArray = [
        ...duplicate.validProducts,
        ...duplicate.validBatchProducts,
      ];
      const formatedArray = groupItemsById(mergedArray, true);

      Object.values(formatedArray).forEach(async (group: any) => {
        let batches = undefined;
        if (group.some((item: any) => item.scannedBatch)) {
          /*
           * Set the batch array for the outer object to select the required batches when
           *  there is scannedBatch present for one of the items with same ID
           **/

          dispatch(setProductBatchLoader(true));
          await dispatch(
            getBatches(group[0].id, (res: any) => {
              batches = res.data;
            })
          );
          dispatch(setProductBatchLoader(false));
          let g = group[group.length - 1];
          delete g.batches;
          group[group.length - 1] = { ...g, batches };
        }
      });
      console.warn("formated Array", formatedArray);

      setOfflineDuplicateProducts(formatedArray);
    } else {
      /**
       * If no dulpciates are there, check if any state array is empty or not
       *
       */
      if (validBatchProductsFound) {
        let flag = offlineBatchProducts.every(
          (item, index) => item.scannedBatch
        );
        setMatchNotFoundProducts([]);
        if (!flag) {
          setBatchView();
        } else setValidView();
      } else if (validProductsFound) {
        setValidView();
      }
    }
  };
  useEffect(() => {
    if (
      products.length == 0 &&
      matchNotFoundProducts.length == 0 &&
      processView &&
      currentIndex != null &&
      processViewTitle == ""
    ) {
      /**
       * Will be executed automatically one all the invalid items have been handled
       */
      console.warn(
        matchNotFoundProducts.length +
          " " +
          products.length +
          "" +
          processView +
          " " +
          processViewTitle
      );

      checkduplicates();
    }
  }, [matchNotFoundProducts, products]);
  useEffect(() => {
    if (!issyncing) setIsLoop(false);
    if (!issyncing && currentIndex == 0 && products.length == 0) {
      {
        if (invalidProductsFound) {
          /**
           * Invalid products found after sync process
           * Set the view to the invlaid screen
           */
          setshowProcessModal(false);
          setTimeout(() => {
            onPressProcess("invalid");
          }, 800);
        } else {
          /**
           * if no invaid products found after the sunc process then check for duplciates
           */
          checkduplicates();
        }
      }
    }
    if (issyncing && currentIndex != null && !isLoop && !isBackPressed) {
      /*
       * After checking the validation the sync process starts
       */
      const selectedPdt = products?.length
        ? products?.filter((item: any, index: any) => item?.selected)
        : [];

      setTotal(selectedPdt?.length);
      processSelectedProducts([...products]);
    }
  }, [issyncing, currentIndex]);

  useEffect(() => {
    if (isBatchSaved && validBatchProductsFound) {
      /**
       * Once all the items in the batch management screen has been saved with updated batch details
       * we need to show a popup prompting the user move forward
       */
      setModalData({
        title: BATCH_DETAILS_SAVED,
        message: FOUND_VALID_PRODUCT_MESSAGE,
        buttonTitle: NEXT_BUTTON_TITLE,
        onClick: onNextPress,
      });
      setshowProcessModal(true);
    }
  }, [isBatchSaved]);

  const renderProducts = (item: any, index: any) => {
    return (
      <View style={styles.headerMainContainerStyle}>
        <View
          accessible={true}
          accessibilityLabel={"consume_order_view_product_item_container"}
          style={styles.headerContainerStyle}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              maxWidth: wp(38),
            }}
          >
            {getDetailsView(item, index)}
            {!!processView && !editView && (
              <TouchableOpacity
                accessible={true}
                accessibilityLabel={"consume_order_view_right_icon"}
                style={styles.editButton}
                onPress={() => onClickEditItem(index)}
              >
                <OfflineEdit
                  accessible={true}
                  accessibilityLabel={"edit_icon"}
                  width={wp(7)}
                  height={wp(7)}
                />
              </TouchableOpacity>
            )}
          </View>
        </View>
        <View
          accessible={true}
          accessibilityLabel={"consume_order_view_qty_container"}
          style={[styles.center]}
        >
          <Text
            allowFontScaling={false}
            accessibilityLabel={"consume_order_view_qty_title"}
            style={[styles.itemText]}
          >
            {strings["ime.qty"]}
          </Text>

          <QtyController
            isOffline={true}
            onChange={(val: React.SetStateAction<string>) => {
              updateItemQty(val, index);
            }}
            showLabel={false}
            inputStyle={styles.controllerInputStyle}
            inputValue={item["actualQty"]}
            disable={issyncing}
          />
        </View>
      </View>
    );
  };
  const setFormatedData = async (value) => {
    setBatchArray(value);
  };
  const getBatchTotal = (batches: any[]) => {
    /**Used to check if the original item in the duplciate screen has the valid qty or not */
    return batches.reduce((total: number, item: any) => {
      if (item.actualQty !== null) {
        return total + parseInt(item.actualQty);
      } else {
        return total;
      }
    }, 0);
  };

  const handleBatch = (
    batches: any,
    parentIndex: number,
    itemIndex: number
  ) => {
    /**
     * Update the batch details in the parent item and mark it as handledso that it wont go to the next screen
     */
    let updatedProducts = [...offlineDuplicateProducts];
    let batchTotal = getBatchTotal(batches);
    let item = updatedProducts[parentIndex][itemIndex];
    item.batches = batches;
    item.actualQty = batchTotal;
    item.selectedQty = batchTotal;
    item.handled = true;
    setOfflineDuplicateProducts(updatedProducts);
  };

  const renderDuplicates = (parentItem: any, parentIndex: any) => {
    return (
      parentItem?.length &&
      parentItem?.map((item, index) => {
        const uomId =
          item?.uomManagementEnabled == 1
            ? item?.stockRoomUOMUnit
            : item?.uomId;
        let batches =
          index == parentItem.length - 1
            ? parentItem?.[index]?.batches?.filter(
                (item, index) => item.availableQty > 0
              )
            : [];
        return index == parentItem.length - 1 ? (
          <View style={{ marginTop: 4 }}>
            <ConsumeBatchListItem
              disabled={true}
              isOnline={false}
              checkifTheItemExistInOrder={checkifTheItemExistInOrder}
              index={parentIndex}
              productsData={products}
              itemFooter={itemFooter}
              setSelectedItem={setSelectedItem}
              checkifBatchEnabled={checkifBatchEnabled}
              checkifExpiryEnabled={checkifExpiryEnabled}
              bottomSheetRef={bottomSheetRef}
              errorCallBack={errorCallBack}
              showToast={showToast}
              item={item}
              batchSaved={false}
              setChildState={setChildState}
            />

            {batches?.length && isConsume ? (
              <View
                style={[styles.offlineQtyContainer, { marginHorizontal: 0 }]}
              >
                <AddBatch
                  item={item}
                  onChange={(batches: any) =>
                    handleBatch(batches, parentIndex, index)
                  }
                  updateActualQty={(val: any) => {
                    setQty(val);
                  }}
                  setLoader={(val: boolean) => dispatch(setProductLoader(val))}
                  data={batches}
                  formatedData={batches}
                  setFormatedData={setFormatedData}
                  uomId={uomId}
                  topLimitValue
                  availableQty={item.availableQty}
                  // showWarn={(val: boolean) => setIsShowWarn(val)}
                  // showAlert={(val: boolean) => showAlert(val)}
                  freeze={false}
                  from="item_confirm"
                />
              </View>
            ) : (
              <View
                style={[styles.offlineQtyContainer, { marginHorizontal: 0 }]}
              >
                <Text
                  allowFontScaling={false}
                  accessibilityLabel="consume_offline_list_title"
                  style={styles.offlineQty}
                >
                  {"Qty"}
                </Text>
                <QtyController
                  onChange={(val: React.SetStateAction<string>) => {
                    updateQtyForDuplicates(val, parentIndex, index);
                  }}
                  disable={false}
                  showLabel={false}
                  inputStyle={styles.controllerInputStyle}
                  inputValue={item.actualQty}
                />
              </View>
            )}
          </View>
        ) : (
          <View style={{}}>
            <View style={styles.headerMainContainerStyle}>
              <View
                accessible={true}
                accessibilityLabel={"consume_order_view_product_item_container"}
                style={styles.headerContainerStyle}
              >
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    maxWidth: wp(38),
                  }}
                >
                  <View style={{}}>
                    <Text
                      allowFontScaling={false}
                      accessibilityLabel={"consume_order_view_description"}
                      style={styles.itemHeaderContent}
                    >
                      {strings["ime.scanner.Product.Number"] ??
                        "Product Number"}
                    </Text>
                    <Text
                      allowFontScaling={false}
                      accessibilityLabel={"consume_order_view_catalog_number"}
                      style={styles.catalogNumber}
                    >
                      {item?.catalogNo +
                        `${
                          item.scannedBatch ? `*UI#${item.scannedBatch.id}` : ""
                        }`}
                    </Text>
                  </View>
                </View>
              </View>
              <View
                accessible={true}
                accessibilityLabel={"consume_order_view_qty_container"}
                style={[styles.center]}
              >
                <Text
                  allowFontScaling={false}
                  accessibilityLabel={"consume_order_view_qty_title"}
                  style={[
                    styles.itemText,
                    {
                      fontFamily: FONTFAMILY.averta_bold,
                      fontSize: FONTS.h1_9,
                    },
                  ]}
                >
                  {"Offline Qty"}
                </Text>
                <View
                  style={[
                    styles.controllerInputStyle,
                    {
                      borderWidth: 1,
                      marginLeft: 4,
                      borderColor: COLORS.gray4,
                      alignItems: "center",
                      justifyContent: "center",
                      height: 40,
                      maxWidth: 60,
                      minWidth: 40,
                    },
                  ]}
                >
                  <Text
                    style={{
                      color: COLORS.gray4,
                    }}
                  >
                    {item.actualQty}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        );
      })
    );
  };
  return (
    <View
      accessibilityLabel="consume_offline_view_container"
      accessible={true}
      style={styles.container}
    >
      <ScrollView keyboardShouldPersistTaps="handled">
        {!!productArray?.length && (
          <Text
            allowFontScaling={false}
            accessibilityLabel="consume_offline_list_title"
            style={styles.title}
          >
            {processView
              ? strings["ime.scanner.Process.Data"]
              : strings["ime.scanner.Offline.Collection"]}
          </Text>
        )}
        {!!productArray?.length && !!processView && (
          <Text
            allowFontScaling={false}
            accessibilityLabel="consume_offline_list_title"
            style={styles.subTitle}
          >
            {processViewTitle}
          </Text>
        )}
        {!!productArray?.length && !processView && (
          <View style={styles.rightContainer}>
            <View
              accessible={true}
              accessibilityLabel={"consume_order_view_header_right"}
              style={styles.headerRight}
            >
              <Text
                allowFontScaling={false}
                accessibilityLabel={"consume_order_view_selection_label"}
                style={styles.selectAll}
              >
                {isAllSelcted
                  ? Strings["ime.scanner.deselect.all"] ?? "Deselect All"
                  : Strings["ime.select.all"] ?? "Select All"}
              </Text>
              <TouchableOpacity
                disabled={issyncing}
                accessible={true}
                accessibilityLabel={"consume_order_view_selection_button"}
                style={isAllSelcted ? styles.activeTick : styles.deactiveTick}
                onPress={() => {
                  toggleSelectAll(isAllSelcted);
                }}
              >
                {isAllSelcted && (
                  <View
                    accessible={true}
                    accessibilityLabel={"consume_order_view_tick_icon"}
                    style={styles.dot}
                  />
                )}
              </TouchableOpacity>
            </View>
          </View>
        )}
        <View style={styles.listContainer}>
          {productArray?.map((item: any, index: any) => {
            let batchSaved = item.batchSaved;
            return !processView ||
              (processView &&
                (processViewTitle == "Invalid Product Numbers" ||
                  processViewTitle == "Duplicate Scanned Products")) ? (
              <View
                accessible={true}
                accessibilityLabel={"consume_order_view_item_container"}
              >
                <ListItem
                  leftIcon={
                    !!processView ? (
                      <View style={{ marginStart: wp(2) }} />
                    ) : (
                      <View
                        accessible={true}
                        accessibilityLabel={
                          "consume_order_view_left_icon_ontainer"
                        }
                        style={styles.leftIconContainer}
                      >
                        <Text
                          allowFontScaling={false}
                          accessibilityLabel={
                            "consume_order_view_selection_label"
                          }
                          style={styles.indexText}
                        >
                          {item.index}
                        </Text>
                      </View>
                    )
                  }
                  headerContent={
                    duplicatesFound
                      ? renderDuplicates(item, index)
                      : renderProducts(item, index)
                  }
                  rightIcon={
                    !!processView ? (
                      duplicatesFound ? (
                        <View />
                      ) : (
                        <TouchableOpacity
                          accessible={true}
                          accessibilityLabel={"consume_order_view_right_icon"}
                          style={styles.deleteButton}
                          onPress={() => onDeletePressed(index)}
                        >
                          <OfflineDelete
                            accessible={true}
                            accessibilityLabel={"delete_icon"}
                            width={wp(7)}
                            height={wp(7)}
                          />
                        </TouchableOpacity>
                      )
                    ) : (
                      <TouchableOpacity
                        disabled={issyncing}
                        accessible={true}
                        accessibilityLabel={"consume_order_view_right_icon"}
                        style={[
                          item?.selected
                            ? styles.activeTick
                            : styles.deactiveTick,
                          {
                            marginTop: wp(1),
                          },
                        ]}
                        onPress={() => toggleSelectItem(index)}
                      >
                        {item?.selected && (
                          <View
                            accessible={true}
                            accessibilityLabel={"consume_order_view_tick_icon"}
                            style={styles.dot}
                          />
                        )}
                      </TouchableOpacity>
                    )
                  }
                ></ListItem>
                {itemFooter()}
              </View>
            ) : (
              !issyncing && !!processView && validBatchProductsFound && (
                <View style={{ marginHorizontal: wp(2) }}>
                  <ConsumeBatchListItem
                    isOnline={false}
                    checkifTheItemExistInOrder={checkifTheItemExistInOrder}
                    index={index}
                    productsData={products}
                    itemFooter={itemFooter}
                    setSelectedItem={setSelectedItem}
                    checkifBatchEnabled={checkifBatchEnabled}
                    checkifExpiryEnabled={checkifExpiryEnabled}
                    bottomSheetRef={bottomSheetRef}
                    errorCallBack={errorCallBack}
                    showToast={showToast}
                    item={item}
                    batchSaved={batchSaved}
                    setChildState={setChildState}
                    disabled={false}
                  />
                  <View style={styles.offlineQtyContainer}>
                    <Text
                      allowFontScaling={false}
                      accessibilityLabel="consume_offline_list_title"
                      style={styles.offlineQty}
                    >
                      {strings["ime.scanner.Offline.Qty"] + " "}
                    </Text>
                    <QtyController
                      onChange={(val: React.SetStateAction<string>) => {
                        updateItemQty(val, index);
                      }}
                      disable={true}
                      showLabel={false}
                      inputStyle={styles.controllerInputStyle}
                      inputValue={item["actualQty"]}
                    />
                  </View>
                </View>
              )
            );
          })}
        </View>
        <View
          accessible={true}
          accessibilityLabel={"consume_offline_Spacer"}
          style={styles.footerView}
        />
      </ScrollView>

      <Footer
        mainButtonDisabled={isDisabled}
        mainbuttonTitle={modalData.buttonTitle}
        secondaryButtonTitle={Strings["ime.scanner.clear"] ?? "Clear"}
        secondaryButtonDisabled={!products?.length}
        count={
          modalData.buttonTitle == SYNC_BUTTON_TITLE
            ? selectedProducts?.length
            : modalData.buttonTitle == NEXT_BUTTON_TITLE
            ? offlineDuplicateProducts
              ? offlineDuplicateProducts?.length
              : invalidProductsFound
              ? matchNotFoundProducts.length
              : offlineBatchProducts.length
            : 0
        }
        mainButtonStyle={styles.syncButton}
        mainButtonTextStyle={styles.syncButtonText}
        onChangePrimaryBtnPress={() => {
          // modalData.onClick();
          if (modalData.buttonTitle == SYNC_BUTTON_TITLE) {
            onSyncPress();
          } else if (modalData.buttonTitle == PROCESS_BUTTON_TITLE) {
            onPressProcess("process");
          } else if (modalData.buttonTitle == NEXT_BUTTON_TITLE) {
            onNextPress();
          }
        }}
        onChangeSecondaryBtnPress={() => {
          setClearModalData({
            title: strings["ime.scanner.Clear.this.list"],
            buttonTitle: strings["ime.scanner.Clear.list"],
            desc: strings[
              "ime.scanner.All.products.in.this.list.will.be.removed"
            ],
            buttonPress: onPressClearOrder,
          });
          setIsVisibleClearOrder(true);
        }}
        mainContainerStyle={styles.footerMainContainer}
        outlinedBtnTextStyle={styles.outlinedBtnText}
        outlinedBtnContainerStyle={styles.outlinedBtnContainer}
      />
      {!invalidProductsFound &&
        !validBatchProductsFound &&
        (products?.length == 0 || !processView) &&
        products?.length < 500 &&
        !issyncing &&
        !showProcessModal &&
        modalData.buttonTitle != NEXT_BUTTON_TITLE && (
          <ScannerButton
            scanBatch={from == "consume" && isConsume}
            disabled={products?.length == 500}
            mainButtonStyle={styles.scannerBtnOrder}
            onButtonPressed={async () => {
              setCurrentIndex(0);
              setIsLoop(false);
              setMatchFoundProducts([]);
              setOfflineBatchProducts([]);
              setMatchNotFoundProducts([]);
              resetData();
            }}
            onBarcodeDetected={async (barcode) => {
              let batchesArray = barcode.split("*UI#");
              if (!checkifTheItemExistInOrder(null, barcode)) {
                let mostRecentlyAdded = null;
                let newProduct = {
                  catalogNo: barcode,
                  actualQty: 1,
                  selectedQty: 1,
                  selected: true,
                  index: products?.length + 1,
                  isSelected: true,
                };
                if (batchesArray?.length > 1) {
                  newProduct["productCode"] = batchesArray[0];
                  newProduct["batchCode"] = batchesArray[1];
                }
                products.unshift(newProduct);
                mostRecentlyAdded = newProduct;
                setProducts([...products]);
                await saveDataToStorage(
                  from === "consume"
                    ? "consume_offline_data"
                    : "replenish_offline_data",
                  products
                );
              } else {
                showToast(
                  Strings["ime.scanner.error.occured.msg"],
                  strings["ime.scanner.Item.already.exists.in.the.collection"]
                );
              }
            }}
          />
        )}

      {!!showProcessModal && (
        <View
          accessible={true}
          accessibilityLabel={"consume_offline_process_view_container"}
          style={styles.main}
        >
          <View
            accessible={true}
            accessibilityLabel={"consume_offline_inner_container"}
            style={styles.inner}
          >
            <View
              accessible={true}
              accessibilityLabel={"consume_offline_catalog_container"}
              style={{ flex: 1 }}
            >
              <Text
                accessibilityLabel={"consume_offline_title_label"}
                style={styles.tite}
              >
                {modalData.title}
              </Text>
              <Text
                accessibilityLabel={"consume_offline_catalog_number_value"}
                style={styles.des}
              >
                {modalData.message}
              </Text>
            </View>
            <TouchableOpacity
              accessible={true}
              accessibilityLabel={"consume_offline_process_close_button"}
              onPress={() => {
                setshowProcessModal(false);
              }}
            >
              <Cross
                accessible={true}
                accessibilityLabel={"consume_offline_process_close_icon"}
                height={hp(1.7)}
                width={hp(1.7)}
              />
            </TouchableOpacity>
          </View>
          {
            <View
              accessible={true}
              accessibilityLabel={"consume_offline_dynamic_label_container"}
              style={styles.sub}
            >
              <Text
                accessibilityLabel={"consume_offline_dynamic_label"}
                style={styles.processLabel}
              >
                {issyncing ? processLabel : ""}
              </Text>
            </View>
          }
        </View>
      )}
    </View>
  );
};
const MemoizedChildComponent = React.memo(OfflineConsumeView);
export default MemoizedChildComponent;
