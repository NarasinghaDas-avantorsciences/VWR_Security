import React from "react";
import RBSheet from "react-native-raw-bottom-sheet";
import { StyleProp, ViewStyle } from "react-native";
import { COLORS, SIZES } from "../../../Utils/theme";
import { wp } from "../../../Utils/globalFunction";

export type BottomSheetProps = {
  children: React.ReactNode;
  bottomSheetRef: any;
  height?: number;
  onClose?: any;
  customStyles?: {
    wrapper?: StyleProp<ViewStyle>;
    container?: StyleProp<ViewStyle>;
    draggableIcon?: StyleProp<ViewStyle>;
  };
  closeOnDragDown?: boolean;
  closeOnPressMask?: boolean;
  dragFromTopOnly?: boolean;
  onOpen?: () => void;
};

const CustomToast: React.FC<BottomSheetProps> = (props) => {
  const {
    bottomSheetRef,
    children,
    onClose,
    closeOnDragDown,
    closeOnPressMask,
    dragFromTopOnly,
    onOpen,
  } = props;

  return (
    <RBSheet
      accessible={true}
      accessibilityLabel="bottom-sheet"
      ref={bottomSheetRef}
      closeOnDragDown={closeOnDragDown ? closeOnDragDown : true}
      closeOnPressMask={closeOnPressMask ? closeOnPressMask : true}
      height={SIZES.height * 0.23}
      onClose={onClose}
      onOpen={onOpen}
      dragFromTopOnly={dragFromTopOnly}
      customStyles={{
        wrapper: {
          backgroundColor: "transparent",
        },
        draggableIcon: {
          backgroundColor: COLORS.white,
        },
        container: {
          borderTopLeftRadius: SIZES.radius,
          borderTopRightRadius: SIZES.radius,
          overflow: "hidden",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "rgba(0,0,0,0.0)",
          bottom: wp(14),
        },
      }}
    >
      {children}
    </RBSheet>
  );
};

export default CustomToast;
