import moment from "moment";
const onPrimaryButtonPressLogic = async (
  allSelectedProducts: any,
  showToast: any,
  isConsumeView: any,
  onPressConsume: any,
  setIsConsumeView: any,
  dateFormat: any,
  checkifBatchEnabled: any,
  checkifExpiryEnabled: any,
  stockRoomDetail: any,
  isShowAlert: any,
  setIsShowAlert: any,
  setIsVisibleMaxconsumptionPopup: any,
  consumeCustomPrivilage: any,
  onPressRequest: any,
  userType: any,
  setOrderPreviewData: any,
  Strings: any
) => {
  let flag = 1;
  if (!allSelectedProducts?.length) {
    flag = 0;
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      Strings["ime.scanner.select.one.product.msg"]
    );
  } else {
    const selectedProducts = allSelectedProducts?.map(async (item: any) => {
      let batches = [];
      let pActualQty = 0;
      if (
        (!!checkifBatchEnabled(item) || !!checkifExpiryEnabled(item)) &&
        item?.batches?.length
      ) {
        batches = item?.batches.map((batch: any) => {
          const { batchNo, actualQty, expiryDate, availableQty, id } = batch;
          const bActualQty = !!actualQty ? parseInt(actualQty) : 0;
          const bAvailableQty = !!availableQty ? parseInt(availableQty) : 0;

          if (batchNo == "" && !!checkifBatchEnabled(item)) {
            flag = 0;
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.batch.empty.msg"]
            );
            throw new Error("batchNo occured");
          } else if (
            (!expiryDate || expiryDate == "") &&
            !!checkifExpiryEnabled(item)
          ) {
            flag = 0;
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.expiry.date.empty.msg"]
            );
            throw new Error("expiryDate occured");
          } else if (
            (!bActualQty || bActualQty > bAvailableQty) &&
            !(consumeCustomPrivilage == "request" && userType != "SUPER_USER")
          ) {
            flag = 0;
            let text = `BatchProducts: ${item.catalogNo} - Batch: ${batchNo} - `;
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              text + Strings["ime.scanner.quantity.zero.available.quantity.msg"]
            );

            throw new Error("actualQty occured");
          }
          pActualQty += bActualQty;
          return {
            id: id?.includes("addedBatch") ? null : id,
            availableQty: id?.includes("addedBatch")
              ? 0
              : availableQty
              ? availableQty
              : "0",
            consumedQty: actualQty,
          };
        });

        if (
          stockRoomDetail?.isMaximumConsumptionEnabled &&
          item?.maxConsumptionQuantity != null
        ) {
          if (
            !stockRoomDetail.isOverConsume &&
            pActualQty > item?.maxConsumptionQuantity
          ) {
            flag = 0;
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              stockRoomDetail?.maxConsumptionText
            );
          } else if (
            stockRoomDetail.isOverConsume &&
            !!isShowAlert &&
            pActualQty > item?.maxConsumptionQuantity
          ) {
            flag = 0;
            setIsVisibleMaxconsumptionPopup(true);
          }
        }
      } else {
        const pActualQty = !!item.actualQty ? parseInt(item.actualQty) : 0;
        const availableQty = !!item.availableQty
          ? parseInt(item.availableQty)
          : 0;

        if (
          !pActualQty ||
          (pActualQty > availableQty &&
            !(consumeCustomPrivilage == "request" && userType != "SUPER_USER"))
        ) {
          flag = 0;
          if (
            !(consumeCustomPrivilage == "request" && userType != "SUPER_USER")
          ) {
            // let prdtsArray = await getAllProductsExceedingAvailableQty(
            //   allSelectedProducts
            // );
            // let text = `Products: ${prdtsArray.map(
            //   (item, index) =>
            //     item + (index + 1 == prdtsArray?.length ? " " : ", ")
            // )}`;
            let text = `Products: ${item.catalogNo} - `;
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              text + Strings["ime.scanner.quantity.zero.available.quantity.msg"]
            );
          } else {
            showToast(
              "Request Stock Validation",
              "Please enter quantity greater than 0 to consume request!"
            );
          }
        } else {
          if (
            stockRoomDetail?.isMaximumConsumptionEnabled &&
            item?.maxConsumptionQuantity != null
          ) {
            if (
              !stockRoomDetail.isOverConsume &&
              pActualQty > item?.maxConsumptionQuantity
            ) {
              flag = 0;
              showToast(
                Strings["ime.scanner.error.occured.msg"],
                stockRoomDetail?.maxConsumptionText
              );
            } else if (
              stockRoomDetail.isOverConsume &&
              !!isShowAlert &&
              pActualQty > item?.maxConsumptionQuantity
            ) {
              flag = 0;
              setIsVisibleMaxconsumptionPopup(true);
            }
          }
        }
      }
      return {
        id: item.id,
        quantity: item.actualQty,
        costCenterName: undefined,
        departmentName: undefined,
        ...{ batches: batches?.length ? batches : [] },
      };
    });
    if (selectedProducts?.length && flag == 1) {
      if (isConsumeView) {
        consumeCustomPrivilage == "request"
          ? onPressRequest()
          : onPressConsume();
      } else {
        setOrderPreviewData(allSelectedProducts);
        setIsConsumeView(true);
      }
    }
  }
};
const onConsumeLogic = async (
  allSelectedProducts: any,
  showToast: any,
  consumeSuccessCallBack: any,
  stockRoomDetail: any,
  userValue: any,
  costValue: any,
  departmentValue: any,
  orderData: any,
  dateFormat: any,
  checkifBatchEnabled: any,
  checkifExpiryEnabled: any,
  consumeCustomPrivilage: any,
  userType: any,
  isShowAlert: any,
  setIsShowAlert: any,
  setIsVisibleMaxconsumptionPopup: any,
  Strings: any
) => {
  let flag = 1;
  if (!userValue) {
    flag = 0;
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      Strings["ime.scanner.Please.select.a.user"]
    );
  } else if (stockRoomDetail?.isCostCenterMandatory && !costValue) {
    flag = 0;
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      Strings["ime.scanner.Please.select.a.cost.center"]
    );
  } else if (stockRoomDetail?.isDepartmentMandatory && !departmentValue) {
    flag = 0;
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      Strings["ime.scanner.Please.select.a.department"]
    );
  } else if (!allSelectedProducts?.length) {
    flag = 0;
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      Strings["ime.scanner.select.one.product.msg"]
    );
  } else {
    const selectedProducts = allSelectedProducts?.map((item: any) => {
      let batches;
      let pActualQty = 0;
      if (
        (!!checkifBatchEnabled(item) || !!checkifExpiryEnabled(item)) &&
        item?.batches?.length
      ) {
        batches = item?.batches.map((batch: any) => {
          const { batchNo, actualQty, expiryDate, availableQty, id } = batch;
          const bActualQty = !!actualQty ? parseInt(actualQty) : 0;
          const bAvailableQty = !!availableQty ? parseInt(availableQty) : 0;

          if (batchNo == "" && !!checkifBatchEnabled(item)) {
            flag = 0;
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.batch.empty.msg"]
            );
            throw new Error("batchNo occured");
          } else if (
            (!expiryDate || expiryDate == "") &&
            !!checkifExpiryEnabled(item)
          ) {
            flag = 0;
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.expiry.date.empty.msg"]
            );
            throw new Error("expiryDate occured");
          } else if (
            (!bActualQty || bActualQty > bAvailableQty) &&
            !(consumeCustomPrivilage == "request" && userType != "SUPER_USER")
          ) {
            flag = 0;
            let text = `BatchProducts: ${item.catalogNo} - Batch: ${batchNo} - `;
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              text + Strings["ime.scanner.quantity.zero.available.quantity.msg"]
            );

            throw new Error("actualQty occured");
          }
          pActualQty += bActualQty;
          return {
            id: id?.includes("addedBatch") ? null : id,
            availableQty: id?.includes("addedBatch")
              ? 0
              : availableQty
              ? availableQty
              : "0",
            consumedQty: actualQty,
          };
        });

        if (
          stockRoomDetail?.isMaximumConsumptionEnabled &&
          item?.maxConsumptionQuantity != null
        ) {
          if (
            !stockRoomDetail.isOverConsume &&
            pActualQty > item?.maxConsumptionQuantity
          ) {
            flag = 0;
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              stockRoomDetail?.maxConsumptionText
            );
          } else if (
            stockRoomDetail.isOverConsume &&
            !!isShowAlert &&
            pActualQty > item?.maxConsumptionQuantity
          ) {
            flag = 0;
            setIsVisibleMaxconsumptionPopup(true);
          }
        }
      } else {
        const pActualQty = !!item.actualQty ? parseInt(item.actualQty) : 0;
        const availableQty = !!item.availableQty
          ? parseInt(item.availableQty)
          : 0;

        if (
          (!pActualQty || pActualQty > availableQty) &&
          !(consumeCustomPrivilage == "request" && userType != "SUPER_USER")
        ) {
          flag = 0;
          let text = `Products: ${item.catalogNo} - `;
          showToast(
            Strings["ime.scanner.error.occured.msg"],
            text + Strings["ime.scanner.quantity.zero.available.quantity.msg"]
          );
        } else {
          if (
            stockRoomDetail?.isMaximumConsumptionEnabled &&
            item?.maxConsumptionQuantity != null
          ) {
            if (
              !stockRoomDetail.isOverConsume &&
              pActualQty > item?.maxConsumptionQuantity
            ) {
              flag = 0;
              showToast(
                Strings["ime.scanner.error.occured.msg"],
                stockRoomDetail?.maxConsumptionText
              );
            } else if (
              stockRoomDetail.isOverConsume &&
              !!isShowAlert &&
              pActualQty > item?.maxConsumptionQuantity
            ) {
              flag = 0;
              setIsVisibleMaxconsumptionPopup(true);
            }
          }
        }
      }

      return {
        id: item.id,
        quantity: item.actualQty,
        costCenterName: !!costValue ? costValue : undefined,
        departmentName: !!departmentValue ? departmentValue : undefined,
        ...{ batchProducts: batches?.length ? batches : undefined },
      };
    });

    if (selectedProducts?.length && flag != 0) {
      const params = [];
      orderData.map((item, index) => {
        let d = {
          id: item.id,
          quantity: item.actualQty,
          costCenterName: !!costValue ? costValue : undefined,
          departmentName: !!departmentValue ? departmentValue : undefined,
        };
        if (item.batchProducts?.length) {
          delete d.quantity;
          let batchProducts = [];
          item.batches.map((i, j) => {
            batchProducts.push({
              id: i.id,
              consumedQty: i.actualQty,
            });
          });
        }
        params.push(d);
      });

      consumeSuccessCallBack(selectedProducts);
    }
  }
};
const handleAvailQtyLogic = async (
  val: any,
  id: any,
  orderData?: any,
  setOrderData?: any
) => {
  let orders = [...orderData];
  orders.map(async (product) => {
    if (product.id === id) {
      product.actualQty = val;
      // console.warn(val);
      product.selected = !!parseInt(val);
    }
  });
  setOrderData(orders);
};
const onChangeCommentTextLogic = async (
  val: any,
  id: any,
  setOrderData: any
) => {
  setOrderData((prevProducts) => {
    const updatedProducts = prevProducts.map((product) => {
      if (product.id === id) {
        let d = { ...product, comments: val };
        return d;
      }
      return product;
    });
    return updatedProducts;
  });
};
const handleBatchesLogic = async (
  batches: any,
  batchId: any,
  itemId: any,
  products: any,
  setOrderData?: any
) => {
  let arr = [...products];
  let arrIndex = arr?.findIndex((obj: { id: any }) => obj?.id == itemId);
  let batchIndex = batches?.findIndex((obj: { id: any }) => obj?.id == batchId);
  const itemIndex = arr[arrIndex]?.batches.findIndex(
    (obj: { id: string }) => obj?.id == batchId
  );
  if (itemIndex >= 0) {
    await arr[arrIndex]?.batches.map((obj: any) => {
      if (obj?.id == batchId) {
        obj["actualQty"] = batches[batchIndex]["actualQty"];
        obj["batchNo"] = batches[batchIndex]["batchNo"];
        obj["expiryDate"] = batches[batchIndex]["expiryDate"];
      }
    });
  } else {
    arr[arrIndex]?.batches?.push(batches[batchIndex]);
  }
  setOrderData(arr);
};

const checkForMaxConsumptionQty = async (
  item: any,
  childState: any,
  showOverConsumePopup: any
) => {
  let data = {
    maxConsumptionText: "",
    isOverconsume: null,
    isMaximumConsumptionEnabled: null,
  };
  if (
    item.isMaximumConsumptionEnabled &&
    item?.maxConsumptionQuantity != null
  ) {
    //check if the qty is less that or equal to maxConsumptionQuantity
    data.maxConsumptionText = item.maxConsumptionText;
    if (childState.actualQty > item.maxConsumptionQuantity)
      if (item.isOverConsume)
        showOverConsumePopup(true, data.maxConsumptionText);
      else return data;
  } else return data;
};

const getAllProductsExceedingAvailableQty = async (products: any) => {
  let array = [];
  products.map((item) => {
    if (item.actualQty > item.availableQty) {
      array.push(item.catalogNo);
    }
  });
  return array;
};

const handleBatchDeleteLogic = async (
  item: any,
  val: any,
  productsDataArray?: any,
  setOrderData?: any
) => {
  let arr = productsDataArray;

  let objIndex = arr.findIndex((obj: { id: any }) => obj?.id == item?.id);

  const findIndex = arr[objIndex]?.batches?.findIndex(
    (obj: { id: any }) => obj?.id === val?.id
  );
  findIndex !== -1 && arr[objIndex]?.batches?.splice(findIndex, 1);
  setOrderData([...arr]);
};
const onChangeCostSearchLogic = (searchKey: string, costCenterList: any) => {
  const filterData = filterByMultipleKeys(
    costCenterList,
    "costCenterName",
    "id",
    searchKey
  );

  return filterData;
};

const onChangeDepartmentLogic = (searchKey: string, deptList: any) => {
  const filterData = filterByMultipleKeys(
    deptList,
    "departmentName",
    "id",
    searchKey
  );
  return filterData;
};

const filterByMultipleKeys = (
  blockData: any,
  firstKey: string,
  secondKey: string,
  searchText: any
) => {
  let filteredData = null;
  if (blockData) {
    filteredData = blockData?.filter((element) => {
      return (
        element?.[firstKey]?.toLowerCase() +
        " " +
        element?.[secondKey]?.toLowerCase()
      ).includes(searchText?.toLowerCase());
    });
  }
  return filteredData;
};
/**Offline Logics */
const updateItemQtyLogic = async (
  products: any,
  setProducts: any,
  val: any,
  index: any,
  saveDataToStorage: any,
  from: any,
  matchNotFoundProducts: any
) => {
  let updatedProducts = [...products];
  updatedProducts[index].actualQty = val;
  updatedProducts[index].selectedQty = val;
  updatedProducts[index].selectedQty = val;
  updatedProducts[index].selected = val > 0;
  updatedProducts[index].isSelected = val > 0;
  setProducts(updatedProducts);
  if (!matchNotFoundProducts.length) {
    await saveDataToStorage(
      from == "consume" ? "consume_offline_data" : "replenish_offline_data",
      updatedProducts
    );
  }
};
const updateProductItemLogic = (
  products: any,
  setProducts: any,
  val: any,
  index: any
) => {
  let updatedProducts = [...products];
  updatedProducts[index].catalogNo = val;
  setProducts(updatedProducts);
};

const onSyncPressLogic = (
  products: any,
  selectedProducts: any,
  showOfflineCollection: any,
  showToast: any,
  successCallBack: any,
  Strings: any
) => {
  if (products?.length == 0) {
    showOfflineCollection(false);
  } else if (selectedProducts?.length == 0) {
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      Strings["ime.scanner.select.one.product.msg"]
    );
  } else if (selectedProducts?.some((item: any) => item.actualQty == 0)) {
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      Strings["ime.scanner.quantity.zero.available.quantity.msg"]
    );
  } else {
    successCallBack();
  }
};
const onPressProcessLogic = async (
  type: any,
  products: any,
  setProducts: any,
  matchNotFoundProducts: any,
  mergeAndRemoveDuplicates: any,
  modalData: any,
  setProcessView: any,
  setshowProcessModal: any,
  setModalData: any,
  offlineBatchProducts: any,
  offlineDuplicateProducts: any,
  setOfflineBatchProducts: any
) => {
  if (type == "invalid" && matchNotFoundProducts?.length) {
    await setProducts(matchNotFoundProducts);
    // await setMatchNotFoundProducts([]);
  } else if (offlineDuplicateProducts?.length) {
  } else {
    const updatedMatchFoundProducts = await mergeAndRemoveDuplicates(
      offlineBatchProducts,
      [],
      [],
      true
    );
    setOfflineBatchProducts(updatedMatchFoundProducts);
    setProducts(updatedMatchFoundProducts);
  }
  setModalData(modalData);
  // setshowProcessModal(false);
  setProcessView(true);
};
const onNextProcessLogic = async (
  setCurrentIndex: any,
  updatedMatchFoundProducts: any,
  setProcessView: any,
  setshowProcessModal: any,
  setProducts: any,
  setMatchFoundProducts: any,
  setMatchNotFoundProducts: any,
  setOfflineBatchProducts: any,
  showOfflineCollection: any,
  from: any,
  replenishCallBack: any,
  setOrderView?: any,
  setIsConsumeView?: any,
  setOrderData?: any,
  setOrderPreviewData?: any,
  setSearchKey?: any,
  setIsDataUpdating?: any,
  setDefOfflineProducts?: any
) => {
  setshowProcessModal(false);
  setCurrentIndex(0);
  setSearchKey?.("");
  setProducts([]);
  setMatchFoundProducts([]);
  setMatchNotFoundProducts([]);
  setOfflineBatchProducts([]);
  if (from == "consume") {
    setIsDataUpdating?.(true);
    setTimeout(() => {
      setIsDataUpdating?.(false);
      showOfflineCollection(false);
      setDefOfflineProducts?.(false);
      setOrderPreviewData?.(updatedMatchFoundProducts);
      setOrderData?.(updatedMatchFoundProducts);
      setProcessView(false);
      setOrderView?.(true);
      setIsConsumeView?.(true);
    }, 50);
  } else {
    showOfflineCollection(false);
    setProcessView(false);
    replenishCallBack(updatedMatchFoundProducts);
  }
};
const onUpdateItemLogic = (
  setEditView: any,
  setModalData: any,
  onSyncPress: any,
  modalData: any
) => {
  setEditView(false);
  setModalData(modalData);
  onSyncPress();
};
const onDeleteItemLogic = (
  index: any,
  products: any,
  setProducts: any,
  offlineBatchProducts: any,
  matchFoundProducts: any,
  setMatchNotFoundProducts: any,
  setIsVisibleClearOrder: any,
  onPressClearOrder: any,
  setProcessView: any,
  setEditView: any,
  setBatchView: any,
  checkduplicates: any,
  processView: any
) => {
  setIsVisibleClearOrder(false);
  let array = [...products];
  array.splice(index, 1);
  setProducts(array);
  setMatchNotFoundProducts(array);
  if (array?.length == 0) {
    if (
      processView &&
      !matchFoundProducts.length &&
      !offlineBatchProducts.length
    ) {
      onPressClearOrder?.();
    } else checkduplicates();
  }
};
export {
  onPrimaryButtonPressLogic,
  onConsumeLogic,
  handleAvailQtyLogic,
  handleBatchDeleteLogic,
  handleBatchesLogic,
  onChangeCommentTextLogic,
  checkForMaxConsumptionQty,
  onChangeCostSearchLogic,
  onChangeDepartmentLogic,
  filterByMultipleKeys,
  updateItemQtyLogic,
  updateProductItemLogic,
  onSyncPressLogic,
  onPressProcessLogic,
  onNextProcessLogic,
  onUpdateItemLogic,
  onDeleteItemLogic,
};
