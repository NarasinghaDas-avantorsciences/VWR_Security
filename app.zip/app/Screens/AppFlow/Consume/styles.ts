import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  syncButtonText: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_9,
  },
  syncButton: {
    height: hp(6),
    width: wp(20),
  },
  itemFooter: {
    height: hp(10),
    width: wp(100),
  },
  bottomSheetContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: SIZES.base,
    paddingVertical: SIZES.radius,
    borderBottomWidth: 1,
    borderTopWidth: 1,
    borderBottomColor: COLORS.whiteSmoke,
    borderTopColor: COLORS.whiteSmoke,
  },
  stockTitle: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
    width: SIZES.width * 0.6,
    textAlign: "center",
  },
  contentContainerStyle: {
    flexGrow: 1,
    paddingBottom: hp(6),
  },
  buttonsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: SIZES.base,
    position: "absolute",
    paddingBottom: wp(6),
    backgroundColor: COLORS.white,
    width: "100%",
    bottom: 0,
  },
  cancelButtonContainer: {
    width: "50%",
    alignItems: "center",
    padding: SIZES.padding,
  },
  mainText: { ...FONTS.title, color: COLORS.white },

  searchContainer: {
    marginVertical: wp(1),
    marginTop: wp(3.5),
  },

  leftIconContainer: { marginRight: wp(4) },

  leftIcon: { width: wp(20), height: wp(20) },

  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },

  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },

  qtyInfoContainer: {
    paddingVertical: hp(0.8),
    marginVertical: hp(1.2),
  },

  itemSubHeaderStyle: {
    textAlign: "center",
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    minWidth: wp(10),
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
    position: "absolute",
    paddingVertical: hp(0.1),
  },

  itemContainerStyle: {
    marginVertical: hp(1),
    borderBottomWidth: 1,
    paddingBottom: hp(0.5),
    borderColor: COLORS.whiteSmoke,
  },

  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginTop: hp(1.2),
  },

  itemChildContainer: {
    width: wp(45),
    marginVertical: wp(0.5),
    paddingVertical: 8,
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },

  dataContainer: {
    paddingBottom: hp(10),
    marginHorizontal: 16,
    marginBottom: hp(5),
  },

  scannerBtn: { bottom: hp(5) },
  scannerBtnOrder: {
    bottom: hp(13),
  },

  footerMainContainer: { bottom: 0 },

  outlinedBtnText: { color: COLORS.gray },

  outlinedBtnContainer: { borderWidth: 0 },
  consumeView: {
    marginBottom: hp(3),
    marginTop: hp(2),
  },
  tagContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: hp(0.4),
  },
  clearModalContainer: { height: SIZES.height * 0.2 },
  clearContainer: {
    flex: 1,

    justifyContent: "center",
    alignItems: "center",
  },
  clearOrderTitle: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h2,
    color: COLORS.black,
  },
  clearOrderDesc: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h2,
    color: COLORS.black,
    marginVertical: hp(1),
  },
  cancelContainer: {
    width: wp(45),
    marginTop: hp(1),
    marginLeft: 0,
    borderWidth: 0,
  },
  cancelText: { ...FONTS.body, color: COLORS.gray },
  clearOrderContainer: {
    width: wp(30),
    marginTop: hp(1),
  },
  clearOrderText: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.white,
    fontSize: FONTS.h2,
  },
  warningText: {
    position: "absolute",
    bottom: hp(10),
    backgroundColor: COLORS.aliceBlue,
    width: "100%",
    textAlign: "justify",
    paddingHorizontal: wp(2),
    paddingVertical: wp(2),
    ...FONTS.title2,
    color: COLORS.black,
  },
  emptyContainer: { alignItems: 'center', justifyContent: 'center' },
  emptyText: { color: COLORS.lightGray, fontFamily: FONTFAMILY.averta_semibold, marginTop: wp(8) },
});
