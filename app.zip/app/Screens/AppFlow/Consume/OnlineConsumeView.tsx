import React, { useEffect } from "react";
import {
  Image,
  ScrollView,
  View,
  Pressable,
  Keyboard,
  TouchableOpacity,
  TouchableWithoutFeedback,
} from "react-native";
import { DefaultProductImage, Locked } from "../../../Utils/images";
import {
  wp,
  isProductFreezed,
  getMultiplier,
} from "../../../Utils/globalFunction";
import {
  getProductDetails,
  getProductList,
  setProductLoader,
  getProductBatchDetails,
  emptyProductData,
  setProductBatchLoader,
  getOfflineProducts,
  getProductListFromBarcode,
} from "../../../Redux/Action/searchAction";
import Text from "../../../Components/CustomText";
import {
  AnimatedSearch,
  ConsumeDropdown,
  ConsumeOrderView,
  ConsumeTag,
  ListItem,
  SearchBar,
} from "../../../Components";
import { useDispatch, useSelector } from "react-redux";
import { Toast } from "react-native-toast-message/lib/src/Toast";
import styles from "./styles";
import {
  handleAvailQtyLogic,
  handleBatchesLogic,
  onChangeCommentTextLogic,
} from "./logic";
import { setLoader } from "../../../Redux/Action/consumeAction";
import { SIZES } from "../../../Utils/theme";

interface OnlineConsumeView {
  isConsume: any;
  isOrderView: any;
  batchFetchSuccess: any;
  checkifTheBatchItemExistInOrder: any;
  setOrderView: any;
  setIsConsumeView: any;
  batchFetchFailed: any;
  isConsumeView: any;
  uSerPriceData:any,
  setUserValue: any;
  userValue: any;
  userList: any;
  showToast: any;
  userDataList: any;
  setCostValue: any;
  costValue: any;
  costCenterList: any;
  userId: any;
  newCostArray: any;
  setCostCenterList: any;
  setNewCostArray: any;
  costCentersList: any;
  setDepartmentValue: any;
  depratmentValue: any;
  departmentList: any;
  newDepArray: any;
  setNewDeptArray: any;
  offlineCollection: any;
  orderPreviewData: any;
  bottomSheetRefDetails: any;
  setDeapartmentList: any;
  searchKey: any;
  setSearchKey: any;
  checkifBatchEnabled: any;
  checkifExpiryEnabled: any;
  pageSize: any;
  productsData: any;
  checkifTheItemExistInOrder: any;
  setChildState: any;
  setSelectedItem: any;
  bottomSheetRef: any;
  selectedItem: any;
  selectedItemId: any;
  setIsShowWarn: any;
  setIsShowAlert: any;
  setUserList: any;
  orderData: any;
  setOrderData: any;
  departments: any;
  setPage: any;
  page: any;
}

const OnlineConsumeView = (props: OnlineConsumeView) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const {
    isConsume,
    isOrderView,
    batchFetchSuccess,
    checkifTheBatchItemExistInOrder,
    setOrderView,
    setIsConsumeView,
    batchFetchFailed,
    isConsumeView,
    uSerPriceData,
    setUserValue,
    userValue,
    userList,
    showToast,
    userDataList,
    setCostValue,
    costValue,
    costCenterList,
    userId,
    newCostArray,
    setCostCenterList,
    setNewCostArray,
    costCentersList,
    setDepartmentValue,
    depratmentValue,
    departmentList,
    newDepArray,
    setNewDeptArray,
    offlineCollection,
    orderPreviewData,
    bottomSheetRefDetails,
    setDeapartmentList,
    searchKey,
    setSearchKey,
    checkifBatchEnabled,
    checkifExpiryEnabled,
    pageSize,
    productsData,
    checkifTheItemExistInOrder,
    setChildState,
    setSelectedItem,
    bottomSheetRef,
    selectedItem,
    selectedItemId,
    setIsShowWarn,
    setIsShowAlert,
    setUserList,
    orderData,
    setOrderData,
    departments,
    setPage,
    page,
  } = props;

  const { stockRoomDetail, userSelectPrivilege } = useSelector(
    (state: any) => state.userReducer
  );
  const { productDetailsLoading } = useSelector(
    (state: any) => state.searchReducer
  );
  const dispatch = useDispatch<any>();

  const _renderList = () => {
    const filteredData = productsData?.data?.length && productsData?.data;
    return (
      filteredData?.length &&
      filteredData?.map((item: any, index: number) => {
        return renderItem(item, index);
      })
    );
  };
  const resetProductData = async (value) => {
    dispatch(setProductLoader(value));
    dispatch(emptyProductData());
  };
  const onPressItem = async (item) => {
    if (!checkifTheItemExistInOrder(item.id)) {
      dispatch(setProductBatchLoader(true));
      await dispatch(
        getProductBatchDetails(
          item?.id ?? "",
          (data: any) => {
            dispatch(setProductBatchLoader(false));
            console.log(data);
            let batches = data;
            item["batches"] = batches;
            setChildState(null);
            setSelectedItem(item);
            bottomSheetRef?.current?.open();
          },
          (error: any) => {
            dispatch(setProductBatchLoader(false));
            errorCallBack(error);
          }
        )
      );
    } else {
      showToast(
        Strings["ime.scanner.error.occured.msg"],
        Strings["ime.scanner.Item.already.exists.in.the.order"]
      );
    }
  };
  const handleAvailQty = (val: any, id: any, item?: any) => {
    if (
      stockRoomDetail?.isMaximumConsumptionEnabled &&
      item?.maxConsumptionQuantity != null
    ) {
      if (Number(val) > item?.maxConsumptionQuantity) {
        if (stockRoomDetail?.isOverConsume) {
          setIsShowWarn(false);
          setIsShowAlert(true);
        } else {
          setIsShowWarn(true);
          setIsShowAlert(false);
        }
      } else {
        setIsShowWarn(false);
        setIsShowAlert(false);
      }
      handleAvailQtyLogic(val, id, orderData, setOrderData);
    } else {
      handleAvailQtyLogic(val, id, orderData, setOrderData);
    }
  };
  const handleScroll = (event) => {
    const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;
    const newProducts = productsData?.data?.length ? productsData?.data : [];
    const isEndReached =
      layoutMeasurement.height + contentOffset.y + 5 >= contentSize.height;
    if (
      isEndReached &&
      !productDetailsLoading &&
      newProducts?.length < productsData?.data?.totalCount
    ) {
      loadMoreData();
    }
  };
  const loadMoreData = () => {
    setPage((prevPage) => prevPage + 1);
    setTimeout(() => {
      dispatch(
        getProductList(searchKey, (page == 1 ? page + 1 : page) * pageSize)
      );
    }, 800);
  };
  const getTotalPrice = () => {
    return  calculateTotalPurchasePrice(orderData, uSerPriceData);
  };
  const calculateTotalPurchasePrice = (orderData: any[], uSerPriceData: { data: any; }) => {
    if(uSerPriceData?.data?.length > 0){
    const purchasePriceMap = (uSerPriceData?.data || []).reduce((map, item) => {
      const price = parseFloat(item.purchasePrice);
      if (!isNaN(price)) {
        map[item.id] = price;
      }
      return map;
    }, {});
  
    const totalPurchasePrice = orderData
      ?.reduce((sum, item) => {
        if (item.selected) {
          const price = purchasePriceMap[item.id] * parseFloat(item?.actualQty ?? 0);
          return isNaN(price) ? sum : sum + price;
        }
        return sum;
      }, 0)
      .toFixed(2);
  
    return totalPurchasePrice;
    }else{
      return orderData
      ?.reduce((sum, item) => {
        if (item.selected) {
          const price =
            parseFloat(item?.purchasePrice) * parseFloat(item?.actualQty ?? 0);
          return sum + price;
        }
        return sum;
      }, 0)
      .toFixed(2);
    }
  };
  const onPressItemCheck = (index: number) => {
    const newArray = [...orderData];
    newArray[index].selected = !newArray[index].selected;
    setOrderData(newArray);
  };
  const onPressDropDownItem = (index: number, type: string) => {
    let newArray = [...userList];
    if (type === "cost") {
      newArray = [...costCenterList];
    } else if (type === "department") {
      newArray = [...departmentList];
    }
    newArray.map((element, idx) => {
      if (idx == index) {
        element.selected = true;

        if (type === "user") {
          setUserValue(element.title);
        } else if (type === "cost") {
          setCostValue(element.title);
        } else if (type === "department") {
          setDepartmentValue(element.title);
        }
      } else {
        element.selected = false;
      }
    });
    if (index == -1) {
      if (type === "user") {
        setUserValue("");
      } else if (type === "cost") {
        setCostValue("");
      } else if (type === "department") {
        setDepartmentValue("");
      }
    }
    if (type === "user") {
      setUserList(newArray);
    } else if (type === "cost") {
      setCostCenterList(newArray);
    } else if (type === "department") {
      setDeapartmentList(newArray);
    }
  };
  const onPressSelectAll = (state: boolean) => {
    const newArray = [...orderData];
    orderData.map((e, index) => {
      return (e.selected = state);
    });
    setOrderData(newArray);
  };
  const errorCallBack = (err) => {
    if (err?.errorMessage) {
      Toast.show({
        type: "alertToast",
        text1: err?.errorMessage,
      });
    } else {
      Toast.show({
        type: "alertToast",
        text1: Strings["ime.attention"],
        text2: "Error occured while fetching the batch",
      });
    }
  };

  const setFormatedData = async (value, id) => {
    let updatedProducts = [...orderData];
    const index = updatedProducts.findIndex((item) => item.id == id);
    if (index != -1) {
      updatedProducts[index].batches = value;
      setOrderData(updatedProducts);
    }
  };
  const handleBatch = (batches: any, batchId: string, itemId: string) => {
    handleBatchesLogic(batches, batchId, itemId, orderData, setOrderData);
  };

  const onChangeCommentText = async (val: any, id: any) => {
    onChangeCommentTextLogic(val, id, setOrderData);
  };

  const renderItemHeader = (item: any) => {
    const uomId =
      item?.uomManagementEnabled == 1 ? item.stockRoomUOMUnit : item.uomId;
    return (
      <TouchableOpacity
        accessible={true}
        accessibilityLabel="item_header_button"
        onPress={() => {}}
      >
        <Text
          accessibilityLabel="catalog_no_value"
          style={styles.catalogNumber}
        >
          {item?.catalogNo}
        </Text>
        <Text
          accessibilityLabel="description_value"
          onPress={() => onPressItem(item)}
          style={styles.itemHeaderContent}
        >
          {item?.description}
        </Text>
        {isConsume &&
          (!!checkifBatchEnabled(item) || !!checkifExpiryEnabled(item)) && (
            <View
              accessible={true}
              accessibilityLabel="tag_container"
              style={styles.tagContainer}
            >
              {!!checkifBatchEnabled(item) && (
                <ConsumeTag tag="Batch Controlled" />
              )}
              {!!checkifExpiryEnabled(item) && (
                <ConsumeTag tag="Expiry Date Controlled" />
              )}
            </View>
          )}
        {!!uomId && (
          <View
            accessible={true}
            accessibilityLabel="item_uomid_container"
            style={styles.qtyInfoContainer}
          >
            <Text
              accessibilityLabel="item_uomid_value"
              style={styles.itemSubHeaderStyle}
            >{`(${uomId})`}</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };
  const renderItem = (item: Item, index: number) => {
    return (
      <ListItem
        leftIcon={
          <View
            accessible={true}
            accessibilityLabel={"left_icon_cointainer"}
            style={styles.leftIconContainer}
          >
            {!!item.imagePath || !!item?.imageURL ? (
              <Image
                accessible={true}
                accessibilityLabel={"item_image"}
                source={{
                  uri: item.imagePath
                    ? `https://vsr-stage4.vwr.com/${item?.imagePath}`
                    : item?.imageURL.replace("http://", "https://"),
                }}
                style={styles.leftIcon}
                resizeMode={"contain"}
              />
            ) : (
              <DefaultProductImage
                accessible={true}
                accessibilityLabel={"default_image"}
                width={wp(18)}
                height={wp(18)}
              />
            )}
          </View>
        }
        headerContent={renderItemHeader(item)}
        rightIcon={
          item?.freeze == true && (
            <Locked
              accessible={true}
              accessibilityLabel="consume-item-locked-image"
            />
          )
        }
        customStyles={{ container: styles.itemContainerStyle }}
        onPress={() => onPressItem(item)}
      >
        <View
          accessible={true}
          accessibilityLabel={"row_flex_container"}
          style={styles.flexRowContainer}
        >
          <DetailItem
            // value={item?.availableQty}
            value={`${item?.availableQty + " "}${
              getMultiplier(item) == null ? " " : getMultiplier(item)
            }`}
            title={Strings["ime.availqty"] ?? "Avail Qty"}
          />
          <DetailItem value={item?.vendorName} title={Strings["vendor"]} />
        </View>
        {!!(index == productsData?.data?.length - 1) && itemFooter()}
      </ListItem>
    );
  };
  const DetailItem = ({ value, title }) => {
    return (
      <View
        accessible={true}
        accessibilityLabel={"detail_item_container"}
        style={[styles.itemChildContainer]}
      >
        <Text
          accessibilityLabel={"item_title "}
          style={styles.itemChildTitleText}
        >
          {title}
        </Text>
        <Text
          accessibilityLabel={"item_value"}
          style={styles.itemChildValueText}
        >
          {value}
        </Text>
      </View>
    );
  };

  const itemFooter = () => {
    return (
      <View
        accessible={true}
        accessibilityLabel="footer_component"
        style={styles.itemFooter}
      />
    );
  };
  const noDataFound = () => {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>{Strings["no.records.found"]}</Text>
      </View>
    );
  };

  const getProductFromApi = async (searchKey: any, pageSize: any) => {
    dispatch(
      getProductListFromBarcode(
        searchKey,
        pageSize,
        async (res: any) => {
          // if (res?.data[0]?.catalogNo == searchKey) {
          if (
            res?.data[0]?.catalogNo == searchKey ||
            res?.data[0]?.vendorCatalogNo == searchKey ||
            res?.data[0]?.custCatalogNo == searchKey
          ) {
            // renderItemFromBarcode(res?.data[0]);
            setChildState?.(null);
            await setSelectedItem(res?.data[0]);
            bottomSheetRef?.current?.open();
            dispatch(setLoader(false));
          } else {
            Toast.show({
              type: "alertToast",
              text1: Strings["ime.scanner.error.occured.msg"],
              text2: "Product does not exist!",
              position: "bottom",
              bottomOffset: SIZES.padding * 2,
            });
            dispatch(setLoader(false));
          }
        },
        (res: any) => {
          dispatch(setLoader(false));

          console.log(res);
        }
      )
    );
  };

  return (
    <ScrollView
      accessible={true}
      accessibilityLabel={"scrollview"}
      style={styles.dataContainer}
      showsVerticalScrollIndicator={false}
      overScrollMode="never"
      onScroll={(event) => {
        Keyboard?.dismiss();
        !isOrderView && handleScroll(event);
      }}
      keyboardShouldPersistTaps="handled"
      scrollEventThrottle={16}
    >
      {isConsumeView && searchKey == "" && (
        <View
          accessible={true}
          accessibilityLabel={"consume_view_container"}
          style={styles.consumeView}
        >
          <ConsumeDropdown
            onBarcodeDetected={(barcode) => setUserValue(barcode)}
            title={Strings["user"]}
            value={userValue}
            items={userList}
            onPressItem={(index) => onPressDropDownItem(index, "user")}
            required={true}
            buttonEnabled={false}
            showToast={showToast}
            allData={userDataList}
            disabled={!userSelectPrivilege}
          />
          <ConsumeDropdown
            onBarcodeDetected={(barcode) => setCostValue(barcode)}
            title={Strings["cost.center"]}
            value={costValue}
            items={costCenterList}
            onPressItem={(index) => onPressDropDownItem(index, "cost")}
            required={stockRoomDetail?.isCostCenterMandatory}
            buttonEnabled={stockRoomDetail?.oneTimeCostCenterEnabled}
            type={"cost_center"}
            userId={userId}
            buttonTitle={Strings["ime.scanner.Add.One-Time.Cost.Center"]}
            showToast={showToast}
            callBack={(res) => {
              let data = [...newCostArray];
              let item = {
                id: res?.data?.id,
                title: res?.data?.costCenterName,
                costCenterName: res?.data?.costCenterName,
                selected: false,
              };
              data.push(item);
              setCostCenterList([...costCenterList, item]);
              setNewCostArray(data);
            }}
            baseSelectedValue={userValue}
            allData={[...costCentersList, ...newCostArray]}
            maxLength={50}
          />
          <ConsumeDropdown
            onBarcodeDetected={(barcode) => setDepartmentValue(barcode)}
            type={"department"}
            userId={userId}
            title={Strings["department"]}
            value={depratmentValue}
            items={departmentList}
            onPressItem={(index) => onPressDropDownItem(index, "department")}
            required={stockRoomDetail?.isDepartmentMandatory}
            buttonEnabled={stockRoomDetail?.oneTimeDepartmentEnabled}
            buttonTitle={Strings["ime.scanner.Add.One-Time.Department"]}
            showToast={showToast}
            callBack={(res) => {
              let data = [...newDepArray];
              let item = {
                id: res?.data?.id,
                title: res?.data?.departmentName,
                departmentName: res?.data?.departmentName,
                selected: false,
              };
              data.push(item);
              setNewDeptArray(data);
              setDeapartmentList([...departmentList, item]);
            }}
            baseSelectedValue={userValue}
            allData={[...departments, ...newDepArray]}
          />
        </View>
      )}
      <AnimatedSearch
        search={searchKey ?? ""}
        onSearch={async (text) => {
          await resetProductData(!!text);
          setIsShowAlert(false);
          setIsShowWarn(false);
          setSearchKey(text);
        }}
        containerStyle={styles.searchContainer}
        placeholder={
          Strings?.["ime.scanner.Search.Products"] ?? "Search Products"
        }
        clearText={async () => {
          await resetProductData("");
          setSearchKey("");
        }}
        onBarcodeDetected={async (barcode) => {
          let bcodes = barcode.split("*UI#");
          if (bcodes.length === 1) {
            // await resetProductData(!!bcodes[0]);
            // setSearchKey(bcodes[0]);
            // dispatch(getProductList(bcodes[0], pageSize));
            await getProductFromApi(bcodes[0], pageSize);
          } else {
            setSearchKey("");
            setIsConsumeView(false);
            setOrderView(false);
            /**Check if the batch already added */
            if (!checkifTheBatchItemExistInOrder(bcodes[0], bcodes[1])) {
              dispatch(setProductBatchLoader(true));
              const data = await new Promise((resolve, reject) => {
                dispatch(
                  getOfflineProducts(
                    bcodes[0],
                    async (res: any, productId: string) => {
                      resolve(res);
                    },
                    (res: any, productId: string) => {
                      reject(res);
                    }
                  )
                );
              });
              if (data?.[0]) {
                batchFetchSuccess(data[0], bcodes[1]);
              } else {
                dispatch(setProductBatchLoader(false));

                batchFetchFailed();
              }
            } else {
              showToast(
                Strings["ime.scanner.error.occured.msg"],
                Strings["ime.scanner.Item.already.exists.in.the.order"],
                3000,
                () => {}
              );
            }
          }
        }}
        from={"consume"}
        scanBatch={true}
        returnKeyLabel={Strings["save"]}
        returnKeyType="go"
        onCancel={() => {
          setSearchKey("");
          Keyboard.dismiss();
        }}
      />
      {/* <SearchBar
        search={searchKey}
        scanBatch={true}
        onSearch={async (text) => {
          await resetProductData(!!text);
          setIsShowAlert(false);
          setIsShowWarn(false);
          setSearchKey(text);
        }}
        placeholder={
          Strings?.["ime.scanner.Search.Products"] ?? "Search Products"
        }
        containerStyle={styles.searchContainer}
        onBarcodeDetected={async (barcode) => {
          let bcodes = barcode.split("*UI#");
          if (bcodes.length === 1) {
            await resetProductData(!!bcodes[0]);
            setSearchKey(bcodes[0]);
            dispatch(getProductList(bcodes[0], pageSize));
          } else {
            setSearchKey("");
            setIsConsumeView(false);
            setOrderView(false);
            if (!checkifTheBatchItemExistInOrder(bcodes[0], bcodes[1])) {
              dispatch(setProductBatchLoader(true));
              const data = await new Promise((resolve, reject) => {
                dispatch(
                  getOfflineProducts(
                    bcodes[0],
                    async (res: any, productId: string) => {
                      resolve(res);
                    },
                    (res: any, productId: string) => {
                      reject(res);
                    }
                  )
                );
              });
              if (data?.[0]) {
                batchFetchSuccess(data[0], bcodes[1]);
              } else {
                dispatch(setProductBatchLoader(false));

                batchFetchFailed();
              }
            } else {
              showToast(
                Strings["ime.scanner.error.occured.msg"],
                Strings["ime.scanner.Item.already.exists.in.the.order"],
                3000,
                () => {}
              );
            }
          }
        }}
        cancel={!!searchKey}
        onPressCancel={() => {
          setSearchKey("");
        }}
        returnKeyLabel={Strings["save"]}
        returnKeyType="go"
      /> */}
      {searchKey == "" && !isOrderView && noDataFound()}
      {searchKey != "" ? _renderList() : null}
      {searchKey == "" && (
        <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
          <ConsumeOrderView
            isConsume={isConsume}
            data={isConsumeView ? orderPreviewData : orderData}
            onPressItemCheck={onPressItemCheck}
            onPressSelectAll={onPressSelectAll}
            checkifBatchEnabled={checkifBatchEnabled}
            checkifExpiryEnabled={checkifExpiryEnabled}
            handleAvailQty={handleAvailQty}
            handleBatch={handleBatch}
            onNamePressed={async (item: any) => {
              setSelectedItem(item);
              setTimeout(() => {
                bottomSheetRefDetails?.current?.open();
              }, 500);
              await dispatch(getProductDetails(item?.id));
              await dispatch(setProductLoader(false));
            }}
            totalPrice={getTotalPrice()}
            itemPrice={uSerPriceData}
            item={selectedItem}
            key={`${selectedItemId}`}
            comment={false}
            freeze={isProductFreezed(selectedItem)}
            bottomBorder={true}
            rightIcon={<Locked />}
            onChangeCommentText={onChangeCommentText}
            setFormatedData={setFormatedData}
            showWarn={(val: boolean) => setIsShowWarn(val)}
            showAlert={(val: boolean) => setIsShowAlert(val)}
          />
        </TouchableWithoutFeedback>
      )}
    </ScrollView>
  );
};
export default OnlineConsumeView;
