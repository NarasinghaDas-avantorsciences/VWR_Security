import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";

export default StyleSheet.create({
    leftIconContainer: { paddingTop: wp(6), width: wp(10), alignItems: 'flex-start', justifyContent: 'center' },
    editContainer: { flexDirection: 'row', alignItems: 'flex-end' },
    offlineQtyContainer: { marginTop: wp(-4), alignSelf: 'flex-end', flexDirection: 'row', marginHorizontal: wp(2), alignItems: 'center' },
    offlineQty: { color: COLORS.abbey, fontFamily: FONTFAMILY.averta_bold, fontSize: FONTS.h2 },
    footerView: { marginVertical: wp(18) },
    updateButton: { marginBottom: wp(2), backgroundColor: COLORS.scienceBlue, padding: wp(1), borderRadius: wp(2), paddingHorizontal: wp(2) },
    updateButtonText: { color: COLORS.white, fontFamily: FONTFAMILY.averta_semibold, fontSize: FONTS.h1_4 },
    itemFooter: {
        height: wp(0.1),
        backgroundColor: COLORS.abbey,
        width: wp(100),
        marginTop: wp(1), marginBottom: wp(1)
    },
    productTxtContainerStyle: {
        width: wp(30),
        marginEnd: wp(1),
        alignSelf: "center",
        backgroundColor: COLORS.white,
    },
    inputStyle: {
        height: hp(4),
        padding: 0,
        fontSize: FONTS.h1_5,
        color: COLORS.abbey,
        left: -wp(2),
    },

    inputMainStyle: {
        height: hp(5),
        top: 0,
        borderColor: COLORS.gray2,
        borderWidth: 0.8,
    },
    main: {
        position: "absolute",
        width: "90%",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        borderWidth: 1,
        borderColor: COLORS.alto,
        elevation: 5,
        backgroundColor: COLORS.white,
        alignSelf: 'center',
        bottom: wp(4),
        borderRadius: 6,
        marginBottom: wp(20)
    },
    inner: {
        width: "90%",
        marginTop: hp(1),
        alignSelf: "center",
        paddingVertical: hp(2),
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    sub: {
        width: "90%",
        alignSelf: "center",
        paddingVertical: hp(2),
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    tite: {
        color: COLORS.blackBright,
        ...FONTS.title,
        marginBottom: SIZES.base,
    },
    processLabel: {
        color: COLORS.blackBright,
        ...FONTS.title,
        flex: 1,
        marginBottom: SIZES.base,
        textAlign: 'center',

    },
    des: {
        color: COLORS.blackBright,
        marginRight: wp(2),
        ...FONTS.body,
    },
    buttonMain: {
        borderWidth: 1,
        borderColor: COLORS.scienceBlue,
        justifyContent: 'flex-start',
        alignItems: "center",
        marginTop: hp(1),
    },
    buttonTitle: {
        padding: wp(1.5),
        color: COLORS.scienceBlue,
        fontSize: FONTS.h1_6,
        fontFamily: FONTFAMILY.averta_bold,
    },
    bottomTitle: {
        color: COLORS.blackBright,
        fontFamily: FONTFAMILY.averta_bold,
        fontSize: hp(2),
        marginBottom: SIZES.base,
        textTransform: "uppercase",
    },
    buttonContainers: {
        flexDirection: "row",
    },
    outlineBtnContainer: {
        width: wp(30),
        marginTop: hp(1),
        marginLeft: 0,
        marginRight: wp(4),
    },
    barcodeText: {
        color: COLORS.white,
        fontSize: FONTS.h1_6,
        fontFamily: FONTFAMILY.averta_bold,
    },
    footerMainContainer: { bottom: 0 },
    scannerBtnOrder: {
        bottom: hp(13),
    },
    scannerBtn: { bottom: hp(5) },

    dot: {
        width: wp(3),
        height: wp(3),
        backgroundColor: COLORS.abbey,
        borderRadius: 6
    },
    outlinedBtnText: { color: COLORS.gray },

    outlinedBtnContainer: { borderWidth: 0 },
    listContainer: { marginTop: wp(5), },
    headerContainerStyle: { flex: 1, paddingTop: wp(4) },
    headerMainContainerStyle: { flex: 1, flexDirection: 'row' },
    catalogNumber: {
        color: COLORS.abbey,
        fontSize: FONTS.h1_9,
        fontFamily: FONTFAMILY.averta_regular,
    },
    itemText: {
        fontFamily: FONTFAMILY.averta_bold,
        fontSize: FONTS.h2_1,
        color: COLORS.abbey,
        marginBottom: SIZES.tip,
        marginEnd: wp(0.5),
        marginTop: wp(1)
    },
    center: {
        alignItems: "center",
        justifyContent: 'flex-end',
        flexDirection: "row",
        flex: 1,
        marginTop: wp(1)
    },
    itemHeaderContent: {
        color: COLORS.abbey,
        fontSize: FONTS.h1_4,
        fontFamily: FONTFAMILY.averta_bold,
    },
    controllerInputStyle: {
        ...FONTS.body,
        paddingVertical: SIZES.base,
        paddingHorizontal: SIZES.tip,
        maxWidth: wp(10),
    },
    qtyInfoContainer: {
        paddingVertical: hp(0.8),
        marginVertical: hp(1.2),
    },
    itemSubHeaderStyle: {
        textAlign: "center",
        color: COLORS.abbey,
        fontSize: FONTS.h1_5,
        fontFamily: FONTFAMILY.averta_bold,
        backgroundColor: COLORS.whiteSmoke,
        minWidth: wp(10),
        paddingHorizontal: wp(1),
        borderRadius: hp(1),
        position: "absolute",
        paddingVertical: hp(0.1),
    },
    container: { flex: 1, marginHorizontal: wp(2) },
    subContainer: {},
    title: { color: COLORS.scienceBlue, marginTop: wp(12), ...FONTS.title, fontFamily: FONTFAMILY.averta_semibold, textAlign: 'center' },
    subTitle: { color: COLORS.abbey, marginTop: wp(12), fontFamily: FONTFAMILY.averta_bold, marginStart: wp(2), fontSize: FONTS.h2_1 },
    headerRight: {
        flexDirection: "row",
        alignItems: "center",
    },
    rightContainer: {
        alignItems: "flex-end",
        alignSelf: 'flex-end',
        marginTop: wp(2),
        marginEnd: wp(1)
    },
    header: {
        flexDirection: "row",
        alignItems: "flex-start",
        justifyContent: "space-between",
    },
    orderLabel: {
        color: COLORS.abbey,
        fontFamily: FONTFAMILY.averta_semibold,
        fontSize: wp(3),
    },
    selectAll: {
        color: COLORS.abbey,
        fontFamily: FONTFAMILY.averta_semibold,
        fontSize: wp(3.5),
        marginRight: wp(2),
        marginLeft: wp(3),
    },
    indexText: {
        color: COLORS.abbey,
        fontFamily: FONTFAMILY.averta_regular,
        fontSize: wp(3.5),
        marginRight: wp(2),
        marginLeft: wp(3),
    },
    activeTick: {
        width: wp(6),
        height: wp(6),
        backgroundColor: COLORS.white,
        borderRadius: wp(6),
        alignItems: "center",
        justifyContent: "center",
        borderColor: COLORS.lightGray,
        borderWidth: 1,
    },
    editButton: {
        backgroundColor: COLORS.white,
        alignItems: "center",
        justifyContent: "center",
        borderColor: COLORS.lightGray,
        marginTop: 1,
        marginStart: wp(3),
    },
    deleteButton: {
        backgroundColor: COLORS.white,
        alignItems: "center",
        justifyContent: "center",
        borderColor: COLORS.lightGray,
        marginTop: 1,
        marginStart: wp(3)
    },
    deactiveTick: {
        width: wp(6),
        height: wp(6),
        backgroundColor: COLORS.white,
        borderRadius: wp(6),
        alignItems: "center",
        justifyContent: "center",
        borderColor: COLORS.lightGray,
        borderWidth: 1,
    },
    syncButtonText: {
        fontFamily: FONTFAMILY.averta_bold,
        fontSize: FONTS.h1_9,
    },
    syncButton: {
        height: hp(6),
        width: wp(20),
    },
})