import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },

  headerTitle: {
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h2_2,
    color: COLORS.abbey,
  },

  headerContainer: { backgroundColor: COLORS.white },

  rightIcon: {
    fontSize: FONTS.h2,
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_regular,
  },

  contentContainer: {
    flex: 1,
    paddingLeft: wp(4),
  },

  listBtn: {
    fontSize: FONTS.h2_2,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.scienceBlue,
  },

  listItemContainer: {
    paddingVertical: hp(0.6),
    marginBottom: hp(1),
    borderBottomWidth: 1,
    borderBottomColor: COLORS.alto,
  },

  supportContainer: {
    paddingVertical: hp(2),
  },

  contactSupport: {
    fontSize: FONTS.h2,
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    paddingBottom: hp(0.8),
  },

  subContent: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
    lineHeight: hp(2.5),
  },

  subInfoContent: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_semibold,
    lineHeight: hp(2.5),
  },
});
