import React, { useCallback, useEffect, useState } from "react";
import { View, Platform, BackHandler } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { Header, ListItem } from "../../../Components";
import { COLORS } from "../../../Utils/theme";
import { ChevronRight } from "../../../Utils/images";
import styles from "./styles";
import { WalkthroughTips } from "../../../Components";
import CustomText from "../../../Components/CustomText";
import UserManual from "../UserMannual";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import { useFocusEffect } from "@react-navigation/native";
const Help = (props: any) => {
  const [showWalkthrough, setShowWalkthrough] = useState(false);
  const [showUserManual, setShowUserManual] = useState(false);
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  function closeWalkThrought() {
    setShowWalkthrough(false);
    setShowUserManual(false);
  }
  useEffect(() => {
    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );
    return () => backHandler.remove();
  }, []);
  const backAction = () => {
    props.navigation.navigate("Dashboard");
    return true;
  };
  const dispatch = useDispatch<any>();

  useFocusEffect(
    useCallback(() => {
      dispatch(setIsShowConfirmationAlert({}));
    }, [])
  );

  return (
    <View
      style={styles.container}
      accessible={true}
      accessibilityLabel="help-container"
    >
      {showWalkthrough ? (
        <WalkthroughTips onFinish={closeWalkThrought} />
      ) : showUserManual ? (
        <UserManual onFinish={closeWalkThrought} />
      ) : (
        <>
          <Header
            idLabel={"Help"}
            title={Strings["help"]}
            titleStyle={styles.headerTitle}
            container={styles.headerContainer}
            onLeftIconPress={() => null}
            onRightIconPress={() => props.navigation.goBack()}
            statusBar={true}
            statusBarColor={COLORS.white}
            iconLeft={false}
            iconRight={true}
            RightIcon={() => (
              <CustomText
                style={styles.rightIcon}
                accessibilityLabel="help-close-text"
              >
                {Strings["close"]}
              </CustomText>
            )}
          />
          <View
            style={styles.contentContainer}
            accessible={true}
            accessibilityLabel="help-content-container"
          >
            <ListItem
              idLabel="help-user-manual-item"
              leftIcon={
                <CustomText
                  style={styles.listBtn}
                  accessibilityLabel="help-user-manual-text"
                >
                  {Strings["ime.user.manual"] ?? "User Manual"}
                </CustomText>
              }
              rightIcon={
                <View>
                  <ChevronRight
                    accessible={true}
                    accessibilityLabel="help-right-icon"
                  />
                  <View style={{ width: 30 }} />
                </View>
              }
              customStyles={{ container: styles.listItemContainer }}
              onPress={() => {
                setShowWalkthrough(false);
                setShowUserManual(true);
              }}
            />

            <ListItem
              idLabel="help-walkthrough-item"
              onPress={() => {
                setShowWalkthrough(true);
                setShowUserManual(false);
              }}
              leftIcon={
                <CustomText
                  style={styles.listBtn}
                  accessibilityLabel="help-walkthrough-text"
                >
                  {Strings["ime.scanner.Walkthrough"] ?? "Walkthrough"}
                </CustomText>
              }
              rightIcon={
                <View>
                  <ChevronRight
                    accessible={true}
                    accessibilityLabel="help-right-icon"
                  />
                  <View style={{ width: 30 }} />
                </View>
              }
              customStyles={{ container: styles.listItemContainer }}
            />

            <View
              style={styles.supportContainer}
              accessible={true}
              accessibilityLabel="help-support-container"
            >
              <CustomText
                style={styles.contactSupport}
                accessibilityLabel="help-contact-support"
              >
                {Strings["unavailable.delivery.w2.product.short.msg"]}
              </CustomText>
              <CustomText
                style={styles.subContent}
                accessibilityLabel="help-subcontent-text1"
              >
                {"Avantor Services Team - Local Quality Process \nManager"}
              </CustomText>
              <CustomText
                style={styles.subContent}
                accessibilityLabel="help-subcontent-text2"
              >
                Customers – Digital Tech Solutions
              </CustomText>
              <CustomText
                style={styles.subInfoContent}
                accessibilityLabel="help-subinfo-content1"
              >{`${Strings["email"]}: digitaltechsupport@avantorsciences.com`}</CustomText>
              <CustomText
                style={styles.subInfoContent}
                accessibilityLabel="help-subinfo-content2"
              >{`${Strings["phone"]}: 1-888-793-2300 and select option 3`}</CustomText>
            </View>
          </View>
        </>
      )}
    </View>
  );
};

export default Help;
