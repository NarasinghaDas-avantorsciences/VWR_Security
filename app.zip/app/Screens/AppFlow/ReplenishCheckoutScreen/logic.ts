import moment from "moment";
import {
  filterByFiveKeys,
  filterByMultipleKeys,
} from "../../../Utils/globalFunction";

const onDecrement = (focusedDate: string, setFocusedDate: any) => {
  const previousMonth = moment(focusedDate, "YYYY-MM-DD")
    .subtract(1, "months")
    .format("YYYY-MM-DD");
  setFocusedDate(previousMonth);
};

const onIncrement = (focusedDate: string, setFocusedDate: any) => {
  const nextMonth = moment(focusedDate, "YYYY-MM-DD")
    .add(1, "months")
    .format("YYYY-MM-DD");
  setFocusedDate(nextMonth);
};

const fetchCostCenterList = (
  userId: string,
  dispatch: any,
  getCostCentersList: any
) => {
  if (userId) {
    const params = {
      id: userId,
    };
    dispatch(getCostCentersList(params));
  }
};

const onChangeCommentLogic = (
  initialRecommendedData: any,
  text: string,
  index: number
) => {
  let sampleData = initialRecommendedData;
  sampleData[index].enteredComment = text;
  return sampleData;
};

const onChangeUserSearchLogic = (
  searchKey: string,
  userDataList: any,
  setSearchKey: any,
  setUserList: any,
  barcode=false
) => {
  const filterData = filterByFiveKeys(
    userDataList,
    "firstName",
    "lastName",
    "loginId",
    "id",
    "vwrUserId",
    searchKey?.toLocaleLowerCase()
  );
  if (
    filterData &&
    (filterData[0]?.id == searchKey ||
      filterData[0]?.firstName == searchKey ||
      filterData[0]?.loginId == searchKey ||
      filterData[0]?.vwrUserId == searchKey ||
      filterData[0]?.lastName == searchKey)
      &&barcode
  ) {
    setSearchKey(filterData[0]?.firstName + " " + filterData[0]?.lastName);
  } else {
  }
  setSearchKey(searchKey);

  setUserList(filterData);
};

const onChangeCostSearchLogic = (
  searchKey: string,
  costCenterList: any,
  setSearchKey: any,
  setCostList: any
) => {
  const filterData = filterByMultipleKeys(
    costCenterList,
    "costCenterName",
    "id",
    searchKey
  );
  if (
    filterData &&
    (filterData[0]?.id == searchKey ||
      filterData[0]?.costCenterName == searchKey)
  ) {
    setSearchKey(filterData[0]?.costCenterName);
  } else {
    setSearchKey(searchKey);
  }
  setCostList(filterData);
};

export {
  onDecrement,
  onIncrement,
  fetchCostCenterList,
  onChangeCommentLogic,
  onChangeUserSearchLogic,
  onChangeCostSearchLogic,
};
