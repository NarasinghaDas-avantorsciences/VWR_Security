import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 0.5,
    borderBottomColor: COLORS.alto,
    paddingVertical: hp(1),
    paddingRight: wp(3),
  },
  clearModalContainer: { height: SIZES.height * 0.2 },
  initialselectText: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: wp(3.3),
    fontStyle: "italic",
  },
  clearContainer: {
    flex: 1,

    justifyContent: "center",
    alignItems: "center",
  },

  clearOrderTitle: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h2,
    color: COLORS.black,
  },

  clearOrderDesc: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h2,
    color: COLORS.black,
    marginVertical: hp(1),
  },

  cancelContainer: {
    width: wp(45),
    marginTop: hp(1),
    marginLeft: 0,
    borderWidth: 0,
    // marginRight: wp(4),
  },

  cancelText: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    fontSize: FONTS.h2,
  },

  clearOrderContainer: {
    width: wp(30),
    marginTop: hp(1),
  },

  clearOrderText: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.white,
    fontSize: FONTS.h2,
  },

  contentContainerStyle: {
    flexGrow: 1,
    paddingHorizontal: wp(4),
    paddingBottom: hp(6),
  },

  searchInputTextStyle: {
    color: COLORS.abbey,
  },

  buttonStyle: {
    width: "100%",
    marginBottom: 16,
    backgroundColor: "#FFF",
    borderWidth: 1,
    borderColor: COLORS.blue,
  },

  subHeaderTextContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 6,
    marginTop: hp(3),
  },

  itemChildHeaderText: {
    fontSize: FONTS.h1_7,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    alignItems: "center",
  },

  recommendedText: { ...FONTS.title2, fontSize: FONTS.h2, lineHeight: 20 },

  priceText: {
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    alignItems: "center",
  },

  dataContainer: { paddingBottom: hp(10) },
  selectedItemContainer: {
    paddingBottom: hp(10),
    paddingHorizontal: wp(5),
  },
  leftIconContainer: { marginRight: wp(4) },

  leftIcon: {
    width: wp(18),
    height: wp(18),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: COLORS.gray2,
  },

  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },

  tagContainer: { marginHorizontal: wp(2) },

  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },

  qtyInfoContainer: { paddingVertical: hp(0.8), alignSelf: "flex-start" },

  itemSubHeaderStyle: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
  },

  itemContainerStyle: {
    marginVertical: hp(1.8),
    borderBottomWidth: 1,
    paddingBottom: hp(1),
    borderColor: COLORS.whiteSmoke,
  },

  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  itemChildContainer: {
    width: SIZES.width * 0.4,
    marginVertical: wp(0.5),
    paddingVertical: 8,
    opacity: 0.7,
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },

  flexRowCenter: { flexDirection: "row", alignItems: "center" },

  commentInputStyle: {
    width: wp(42),
    alignSelf: "flex-start",
    backgroundColor: COLORS.white,
    marginRight: wp(4),
  },

  inputStyle: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h1_5,
    color: COLORS.abbey,
    left: -wp(2),
  },

  inputMainStyle: {
    height: hp(4),
    top: 0,
    borderColor: COLORS.gray2,
    borderWidth: 0.8,
  },

  qtyTitleStyle: { marginRight: wp(3) },

  footerMainContainer: { bottom: 0 },

  outlinedBtnText: { color: COLORS.gray },

  outlinedBtnContainer: { borderWidth: 0 },

  stockTxtContainerStyle: {
    width: wp(92),
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginTop: hp(2),
  },

  bottomSheetContainer: {
    borderTopLeftRadius: hp(1),
    borderTopRightRadius: hp(1),
  },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    paddingTop: hp(1),
  },
  headerText: {
    fontSize: FONTS.h2_3,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.doveGray,
    textAlign: "center",
    // flex: 1,
  },
  closeBtn: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.blue,
    // paddingLeft: wp(6),
    fontFamily: FONTFAMILY.averta_regular,
  },
  searchMain: {
    width: "95%",
    alignSelf: "center",
  },
  listMain: {
    width: "90%",
    alignSelf: "center",
  },

  itemMain: {
    borderBottomWidth: 0.4,
    borderBottomColor: COLORS.alto,
    paddingVertical: hp(1.3),
    flexDirection: "row",
    justifyContent: "space-between",
  },
  itemTitle: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_8,
    color: COLORS.abbey,
  },

  buttonsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: SIZES.base,
  },
  mainText: { ...FONTS.title, color: COLORS.white },
  addBtnStyle: { width: "100%", marginVertical: hp(2) },

  bottomsheetContainer: { width: "100%", height: 120 },

  buttonContainer: {
    flex: 1,
    alignItems: "flex-end",
    marginEnd: wp(5),
  },
  secondaryPressableContainer: {
    justifyContent: "center",
    alignItems: "center",
    padding: hp(1),
  },
  errorMessage: {
    color: "red",
    fontFamily: FONTFAMILY.averta_regular,
    alignSelf: "center",
    marginTop: hp(1.5),
    marginHorizontal: wp(4),
    marginBottom: hp(5),
  },

  multipierText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_regular,
  },

  emptyContainer: { alignItems: "center", justifyContent: "center" },

  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },
});
