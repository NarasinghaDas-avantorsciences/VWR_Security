import React, {
  Dispatch,
  SetStateAction,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  View,
  Image,
  Pressable,
  ScrollView,
  TouchableOpacity,
  Keyboard,
  Platform,
  BackHandler,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { Toast } from "react-native-toast-message/lib/src/Toast";
import moment from "moment";
import Text from "../../../Components/CustomText";

import {
  Header,
  BottomSheetComponent,
  QtyController,
  ListItem,
  Subheader,
  TextInputComponent,
  MainButton,
  Footer,
  ProductInfoDetails,
  AnimatedSearch,
  Loader,
  ToastComponent,
  ClearSelectionAlert,
  ProductDetails,
  AlertModal,
  CalendarSheet,
  CustomerApprovalIDModal,
  SpclMessageModal,
  CustomText,
} from "../../../Components";
import { Item } from "../Replenish";
import {
  checkUomCondition,
  getCurrencySymbol,
  getMultiplier,
  getReplenishReceipt,
  hp,
  removeEmojis,
  sortArray,
  wp,
} from "../../../Utils/globalFunction";
import {
  ArrowDown,
  WhiteLeftArrow,
  Cross,
  DefaultProductImage,
  Check,
  RTag,
  STag,
  OneTag,
} from "../../../Utils/images";
import { FONTS, SIZES } from "../../../Utils/theme";

import {
  addOneTimeCostCenter,
  getCostCentersList,
  getReplenishCustomerApprovalIds,
  getSpecialHandlingMessages,
  getUsersList,
  replenishOrder,
  resetPriceState,
  setCostCentersList,
  setUpdatedRecommendedData,
} from "../../../Redux/Action/replenishAction";
import {
  getProductDetails,
  setProductLoader,
} from "../../../Redux/Action/searchAction";
import * as storage from "../../../Service/AsyncStoreConfig";
import { ApiConfig } from "../../../Service/Api";
import RNHTMLtoPDF from "react-native-html-to-pdf";
import ReactNativeBlobUtil from "react-native-blob-util";
import styles from "./styles";
import {
  fetchCostCenterList,
  onDecrement,
  onIncrement,
  onChangeCommentLogic,
  onChangeUserSearchLogic,
  onChangeCostSearchLogic,
} from "./logic";
import {
  useFocusEffect,
  useIsFocused,
  useNavigation,
} from "@react-navigation/native";
import ConfirmationAlert from "../../../Components/ConfirmationPopup";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import { saveDataToStorage } from "../../../Components/Subheader/logic";

type SelectedListProps = {
  id?: string;
  name?: string;
  firstName?: string;
  lastName?: string;
  costCenterName?: string;
};

type ReplenishCheckoutScreenProps = {
  data: Item[];
  isSelectedAll: boolean;
  setNavigatedRoute: Dispatch<SetStateAction<string>>;
  clearState: () => void;
  onClose: () => void;
  approval?: boolean;
  orderId?: number;
};

const ReplenishCheckoutScreen: React.FC<ReplenishCheckoutScreenProps> = ({
  data,
  isSelectedAll,
  setNavigatedRoute,
  clearState,
  approval = false,
  ...props
}) => {
  const today = moment();
  const navigation = useNavigation<any>();
  const dispatch = useDispatch<any>();
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const profileData = useSelector((state: any) => state.accountReducer?.data);
  const {
    userDataList,
    isLoading,
    costCenterList,
    customerApprovalIDs,
    spclhandlingmsg,
    initialRecommendedData,
    userPrice,
  } = useSelector((state: any) => state.replenishReducer);
  const { userToken } = useSelector((state: any) => state.loginReducer);
  const productDetails = useSelector(
    (state: any) => state.searchReducer?.productDetails
  );
  const isFocused = useIsFocused();
  const [sheet, setSheet] = useState<any>(false);

  const {
    stockRoomDetail,
    org_details,
    selectedTitle,
    selectedSubTitle,
    soldToNumber,
    shipToNumber,
    userSelectPrivilege,
    confirmationAlertInfo,
  } = useSelector((state: any) => state.userReducer);
  const { dateFormat, timeFormat } = useSelector(
    (state: any) => state.userReducer
  );
 
  const [todayDate, setToday] = useState(moment().format("YYYY-MM-DD"));
  const [flag, setFlag] = useState(0);
  const [oneTimeCostCenter, setOneTimeCostCenter] = useState<any>([]);
  const [focusedDate, setFocusedDate] = useState(todayDate);
  const [selectedDate, setSelectedDate] = useState<any>(null);
  const [visible, setVisible] = useState(false);
  const [timeString, setTimeString] = useState("h:mm:ss A");
  const ref_add_costCenter = useRef<any>(null);
  const itemDetailsRef = useRef<any>(null);
  const userList_ref = useRef<any>();
  const costCenter_ref = useRef<any>();
  const customerApprovalRef = useRef<any>();
  const spclhandlingmsgRef = useRef<any>();
  const [searckKey, setSearchKey] = useState("");
  const [selectedUser, setSelectedUser] = useState<SelectedListProps | any>(
    null
  );
  
  const [selectedCostCenter, setSelectedCostCenter] = useState<
    SelectedListProps | any
  >(null);
  const [showClearAlert, setClearAlert] = useState<boolean>(false);
  const [userList, setUserList] = useState(userDataList);
  const [costList, setCostList] = useState(costCenterList);
  const [isTotalpriceLoad,setIsTotalpriceLoad] = useState(true);
  const [costCenterName, setCostCenterName] = useState(
    stockRoomDetail?.costCenterValue
  );
  const [projectNumber, setProjectNumber] = useState(
    stockRoomDetail?.projectNumber
  );
  const [orderNumber, setOrderNumber] = useState(
    stockRoomDetail?.purchaseOrderNo
  );
  const [contractNumber, setContractNumber] = useState(
    stockRoomDetail?.contractNo
  );
  const [deliverCode, setDeliverCode] = useState(
    stockRoomDetail?.deliverToCode
  );
  const [requiredByDate, setRequiredByDate] = useState("");
  const [specialMessage, setSpecialMessage] = useState<any>(null);
  const [selectedApproverId, setSelectedApproverId] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [filterText, setFilterText] = useState("");
  const [totalPrice, setTotalPrice] = useState(0);
  const [count, setCount] = useState(10);
  const [isLoadingData, setIsLoading] = useState(false);
  const { currency } = useSelector((state: any) => state.userReducer);
  const [iSClickBack, setISClickBack] = useState(false);
  useEffect(() => {
    function handleBackButton() {
      // dispatch(setCostCentersList());
      // dispatch(
      //   setIsShowConfirmationAlert({
      //     isShow: true,
      //     data: confirmationAlertInfo?.data,
      //   })
      // );
      setISClickBack(true);
      // props.onClose();
      // backAction()
      return true;
    }

    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      handleBackButton
    );

    return () => backHandler.remove();
  }, [navigation]);

  const onBack = () => {
    dispatch(setCostCentersList());
    props.onClose();
  };

  useEffect(() => {
    getTotalPrice(data,userPrice);
  }, [userPrice]);

  useEffect(() => {
    getDropDownData();
  }, []);

  useEffect(() => {
    if (timeFormat?.toUpperCase() == "24Hours".toUpperCase())
      setTimeString("H:mm:ss");
    else setTimeString("h:mm:ss A");
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (userSelectPrivilege) {
        if (userDataList) {
          setUserList(userDataList);
          if (userDataList.length == 1) {
            onSelectUser(userDataList[0], true);
          }
        }
      } else {
        setUserList([profileData]);
        onSelectUser(profileData, true);
      }
    }, [userDataList])
  );

  useFocusEffect(
    useCallback(() => {
      // if (costCenterList) {
      //   setCostList(costCenterList);
      if (selectedUser !== null && costCenterList) {
        console.log("SELCTEDUSER: ==", costCenterList);
        setCostList(costCenterList);
        if (costCenterList.length == 1) {
          onSelectUser(costCenterList[0], false);
        }
      }

      // }
    }, [selectedUser])
  );

  useEffect(() => {
    const { isSplHandlingMsgEnabled } = org_details;
    const selectedDefaultSplHandlingMsg =
      stockRoomDetail?.selectedDefaultSplHandlingMsg ?? 0;
    if (isSplHandlingMsgEnabled && spclhandlingmsg?.length > 0) {
      const msgIndex = spclhandlingmsg?.findIndex(
        (element: { id: number }) =>
          element?.id?.toString() ==
          (selectedDefaultSplHandlingMsg &&
            selectedDefaultSplHandlingMsg?.toString())
      );
      if (msgIndex !== -1) {
        setSpecialMessage(spclhandlingmsg[msgIndex]);
      }
    }
  }, [spclhandlingmsg]);

  useEffect(()=>{
    setTimeout(() => {
      setIsTotalpriceLoad(false);
    }, 600);
  },[totalPrice]);

  const getTotalPrice = (data: any,userPricedata:any) => {
    if (userPricedata?.data?.length > 0){
    const userData = userPricedata?.data || [];
    let sum: any;
    if (approval) {
      sum = userData.reduce((acc: number, item: Item | any) => {
        return item?.purchasePrice * parseInt(item?.quantity) + acc;
      }, 0);
    } else {
      sum = sum = userData.reduce((acc: number, item: Item | any) => {
        return parseFloat(item.purchasePrice) * parseInt(item.quantity) + acc;
      }, 0);
    }
    setTotalPrice(sum.toFixed(2));
  }else{
    let sum: any;
    if (approval) {
      sum = data.reduce((acc: number, item: Item | any) => {
        return item?.purchasePrice * parseInt(item?.availableQty) + acc;
      }, 0);
    } else {
      sum = data.reduce((acc: number, item: Item | any) => {
        return item?.purchasePrice * parseInt(item?.selectedQty) + acc;
      }, 0);
    }
    setTotalPrice(sum.toFixed(2));
  }
  };
  
  const getDropDownData = async () => { 
    const org = (await storage.getItem("org")) || "";
    new ApiConfig().setToken(userToken, org);
    dispatch(getUsersList());
    dispatch(getReplenishCustomerApprovalIds());
    dispatch(getSpecialHandlingMessages());  
  };

  const getCostCenterData = (userId: string, item: any) => {
    // fetchCostCenterList(userId, dispatch, getCostCentersList);
    if (userId) {
      const params = {
        id: userId,
      };
      dispatch(
        getCostCentersList(params, (respData: any) => {
          if (respData.length == 1) {
            onSelectUser(respData[0], false);
          } else {
            // commented this as it was saving user in cost center
            // if (item) setSelectedCostCenter(item);
            // else setSelectedCostCenter(null);
            setSelectedCostCenter(null);
          }
        })
      );
    }
  };

  const _renderList = () => {
    let filteredData =
      data &&
      data?.filter(
        (item: Item) =>
          item?.description.toLowerCase().includes(filterText.toLowerCase()) ||
          item?.catalogNo.toLowerCase().includes(filterText.toLowerCase()) ||
          item?.vendorName.toLowerCase().includes(filterText.toLowerCase())
      );
    filteredData = filteredData?.slice(0, count);
    return (
      filteredData &&
      filteredData?.map((item: any, index: number) => {
        return renderItem(item, index);
      })
    );
  };

  const productInfo = (item: Item) => {
    return (
      <ProductInfoDetails
        vendorName={item?.vendorName}
        locationName={item?.locationName}
        requiredQty={item?.maxStockQty}
        transitQty={item?.backlogQty}
      />
    );
  };

  const onChangeComment = async (text: string, index: number) => {
    setUpdatedRecommendedData(
      onChangeCommentLogic(initialRecommendedData, text, index)
    );
  };

  const decrement = () => {
    onDecrement(focusedDate, setFocusedDate);
  };

  const increment = () => {
    onIncrement(focusedDate, setFocusedDate);
  };

  const renderItem = (item: any, index: number) => {
    let isShow = searckKey?.length > 0;
    let inputQty = approval
      ? item?.availableQty
      : item?.selectedQty ?? item?.orderedQuantity;
    return (
      <TouchableOpacity>
        <ListItem
          disabled={true}
          leftIcon={
            <View
              style={styles.leftIconContainer}
              accessible={true}
              accessibilityLabel="left-icon-container"
            >
              {item?.imageURL ? (
                <Image
                  accessible={true}
                  accessibilityLabel="item-image"
                  source={{ uri: item.imageURL.replace("http://", "https://") }}
                  style={styles.leftIcon}
                  resizeMode={"contain"}
                />
              ) : (
                <DefaultProductImage
                  width={wp(18)}
                  height={wp(18)}
                  accessible={true}
                  accessibilityLabel="item-default-image"
                />
              )}
            </View>
          }
          headerContent={
            <View>
              <View
                style={styles.flexRowCenter}
                accessible={true}
                accessibilityLabel="item-header-content"
              >
                <Text
                  style={styles.catalogNumber}
                  accessibilityLabel="item-catalogNo"
                >
                  {item?.catalogNo}
                </Text>
                {item.type === "RECOMMENDED" && (
                  <RTag
                    style={styles.tagContainer}
                    accessible={true}
                    accessibilityLabel="item-r-tag"
                  />
                )}
                {item.type === "STOCKED" && (
                  <STag
                    style={styles.tagContainer}
                    accessible={true}
                    accessibilityLabel="item-s-tag"
                  />
                )}
                {item.type === "ONETIME" && (
                  <OneTag
                    style={styles.tagContainer}
                    accessible={true}
                    accessibilityLabel="item-one-tag"
                  />
                )}
              </View>
              <TouchableOpacity
                accessible={true}
                accessibilityLabel="item-desciption-btn"
                onPress={async () => {
                  itemDetailsRef?.current?.open();
                  await dispatch(getProductDetails(item?.id));
                  dispatch(setProductLoader(false));
                }}
              >
                <Text style={styles.itemHeaderContent}>
                  {item?.description}
                </Text>
              </TouchableOpacity>
              {checkUomCondition(item) && (
                <View style={styles.qtyInfoContainer}>
                  <Text
                    style={styles.itemSubHeaderStyle}
                    accessible={true}
                    accessibilityLabel="item-uom-label"
                  >
                    {item?.uomManagementEnabled == 1
                      ? item.stockRoomUOMUnit !== null
                        ? `(${item.stockRoomUOMUnit})`
                        : ""
                      : item.uomId !== null
                      ? `(${item.uomId})`
                      : ""}
                  </Text>
                </View>
              )}
            </View>
          }
          customStyles={{ container: styles.itemContainerStyle }}
        >
          <View
            style={styles.flexRowContainer}
            accessible={true}
            accessibilityLabel="order-row-container"
          >
            {productInfo(item)}
            {!isShow && (
              <View style={[styles.itemChildContainer, styles.flexRowCenter]}>
                <TextInputComponent
                  disabled={true}
                  title={strings["comment"]}
                  disableRightIcon={true}
                  disableLeftIcon={true}
                  placeholder={
                    (item?.enteredComment || item?.comments) ??
                    strings["ime.scanner.enter.comment"] ??
                    "Enter comment"
                  }
                  editable={false}
                  onChangeText={(text: string) => onChangeComment(text, index)}
                  main={styles.commentInputStyle}
                  inputStyle={styles.inputStyle}
                  inputMain={styles.inputMainStyle}
                />
                <QtyController
                  // onChange={(v: string) => changeQty(v, index)}
                  titleStyle={styles.qtyTitleStyle}
                  inputValue={String(inputQty)}
                  disable={true}
                />

                <Text
                  style={[styles.multipierText, { maxWidth: wp(12) }]}
                  accessibilityLabel="checkout-list-item-multiplier"
                >
                  {item?.orderedQtyUOMDisplay ?? getMultiplier(item)}
                </Text>
              </View>
            )}
          </View>
        </ListItem>
      </TouchableOpacity>
    );
  };

  const noDataFound = () => {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>{strings["no.records.found"]}</Text>
      </View>
    );
  };

  const userItemList = () => {
    if (userList?.length == 0 && searckKey) {
      return noDataFound();
    } else {
      const data = userList?.sort((a, b) => {
        return a.firstName.localeCompare(b.firstName);
      });
      return data?.map((item: any, index: number) =>
        _renderItemList(item, index, true)
      );
    }
  };

  const onSelectUser = (item: any, isUser: boolean) => {
    setSheet(false);
    if (isUser) {
      // oneTimeCostCenter.length == 0 &&
      // setCostCenterName(costCenterName ? costCenterName : "");
      // setSelectedCostCenter(null);
      getCostCenterData(item?.id, item);
      setSelectedUser(item);
      userList_ref?.current.close();
    } else {
      if (item) setSelectedCostCenter(item);
      else setSelectedCostCenter(null);
      costCenter_ref?.current.close();
    }
  };

  const _renderItemList = (item: any, index: number, isUser: boolean) => {
    let isCheck = false;
    if (isUser) {
      isCheck = selectedUser?.id === item?.id;
    } else {
      isCheck = selectedCostCenter?.id === item?.id;
    }

    return (
      <TouchableOpacity
        accessible={true}
        accessibilityLabel="list-btn-item"
        onPress={() => onSelectUser(item, isUser)}
        key={index}
        style={[styles.itemMain]}
      >
        <Text
          style={[styles.itemTitle]}
          accessible={true}
          accessibilityLabel="name-list"
        >
          {isUser
            ? `${item?.firstName} ${item?.lastName}`
            : item?.costCenterName}
        </Text>
        {isCheck ? (
          <Check
            height={hp(2)}
            width={hp(2)}
            style={{
              marginRight: wp(2),
            }}
            accessible={true}
            accessibilityLabel="check-mark"
          />
        ) : null}
      </TouchableOpacity>
    );
  };

  const costCenetrItemList = () => {
    if (costList?.length == 0 && !!searckKey) {
      return noDataFound();
    } else
      return costList?.map((item: any, index: number) => {
        return _renderItemList(item, index, false);
      });
  };

  const getUserName = () => {
    let name = selectedUser
      ? `${selectedUser?.firstName} ${selectedUser?.lastName}`
      : userDataList.length == 1
      ? `${userDataList[0]?.firstName ?? ""} ${userDataList[0]?.lastName ?? ""}`
      : "";

    return name;
  };

  const checkoutForm = () => {
    return (
      <View accessible={true} accessibilityLabel="order-checkout-form">
        <TextInputComponent
          title={strings["user"]}
          onPressRightIcon={() => userList_ref.current.open()}
          RightIcon={ArrowDown}
          value={getUserName()}
          placeholder={strings["select.user"]}
          editable={false}
          required={true}
          main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
          pointerEvents="none"
          disabled={!userSelectPrivilege}
        />
        <TextInputComponent
          title={strings["cost.center"]}
          onPressRightIcon={() => {
            if (selectedUser) {
              costCenter_ref.current.open();
              setSheet(true);
            } else {
              showToast(
                "alertToast",
                strings["cost.center"],
                strings["ime.scanner.select.user.msg"] ??
                  "Please select user first."
              );
            }
          }}
          RightIcon={ArrowDown}
          required={stockRoomDetail?.isCostCenterMandatory}
          value={
            selectedCostCenter?.costCenterName || costCenterName
            // selectedCostCenter?.costCenterName
            //   ? selectedCostCenter?.costCenterName
            //   : costCenterName
            //   ? costCenterName
            //   : `${costCenterList[0]?.costCenterName ?? ""}`
          }
          placeholder={
            stockRoomDetail?.isCostCenterMandatory
              ? strings["select.cost.center"]
              : ""
          }
          editable={false}
          main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
          pointerEvents="none"
        />
        <TextInputComponent
          title={strings["project.number"]}
          value={removeEmojis(projectNumber)}
          editable={true}
          main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
          onChangeText={setProjectNumber}
        />
        <TextInputComponent
          title={strings["purchase.order.number"]}
          value={removeEmojis(orderNumber)}
          editable={true}
          main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
          onChangeText={setOrderNumber}
        />
        <TextInputComponent
          title={strings["contract.number"]}
          value={removeEmojis(contractNumber)}
          editable={true}
          main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
          onChangeText={setContractNumber}
        />
        {stockRoomDetail?.enableVWRXMLApproverField ? (
          <TextInputComponent
            title={strings["deliver.to.code"]}
            value={removeEmojis(deliverCode)}
            editable={true}
            required={false}
            main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
            inputStyle={styles.inputStyle}
            inputMain={styles.inputMainStyle}
            onChangeText={setDeliverCode}
          />
        ) : null}
        {stockRoomDetail?.enableVWRXMLRequiredDateField ? (
          <TextInputComponent
            title={strings["required.by.date"]}
            value={
              requiredByDate
                ? moment(requiredByDate).format(dateFormat.date)
                : ""
            }
            editable={false}
            required={true}
            main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
            inputStyle={styles.inputStyle}
            inputMain={styles.inputMainStyle}
            onPressRightIcon={() => setVisible(true)}
            pointerEvents="none"
          />
        ) : null}
        {stockRoomDetail?.enableVWRXMLApproverField ? (
          <TextInputComponent
            title={strings["customer.approver.id"]}
            RightIcon={ArrowDown}
            placeholder={strings["select"]}
            editable={false}
            required={true}
            value={selectedApproverId?.keyElement || ""}
            main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
            inputStyle={styles.inputStyle}
            inputMain={styles.inputMainStyle}
            onPressRightIcon={() => customerApprovalRef?.current?.open()}
            pointerEvents="none"
          />
        ) : null}
        {org_details?.isSplHandlingMsgEnabled ? (
          <TextInputComponent
            title={strings["special.handling.message"]}
            value={specialMessage?.splHandlingCode}
            editable={false}
            main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
            inputStyle={styles.inputStyle}
            inputMain={styles.inputMainStyle}
            onPressRightIcon={() => spclhandlingmsgRef?.current?.open()}
            RightIcon={ArrowDown}
          />
        ) : null}
      </View>
    );
  };

  const changeDate = (date: string) => {
    setSelectedDate(null);
    setToday(date);
    setVisible(false);
    setFocusedDate(moment(date).format("YYYY-MM-DD"));
  };

  const __renderCalander = () => (
    <CalendarSheet
      todayDate={todayDate}
      focusedDate={focusedDate}
      increment={increment}
      decrement={decrement}
      changeDate={(date: any) => {
        // let dateISOString = moment(date).toISOString();
        // let timeString = dateISOString.slice(dateISOString.indexOf("T"));
        changeDate(date);
        setRequiredByDate(date);
        setVisible(false);
        setFocusedDate(moment(date).format("YYYY-MM-DD"));
      }}
      onClose={() => setVisible(false)}
      addExpiryDate={(date: any) => date.isBefore(today, "day")}
    />
  );

  const checkoutComplete = () => {
    clearState();
    setNavigatedRoute("");
    navigation.navigate("Dashboard");
    props.onClose();
   dispatch(resetPriceState());
  };

  const onPressSaveRecipt = async (data: any) => {
    checkoutComplete();
    const pdfOptions = {
      html: getReplenishReceipt(
        data,
        selectedTitle,
        selectedSubTitle,
        timeString,
        dateFormat?.date,
        soldToNumber,
        shipToNumber,
        currency
      ),
      fileName: `pdf_${data?.transactionId}`,
      directory: "Documents",
    };
    const file = await RNHTMLtoPDF.convert(pdfOptions);
    if (file?.filePath) {
      if (Platform.OS === "android") {
        ReactNativeBlobUtil.android.actionViewIntent(
          file?.filePath,
          "application/pdf"
        );
      } else {
        ReactNativeBlobUtil.ios.previewDocument(file?.filePath);
      }
    }
  };

  const showToast = (
    type: string = "alertToast",
    text1: string,
    text2: string,
    duration = 4000,
    onHideToast?: any,
    onPressBtn?: any
  ) => {
    Toast.show({
      type: type,
      text1: text1,
      text2: text2,
      position: "bottom",
      bottomOffset: SIZES.padding * 2,
      // visibilityTime: duration,
      onHide: onHideToast,
      onPress: onPressBtn,
    });
  };

  const submitCheckout = async () => {
    if (selectedUser == null) {
      showToast(
        "alertToast",
        strings["user"],
        strings["ime.please.select.users"]
      );
    } else if (
      stockRoomDetail?.isCostCenterMandatory &&
      selectedCostCenter == null &&
      stockRoomDetail?.id == null
    ) {
      showToast(
        "alertToast",
        strings["cost.center"],
        strings["ime.scanner.cost.center.mand.msg"] ??
          "Cost center is mandatory to select"
      );
      return;
    } else if (
      stockRoomDetail?.enableVWRXMLRequiredDateField &&
      !requiredByDate
    ) {
      showToast(
        "alertToast",
        strings["required.by.date"],
        strings["please.enter.the.required.by.date"]
      );
    } else if (
      stockRoomDetail?.enableVWRXMLApproverField &&
      !selectedApproverId?.keyElement
    ) {
      showToast(
        "alertToast",
        strings["customer.approver.id"],
        strings["please.select.the.customer.approver.id"]
      );
    } else {
      let replenishOrderProductsParams;
      if (approval) {
        replenishOrderProductsParams = {
          selectedUserId: selectedUser?.id || "",
          costCenterId: selectedCostCenter?.id || "",
          replenishProducts: data.flatMap((item: any) => {
            return item?.replenishProducts || [];
          }),

          deliverToCode: deliverCode ? deliverCode : "",
          customerApproverId: selectedApproverId?.value ?? "",
          requiredByDateValue: requiredByDate ?? "",
          costCenterName:
            selectedCostCenter?.costCenterName ||
            stockRoomDetail?.costCenterValue,
          projectNo: projectNumber ?? "",
          purchaseOrderNo: orderNumber ?? "",
          contractNo: contractNumber ?? "",
          splInstructions: specialMessage
            ? specialMessage?.splHandlingCode
            : "",
          isApprovalParam: true,
          orderId: props?.orderId,
        };
      } else {
        replenishOrderProductsParams = {
          selectedUserId: selectedUser?.id,

          //Changed by kiran 'costCenterId' due to default value csuses the API error. oct /7/ 23
          costCenterId:
            selectedCostCenter?.costCenterName == undefined
              ? ""
              : selectedCostCenter?.id,
          //costCenterId: selectedCostCenter?.id,// before oct /7/ 23
          replenishProducts: data
            .filter((item) => item.selected === true)
            .map((item) => ({
              id: item.id,
              qty: item.selectedQty ?? item.orderedQuantity,
              type: item.type,
              comment: item.enteredComment ? item.enteredComment : null,
            })),
          deliverToCode: deliverCode ? deliverCode : "",
          customerApproverId: selectedApproverId?.value ?? "",
          requiredByDateValue: !!requiredByDate ? requiredByDate : undefined,
          costCenterName: selectedCostCenter?.costCenterName ?? costCenterName,
          projectNo: projectNumber ?? "",
          purchaseOrderNo: orderNumber ?? "",
          contractNo: contractNumber ?? "",
          splInstructions: specialMessage
            ? specialMessage?.splHandlingCode
            : "",
        };
      }

      console.log("Params: " + JSON.stringify(replenishOrderProductsParams));

      await dispatch(
        replenishOrder(
          replenishOrderProductsParams,
          async (res: any) => {
            await saveDataToStorage("replenish_offline_data", []);
            const mappedData = res?.data?.labels.map(
              (item: any) => `${strings[item]}\n`
            );
            const alertData = mappedData.join("");
            if (String(res.status) == "200") {
              setFlag(flag + 1);
              showToast(
                "alertButton",
                "STOCK REPLENISHED!",
                `${alertData}`,
                5000,
                () => {
                  checkoutComplete();
                },
                () => {
                  onPressSaveRecipt(res?.data?.data);
                }
              );
            }
          },
          async (res: any) => {
            showToast(
              "alertToast",
              strings["ime.scanner.error.occured.msg"],
              strings[res?.data?.label]
            );
          }
        )
      );
    }
  };
  const onSubmitEditing = () => {
    let prevData = oneTimeCostCenter;

    setOneTimeCostCenter([]);
    if (costCenterName) {
      const obj = {
        data: {
          costCenterName: costCenterName,
          userId: selectedUser?.id,
          isOneTime: false,
        },
        onSuccess: (res: any) => {
          //onSelectUser(res?.data, false);
          //setSelectedCostCenter(res?.data);
          setCostList([...costList, res?.data]);
          showToast("alertToast", res?.status || "", "");
          setErrorMessage("");
          Keyboard.dismiss();
          setCostCenterName("");
          setOneTimeCostCenter((prevList: any) => [...prevData, res?.data]);
          // costCenter_ref.current.close();
          ref_add_costCenter.current.close();
          // getDropDownData();
        },
        onFail: (errorMsg: string) => {
          setErrorMessage(errorMsg);
        },
      };
      dispatch(addOneTimeCostCenter(obj));
    } else {
      // Keyboard.dismiss();
      ref_add_costCenter.current.close();
      setCostCenterName("");
      showToast?.(
        "alertToast",
        strings["ime.scanner.error.occured.msg"],
        "Cost center field should not be empty "
      );
      // showToast("alertToast", strings["ime.scanner.error.occured.msg"], "ghj");
      // Keyboard.dismiss();
      // ref_add_costCenter.current.close();
    }
  };

  const onChangeUserSearch = (text: string, barcode = false) => {
    onChangeUserSearchLogic(
      text,
      userDataList,
      setSearchKey,
      setUserList,
      barcode
    );
  };

  const onChangeCostSearch = (text: string) => {
    onChangeCostSearchLogic(
      text,
      [...costCenterList, ...oneTimeCostCenter],
      setSearchKey,
      setCostList
    );
  };

  const renderUserListBottomSheet = () => {
    return (
      <BottomSheetComponent
        customStyles={{ container: styles.bottomSheetContainer }}
        bottomSheetRef={userList_ref}
        height={hp(80)}
        onOpen={() => onChangeUserSearch("")}
      >
        <View
          style={[styles.headerContainer]}
          accessible={true}
          accessibilityLabel="user-list-sheet-header-container"
        >
          <View style={{ flex: 1 }} />
          <Text style={styles.headerText}>{strings["user"]}</Text>

          <View style={styles.buttonContainer}>
            <TouchableOpacity
              accessible={true}
              accessibilityLabel="user-list-sheet-close-btn"
              style={styles.secondaryPressableContainer}
              onPress={() => userList_ref.current.close()}
            >
              <Text
                style={styles.closeBtn}
                accessible={true}
                accessibilityLabel="close-btn"
              >
                {strings["close"]}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <AnimatedSearch
          search={searckKey ?? ""}
          onSearch={(res) => onChangeUserSearch(res)}
          containerStyle={styles.searchMain}
          placeholder={strings["search"]}
          clearText={() => onChangeUserSearch("")}
          onBarcodeDetected={(barcode) => onChangeUserSearch(barcode, true)}
          from={"Replenish"}
          onCancel={() => {
            onChangeUserSearch("");
            Keyboard.dismiss();
          }}
        />

        <ScrollView style={styles.listMain}>{userItemList()}</ScrollView>
      </BottomSheetComponent>
    );
  };

  const renderCostCenterListBottomSheet = () => {
    return (
      <BottomSheetComponent
        customStyles={{ container: styles.bottomSheetContainer }}
        bottomSheetRef={costCenter_ref}
        height={hp(70)}
        onOpen={() => onChangeCostSearch("")}
        didCloseModal={() => setSheet(false)}
      >
        <View
          style={styles.headerContainer}
          accessible={true}
          accessibilityLabel="costcenter-list-sheet-header-container"
        >
          <View style={{ flex: 1 }} />
          <Text style={styles.headerText}>{strings["cost.center"]}</Text>

          <View style={styles.buttonContainer}>
            <TouchableOpacity
              accessible={true}
              accessibilityLabel="costcenter-list-sheet-close-btn"
              style={styles.secondaryPressableContainer}
              onPress={() => costCenter_ref.current.close()}
            >
              <Text
                style={styles.closeBtn}
                accessible={true}
                accessibilityLabel="close-btn"
              >
                {strings["close"]}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        <AnimatedSearch
          search={searckKey ?? ""}
          onSearch={onChangeCostSearch}
          containerStyle={styles.searchMain}
          placeholder={strings["search"]}
          clearText={() => onChangeCostSearch("")}
          onBarcodeDetected={(barcode) => onChangeCostSearch(barcode)}
          from={"Replenish"}
          onCancel={() => {
            onChangeCostSearch("");
            Keyboard.dismiss();
          }}
        />
        <ScrollView
          style={styles.listMain}
          showsVerticalScrollIndicator={false}
        >
          {!!costList?.length &&
            // !stockRoomDetail?.isCostCenterMandatory &&
            !searckKey && (
              <TouchableOpacity
                accessible={true}
                accessibilityLabel={"consume_bottomsheet_element_button"}
                style={styles.itemContainer}
                onPress={() => onSelectUser(null, false)}
                activeOpacity={0.8}
              >
                <CustomText
                  accessibilityLabel={"consume_bottomsheet_element_title"}
                  style={styles.itemTitle}
                >
                  {strings["select"]}
                </CustomText>
              </TouchableOpacity>
            )}
          {costCenetrItemList()}
          {stockRoomDetail?.oneTimeCostCenterEnabled ? (
            <View
              style={styles.buttonsContainer}
              accessible={true}
              accessibilityLabel="one-time-cc-btn-container"
            >
              <MainButton
                title={strings["ime.scanner.Add.One-Time.Cost.Center"]}
                buttonTextStyle={styles.mainText}
                onChangeBtnPress={() => ref_add_costCenter.current.open()}
                buttonStyle={styles.addBtnStyle}
              />
            </View>
          ) : null}
        </ScrollView>
        <BottomSheetComponent
          customStyles={{ container: styles.bottomSheetContainer }}
          height={hp(25)}
          bottomSheetRef={ref_add_costCenter}
          onOpen={() => {
            setErrorMessage("");
            setCostCenterName("");
          }}
        >
          <View style={styles.headerContainer}>
            <View style={{ flex: 1 }} />
            <Text style={[styles.headerText, { fontSize: FONTS.h1_9 }]}>
              {"Add One-Time  Cost Center"}
            </Text>

            <View
              style={styles.buttonContainer}
              accessible={true}
              accessibilityLabel="add-onetime-cc-close-view-container"
            >
              <TouchableOpacity
                accessible={true}
                accessibilityLabel="add-onetime-cc-close-btn"
                style={styles.secondaryPressableContainer}
                onPress={() => ref_add_costCenter.current.close()}
              >
                <Text style={styles.closeBtn}>{strings["close"]}</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View>
            <TextInputComponent
              title={strings["cost.center.name"]}
              onPressRightIcon={(isClear?: boolean) => {
                setErrorMessage("");
                isClear && setCostCenterName("");
              }}
              RightIcon={Cross}
              value={costCenterName}
              editable={true}
              onChangeText={(value) => {
                setErrorMessage("");
                setCostCenterName(value);
              }}
              main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
              inputStyle={styles.inputStyle}
              inputMain={styles.inputMainStyle}
              returnKeyType="go"
              onSubmitEditing={() => onSubmitEditing()}
            />
            {errorMessage ? (
              <Text
                style={styles.errorMessage}
                accessible={true}
                accessibilityLabel="add-onetime-cc-err-msg"
              >
                {errorMessage}
              </Text>
            ) : null}
          </View>
        </BottomSheetComponent>
        {sheet && <ToastComponent />}
      </BottomSheetComponent>
    );
  };
  const isCloseToBottom = ({
    layoutMeasurement,
    contentOffset,
    contentSize,
  }: any) => {
    const paddingToBottom = 20;
    return (
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom
    );
  };

  const fetchData = () => {
    const all = data?.filter(
      (item: Item) =>
        item?.description.toLowerCase().includes(filterText.toLowerCase()) ||
        item?.catalogNo.toLowerCase().includes(filterText.toLowerCase()) ||
        item?.vendorName.toLowerCase().includes(filterText.toLowerCase())
    );
    if (count < all?.length) {
      setIsLoading(true);
      setCount((prv) => prv + 10);
      setTimeout(() => {
        setIsLoading(false);
      }, 1000);
    }
  };
  
  return (
    <View
      style={styles.container}
      accessible={true}
      accessibilityLabel="checkout-main-container"
    >
      <Header
        title={strings["ime.checkout"] ?? "Checkout"}
        onLeftIconPress={() =>
          // dispatch(
          //   setIsShowConfirmationAlert({
          //     isShow: true,
          //     data: confirmationAlertInfo?.data,
          //   })
          // )
          setISClickBack(true)
        }
        LeftIcon={() => <WhiteLeftArrow />}
        statusBar={true}
        statusBarColor={"blue"}
        iconLeft={true}
        iconRight={true}
      />
      <Subheader clearReplenishState={clearState} />

      <ScrollView
        contentContainerStyle={styles.contentContainerStyle}
        accessible={true}
        accessibilityLabel="checkout-scroll-container"
        // onScroll={({ nativeEvent }) => {
        //   if (isCloseToBottom(nativeEvent)) {
        //     setCount((prv) => prv + 10);
        //   }
        // }}
        scrollEventThrottle={400}
        onScroll={({ nativeEvent }) => {
          if (isCloseToBottom(nativeEvent) && !isLoadingData) {
            fetchData();
          }
        }}
      >
        {checkoutForm()}

        <View
          style={styles.subHeaderTextContainer}
          accessible={true}
          accessibilityLabel="order-header"
        >
          <Text
            style={[styles.itemChildHeaderText, styles.recommendedText]}
            accessible={true}
            accessibilityLabel="order-length"
          >
            {`${strings["order"]} (${data?.length})`}
          </Text>

          {stockRoomDetail?.isReplishShowPrice && (
            <Text
              style={styles.priceText}
              accessible={true}
              accessibilityLabel="order-price"
            >
              {getCurrencySymbol(
                data[0]?.vendorName ? data[0]?.currency : currency
              ) + `${totalPrice}`}
            </Text>
          )}
        </View>

        <View
          style={styles.dataContainer}
          accessible={true}
          accessibilityLabel="order-list-container"
        >
          {_renderList()}
          {/* {isLoadingData && (
        <View style={{flex:1}}>
          <ActivityIndicator size="large" color="#0000ff" />
        </View>
      )} */}
        </View>
      </ScrollView>
      <Footer
        mainbuttonTitle={strings["ime.checkout"] ?? "Checkout"}
        secondaryButtonTitle={strings["cancel"] ?? "Cancel"}
        secondaryButtonDisabled={!data?.length}
        count={String(data?.length ?? "0")}
        mainButtonStyle={{}}
        mainButtonTextStyle={{}}
        onChangePrimaryBtnPress={() => submitCheckout()}
        onChangeSecondaryBtnPress={() => {
          setClearAlert(true);
        }}
        mainContainerStyle={styles.footerMainContainer}
        outlinedBtnTextStyle={styles.outlinedBtnText}
        outlinedBtnContainerStyle={styles.outlinedBtnContainer}
      />

      {renderUserListBottomSheet()}

      {renderCostCenterListBottomSheet()}
      <BottomSheetComponent
        bottomSheetRef={customerApprovalRef}
        height={hp(70)}
      >
        <CustomerApprovalIDModal
          ids={customerApprovalIDs?.data?.customerApproverID}
          onClose={() => customerApprovalRef?.current?.close()}
          selectedItem={selectedApproverId}
          onPress={setSelectedApproverId}
        />
      </BottomSheetComponent>

      <BottomSheetComponent bottomSheetRef={spclhandlingmsgRef} height={hp(70)}>
        <SpclMessageModal
          msgs={spclhandlingmsg}
          onClose={() => spclhandlingmsgRef?.current?.close()}
          selectedItem={specialMessage}
          onPress={setSpecialMessage}
        />
      </BottomSheetComponent>

      {visible && (
        <AlertModal
          isShow={visible}
          customStyles={{
            width: wp(95),
            borderRadius: 4,
            alignSelf: "center",
            paddingVertical: hp(1),
          }}
        >
          {__renderCalander()}
        </AlertModal>
      )}

      <ClearSelectionAlert
        isShow={showClearAlert}
        didCloseModal={() => {
          setClearAlert(false);
        }}
        outlinedButtonTitle={"Cancel"}
        mainButtonTitle={strings["ime.scanner.Clear.Order"]}
        didMainButtonTitleClicked={() => {
          clearState();
          // props.onClose();
          setClearAlert(false);
          setTimeout(() => {
            props.onClose();
            //navigation.navigate("Dashboard");
          }, 1000);
        }}
        didOutlinedButtonClicked={() => setClearAlert(false)}
        orderTitle={strings["ime.scanner.Clear.this.order"]}
        orderDesc={
          strings["ime.scanner.All.products.in.this.order.will.be.removed."]
        }
      />
      {!sheet && <ToastComponent />}

      <ProductDetails
        itemDetailsRef={itemDetailsRef}
        productDetailsList={productDetails}
        isShowPrice={stockRoomDetail?.isReplishIndividual}
      />
      <Loader show={isLoading || isTotalpriceLoad} />

      {iSClickBack && (
        <ConfirmationAlert
          isShow={iSClickBack}
          onTapNo={() => {
            setISClickBack(false);
          }}
          goBack={false}
          from="Checkoutscreen"
          onTapYes={() => {
            clearState();
            setISClickBack(false);
            navigation.goBack();
            dispatch(resetPriceState());
          }}
          onBack={() => props?.onClose()}
        />
      )}
    </View>
  );
};

export default ReplenishCheckoutScreen;
