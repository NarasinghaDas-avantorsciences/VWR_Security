import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import { hp, wp, isDeviceTablet } from "../../../Utils/globalFunction";
import DeviceInfo from "react-native-device-info";
import { ReactNativeBlobUtilFetchPolyfill } from "react-native-blob-util";

export default StyleSheet.create({
  container: {
    flex: 1,
    ...(!isDeviceTablet() && { paddingBottom: 10}),
  },
   
  // downloadText: {
  //   color: COLORS.gray,
  //   fontFamily: FONTFAMILY.averta_bold,
  //   fontSize: FONTS.h1_8,
  //   fontWeight: "600",
  // },
  acceptButtonText: {
    fontSize: FONTS.h1_9,
  },
  btnContainer: {
    paddingRight: 10,
    paddingTop: 10,
    flexDirection: isDeviceTablet() ? "row" : "column",
    ...(isDeviceTablet()
      ? {
          width: "100%",
          paddingLeft: 10,
          justifyContent:'flex-start'
        }
      : { paddingLeft: 10 }),
  },
  declineBtnTextStyle: {
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h2,
    color: COLORS.scienceBlue,
    fontWeight: "600",
  },
  mainBtnText: {
    fontSize: FONTS.h1_9,
  },
  btnWidth: {
    backgroundColor: COLORS.scienceBlue,
    flex: 1,
  },
  outlinedBtnContainerStyle: {
    ...(isDeviceTablet()
      ? {
          marginBottom: hp(1),
          marginLeft: "auto",
          flex: 1,
        }
      : { marginHorizontal: 0, marginTop: 10 }),
  },

  // downLoadButton: {
  //   borderWidth: isDeviceTablet() ? 0 : 1,

  //   ...(isDeviceTablet()
  //     ? {
  //         alignSelf: "center",
  //         justifyContent: "flex-start",
  //         marginLeft: "auto",
  //         flex: 1,
  //       }
  //     : {
  //         marginHorizontal: 0,
  //       }),
  // },

  acceptButton: {
    ...(isDeviceTablet()
      ? {
          marginBottom: hp(1),
          marginLeft: "auto",
          flex: 1,
        }
      : { paddingVertical: hp(2), marginTop: 10 }),
  },
});
