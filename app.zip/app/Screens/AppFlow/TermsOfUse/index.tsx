import React, { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import styles from "./styles";
import {
  getTermsOfUse,
  setAcceptDeclineTerms,
} from "../../../Redux/Action/TermsOfUseAction";
import Toast from "react-native-toast-message";
import { useDispatch, useSelector } from "react-redux";
import { Loader } from "../../../Components";
import { View, StatusBar,Linking } from "react-native";
import { WebView } from "react-native-webview";
import FlatButton from "../../../Components/Common/FlatButton";
import OutlinedButton from "../../../Components/OutlinedButton";
import { showTermsAgreedPage } from "../../../Redux/Action/accountAction";

const TermsOfUse = ({ licenseAgreed }: any) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const dispatch = useDispatch<any>();
  const [loader, setLoader] = useState(false);
  const [disableBottomButtons, setDisableBottomButton] = useState(true);
  const [termsData, setTermsData] = useState("");

  useEffect(() => {
    setLoader(true);
    fetchTermsOfUse();
  }, []);

  const fetchTermsOfUse = () => {
    dispatch(
      getTermsOfUse((data: any) => {
        setTermsData(data);
        //setLoader(false);
      }, errorCallBack)
    );
  };

  const acceptClicked = () => {
    setLoader(true);
    dispatch(
      setAcceptDeclineTerms(
        true,
        (data: any) => {
          if (data.licenseAgreed == true) {
            dispatch(showTermsAgreedPage(false));
            licenseAgreed(true);
            setLoader(false);
          }
        },
        errorCallBack
      )
    );
  };
  /*
  function downloadClicked() {
    createPDF();
  }*/
  const declineClicked = () => {
    dispatch(showTermsAgreedPage(true));
    licenseAgreed(false);
  };

  const errorCallBack = (err) => {
    setLoader(false);
    if (err?.errorMessage) {
      Toast.show({
        type: "alertToast",
        text1: err?.errorMessage,
      });
    } else {
      Toast.show({
        type: "alertToast",
        text1: Strings["ime.attention"],
        text2: "Unable to proceed the current process, please try later.",
      });
    }
  };

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: "white",
      }}
      edges={["left", "right", "top", "bottom"]}
    >
      <StatusBar translucent={true} backgroundColor={"transparent"} />
      <View style={styles.container}>
        <WebView
          originWhitelist={["*"]}
          source={{ html: termsData }}
          automaticallyAdjustContentInsets={true}
          javaScriptEnabled={true}
          javaScriptCanOpenWindowsAutomatically={false}
          domStorageEnabled={true}
          decelerationRate="normal"
          startInLoadingState={true}
          scalesPageToFit={true}
          showsHorizontalScrollIndicator={false}
          showsVerticalScrollIndicator={false}
          allowsLinkPreview={false}
          onShouldStartLoadWithRequest={(request) => {
            //We are using only HTML string not URL.
            if (request.url.includes("https") || request.url.includes("http")) {
              Linking.openURL(request.url);
              return false;
            } else return true;
          }}
          onLoadEnd={(event) => {
            setLoader(false);
            setTimeout(() => {
              setDisableBottomButton(false)
            }, 500);
          }}
          onLoadStart={(event) => {
            setLoader(true);
          }}
          allowsBackForwardNavigationGestures = {true}
        />

        <View style={styles.btnContainer}>
          <OutlinedButton
            title={"I Decline"}
            disabled={disableBottomButtons}
            onChangeBtnPress={declineClicked}
            mainContainerStyle={{ ...styles.outlinedBtnContainerStyle }}
            mainTextStyle={styles.declineBtnTextStyle}
          />

          <FlatButton
            text={"Accept"}
            onPress={acceptClicked}
            disabled={disableBottomButtons}
            container={styles.acceptButton}
            textStyle={styles.acceptButtonText}
            accessibilityLabel={"terms-accept"}
          />
        </View>
      </View>
      <Loader show={loader} />
    </SafeAreaView>
  );
};

export default TermsOfUse;
