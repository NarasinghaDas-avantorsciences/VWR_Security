import React, {
  useState,
  useRef,
  useEffect,
  useCallback,
  Dispatch,
  SetStateAction,
} from "react";
import {
  TouchableOpacity,
  View,
  Pressable,
  Keyboard,
  Alert,
} from "react-native";
import Text from "../../../Components/CustomText";
import { useDispatch, useSelector } from "react-redux";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { useFocusEffect } from "@react-navigation/native";
import Toast from "react-native-toast-message";
import {
  SearchBar,
  ReasonCode,
  BottomSheetComponent,
  MainButton,
  StockListItem,
  Footer,
  ToastComponent,
  ProductDetails,
  ClearSelectionAlert,
  ScannerButton,
  AnimatedSearch,
} from "../../../Components";
import {
  hp,
  wp,
  isDeviceTablet,
  isProductFreezed,
  checkifBatchEnabled,
  checkifExpiryEnabled,
} from "../../../Utils/globalFunction";
import { useDebounceHook } from "../../../Hooks";
import { Search, Unselected, Checkbox, Locked } from "../../../Utils/images";
import { COLORS, SIZES } from "../../../Utils/theme";
import styles from "./styles";
import {
  setReason,
  getReasonCode,
  setCorrectStockList,
  setSelectedStock,
} from "../../../Redux/Action/stockCorrection";
import {
  getProductBatchDetails,
  getProductDetails,
  getProductList,
  setProductLoader,
  emptyProductData,
  getProductListFromBarcode,
} from "../../../Redux/Action/searchAction";
import {
  addItemsToOrderList,
  replenishStockCorrection,
  setLoader,
} from "../../../Redux/Action/replenishAction";
import {
  handleStockCorrect,
  handleAvailQty,
  handleBatches,
  handleBatchDelete,
} from "./logic";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import { ModalToast } from "../../../Components/ModalToast";

type ReplenishStockCorrectionProps = {
  initialRecommendedData: any;
  setIsCorrected: Dispatch<SetStateAction<boolean>>;
  setTapOnAddtoOrder: Dispatch<SetStateAction<boolean>>;
  setIsSelectedAll: Dispatch<SetStateAction<boolean>>;
  setShowVWR: Dispatch<SetStateAction<boolean>>;
  isKPI?: boolean;
  fromScreen?: string;
};

const ReplenishStockCorrection: React.FC<ReplenishStockCorrectionProps> = ({
  initialRecommendedData,
  setIsCorrected,
  setTapOnAddtoOrder,
  setIsSelectedAll,
  setShowVWR,
  isKPI,
  fromScreen,
}) => {
  const isTablet = isDeviceTablet();
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const productsData = useSelector(
    (state: any) => state.searchReducer?.searchList
  );
  const { correctStockList, reason, selectedStock } = useSelector(
    (state: any) => state.stockCorrectionReducer
  );
  const { productDetails, productDetailsLoading } = useSelector(
    (state: any) => state.searchReducer
  );
  const { stockRoomDetail, org_details, selectedStockRoom } = useSelector(
    (state: any) => state.userReducer
  );
  const { data } = useSelector((state: any) => state.accountReducer);
  const { isLoading } = useSelector((state: any) => state.replenishReducer);

  const [search, setSearch] = useState("");
  const [isSelectedAll, setSelectAll] = useState(true);
  const [clearModal, setClearModal] = useState(false);
  const [showFooter, setShowFooter] = useState(false);
  const [confirmationModel, setConfirmationModal] = useState(false);
  const stockRef = useRef<any>();
  const outterProductDetailsRef = useRef<any>(null);
  const innerProductDetailsRef = useRef<any>(null);
  const [isShowToasReft, setIsShowToast] = useState(false);
  const debouncedSearchTerm = useDebounceHook(search, 800);
  const reasonSuffix =
    stockRoomDetail?.stockroomType == "Regular"
      ? false
      : org_details?.showSapSetting;

  useEffect(() => {
    if (debouncedSearchTerm) {
      dispatch(getProductList(debouncedSearchTerm));
    } else {
      dispatch(setProductLoader(false));
    }
  }, [debouncedSearchTerm]);

  const getProductFromApi = async (searchKey: any) => {
    dispatch(
      getProductListFromBarcode(
        searchKey,
        null,
        (res: any) => {
          console.log(
            res?.data[0]?.catalogNo,
            res?.data[0]?.vendorCatalogNo,
            res?.data[0]?.custCatalogNo,
            "=,==========================",
            searchKey
          );

          if (
            res?.data[0]?.catalogNo == searchKey ||
            res?.data[0]?.vendorCatalogNo == searchKey ||
            res?.data[0]?.custCatalogNo == searchKey
          ) {
            renderItemFromBarcode(res?.data[0]);
            dispatch(setLoader(false));
          } else {
            Toast.show({
              type: "alertToast",
              text1: Strings["ime.scanner.error.occured.msg"],
              text2: "Product does not exist!",
              position: "bottom",
              bottomOffset: SIZES.padding * 2,
            });
            dispatch(setLoader(false));
          }
        },
        (res: any) => {
          dispatch(setLoader(false));

          console.log(res);
        }
      )
    );
  };

  useFocusEffect(
    useCallback(() => {
      dispatch(setIsShowConfirmationAlert({}));
      dispatch(
        getReasonCode(
          { codeType: "stock.correction" },
          stockRoomDetail?.stockroomType
        )
      );

      return () => {
        dispatch(setCorrectStockList([]));
        setSearch("");
        setShowFooter(false);
      };
    }, [])
  );

  useFocusEffect(
    useCallback(() => {
      if (fromScreen == "ReplenishOffline") {
        dispatch(setCorrectStockList(initialRecommendedData));
      }
    }, [initialRecommendedData])
  );

  useFocusEffect(
    useCallback(() => {
      return async () => {
        await dispatch(emptyProductData());
        await dispatch(
          setReason({
            code: "",
            id: 0,
          })
        );
      };
    }, [])
  );

  useFocusEffect(
    useCallback(() => {
      if (correctStockList?.length != 0 && search == "") {
        setTimeout(() => {
          setShowFooter(true);
        }, 900);
      } else {
        setShowFooter(false);
      }
    }, [correctStockList?.length, search])
  );

  const showToast = (text1: string, text2: string) => {
    Toast.show({
      type: "alertToast",
      text1: text1,
      text2: text2,
      position: "bottom",
      bottomOffset: SIZES.padding * 2,
    });
  };

  const stockCorrect = () => {
    handleStockCorrect(
      correctStockList,
      showToast,
      reason,
      setReason,
      data,
      dispatch,
      replenishStockCorrection,
      setCorrectStockList,
      addItemsToOrderList,
      initialRecommendedData,
      setIsCorrected,
      setTapOnAddtoOrder,
      setIsSelectedAll,
      setShowVWR,
      Toast,
      SIZES,
      Strings,
      isKPI,
      fromScreen
    );
    resetProductData(false);
  };

  const availQty = async (val: any, id: any) => {
    handleAvailQty(val, id, correctStockList, setCorrectStockList, dispatch);
  };

  const batchUpdates = async (
    batches: any,
    batchId: string,
    itemId: string
  ) => {
    handleBatches(
      batches,
      batchId,
      itemId,
      correctStockList,
      setCorrectStockList,
      dispatch
    );
  };

  const batchDelete = async (item: any, val: any, selectedItem: any) => {
    handleBatchDelete(
      item,
      val,
      correctStockList,
      setCorrectStockList,
      dispatch,
      selectedItem
    );
  };

  const handleAddToStockList = async () => {
    let item = selectedStock;
    let batches;
    let arr = correctStockList;

    if (selectedStock?.batches.length > 0) {
      let avlbQty = 0;
      batches = selectedStock?.batches?.filter((el: any) => {
        let isAvbl = el?.availableQty != 0 && el?.availableQty != null;
        avlbQty = isAvbl ? avlbQty + el?.availableQty : avlbQty;
        return isAvbl;
      });

      item["batches"] = batches;
      // item["actualQty"] = avlbQty;
      item["actualQty"] = "";
    }

    const found = arr?.some((el: any) => el?.id === selectedStock?.id);

    if (!found) {
      arr?.unshift({
        ...(item ? item : selectedStock),
        isSelected: true,
        selected: isKPI,
      });
    } else {
      //DPIM-5333

      arr &&
        arr.map((data: any, index: number) => {
          if (data?.catalogNo == item?.catalogNo) {
            arr[index].actualQty = item?.actualQty;
          }
        });

      // let index = arr && arr.findIndex((item: any) => item?.id == item?.id);

      // arr[index].actualQty = item?.actualQty;
    }

    await dispatch(setCorrectStockList(arr));
    setSearch("");
    await stockRef.current.close();
  };

  const errorCallBack = (err) => {
    if (err?.errorMessage) {
      Toast.show({
        type: "alertToast",
        text1: err?.errorMessage,
      });
    } else {
      Toast.show({
        type: "alertToast",
        text1: Strings["ime.attention"],
        text2: "Error occured while fetching the batch",
      });
    }
  };

  async function showSearchProductDetails(item: any) {
    await dispatch(setSelectedStock(item));
    await stockRef.current.open();
  }

  const handleSelectstock = async (item: any) => {
    let flag = 0;
    let arr = correctStockList;
    let objIndex = arr.findIndex((obj: { id: any }) => obj?.id == item?.id);
    isKPI
      ? (arr[objIndex].selected = !item?.selected)
      : (arr[objIndex].isSelected = !item?.isSelected);

    isKPI
      ? arr.map((list: { selected: boolean }) => {
          if (list?.selected) {
            flag += 1;
          }
        })
      : arr.map((list: { isSelected: boolean }) => {
          if (list?.isSelected) {
            flag += 1;
          }
        });

    if (flag == arr.length) {
      setSelectAll(true);
    } else {
      setSelectAll(false);
    }
    await dispatch(setCorrectStockList(arr));
  };

  const updateCheckboxStatus = async (value: string, dataItem: any) => {
    let flag = 0;
    let arr = correctStockList;
    let objIndex = arr.findIndex((obj: { id: any }) => obj?.id == dataItem?.id);
    arr[objIndex].isSelected = true;
    //  value == "0" ? false : true;

    arr.map((list: { isSelected: boolean }) => {
      if (list?.isSelected) {
        flag += 1;
      }
    });

    if (flag == arr.length) {
      setSelectAll(true);
    } else {
      setSelectAll(false);
    }
    await dispatch(setCorrectStockList(arr));
  };

  const _renderList = (key: string) => {
    if (key === "search") {
      const filteredData = productsData && productsData?.data;
      return (
        filteredData &&
        filteredData.map((item: any, index: number) => {
          return renderItem(item, index, key);
        })
      );
    } else {
      return (
        correctStockList &&
        correctStockList?.map((item: any, index: number) => {
          return renderItem(item, index, key);
        })
      );
    }
  };

  const renderItemFromBarcode = async (item: any) => {
    if (reason?.code != "") {
      item["reasonCode"] = reason;
    }
    if (
      item?.expiryDateManagementenabled != 0 ||
      item?.batchManagementEnabled != 0
    ) {
      await dispatch(
        getProductBatchDetails(
          item?.id ?? "",
          (data: any) => {
            item["batches"] = data;
            showSearchProductDetails(item);
          },
          errorCallBack
        )
      );
    } else {
      showSearchProductDetails(item);
    }
  };

  const renderItem = (item: any, index: number, key: string) => {
    return (
      <StockListItem
        key={`${index}`}
        item={item}
        from={"RepstockCorrection"}
        containerStyle={{ marginHorizontal: 0 }}
        show={key == "search" ? false : true}
        required={true}
        showBatch={
          checkifBatchEnabled(item, stockRoomDetail) ||
          checkifExpiryEnabled(item, stockRoomDetail)
          // ((stockRoomDetail?.batchManagementEnabled ||
          //   stockRoomDetail?.expiryDateManagementenabled) &&
          //   item?.expiryDateManagementenabled == 1) ||
          // item?.batchManagementEnabled == 1
        }
        fromOffline={fromScreen == "ReplenishOffline"}
        reasonCodeType="stock.correction"
        handleOnSelect={
          key == "search"
            ? async () => {
                if (reason?.code != "") {
                  item["reasonCode"] = reason;
                }
                if (
                  item?.expiryDateManagementenabled != 0 ||
                  item?.batchManagementEnabled != 0
                ) {
                  await dispatch(
                    getProductBatchDetails(
                      item?.id ?? "",
                      (data: any) => {
                        item["batches"] = data;
                        showSearchProductDetails(item);
                      },
                      errorCallBack
                    )
                  );
                } else {
                  showSearchProductDetails(item);
                }
              }
            : () => {
                outterProductDetailsRef.current.open();
              }
        }
        handleAvailQty={availQty}
        handleBatch={batchUpdates}
        handleBatchDelete={batchDelete}
        freeze={isProductFreezed(item)}
        rightIcon={
          key == "stock" ? (
            isKPI ? (
              <Pressable
                onPress={() => handleSelectstock(item)}
                accessible={true}
                accessibilityLabel="checkbox-container"
              >
                {item?.selected ? <Checkbox /> : <Unselected />}
              </Pressable>
            ) : (
              <Pressable
                onPress={() => handleSelectstock(item)}
                accessible={true}
                accessibilityLabel="checkbox-container"
              >
                {item?.isSelected ? <Checkbox /> : <Unselected />}
              </Pressable>
            )
          ) : key == "search" ? (
            isProductFreezed(item) && (
              <Locked
                accessible={true}
                accessibilityLabel="consume-item-locked-image"
              />
            )
          ) : null
        }
        updateCheckbox={(value: string) => updateCheckboxStatus(value, item)}
        disableListPress={key == "search" ? false : true}
      />
    );
  };

  const _renderProductDetails = (itemDetailsRef: any) => (
    <ProductDetails
      itemDetailsRef={itemDetailsRef}
      productDetailsList={productDetails}
    />
  );
  const resetProductData = (value) => {
    dispatch(setProductLoader(value));
    dispatch(emptyProductData());
  };
  return (
    <View
      style={styles.container}
      accessible={true}
      accessibilityLabel="replenish-stockCorrection-cotainer"
    >
      <ReasonCode
        containerStyle={styles.reasonContainer}
        reasonCodeType="stock.correction"
        from="masterCode"
        reason={reason}
        setReason={async (val: any) => await dispatch(setReason(val))}
      />
      {/* <SearchBar
        search={search}
        containerStyle={styles.searchBarContainerStyle}
        onSearch={(text) => {
          resetProductData(!!text);
          setSearch(text);
        }}
        placeholder={
          Strings["ime.scanner.search.stockroom.products"] ??
          "Search stockroom products"
        }
        onBarcodeDetected={(barcode) => {
          resetProductData(!!barcode);
          setSearch(barcode);
        }}
      /> */}

      <AnimatedSearch
        idLabel={"stock-correction"}
        search={search}
        onSearch={(text: any) => {
          if (search != text) {
            resetProductData(!!text);
            setSearch(text);
          }
        }}
        placeholder={Strings["search"]}
        containerStyle={{
          paddingHorizontal: SIZES.padding,
        }}
        cancelBtnStyle={{ paddingRight: wp(5) }}
        clearText={() => {
          resetProductData("");
          setSearch("");
          // Keyboard.dismiss();
        }}
        onBarcodeDetected={async (barcode) => {
          // resetProductData(!!barcode);
          // dispatch(setLoader(true));
          // setSearch(barcode);
          await getProductFromApi(barcode);
        }}
        onCancel={() => {
          setSearch("");
          resetProductData("");
          Keyboard.dismiss();
        }}
        isShowEmptyMsg={false}
        from={"stockCorrection"}
      />

      {/* Stock correct/Product Search */}
      {search != "" || correctStockList?.length == 0 ? (
        <>
          {productsData && productsData?.length != 0 && search != "" ? (
            <KeyboardAwareScrollView
              showsVerticalScrollIndicator={false}
              alwaysBounceVertical={false}
              contentContainerStyle={styles.dataContainer}
              accessible={true}
              accessibilityLabel="searchItem-cotainer"
              keyboardDismissMode="interactive"
              keyboardShouldPersistTaps="always"
              onScroll={() => Keyboard.dismiss()}
            >
              {_renderList("search")}
            </KeyboardAwareScrollView>
          ) : null}
        </>
      ) : (
        <>
          {correctStockList?.length != 0 && search == "" && (
            <KeyboardAwareScrollView
              keyboardDismissMode="interactive"
              keyboardShouldPersistTaps="always"
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.contentContainerStyle}
              accessible={true}
              accessibilityLabel="replenish-stockItem-cotainer"
              enableResetScrollToCoords={false}
              keyboardOpeningTime={Number.MAX_SAFE_INTEGER}
            >
              <View
                style={[
                  styles.subHeaderTextContainer,
                  { paddingHorizontal: wp(4) },
                ]}
                accessible={true}
                accessibilityLabel="replenish-stockItem-content-cotainer"
              >
                <Text
                  style={[styles.itemChildHeaderText, styles.recomentedText]}
                  accessibilityLabel="stockCorrection-label"
                >
                  {Strings["stock.correction"] ?? "Stock Correction"} (
                  {
                    correctStockList.filter(
                      (item: { isSelected: any; selected: any }) =>
                        isKPI ? item.selected : item.isSelected
                    ).length
                  }
                  )
                </Text>

                <View
                  style={styles.subHeaderTextContainer}
                  accessible={true}
                  accessibilityLabel="selectAllItem-container"
                >
                  <Search height={hp(2.5)} width={hp(2.5)} />
                  <Text
                    style={[
                      styles.itemChildHeaderText,
                      styles.selectDeselectText,
                    ]}
                    accessibilityLabel="selectAll-label"
                  >
                    {isSelectedAll
                      ? Strings["ime.scanner.deselect.all"] ?? "Deselect All"
                      : Strings["ime.select.all"] ?? "Select All"}
                  </Text>
                  {isSelectedAll ? (
                    <Checkbox
                      onPress={async () => {
                        let arr = correctStockList;
                        isKPI
                          ? arr.map((v: any) =>
                              Object.assign(v, { selected: false })
                            )
                          : arr.map((v: any) =>
                              Object.assign(v, { isSelected: false })
                            );
                        await dispatch(setCorrectStockList(arr));
                        setSelectAll(false);
                      }}
                    />
                  ) : (
                    <Unselected
                      onPress={async () => {
                        let arr = correctStockList;
                        isKPI
                          ? arr.map((v: any) =>
                              Object.assign(v, { selected: true })
                            )
                          : arr.map((v: any) =>
                              Object.assign(v, { isSelected: true })
                            );
                        await dispatch(setCorrectStockList(arr));
                        setSelectAll(true);
                      }}
                    />
                  )}
                </View>
              </View>

              <View
                style={styles.dataContainer}
                accessible={true}
                accessibilityLabel="replenish-stockItem-content"
              >
                {_renderList("stock")}
              </View>
            </KeyboardAwareScrollView>
          )}
        </>
      )}

      {/* Footer */}

      {showFooter && (
        <Footer
          mainbuttonTitle={Strings["correct.stock"] ?? "Correct Stock"}
          secondaryButtonTitle={Strings["ime.scanner.clear"] ?? "Clear"}
          secondaryButtonDisabled={!correctStockList?.length}
          count={`${
            correctStockList.filter(
              (item: { isSelected: any; selected: any }) =>
                isKPI ? item.selected : item.isSelected
            ).length
          }`}
          mainButtonDisabled={
            correctStockList.filter(
              (item: { isSelected: any; selected: any }) =>
                isKPI ? item.selected : item.isSelected
            ).length == 0
              ? true
              : false
          }
          mainButtonStyle={{
            backgroundColor:
              correctStockList.filter(
                (item: { isSelected: any; selected: any }) =>
                  isKPI ? item.selected : item.isSelected
              ).length == 0
                ? COLORS.gray4
                : COLORS.scienceBlue,
          }}
          mainButtonTextStyle={{}}
          onChangePrimaryBtnPress={() => {
            let correctStockArr = isKPI
              ? correctStockList
                  .map((item: any) => {
                    if (item?.selected) return item;
                  })
                  .filter((item: any) => item)
              : correctStockList
                  .map((item: any) => {
                    if (item?.isSelected) return item;
                  })
                  .filter((item: any) => item);

            let reasonCodeArr = correctStockArr.filter(
              (item: any) => item?.reasonCode
            );
            let newFilterArr: any = [];
            correctStockList.map((item: any, i: number) => {
              let Arr = item?.batches?.filter(
                (item: any) => item?.actualQty == null || item?.actualQty == ""
              );
              if (Arr?.length) newFilterArr = newFilterArr.concat(Arr);
            });

            let nonBatchArr: any = [];
            correctStockList.map((item: any, i: number) => {
              if (item?.batches?.length == 0 || item?.batches == null) {
                if (item?.actualQty == null || item?.actualQty == "") {
                  nonBatchArr.push(item);
                }
              }
            });

            if (reasonCodeArr?.length != correctStockArr?.length) {
              setIsShowToast(true);
              setTimeout(() => {
                setIsShowToast(false);
              }, 4000);
              // showToast(
              //   Strings["ime.scanner.error.occured.msg"],
              //   Strings["ime.scanner.Reason.Code.msg"]
              // );
              return;
            }
            if (newFilterArr?.length > 0 || nonBatchArr.length > 0) {
              showToast(
                Strings["ime.scanner.error.occured.msg"],
                "The Actual Quantity is required"
              );
              return;
            }

            let isSap = correctStockArr.some(
              (item: { reasonCode: { dontSyncWithSap: string } }) =>
                item?.reasonCode?.dontSyncWithSap == "N"
            );

            if (reasonSuffix && isSap) {
              setConfirmationModal(true);
              return;
            }
            stockCorrect();
          }}
          onChangeSecondaryBtnPress={() => setClearModal(true)}
          mainContainerStyle={styles.footerMainContainer}
          outlinedBtnTextStyle={styles.outlinedBtnText}
          outlinedBtnContainerStyle={styles.outlinedBtnContainer}
        />
      )}

      {/* Add Stock BottomSheet */}
      <BottomSheetComponent
        height={SIZES.height - (isTablet ? SIZES.padding : SIZES.padding * 2)}
        bottomSheetRef={stockRef}
        didCloseModal={async () => {
          let item = selectedStock;
          item["reasonCode"] = "";
          await dispatch(setSelectedStock(item));
        }}
      >
        <View
          style={styles.bottomSheetContainer}
          accessible={true}
          accessibilityLabel="addToList-container"
        >
          <Text
            style={styles.stockTitle}
            numberOfLines={1}
            accessibilityLabel="addToList-header"
          >
            {selectedStock?.description}
          </Text>
        </View>

        <KeyboardAwareScrollView
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          showsVerticalScrollIndicator={false}
          alwaysBounceVertical={false}
          contentContainerStyle={styles.contentContainerStyle}
          accessible={true}
          accessibilityLabel="addToList-content-container"
        >
          <StockListItem
            item={selectedStock}
            id={`${selectedStock?.id}`}
            handleOnSelect={async () => {
              innerProductDetailsRef?.current?.open();
              await dispatch(getProductDetails(selectedStock?.id));
              await dispatch(setProductLoader(false));
            }}
            from="addToList"
            reasonCodeType="stock.correction"
            handleReasonCode={async (item: any) =>
              await dispatch(setSelectedStock(item))
            }
            handleAvailQty={async (val: any, id: any) => {
              let item = selectedStock;
              item["actualQty"] = val;
              await dispatch(setSelectedStock(item));
            }}
            show={true}
            freeze={isProductFreezed(selectedStock)}
            showBatch={false}
            bottomBorder={false}
            rightIcon={isProductFreezed(selectedStock) ? <Locked /> : null}
            disableListPress={true}
          />

          <View
            style={styles.buttonsContainer}
            accessible={true}
            accessibilityLabel="addToList-button-container"
          >
            <TouchableOpacity
              style={styles.cancelButtonContainer}
              onPress={() => stockRef.current.close()}
              accessible={true}
              accessibilityLabel="addToList-cancel-button"
            >
              <Text
                style={styles.cancelText}
                accessibilityLabel="cancel-button-label"
              >
                {Strings.cancel}
              </Text>
            </TouchableOpacity>

            <MainButton
              title={
                Strings["ime.add.to.list"]
                  ? "+ " + Strings["ime.add.to.list"]
                  : "+ Add to list"
              }
              buttonTextStyle={styles.mainText}
              onChangeBtnPress={handleAddToStockList}
              disabled={isProductFreezed(selectedStock)}
              buttonStyle={
                isProductFreezed(selectedStock) && {
                  backgroundColor: COLORS.gray4,
                }
              }
            />
          </View>
        </KeyboardAwareScrollView>

        {/* Inner Product Details */}
        {_renderProductDetails(innerProductDetailsRef)}
      </BottomSheetComponent>

      {/* Outter Product Details */}
      {_renderProductDetails(outterProductDetailsRef)}

      {/* Loader */}
      {/* <Loader show={productDetailsLoading || isLoading} /> */}

      {/* Clear model */}
      <ClearSelectionAlert
        isShow={clearModal}
        didCloseModal={() => {
          setClearModal(false);
        }}
        outlinedButtonTitle={Strings["ime.cancel"]}
        mainButtonTitle={Strings["ime.scanner.Clear.Order"]}
        didMainButtonTitleClicked={async () => {
          setClearModal(false);
          setSelectAll(true);
          await dispatch(emptyProductData());
          await dispatch(setCorrectStockList([]));
        }}
        didOutlinedButtonClicked={() => setClearModal(false)}
        orderTitle={Strings["ime.scanner.Clear.list"]}
        orderDesc={
          Strings["ime.scanner.All.products.in.this.list.will.be.removed"]
        }
      />

      {/* Reason code confirmation model */}
      <ClearSelectionAlert
        isShow={confirmationModel}
        didCloseModal={() => {
          setConfirmationModal(false);
        }}
        outlinedButtonTitle={Strings["cancel"]}
        didOutlinedButtonClicked={() => setConfirmationModal(false)}
        mainButtonTitle={Strings["yes"]}
        didMainButtonTitleClicked={async () => {
          setConfirmationModal(false);
          stockCorrect();
        }}
        orderTitle={Strings["sync.with.sap"]}
        orderDesc={Strings["returning.stock.with.this.reason.code"]}
      />

      <ScannerButton
        onBarcodeDetected={async (barcode) => {
          // resetProductData(!!barcode);
          // setSearch(barcode);
          await getProductFromApi(barcode);
        }}
        mainButtonStyle={
          correctStockList?.length != 0 && search == ""
            ? styles.scannerBtn
            : null
        }
        onSearch={(text) => {
          resetProductData(text);
          setSearch(text);
        }}
      />

      {/* Toast */}
      <ModalToast
        isShow={isShowToasReft}
        onClose={() => setIsShowToast(false)}
        title={Strings["ime.scanner.error.occured.msg"]}
        discription={Strings["ime.scanner.Reason.Code.msg"]}
      />
      <ToastComponent />
    </View>
  );
};

export default ReplenishStockCorrection;
