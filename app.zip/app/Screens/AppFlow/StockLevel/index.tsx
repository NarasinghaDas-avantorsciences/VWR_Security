/* Used to show Running Low and out of stock details */

import React, { useState, useRef, useCallback, useEffect } from "react";
import {
  View,
  Image,
  Pressable,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import {
  CommonActions,
  useFocusEffect,
  useNavigation,
} from "@react-navigation/native";

import Text from "../../../Components/CustomText";
import {
  Header,
  Footer,
  ListItem,
  QtyController,
  TextInputComponent,
  ClearSelectionAlert,
  ProductInfoDetails,
  ProductDetails,
  ToastComponent,
  Loader,
} from "../../../Components";
import {
  Unselected,
  Checkbox,
  DefaultProductImage,
  Locked,
  Cross,
} from "../../../Utils/images";
import {
  wp,
  hp,
  isProductFreezed,
  checkUomCondition,
  getMultiplier,
} from "../../../Utils/globalFunction";
import { COLORS, SIZES, FONTS } from "../../../Utils/theme";
import { changeCommentLogic, changeQtyLogic } from "./logic";
import {
  setSelectAllProductData,
  setUpdatedOutofStockData,
  setUpdatedRunningLowData,
} from "../../../Redux/Action/dashboardAction";
import {
  getProductDetails,
  setProductLoader,
} from "../../../Redux/Action/searchAction";
import {
  clearOrderedItemList,
  setUpdatedRecommendedData,
} from "../../../Redux/Action/replenishAction";
import CustomText from "../../../Components/CustomText";
import * as storage from "../../../Service/AsyncStoreConfig";
import styles from "./styles";
import {
  getOutOfStock,
  getRunningLowStock,
  getOutOfProductList,
  getRunningLowProductList,
  clearStockLevelData,
} from "../../../Redux/Action/dashboardAction";

type Item = {
  catalogNo: string;
  uomManagementEnabled: number;
  stockRoomUOMUnit: any;
  selectedQty: string;
  uomId: any;
  description: string;
  vendorName: string;
  locationName: string;
  maxStockQty: string;
  backlogQty: string;
  id: string;
  title: string;
  selected: boolean;
  enteredComment: string;
  imageURL: string;
  freeze: boolean;
  orderedQtyUOMDisplay?: string;
};

const StockLevel = (props: any) => {
  const dispatch = useDispatch<any>();
  const itemDetailsRef = useRef<any>(null);
  const scrollRef = useRef<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const [slectedIndex, setSlectedIndex] = useState(
    props?.route?.params?.route ?? 0
  );
  const [outofStockOffset, setoutofStockOffSet] = useState(0);
  const [runningLowOffSet, setRunningLowOffSet] = useState(0);
  const [qtyFlag, setQtyFlag] = useState(0);
  const [clearModal, setClearModal] = useState(false);
  const [isShowAlert, setIsShowAlert] = useState(false);
  const [selectAllOutofStock, setSelectAllOutofStock] = useState(false);
  const [selectAllRunningLow, setSelectAllRunningLow] = useState(false);
  const {
    outOfStockProductList,
    runningLowProductList,
    outOfStock,
    runningLow,
    loader,
  } = useSelector((state: any) => state.dashboardReducer);
  const { stockRoomDetail, userPrivilege } = useSelector(
    (state: any) => state.userReducer
  );
  const { productDetails } = useSelector((state: any) => state?.searchReducer);
  const navigation = useNavigation<any>();
  let allData =
    slectedIndex == 0 ? outOfStockProductList : runningLowProductList;
  const [progress, setProgress] = useState(true);

  useFocusEffect(
    useCallback(() => {
      dispatch(setUpdatedRecommendedData([]));
      dispatch(clearOrderedItemList());
      if (props?.route?.params?.fromPushNotification) {
        console.log("selected Index", props?.route?.params);
        setoutofStockOffSet(0);
        setRunningLowOffSet(0);
        dispatch(getOutOfStock());
        dispatch(getRunningLowStock());
        dispatch(getOutOfProductList(0, []));
        dispatch(getRunningLowProductList(0, []));
      }
    }, [])
  );
  useCallback(() => {
    setoutofStockOffSet(0);
    setRunningLowOffSet(0);
    dispatch(getOutOfStock());
    dispatch(getRunningLowStock());
    dispatch(getOutOfProductList(0, []));
    dispatch(getRunningLowProductList(0, []));
  }, []);

  useEffect(() => {
    if (
      outOfStockProductList?.length == 0 ||
      outOfStockProductList?.length > 0 ||
      runningLowProductList?.length == 0 ||
      runningLowProductList?.length > 0
    ) {
      setTimeout(() => {
        setProgress(false);
      }, 1000);
    }
  }, [outOfStockProductList, runningLowProductList]);

  const checkUserPrivilege = () => {
    const data = userPrivilege?.filter(
      (item) => item?.name === "replenish.scanner"
    );

    return data?.length ? true : false;
  };

  const onEndScrolling = async (tabIndex: number) => {
    if (loader) return;
    var offset = 0;
    switch (tabIndex) {
      case 0:
        if (outOfStockProductList && outOfStockProductList?.length > 0) {
          if (outOfStock && outOfStock > outofStockOffset * 10) {
            offset = outofStockOffset + 1;
            await dispatch(
              getOutOfProductList(
                offset * 10,
                outOfStockProductList,
                selectAllOutofStock
              )
            );
            setoutofStockOffSet(offset);
          } else {
            return;
          }
        } else {
          return;
        }
        break;
      case 1:
        if (runningLowProductList && runningLowProductList?.length > 0) {
          if (runningLow && runningLow > runningLowOffSet * 10) {
            offset = runningLowOffSet + 1;
            await dispatch(
              getRunningLowProductList(
                offset * 10,
                runningLowProductList,
                selectAllRunningLow
              )
            );
            setRunningLowOffSet(offset);
          } else {
            return;
          }
        } else {
          return;
        }
        break;
    }
  };

  const _renderList = (id: number) => {
    let Data = id == 0 ? outOfStockProductList : runningLowProductList;
    if (Data?.length == 0) {
      return noDataFound();
    } else {
      return (
        Data &&
        Data?.map((item: any, index: number) => {
          return renderItem(item, index, id);
        })
      );
    }
  };

  const setSelectAll = (Id: number) => {
    if (Id == 0) {
      for (let i = 0; i < outOfStockProductList?.length; i++) {
        outOfStockProductList[i]["selected"] = selectAllOutofStock
          ? false
          : true;
      }
      setSelectAllOutofStock(!selectAllOutofStock);
    } else {
      for (let i = 0; i < runningLowProductList?.length; i++) {
        runningLowProductList[i]["selected"] = selectAllRunningLow
          ? false
          : true;
      }
      setSelectAllRunningLow(!selectAllRunningLow);
    }
  };

  const onSelectItems = async (
    item: any,
    index: number,
    id: number,
    value?: string
  ) => {
    if (id == 0) {
      let sampleData = outOfStockProductList;
      if (value) {
        sampleData[index].selected = value == "0" ? false : true;
      } else sampleData[index].selected = !sampleData[index]?.selected;
      await dispatch(setSelectAllProductData(sampleData, id));
      const filteredArr = sampleData.filter((obj: any) => obj.selected == true);
      const freezItems = sampleData.filter(
        (obj: any) => isProductFreezed(obj) == true
      );
      if (
        filteredArr?.length + freezItems?.length ==
        outOfStockProductList?.length
      )
        setSelectAllOutofStock(true);
      else setSelectAllOutofStock(false);
    } else {
      let sampleData = runningLowProductList;
      if (value) {
        sampleData[index].selected = value == "0" ? false : true;
      } else sampleData[index].selected = !sampleData[index]?.selected;
      await dispatch(setSelectAllProductData(sampleData, id));
      const filteredArr = sampleData.filter((obj: any) => obj.selected == true);
      const freezItems = sampleData.filter(
        (obj: any) => isProductFreezed(obj) == true
      );
      if (
        filteredArr?.length + freezItems?.length ==
        runningLowProductList?.length
      )
        setSelectAllRunningLow(true);
      else setSelectAllRunningLow(false);
    }
  };

  const renderItem = (item: Item, index: number, id: number) => {
    return (
      <ListItem
        key={`${index}`}
        leftIcon={
          <View
            style={styles.leftIconContainer}
            accessible={true}
            accessibilityLabel="product-image-container"
          >
            {item?.imageURL ? (
              <Image
                source={{ uri: item.imageURL.replace("http://", "https://") }}
                style={styles.leftIcon}
                resizeMode={"contain"}
                accessible={true}
                accessibilityLabel="product-image"
              />
            ) : (
              <DefaultProductImage width={wp(18)} height={wp(18)} />
            )}
          </View>
        }
        headerContent={
          <View accessible={true} accessibilityLabel="product-header-container">
            <Text
              style={styles.catalogNumber}
              accessibilityLabel="product-catalogNo"
            >
              {item?.catalogNo}
            </Text>
            <TouchableOpacity
              onPress={async () => {
                await itemDetailsRef?.current?.open();
                await dispatch(getProductDetails(item?.id));
                await dispatch(setProductLoader(false));
              }}
              accessible={true}
              accessibilityLabel="product-description-container"
            >
              <Text
                style={styles.itemHeaderContent}
                accessibilityLabel="product-description"
              >
                {item?.description}
              </Text>
            </TouchableOpacity>

            {checkUomCondition(item) && (
              <View
                style={styles.qtyInfoContainer}
                accessible={true}
                accessibilityLabel="product-unit-container"
              >
                <Text
                  style={styles.itemSubHeaderStyle}
                  accessibilityLabel="product-unit"
                >
                  {" "}
                  {item?.uomManagementEnabled == 1
                    ? item.stockRoomUOMUnit !== null
                      ? `(${item.stockRoomUOMUnit})`
                      : ""
                    : item.uomId !== null
                    ? `(${item.uomId})`
                    : ""}
                </Text>
              </View>
            )}
          </View>
        }
        rightIcon={
          checkUserPrivilege() &&
          (isProductFreezed(item) ? (
            <Locked />
          ) : (
            <Pressable
              onPress={() => onSelectItems(item, index, id)}
              accessible={true}
              accessibilityLabel="product-select-checkbox"
            >
              {item?.selected ? <Checkbox /> : <Unselected />}
            </Pressable>
          ))
        }
        customStyles={{ container: styles.itemContainerStyle }}
      >
        <View
          style={styles.flexRowContainer}
          accessible={true}
          accessibilityLabel="productInfo-container"
        >
          <ProductInfoDetails
            vendorName={item?.vendorName}
            locationName={item?.locationName ?? "-"}
            requiredQty={item?.maxStockQty ?? "-"}
            transitQty={item?.backlogQty ?? "-"}
          />
          <View
            style={[styles.itemChildContainer, styles.flexRowCenter]}
            accessible={true}
            accessibilityLabel="productInfo-input-container"
          >
            {stockRoomDetail?.isCommentsEnabled && (
              <TextInputComponent
                title={Strings["comment"]}
                onPressRightIcon={() => console.log("right icon pressed")}
                onPressLeftIcon={() => console.log("left icon pressed")}
                disableRightIcon={true}
                disableLeftIcon={true}
                placeholder={
                  Strings["ime.scanner.enter.comment"] ?? "Enter comment"
                }
                editable={true}
                disabled={!checkUserPrivilege()}
                onChangeText={(text: string) =>
                  onChangeComment(text, index, id)
                }
                main={styles.commentInputStyle}
                inputStyle={styles.inputStyle}
                inputMain={styles.inputMainStyle}
              />
            )}
            <QtyController
              inputValue={String(item?.selectedQty ?? 0)}
              onChange={(v: string) => {
                item["selectedQty"] = v;
                changeQty(v, item?.id, id);
                onSelectItems(item, index, id, v);
              }}
              titleStyle={styles.qtyTitleStyle}
              disable={isProductFreezed(item) || !checkUserPrivilege()}
            />
            <CustomText
              style={styles.multipierText}
              accessibilityLabel="list-item-multiplier"
            >
              {item?.orderedQtyUOMDisplay ?? getMultiplier(item)}
            </CustomText>
          </View>
        </View>
      </ListItem>
    );
  };

  const HeaderComponent = (id: number) => {
    let length =
      id == 0 ? outOfStockProductList?.length : runningLowProductList?.length;

    return (
      <View
        style={styles.subHeaderTextContainer}
        accessible={true}
        accessibilityLabel="productHeader-container"
      >
        <Text
          style={[styles.itemChildHeaderText, styles.recomentedText]}
          accessibilityLabel="productHeader-left-label"
        >
          {""}
        </Text>

        {length > 0 && checkUserPrivilege() && allData?.length ? (
          <TouchableOpacity
            style={styles.subHeaderTextContainer}
            onPress={() => setSelectAll(id)}
            accessible={true}
            accessibilityLabel="productHeader-right-container"
          >
            <Text
              style={[styles.itemChildHeaderText, styles.selectDeselectText]}
              accessibilityLabel="productHeader-right-label"
            >
              {(id == 0 ? selectAllOutofStock : selectAllRunningLow)
                ? Strings["ime.scanner.deselect.all"] ?? "Deselect All"
                : Strings["ime.select.all"] ?? "Select All"}
            </Text>
            {(id == 0 ? selectAllOutofStock : selectAllRunningLow) ? (
              <Checkbox onPress={() => setSelectAll(id)} />
            ) : (
              <Unselected onPress={() => setSelectAll(id)} />
            )}
          </TouchableOpacity>
        ) : null}
      </View>
    );
  };

  const checkDisable = (id: number) => {
    const filteredArr_outOfStock = outOfStockProductList?.filter(
      (obj: any) => obj.selected == true && !isProductFreezed(obj)
    );
    const filteredArr_runningLow = runningLowProductList?.filter(
      (obj: any) => obj.selected == true && !isProductFreezed(obj)
    );
    if (
      filteredArr_outOfStock?.length > 0 ||
      filteredArr_runningLow?.length > 0
    ) {
      return false;
    } else {
      return true;
    }
  };

  const footerNav = async (id: number) => {
    const selectedFilter = (productList: any[]) =>
      productList?.filter(
        (obj: any) => obj.selected == true && !isProductFreezed(obj)
      );

    const outStockSelected = selectedFilter(outOfStockProductList);
    const runningLowSelected = selectedFilter(runningLowProductList);

    const passedData = [...outStockSelected, ...runningLowSelected];
    const emptyProduct =
      passedData.find((item: any) => item.selectedQty === 0) || null;

    if (emptyProduct) {
      setIsShowAlert(true);
    } else {
      await storage.setItem("stocklevel", JSON.stringify(passedData));
      const state = navigation.getState();
      navigation.dispatch(
        CommonActions.reset({
          index: 1,
          routes: [{ name: "Dashboard" }],
        })
      );
      setoutofStockOffSet(0);
      setRunningLowOffSet(0);
      props.navigation.navigate &&
        props.navigation.navigate("Replenish", {
          fromScreen: "stockLevel",
          data: passedData,
        });
    }
  };

  // const footerNav = async (id: number) => {
  //   let passedData: any = [];
  //   let getSelectedOutStockArr = outOfStockProductList?.filter(
  //     (obj: any) => obj.selected == true && !isProductFreezed(obj)
  //   );
  //   let newOutStockDataArr = outOfStockProductList?.filter(
  //     (obj: any) => obj.selected == true && !isProductFreezed(obj)
  //   );

  //   if (
  //     newOutStockDataArr?.length > 0 &&
  //     getSelectedOutStockArr?.length == newOutStockDataArr?.length
  //   ) {
  //     passedData.push(...newOutStockDataArr);
  //   } else {
  //   }

  //   let getSelectedRunningLowArr = runningLowProductList?.filter(
  //     (obj: any) => obj.selected == true && !isProductFreezed(obj)
  //   );
  //   let newRunningLowDataArr = runningLowProductList?.filter(
  //     (obj: any) => obj.selected == true && !isProductFreezed(obj)
  //   );

  //   if (
  //     newRunningLowDataArr?.length > 0 &&
  //     getSelectedRunningLowArr?.length == newRunningLowDataArr?.length
  //   ) {
  //     passedData.push(...newRunningLowDataArr);
  //   }

  //   let emptyProduct =
  //     passedData?.find((item: any) => item.selectedQty == 0) ?? null;

  //   // console.log('passedData',passedData)
  //   // console.log('emptyProduct',emptyProduct)

  //   if (emptyProduct !== null) {
  //     setIsShowAlert(true);
  //     setTimeout(() => {
  //       setIsShowAlert(false);
  //     }, 2500);
  //   } else {
  //     await storage.setItem("stocklevel", JSON.stringify(passedData));
  //     const state = navigation.getState();
  //     navigation.dispatch(
  //       CommonActions.reset({
  //         index: 1,
  //         routes: [
  //           { name: "Dashboard" },
  //           // {
  //           //   name: 'Profile',
  //           //   params: { user: 'jane' },
  //           // },
  //         ],
  //       })
  //     );
  //     setoutofStockOffSet(0);
  //     setRunningLowOffSet(0);
  //     //dispatch(clearStockLevelData());
  //     setTimeout(() => {
  //       props.navigation.navigate &&
  //         props.navigation.navigate("Replenish", {
  //           fromScreen: "stockLevel",
  //           data: passedData,
  //         });
  //     }, 500);
  //   }
  // };

  const getCount = (id: number) => {
    const filteredArr_outOfStock = outOfStockProductList?.filter(
      (obj: any) => obj.selected == true && !isProductFreezed(obj)
    );
    const filteredArr_runningLow = runningLowProductList?.filter(
      (obj: any) => obj.selected == true && !isProductFreezed(obj)
    );

    return filteredArr_outOfStock?.length + filteredArr_runningLow?.length;
  };

  const showToast = () => {
    return (
      <View
        style={styles.main}
        accessible={true}
        accessibilityLabel="showToast-container"
      >
        <View
          style={styles.inner}
          accessible={true}
          accessibilityLabel="showToast-content-container"
        >
          <View
            style={{ flex: 1 }}
            accessible={true}
            accessibilityLabel="showToast-messgae-container"
          >
            <CustomText
              style={styles.tite}
              accessibilityLabel="showToast-messgae-headetText"
            >
              {Strings["ime.scanner.Check.Quantity"] ?? "Check Quantity"}
            </CustomText>
            <CustomText
              style={styles.des}
              accessibilityLabel="showToast-messgae-message"
            >
              {Strings["ime.please.input.qtys.for.the.products"]}
            </CustomText>
          </View>
          <TouchableOpacity
            onPress={() => setIsShowAlert(false)}
            accessible={true}
            accessibilityLabel="showToast-messgae-close-button"
          >
            <Cross height={hp(1.7)} width={hp(1.7)} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const FooterComponent = (id: number) => {
    return (
      <Footer
        mainbuttonTitle={Strings["ime.add.to.order"] ?? "Add to Order"}
        secondaryButtonTitle={Strings["ime.scanner.clear"] ?? "Clear"}
        secondaryButtonDisabled={
          !outOfStockProductList?.length || !runningLowProductList?.length
        }
        count={getCount(id) || 0}
        // label={Strings["products"]}
        mainButtonStyle={
          (checkDisable(id) || !props?.route?.params?.replenish) &&
          styles.disableMainBtn
        }
        mainButtonTextStyle={{}}
        onChangePrimaryBtnPress={() => footerNav(id)}
        onChangeSecondaryBtnPress={() => setClearModal(true)}
        mainContainerStyle={styles.footerMainContainer}
        outlinedBtnTextStyle={styles.outlinedBtnText}
        outlinedBtnContainerStyle={styles.outlinedBtnContainer}
        mainButtonDisabled={
          checkDisable(id) || !props?.route?.params?.replenish
        }
      />
    );
  };
  const isCloseToBottom = ({
    layoutMeasurement,
    contentOffset,
    contentSize,
  }: any) => {
    const paddingToBottom = 20;
    return (
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom
    );
  };
  const OutOfStock = () => (
    <>
      <ScrollView
        contentContainerStyle={styles.contentContainerStyle}
        accessible={true}
        accessibilityLabel="outOfStock-container"
        ref={scrollRef}
        onScroll={({ nativeEvent }) => {
          if (isCloseToBottom(nativeEvent)) {
            onEndScrolling(0);
          }
        }}
        scrollEventThrottle={400}
      >
        {HeaderComponent(0)}
        <View
          style={styles.dataContainer}
          accessible={true}
          accessibilityLabel="outOfStock-productList-container"
        >
          {_renderList(0)}
        </View>
      </ScrollView>
      {FooterComponent(0)}
    </>
  );
  const RunningLowStock = () => (
    <>
      <ScrollView
        scrollEventThrottle={400}
        contentContainerStyle={styles.contentContainerStyle}
        accessible={true}
        accessibilityLabel="runningLowStock-container"
        ref={scrollRef}
        onScroll={({ nativeEvent }) => {
          if (isCloseToBottom(nativeEvent)) {
            onEndScrolling(1);
          }
        }}
      >
        {HeaderComponent(1)}
        <View
          style={styles.dataContainer}
          accessible={true}
          accessibilityLabel="runningLow-productList-container"
        >
          {_renderList(1)}
        </View>
      </ScrollView>
      {FooterComponent(1)}
    </>
  );

  const onChangeComment = async (text: string, index: number, id: number) => {
    changeCommentLogic(
      id == 0 ? outOfStockProductList : runningLowProductList,
      dispatch,
      id == 0 ? setUpdatedOutofStockData : setUpdatedRunningLowData,
      index,
      text
    );
  };

  const changeQty = async (value: string, itemId: string, id: number) => {
    changeQtyLogic(
      id == 0 ? outOfStockProductList : runningLowProductList,
      dispatch,
      id == 0 ? setUpdatedOutofStockData : setUpdatedRunningLowData,
      itemId,
      value
    );
    setQtyFlag(qtyFlag + 1);
  };
  const noDataFound = () => {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>{Strings["no.records.found"]}</Text>
      </View>
    );
  };

  console.log("cec------", loader, progress);
  return (
    <View
      style={styles.container}
      accessible={true}
      accessibilityLabel="stockLevel-contaner"
    >
      <Header
        title={Strings["ime.stock.levels"] ?? "Stock Levels"}
        container={{
          backgroundColor: COLORS.white,
          borderTopWidth: 1,
          borderBottomWidth: 1,
          borderColor: COLORS.grayLight,
          marginTop: SIZES.radius,
        }}
        onLeftIconPress={() => null}
        onRightIconPress={() => {
          dispatch(clearStockLevelData());
          props.navigation.goBack();
        }}
        statusBar={false}
        statusBarColor={"white"}
        iconLeft={false}
        iconRight={true}
        titleStyle={{ color: COLORS.scienceBlue }}
        RightIcon={() => (
          <Text
            style={{
              ...FONTS.body,
              fontSize: FONTS.h2,
              color: COLORS.scienceBlue,
            }}
            accessibilityLabel="close-label"
          >
            {Strings["close"]}
          </Text>
        )}
      />
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tabItemContainer,
            { borderBottomWidth: slectedIndex == 0 ? 3 : 0 },
          ]}
          onPress={() => {
            setSlectedIndex(0);
            scrollRef?.current.scrollTo({
              x: 0,
              y: 0,
              animated: true,
            });
          }}
        >
          <Text
            style={[
              styles.tabLabelStyle,
              {
                color: slectedIndex == 0 ? COLORS.scienceBlue : COLORS.gray,
              },
            ]}
          >
            {outOfStock ?? 0}
            {"  "}
            {Strings["ime.out.of.stock"]}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tabItemContainer,
            { borderBottomWidth: slectedIndex == 1 ? 3 : 0 },
          ]}
          onPress={() => {
            setSlectedIndex(1);
            scrollRef?.current.scrollTo({
              x: 0,
              y: 0,
              animated: true,
            });
          }}
        >
          <Text
            style={[
              styles.tabLabelStyle,
              { color: slectedIndex == 1 ? COLORS.scienceBlue : COLORS.gray },
            ]}
          >
            {runningLow ?? 0}
            {"  "}
            {Strings["ime.running.low"]}
          </Text>
        </TouchableOpacity>
      </View>

      {slectedIndex == 0 ? OutOfStock() : RunningLowStock()}
      <ProductDetails
        itemDetailsRef={itemDetailsRef}
        productDetailsList={productDetails}
        isShowPrice={stockRoomDetail?.isReplishIndividual}
      />
      <ClearSelectionAlert
        isShow={clearModal}
        didCloseModal={() => {
          setClearModal(false);
        }}
        outlinedButtonTitle={"Cancel"}
        mainButtonTitle={Strings["ime.scanner.Clear.Order"]}
        didMainButtonTitleClicked={() => {
          setClearModal(false);
          dispatch(clearStockLevelData());
          props.navigation.navigate("Dashboard");
        }}
        didOutlinedButtonClicked={() => setClearModal(false)}
        orderTitle={Strings["ime.scanner.Clear.this.order"]}
        orderDesc={
          Strings["ime.scanner.All.products.in.this.order.will.be.removed."]
        }
      />
      <ToastComponent />
      {isShowAlert && showToast()}
      <Loader show={progress} />
    </View>
  );
};

export default StockLevel;
