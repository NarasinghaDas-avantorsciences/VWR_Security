const changeQtyLogic = async (
  data: any,
  dispatch: any,
  setUpdatedOutofStockData: any,
  itemId: string,
  value: string
) => {
  let sampleData = data.map((item: any) => {
    if (item.id == itemId) {
      item.selectedQty = value;
    }
    return item;
  });
  await dispatch(setUpdatedOutofStockData(sampleData));
};

const changeCommentLogic = async (
  data: any,
  dispatch: any,
  setUpdatedOutofStockData: any,
  index: number,
  text: string
) => {
  let sampleData = data;
  sampleData[index].enteredComment = text;
  await dispatch(setUpdatedOutofStockData(sampleData));
};

const setSelectAllItem = async (
  data: any,
  dispatch: any,
  setUpdatedData: any,
  val: boolean,
  id: number
) => {
  let sampleData = data;
  sampleData &&
    sampleData.map((v: any, i: number) => {
      v["selected"] = val;
    });
  await dispatch(setUpdatedData(sampleData, id));
};

export { changeQtyLogic, changeCommentLogic, setSelectAllItem };
