import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },

  contentContainerStyle: {
    flexGrow: 1,
    paddingHorizontal: wp(4),
    paddingBottom: hp(6),
  },

  mainInputContainerStyle: { marginVertical: hp(3), width: wp(92) },

  searchInputStyle: {
    backgroundColor: COLORS.whiteSmoke,
    borderWidth: 0,
    paddingRight: 0,
  },

  searchInputTextStyle: {
    color: COLORS.abbey,
  },

  mainBtnTextStyle: { fontSize: FONTS.h1_7, color: COLORS.scienceBlue },

  buttonStyle: {
    width: "100%",
    marginBottom: 16,
    backgroundColor: "#FFF",
    borderWidth: 1,
    borderColor: COLORS.blue,
  },

  subHeaderTextContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 6,
  },

  itemChildHeaderText: {
    fontSize: FONTS.h1_7,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    alignItems: "center",
  },

  recomentedText: { ...FONTS.title2, fontSize: FONTS.h2, lineHeight: 20 },

  selectDeselectText: {
    ...FONTS.title2,
    fontSize: FONTS.h1_5,
    marginHorizontal: wp(2),
  },

  dataContainer: { paddingBottom: hp(10) },

  leftIconContainer: { marginRight: wp(4) },

  leftIcon: {
    width: wp(18),
    height: wp(18),
  },

  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },

  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },

  qtyInfoContainer: { paddingVertical: hp(0.8), alignSelf: "flex-start" },
  itemSubHeaderStyle: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
  },
  // itemSubHeaderStyle: {
  //   textAlign: "center",
  //   color: COLORS.abbey,
  //   fontSize: FONTS.h1_5,
  //   fontFamily: FONTFAMILY.averta_bold,
  //   backgroundColor: COLORS.whiteSmoke,
  //   width: wp(32),
  //   paddingHorizontal: wp(1),
  //   borderRadius: hp(1),
  // },

  itemContainerStyle: {
    marginVertical: hp(1.8),
    borderBottomWidth: 1,
    paddingBottom: hp(1),
    borderColor: COLORS.whiteSmoke,
  },

  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  itemChildContainer: {
    // width: SIZES.width * 0.4,
    marginVertical: wp(0.5),
    paddingVertical: 8,
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },

  flexRowCenter: { flexDirection: "row", alignItems: "center" },

  commentInputStyle: {
    width: wp(42),
    alignSelf: "flex-start",
    backgroundColor: COLORS.white,
    marginRight: wp(4),
  },

  inputStyle: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h1_5,
    color: COLORS.abbey,
    left: -wp(2),
  },
  controllerInputStyle: {
    ...FONTS.body,
    paddingVertical: SIZES.base,
    paddingHorizontal: SIZES.tip,
  },

  inputMainStyle: {
    height: hp(4),
    top: 0,
    borderColor: COLORS.gray2,
    borderWidth: 0.8,
  },

  qtyTitleStyle: { marginRight: wp(3) },

  multipierText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_regular,
    maxWidth: wp(10),
  },

  footerMainContainer: { bottom: 0 },

  outlinedBtnText: { color: COLORS.gray },

  outlinedBtnContainer: { borderWidth: 0 },

  scannerMainBtn: { bottom: hp(13) },

  bottomSheetContainerStyle: {
    borderTopLeftRadius: 1,
    borderTopRightRadius: 1,
  },

  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginLeft: wp(30),
    alignItems: "center",
  },

  headerText: {
    fontSize: FONTS.h2_3,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.scienceBlue,
    textAlign: "center",
  },

  closeBtn: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.scienceBlue,
    paddingLeft: wp(6),
    fontFamily: FONTFAMILY.averta_regular,
  },

  inputStyle_VWR: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h1_5,
    color: COLORS.whiteSmoke,
    left: -wp(2),
  },

  inputMainStyle_VWR: { height: hp(4), top: 0, borderColor: COLORS.whiteSmoke },

  mainStyle: {
    width: wp(90),
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginTop: wp(5),
  },
  disableMainBtn: {
    backgroundColor: COLORS.gray2,
  },

  main: {
    position: "absolute",
    width: "90%",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    borderWidth: 1,
    borderColor: COLORS.alto,
    elevation: 5,
    backgroundColor: COLORS.white,
    borderRadius: 6,
    zIndex: 99,
    bottom: hp(2),
    alignSelf: "center",
  },
  inner: {
    width: "90%",
    marginTop: hp(1),
    alignSelf: "center",
    paddingVertical: hp(2),
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  tite: {
    color: COLORS.blackBright,
    ...FONTS.title,
    marginBottom: SIZES.base,
  },
  des: {
    color: COLORS.blackBright,
    marginRight: wp(2),
    ...FONTS.body,
  },
  tabContainer: {
    flexDirection: "row",
    height: hp(6),
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray3,
    justifyContent: "space-evenly",
    alignItems: "center",
    marginBottom: hp(1),
  },
  tabItemContainer: {
    borderBottomColor: COLORS.scienceBlue,
    height: "100%",
    justifyContent: "center",
    paddingHorizontal: wp(4),
  },
  tabLabelStyle: {
    textTransform: "capitalize",
    paddingTop: SIZES.width <= 360 ? 5 : 0,
    paddingBottom: -2,
    ...FONTS.title2,
    color: COLORS.scienceBlue,
  },
  emptyContainer: { alignItems: "center", justifyContent: "center" },
  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },
});
