import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  View,
  Pressable,
  Image,
  TouchableOpacity,
  UIManager,
  LayoutAnimation,
  Platform,
  BackHandler,
  Alert,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { SafeAreaView } from "react-native-safe-area-context";
import { useSelector, useDispatch } from "react-redux";
import { useFocusEffect } from "@react-navigation/native";
import Toast from "react-native-toast-message";
import moment from "moment";
import Text from "../../../Components/CustomText";
import {
  Header,
  Subheader,
  DecisionModal,
  ReasonCode,
  Footer,
  EditButton,
  Accordion,
  ToastComponent,
  EditProduct,
  ClearSelectionAlert,
  ProductDetails,
  Loader,
  ConsumeTag,
  CustomText,
} from "../../../Components";
import RecieveListItem from "./components/RecieveListItem";
import {
  getProductDetails,
  setProductLoader,
} from "../../../Redux/Action/searchAction";
import {
  getPutAwayTicket,
  wp,
  isReceiveProductFreezed,
  checkifBatchEnabled,
  checkifExpiryEnabled,
  checkRemainingQtyBool,
} from "../../../Utils/globalFunction";
import {
  Checkbox,
  DefaultProductImage,
  Unselected,
  WhiteLeftArrow,
  YellowFlag,
  Locked,
} from "../../../Utils/images";
import {
  onSelectItems,
  setSelectAll,
  handleRecieveStock,
  handleRejectStock,
  handleAvailQty,
  handleBatches,
  handleBatchDelete,
  isQualityInspected,
  selectItemsOnChange,
} from "./logic";
import {
  setUpdatedOrderList,
  setRecieveOrderDetails,
  setReceiveLimtiFlag,
  receiveStock,
  rejectStock,
  getReceiveOrderDetails,
  getReceiveHeaderKPIs,
  receiveAllOrderList,
  receiveReadyOrderList,
  receivePartialOrderList,
  receivePendingOrderList,
  getReceiveStockOrderCurrentStatus,
} from "../../../Redux/Action/receiveAction";
import {
  setReason,
  getReasonCode,
} from "../../../Redux/Action/stockCorrection";
import { SIZES } from "../../../Utils/theme";
import styles from "./styles";
import RNHTMLtoPDF from "react-native-html-to-pdf";
import ReactNativeBlobUtil from "react-native-blob-util";
import PrintBarcodeModal from "./components/PrintBarcodeModal";
import ConfirmationAlert from "../../../Components/ConfirmationPopup";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import * as storage from "../../../Service/AsyncStoreConfig";
import { ModalToastWithTwoButtons } from "../../../Components/ModalToast";
if (Platform.OS === "android") {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const ReceiveDetails = (props: any) => {
  const { itemData, selectedTab } = props.route.params;
  const dispatch = useDispatch<any>();
  const productDetailsRef = useRef<any>(null);
  const isPrintBarcode = useRef<any>(null);
  const btmSheetRef = useRef<any>();

  const [hitSave, onHitSave] = useState(false);
  const [notReceiveEnabled, setNotReceivedEnabled] = useState(true);
  const [timeString, setTimeString] = useState("h:mm:ss A");
  const [receiveEnabled, setReceiveEnabled] = useState(false);
  const [enableBtnAction, setEnableBtnAction] = useState(true);
  const [isSelectedAll, setIsSelectedAll] = useState(true);
  const [showClearAlert, setClearAlert] = useState<boolean>(false);
  const [showLoader, setShowLoader] = useState<boolean>(false);
  const [showReasonModal, setReasonModal] = useState<boolean>(false);
  const [isShowPrintBarcode, setIsShowPrintBarcode] = useState<any>(false);
  const [sampleDataState, setSampleDataState] = useState<any>([]);
  const [flag, setFlag] = useState<any>(0);
  const [barcodeData, setBarcodeData] = useState([]);
  const [receiveRespData, setReceiveRespData] = useState([]);
  const [successFilteredData, setSuccessFilteredData] = useState([]);
  const timerRef = useRef(null);
  const [selectAllViewDisable, setSelectAllViewDisable] = useState(false);
  const { confirmationAlertInfo } = useSelector(
    (state: any) => state.userReducer
  );
  const {
    orderDetails,
    receiveLimitFlag,
    isLoading,
    receiveTitle,
    deliveryNoteTxt,
  } = useSelector((state: any) => state.receiveReducer);
  const { productDetails, productDetailsLoading } = useSelector(
    (state: any) => state.searchReducer
  );
  const { reason } = useSelector((state: any) => state.stockCorrectionReducer);
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const { dateFormat, timeFormat, stockRoomDetail } = useSelector(
    (state: any) => state.userReducer
  );
  const [notes, setNotes] = useState<any>(1);
  const [isShowToasReft, setIsShowToast] = useState(false);
  const [modalData, setModalData] = useState({
    filteredOrderData: [],
    receiveStatus: "",
    orderLinesData: [],
  });
  useEffect(() => {
    const backAction = async () => {
      let asyncData;
      await storage.getItem("receiveCount").then((res) => {
        asyncData = res;
      });
      if (Number(asyncData) > 0) {
        dispatch(
          setIsShowConfirmationAlert({
            isShow: true,
            data: confirmationAlertInfo?.data,
          })
        );
      } else {
        props.navigation.goBack();
      }
      return true;
    };

    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );

    return () => backHandler.remove();
  }, []);

  useEffect(() => {
    setNotes(() => deliveryNoteTxt);
  }, [deliveryNoteTxt]);

  useFocusEffect(
    useCallback(() => {
      dispatch(
        getReasonCode(
          { codeType: "receive.stock" },
          stockRoomDetail?.stockroomType
        )
      );

      return async () => {
        await dispatch(setReceiveLimtiFlag(0));
        await dispatch(
          setReason({
            code: "",
            id: 0,
          })
        );
      };
    }, [])
  );

  useEffect(() => {
    preData();

    let result: any = {};
    let ARRR: any = [];
    orderDetails?.deliveryList &&
      orderDetails?.deliveryList.map((item: any, i: number) => {
        if (item?.remainingQuanityStr.includes("X")) {
          let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
          if (qtyArr[0] == 0) {
            ARRR.push(item);
          }
        }
      });

    ARRR &&
      ARRR.forEach(function (item: any) {
        if (result[item.deliveryNoteNo]) {
          result[item.deliveryNoteNo].push(item);
        } else {
          result[item.deliveryNoteNo] = [item];
        }
      });

    let blockData = [];

    for (let key in result) {
      blockData.push({
        deliveryNote: key,
        result: result[key],
      });
    }
  }, [orderDetails?.deliveryList]);

  useEffect(() => {
    if (timeFormat.toUpperCase() == "24Hours".toUpperCase())
      setTimeString("H:mm:ss");
    else setTimeString("h:mm:ss A");
  }, []);

  useEffect(() => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
  }, [isSelectedAll]);

  useEffect(() => {
    if (receiveLimitFlag > 0) {
      showToast(
        strings["ime.scanner.error.occured.msg"],
        strings["alert.about.receive.more.than.remaining.qty"]
      );
      dispatch(setReceiveLimtiFlag(0));
      clearTimeout(timerRef.current);
    }
  }, [receiveLimitFlag]);

  const getMappedQty = (item: any) => {
    if (item?.remainingQuanityStr.includes("X")) {
      let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
      return qtyArr[0];
    } else {
      return `${item?.remainingQuanityStr}`;
    }
  };

  const preData = async () => {
    let sampleDataSetArr: any = [];

    orderDetails?.deliveryList &&
      orderDetails?.deliveryList?.map((item: any) => {
        let dataSet = {
          id: item?.stockReceiptDetails?.id,
          batchNo: item?.stockReceiptDetails?.batchNo,
          qty: getMappedQty(item),
          expiryDate: item?.stockReceiptDetails?.expiryDate, //Issue in delivery note expiry date show.
          //expiryDate: item?.stockReceiptDetails?.expiryDtFormat,
          // expiryDate: item?.expiryDtFormat,
        };
        sampleDataSetArr.push(dataSet);
      });
    await setSampleDataState(sampleDataSetArr);
  };

  const showToast = async (text1: string, text2: string) => {
    Toast.show({
      type: "alertToast",
      text1: text1,
      text2: text2,
      position: "bottom",
      bottomOffset: SIZES.padding * 2,
      onHide: async () => {
        if (text1 == "Stock Rejected") {
          await receiveCallback();
          props.navigation.goBack();
        }
        await clearTimeout(timerRef.current);
      },
    });
  };
  useEffect(() => {
    if (modalData.filteredOrderData?.length) {
      setIsShowToast(true);
      setTimeout(() => {
        setIsShowToast(false);
      }, 8000);
    }
  }, [modalData]);
  const successToast = (
    filteredOrderData: any,
    orderLinesData: any,
    receiveStatus: string
  ) => {
    setModalData({
      filteredOrderData: filteredOrderData,
      receiveStatus: receiveStatus,
      orderLinesData: orderLinesData,
    });
    // Toast.show({
    //   type: "alertBottomToast",
    //   text1: strings["ime.stock.received"],
    //   text2: strings["ime.selected.products.have.been.received.successfully"],
    //   props: {
    //     putAwayText: "Put-Away Ticket",
    //     printBarcodeText: strings["im.print.barcodes"],
    //     onPressLeft: () =>
    //       onPressSaveRecipt(orderDetails, filteredOrderData, receiveStatus),
    //     onPressRight: async () => {
    //       await clearTimeout(timerRef.current);
    //       onHitSave(true);
    //       Toast.hide();
    //       setSuccessFilteredData(filteredOrderData);
    //       await setBarcodeData(orderLinesData);
    //       clickOnPrintBarcode();
    //     },
    //     goback: () => props.navigation.goBack(),
    //   },
    //   onHide: async () => {
    //     await clearTimeout(timerRef.current);
    //   },
    //   position: "bottom",
    //   autoHide: false,
    // });
  };

  const availQty = async (
    val: any,
    id: any,
    isDeliveryNote: boolean,
    deliveryNote?: string
  ) => {
    if (!isDeliveryNote) {
      await orderDetails.allOrderDetails.map((item: any) => {
        if (item.id == id) {
          return (item["newSelectedQty"] = val);
        }
      });
    } else {
      await orderDetails.deliveryList.map((item: any) => {
        if (item.id == id && item.deliveryNoteNo == deliveryNote) {
          return (item["newSelectedQty"] = val);
        }
      });
    }

    handleAvailQty(
      val,
      id,
      orderDetails,
      setRecieveOrderDetails,
      dispatch,
      isDeliveryNote
    );
  };

  const batchUpdates = async (
    batches: any,
    batchId: string,
    itemId: string,
    isDel: boolean, // Checks whether delivery note exists or not
    deliveryNoteNo?: string
  ) => {
    handleBatches(
      batches,
      batchId,
      itemId,
      orderDetails,
      setRecieveOrderDetails,
      dispatch,
      isDel,
      deliveryNoteNo
    );
  };

  const batchDelete = async (item: any, val: any, productItem: any) => {
    handleBatchDelete(
      item,
      val,
      orderDetails,
      setRecieveOrderDetails,
      dispatch,
      productItem
    );
  };

  const renderLeftIcon = (item: any) => {
    return (
      <View style={styles.leftIconContainer}>
        {item?.product?.imageURL ? (
          <Image
            source={{
              uri: item?.product?.imageURL.replace("http://", "https://"),
            }}
            style={styles.leftIcon}
            resizeMode={"contain"}
          />
        ) : (
          <DefaultProductImage width={wp(18)} height={wp(18)} />
        )}
      </View>
    );
  };

  const renderHeaderContent = (item: any) => (
    <>
      <Text style={styles.catalogNumber}>{item?.product?.catalogNo}</Text>
      <TouchableOpacity
        onPress={async () => {
          productDetailsRef.current.open();
          await dispatch(getProductDetails(item?.product?.id));
          await dispatch(setProductLoader(false));
        }}
      >
        <Text style={styles.catalogTitle}>{item?.product?.description}</Text>
      </TouchableOpacity>
      {/* {receiveEnabled ? null : isQualityInspected(item) ? <YellowFlag /> : null} */}
      {isQualityInspected(item) && <YellowFlag />}
      {item?.product?.uomManagementEnabled == 1 &&
        item?.product?.vendorUOMUnit && (
          <View style={styles.quantityInfoContainer}>
            <Text style={styles.quantityInfoText}>
              ({item?.product?.vendorUOMUnit})
            </Text>
          </View>
        )}
      {(checkifBatchEnabled(item, stockRoomDetail) ||
        checkifExpiryEnabled(item, stockRoomDetail)) && (
        <View
          accessible={true}
          accessibilityLabel="tag_container"
          style={styles.tagContainer}
        >
          {checkifBatchEnabled(item, stockRoomDetail) && (
            <ConsumeTag tag={strings["ime.batch.controlled"]} />
          )}
          {checkifExpiryEnabled(item, stockRoomDetail) && (
            <ConsumeTag tag={strings["ime.expiry.date.controlled"]} />
          )}
        </View>
      )}
    </>
  );

  const renderRightIcon = (item: any, index: number, notReceivedData?: any) => {
    return (
      <>
        {isReceiveProductFreezed(item?.product) || isQualityInspected(item) ? (
          <Locked />
        ) : item?.selected &&
          item.isCheckBoxDisabled == false &&
          item?.isPouApproved ? (
          <Pressable
            style={styles.checkboxSelection}
            onPress={() => {
              onSelectItems(
                orderDetails,
                index,
                setEnableBtnAction,
                setIsSelectedAll,
                setUpdatedOrderList,
                dispatch,
                item.keyId,
                item.id,
                item?.deliveryNoteNo,
                notReceivedData
              );
              setFlag(flag + 1);
            }}
          >
            <Checkbox />
          </Pressable>
        ) : (
          <Pressable
            style={styles.checkboxSelection}
            onPress={() => {
              item.isPouApproved &&
                onSelectItems(
                  orderDetails,
                  index,
                  setEnableBtnAction,
                  setIsSelectedAll,
                  setUpdatedOrderList,
                  dispatch,
                  item.keyId,
                  item.id,
                  item?.deliveryNoteNo,
                  notReceivedData
                );
            }}
          >
            <Unselected opacity={!item?.isPouApproved ? 0.5 : 1} />
          </Pressable>
        )}
      </>
    );
  };

  const renderChildComponent = (
    isReceived: boolean,
    ARRR_received: any,
    ARRR: any,
    showBatch: any,
    isDel: boolean,
    deliveryNoteNo?: string,
    userDeliveryNoteAvailable?: boolean
  ) => {
    return (isReceived ? ARRR_received : ARRR)?.map(
      (item: any, index: number) => {
        return (
          <RecieveListItem
            key={`${index} ${item?.product?.id}`}
            item={item}
            freeze={
              isReceiveProductFreezed(item?.product) || isQualityInspected(item)
            }
            containerStyle={{ marginHorizontal: 0 }}
            showBatch={
              (checkifBatchEnabled(item, stockRoomDetail) ||
                checkifExpiryEnabled(item, stockRoomDetail)) &&
              showBatch
            }
            leftIcon={renderLeftIcon(item)}
            rightIcon={notReceiveEnabled && renderRightIcon(item, index, ARRR)}
            headerContent={renderHeaderContent(item)}
            handleAvailQty={(val: any, id: any) => availQty(val, id, isDel)}
            handleBatch={(data: any, batchId: string, itemId: string) => {
              batchUpdates(data, batchId, itemId, isDel, deliveryNoteNo);
            }}
            handleBatchDelete={batchDelete}
            disabledList={item?.isCheckBoxDisabled}
            receiveTab={receiveEnabled}
            isDeliveryNoteAvailable={isDel ? isDel : false}
            sampleDataState={sampleDataState}
            setDeliveryDataCallback={async (data: any) => {
              setSampleDataState(data);
              setFlag(flag + 1);
            }}
            userDeliveryNoteAvailable={userDeliveryNoteAvailable}
            onSelectItemCall={(val?: any) =>
              selectItemsOnChange(
                orderDetails,
                index,
                setEnableBtnAction,
                setIsSelectedAll,
                setUpdatedOrderList,
                dispatch,
                item.keyId,
                item.id,
                item?.deliveryNoteNo,
                ARRR,
                val
              )
            }
          />
        );
      }
    );
  };

  const isFreez = useCallback((isReceived: boolean) => {
    let data = getFilteredArray(isReceived);
    //check for non freezed and QOI products
    const filteredArr = data.filter(
      (obj: any) =>
        obj?.product?.freeze == false && isQualityInspected(obj) == false
    );

    if (filteredArr?.length > 0) {
      if (data?.length == filteredArr?.length) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }, []);

  const renderRecieveStock = (
    data: any,
    showBatch: boolean,
    isReceived: boolean
  ) => {
    let ARRR: any = [];
    let ARRR_received: any = [];

    data?.allOrderDetails &&
      data?.allOrderDetails.map((item: any, index: number) => {
        let mappedItem = { ...item, keyId: `${item.id}_${index}` };
        if (mappedItem?.remainingQuanityStr.includes("X")) {
          let qtyArr = mappedItem?.remainingQuanityStr
            .replace(/\s+/g, "")
            .split("X");

          if (Number(qtyArr[0]) == 0) {
            ARRR_received.push(mappedItem);
          } else {
            ARRR.push(mappedItem);
          }
        } else {
          if (Number(mappedItem?.remainingQuanityStr) == 0) {
            ARRR_received.push(mappedItem);
          } else {
            ARRR.push(mappedItem);
          }
        }
      });

    return (
      <>
        {data?.userDeliveryNotes && isReceived ? (
          <Accordion
            title={data?.userDeliveryNotes?.deliveryNote ?? ""}
            isShowCheckbox={false}
            children={renderChildComponent(
              isReceived,
              ARRR_received,
              ARRR,
              showBatch,
              data?.userDeliveryNotes?.deliveryNote ? false : true,
              data?.userDeliveryNotes?.deliveryNote,
              true
            )}
            onPressCheckbox={() =>
              setSelectAll(
                orderDetails,
                isSelectedAll,
                setEnableBtnAction,
                setIsSelectedAll
              )
            }
            isSelectedAll={isSelectedAll}
          />
        ) : (
          renderChildComponent(
            isReceived,
            ARRR_received,
            ARRR,
            showBatch,
            false,
            "",
            false
          )
        )}
      </>
    );
  };

  const renderRecieveItem = (
    data: any,
    showBatch: boolean,
    index: number,
    isDel: boolean,
    deliveryNote?: string,
    userDeliveryNoteAvailable?: boolean
  ) => {
    return (
      data &&
      data.map((item: any, i: number) => {
        return (
          <RecieveListItem
            key={`${i} - ${deliveryNote ?? ""}`}
            item={item}
            freeze={isReceiveProductFreezed(item?.product)}
            containerStyle={{ marginHorizontal: 0 }}
            showBatch={
              !receiveEnabled &&
              (checkifBatchEnabled(item, stockRoomDetail) ||
                checkifExpiryEnabled(item, stockRoomDetail)) &&
              showBatch
            }
            leftIcon={renderLeftIcon(item)}
            rightIcon={!receiveEnabled && renderRightIcon(item, index, data)}
            headerContent={renderHeaderContent(item)}
            handleAvailQty={(val: any, id: any) =>
              availQty(val, id, isDel, deliveryNote)
            }
            handleBatch={(data: any, batchId: string, itemId: string) => {
              batchUpdates(data, batchId, itemId, isDel, deliveryNote);
            }}
            handleBatchDelete={batchDelete}
            disabledList={item?.isCheckBoxDisabled}
            receiveTab={receiveEnabled}
            isDeliveryNoteAvailable={isDel ? isDel : false}
            sampleDataState={sampleDataState}
            setDeliveryDataCallback={async (data: any) => {
              setSampleDataState(data);
              setFlag(flag + 1);
            }}
            userDeliveryNoteAvailable={userDeliveryNoteAvailable}
            onSelectItemCall={(val?: any) =>
              selectItemsOnChange(
                orderDetails,
                index,
                setEnableBtnAction,
                setIsSelectedAll,
                setUpdatedOrderList,
                dispatch,
                item.keyId,
                item.id,
                item?.deliveryNoteNo,
                data,
                val
              )
            }
          />
        );
      })
    );
  };

  const onPressSaveRecipt = async (
    data: any,
    filteredOrderData: any,
    receiveStatus: string
  ) => {
    onHitSave(true);

    const pdfOptions = {
      html: getPutAwayTicket(
        receiveStatus,
        data,
        itemData,
        moment(itemData?.createdDate).format(
          `${dateFormat?.date}, ${timeString}`
        ),
        moment(itemData?.receivedDate).format(
          `${dateFormat?.date}, ${timeString}`
        ),
        filteredOrderData,
        dateFormat
      ),
      fileName: `pdf_${data?.internalPurOrderNo}`,
      directory: "Documents",
    };
    const file = await RNHTMLtoPDF.convert(pdfOptions);
    if (file?.filePath) {
      if (Platform.OS === "android") {
        ReactNativeBlobUtil.android.actionViewIntent(
          file?.filePath,
          "application/pdf"
        );
      } else {
        ReactNativeBlobUtil.ios.previewDocument(file?.filePath);
      }
    }
  };

  const clickOnPrintBarcode = async () => {
    setIsShowPrintBarcode(true);
  };

  const checkAllOrders = (i) => {
    let filteredData = orderDetails?.allOrderDetails.filter((item: any) => {
      if (checkRemainingQtyBool(item)) return item;
    });

    if (filteredData?.length == 0 && i == 0) {
      return true;
    } else {
      return false;
    }
  };

  const dataMapping = (data: any, isReceived: boolean, orderDetails?: any) => {
    let result: any = {};
    let ARRR: any = [];
    let ARRR_received: any = []; // another remaining data of receive tab

    data &&
      data.map((item: any, index: number) => {
        let mappedItem = { ...item, keyId: `${item.id}_${index}_dev` };

        if (mappedItem?.remainingQuanityStr.includes("X")) {
          let qtyArr = mappedItem?.remainingQuanityStr
            .replace(/\s+/g, "")
            .split("X");

          if (Number(qtyArr[0]) == 0) {
            ARRR_received.push(mappedItem);
          } else {
            ARRR.push(mappedItem);
          }
        } else {
          if (Number(mappedItem?.remainingQuanityStr) == 0) {
            ARRR_received.push(mappedItem);
          } else {
            ARRR.push(mappedItem);
          }
        }
      });

    {
      !isReceived
        ? ARRR.forEach(function (item: any) {
            if (result[item?.deliveryNoteNo]) {
              result[item?.deliveryNoteNo].push(item);
            } else {
              result[item?.deliveryNoteNo] = [item];
            }
          })
        : ARRR_received.forEach(function (item: any) {
            if (result[item?.deliveryNoteNo]) {
              result[item?.deliveryNoteNo].push(item);
            } else {
              result[item?.deliveryNoteNo] = [item];
            }
          });
    }

    let blockData = [];

    for (let key in result) {
      blockData.push({
        deliveryNote: key,
        result: result[key],
      });
    }

    return (
      blockData &&
      blockData.map((v: any, i: number) => {
        return (
          <Accordion
            title={v["deliveryNote"]}
            isShowCheckbox={
              !receiveEnabled &&
              // orderDetails?.allOrderDetails?.length == 0
              //   ? true
              // :
              checkAllOrders(i)
            }
            children={renderRecieveItem(
              v["result"],
              true,
              i,
              true,
              v["deliveryNote"],
              false
            )}
            onPressCheckbox={() =>
              setSelectAll(
                orderDetails,
                isSelectedAll,
                setEnableBtnAction,
                setIsSelectedAll
              )
            }
            isSelectedAll={isSelectedAll}
          />
        );
      })
    );
  };
  const getCount = () => {
    let data_allOrderDetails =
      orderDetails?.allOrderDetails &&
      orderDetails?.allOrderDetails.filter((obj: any) => {
        if (obj?.remainingQuanityStr.includes("X")) {
          let qtyArr = obj?.remainingQuanityStr.replace(/\s+/g, "").split("X");
          if (
            Number(qtyArr[0]) != 0 &&
            obj.selected == true &&
            obj?.product?.freeze == false &&
            obj.selected == true &&
            isReceiveProductFreezed(obj?.product) == false
          ) {
            return isQualityInspected(obj) == false;
          } else {
            return false;
          }
        } else {
          if (
            Number(obj?.remainingQuanityStr) != 0 &&
            obj.selected == true &&
            obj?.product?.freeze == false &&
            obj.selected == true &&
            isReceiveProductFreezed(obj?.product) == false
          ) {
            return isQualityInspected(obj) === false;
          } else {
            return false;
          }
        }
      });

    let data_deliveryList =
      orderDetails?.deliveryList &&
      orderDetails?.deliveryList.filter((obj: any) => {
        if (obj?.remainingQuanityStr.includes("X")) {
          let qtyArr = obj?.remainingQuanityStr.replace(/\s+/g, "").split("X");
          if (
            Number(qtyArr[0]) != 0 &&
            obj.selected == true &&
            obj?.product?.freeze == false &&
            obj.selected == true &&
            isReceiveProductFreezed(obj?.product) == false
          ) {
            return isQualityInspected(obj) == false;
          } else {
            return false;
          }
        } else {
          if (
            Number(obj?.remainingQuanityStr) != 0 &&
            obj.selected == true &&
            obj?.product?.freeze == false &&
            obj.selected == true &&
            isReceiveProductFreezed(obj?.product) == false
          ) {
            return isQualityInspected(obj) === false;
          } else {
            return false;
          }
        }
      });
    let count = data_allOrderDetails?.length + data_deliveryList?.length ?? "0";
    storage.setItem("receiveCount", JSON.stringify(count));
    let val = count == null ? "0" : count;
    return val;
  };

  const receiveCallback = async (resData?: any) => {
    setReceiveRespData(resData);
    dispatch(getReceiveHeaderKPIs());
    await dispatch(
      getReceiveOrderDetails(itemData, () => {
        setNotReceivedEnabled(true);
      })
    );
  };

  const rejectCallback = async () => {
    await dispatch(getReceiveHeaderKPIs());

    switch (selectedTab) {
      case 1:
        await dispatch(receiveAllOrderList(0));
        break;

      case 2:
        await dispatch(receiveReadyOrderList(0));
        break;

      case 3:
        await dispatch(receivePartialOrderList(0));
        break;

      case 4:
        await dispatch(receivePendingOrderList(0));
        break;

      default:
        break;
    }
  };

  const getTabCount = (isReceived: boolean) => {
    let result: any = {};
    let ARRR: any = [];
    let ARRR_received: any = [];

    orderDetails?.deliveryList &&
      orderDetails.deliveryList.map((item: any, i: number) => {
        if (item?.remainingQuanityStr.includes("X")) {
          let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
          if (Number(qtyArr[0]) == 0) {
            ARRR_received.push(item);
          } else {
            ARRR.push(item);
          }
        } else {
          if (Number(item?.remainingQuanityStr) == 0) {
            ARRR_received.push(item);
          } else {
            ARRR.push(item);
          }
        }
      });
    {
      !isReceived
        ? ARRR.forEach(function (item: any) {
            if (result[item.deliveryNoteNo]) {
              result[item.deliveryNoteNo].push(item);
            } else {
              result[item.deliveryNoteNo] = [item];
            }
          })
        : ARRR_received.forEach(function (item: any) {
            if (result[item.deliveryNoteNo]) {
              result[item.deliveryNoteNo].push(item);
            } else {
              result[item.deliveryNoteNo] = [item];
            }
          });
    }

    let blockData = [];

    for (let key in result) {
      blockData.push({
        deliveryNote: key,
        result: result[key],
      });
    }

    orderDetails?.allOrderDetails &&
      orderDetails?.allOrderDetails.map((item: any, i: number) => {
        if (item?.remainingQuanityStr.includes("X")) {
          let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");

          if (Number(qtyArr[0]) == 0) {
            ARRR_received.push(item);
          } else {
            blockData.push(item);
          }
        } else {
          if (Number(item?.remainingQuanityStr) == 0) {
            ARRR_received.push(item);
          } else {
            blockData.push(item);
          }
        }
      });
    return isReceived ? ARRR_received?.length : blockData?.length;
  };

  const getFilteredArray = (isReceived: boolean) => {
    let result: any = {};
    let ARRR: any = [];
    let ARRR_received: any = [];

    orderDetails?.deliveryList &&
      orderDetails.deliveryList.map((item: any, i: number) => {
        if (item?.remainingQuanityStr.includes("X")) {
          let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
          if (Number(qtyArr[0]) == 0) {
            ARRR_received.push(item);
          } else {
            ARRR.push(item);
          }
        } else {
          if (Number(item?.remainingQuanityStr) == 0) {
            ARRR_received.push(item);
          } else {
            ARRR.push(item);
          }
        }
      });
    {
      !isReceived
        ? ARRR.forEach(function (item: any) {
            if (result[item.deliveryNoteNo]) {
              result[item.deliveryNoteNo].push(item);
            } else {
              result[item.deliveryNoteNo] = [item];
            }
          })
        : ARRR_received.forEach(function (item: any) {
            if (result[item.deliveryNoteNo]) {
              result[item.deliveryNoteNo].push(item);
            } else {
              result[item.deliveryNoteNo] = [item];
            }
          });
    }

    let blockData = [];

    for (let key in result) {
      blockData.push({
        deliveryNote: key,
        result: result[key],
      });
    }

    orderDetails?.allOrderDetails &&
      orderDetails?.allOrderDetails.map((item: any, i: number) => {
        if (item?.remainingQuanityStr.includes("X")) {
          let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");

          if (Number(qtyArr[0]) == 0) {
            ARRR_received.push(item);
          } else {
            blockData.push(item);
          }
        } else {
          if (Number(item?.remainingQuanityStr) == 0) {
            ARRR_received.push(item);
          } else {
            blockData.push(item);
          }
        }
      });

    return isReceived ? ARRR_received : blockData;
  };

  const headerBackClicked = async () => {
    let count = await getCount();
    if (count > 0) {
      dispatch(
        setIsShowConfirmationAlert({
          isShow: true,
          data: confirmationAlertInfo?.data,
        })
      );
    } else {
      props.navigation.goBack();
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={["left", "right", "bottom"]}>
      <Header
        title={
          receiveTitle.length > 30
            ? receiveTitle.slice(0, 27) + "..."
            : receiveTitle
        }
        LeftIcon={() => <WhiteLeftArrow />}
        onLeftIconPress={() => headerBackClicked()}
        statusBar={true}
        statusBarColor={"blue"}
        iconLeft={true}
        iconRight={true}
      />

      <Subheader />
      <KeyboardAwareScrollView
        accessible={true}
        accessibilityLabel="receive-list"
        contentContainerStyle={styles.contentContainerStyle}
        scrollEnabled={true}
        showsVerticalScrollIndicator={false}
        keyboardDismissMode="interactive"
        alwaysBounceVertical={false}
        keyboardShouldPersistTaps={"always"}
      >
        <View style={[styles.flexRowContainer, styles.headerSpacer]}>
          <View style={styles.titleDateContainer}>
            <Text
              style={styles.mainTitle}
              accessible={true}
              accessibilityLabel="receive-title"
              numberOfLines={1}
            >
              {receiveTitle}
            </Text>
            {deliveryNoteTxt.length > 0 && (
              <Text
                style={styles.dateTime}
                accessible={true}
                accessibilityLabel="receive-deliveryNote"
                numberOfLines={1}
              >
                {deliveryNoteTxt}
              </Text>
            )}
            <Text
              style={styles.dateTime}
              accessible={true}
              accessibilityLabel="receive-date"
            >
              {moment(itemData?.createdDate).format(
                `${dateFormat?.date}, ${timeString}`
              )}
            </Text>
          </View>

          <View style={styles.editContainer}>
            <EditButton
              title={strings["edit"]}
              onChangeBtnPress={() => btmSheetRef?.current?.open()}
            />
          </View>
        </View>

        <View
          style={styles.tabsContainer}
          accessibilityLabel="receive-details-toptabBar"
        >
          <TouchableOpacity
            accessibilityLabel="receive-details-toptab1-BarButton"
            style={[
              styles.tabBtnContainer,
              notReceiveEnabled && styles.activeBtnContainer,
            ]}
            onPress={() => {
              setNotReceivedEnabled(true);
              setReceiveEnabled(false);
            }}
          >
            <Text
              accessibilityLabel="receive-details-toptab1-BarText"
              style={[
                styles.tabText,
                notReceiveEnabled && styles.activeTabText,
              ]}
            >
              {`${getTabCount(false) ?? 0} ${strings["not.received"]}`}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            accessibilityLabel="receive-details-toptab2-BarButton"
            style={[
              styles.tabBtnContainer,
              receiveEnabled && styles.activeBtnContainer,
            ]}
            onPress={() => {
              setReceiveEnabled(true);
              setNotReceivedEnabled(false);
            }}
          >
            <Text
              accessibilityLabel="receive-details-toptab2-Bar-text"
              style={[styles.tabText, receiveEnabled && styles.activeTabText]}
            >
              {`${getTabCount(true) ?? 0} ${strings["received"]}`}
            </Text>
          </TouchableOpacity>
        </View>

        {orderDetails?.allOrderDetails?.length > 0 &&
          getTabCount(false) > 0 &&
          !isFreez(false) &&
          notReceiveEnabled && (
            <TouchableOpacity
              accessible={true}
              accessibilityLabel="accordion_select_button"
              style={styles.flexRowContainer}
              disabled={false}
              onPress={() =>
                setSelectAll(
                  orderDetails,
                  isSelectedAll,
                  setEnableBtnAction,
                  setIsSelectedAll
                )
              }
            >
              <CustomText
                accessible={true}
                accessibilityLabel="accordion_select_button_title"
                style={styles.selectAll}
              >
                {isSelectedAll
                  ? strings["ime.scanner.deselect.all"] ?? "Deselect All"
                  : strings["ime.select.all"] ?? "Select All"}
              </CustomText>
              {isSelectedAll ? <Checkbox /> : <Unselected />}
            </TouchableOpacity>
          )}

        {notReceiveEnabled && (
          <View>{renderRecieveStock(orderDetails, true, false)}</View>
        )}

        {notReceiveEnabled &&
          orderDetails?.deliveryList &&
          dataMapping(orderDetails.deliveryList, false, orderDetails)}

        {receiveEnabled && dataMapping(orderDetails.deliveryList, true)}
        {receiveEnabled && renderRecieveStock(orderDetails, false, true)}
      </KeyboardAwareScrollView>

      {notReceiveEnabled && (
        <Footer
          count={getCount()}
          mainbuttonTitle={strings["receive"]}
          secondaryButtonTitle={strings["reject"]}
          tertiaryButtonTitle={strings["ime.scanner.clear"] ?? "Clear"}
          tertiaryryButtonDisabled={!orderDetails?.allOrderDetails?.length}
          mainContainerStyle={styles.footerMainContainer}
          mainButtonStyle={styles.footerBtnContainer}
          mainButtonDisabled={Number(getCount()) > 0 ? !enableBtnAction : true}
          secondaryButtonDisabled={
            Number(getCount()) > 0 ? !enableBtnAction : true
          }
          outlinedBtnContainerStyle={styles.footerBtnContainer}
          tertiaryBtnContainerStyle={styles.tertiaryBtnContainer}
          onChangeSecondaryBtnPress={() => {
            setReasonModal(true);
          }}
          onChangePrimaryBtnPress={() => {
            handleRecieveStock(
              itemData.id,
              orderDetails,
              showToast,
              successToast,
              dispatch,
              receiveStock,
              receiveCallback,
              strings,
              sampleDataState,
              stockRoomDetail
            );

            if (hitSave == false) {
              timerRef.current = setTimeout(() => {
                Toast.hide();
                props.navigation.goBack();
              }, 8000);
            }
          }}
          onChangeTertiaryBtnPress={() => setClearAlert(true)}
        />
      )}
      <ClearSelectionAlert
        isShow={showClearAlert}
        didCloseModal={() => {
          setClearAlert(false);
        }}
        outlinedButtonTitle={"Cancel"}
        mainButtonTitle={strings["ime.scanner.Clear.Order"]}
        didMainButtonTitleClicked={() => {
          setClearAlert(false);
          props.navigation.navigate("Dashboard");
        }}
        didOutlinedButtonClicked={() => setClearAlert(false)}
        orderTitle={strings["ime.scanner.Clear.this.order"]}
        orderDesc={
          strings["ime.scanner.All.products.in.this.order.will.be.removed."]
        }
      />

      <DecisionModal
        show={showReasonModal}
        title={`Select ${strings["reason.code"]}`}
        secondaryBtnText={strings["no"]}
        primaryBtnText={strings["yes"]}
        primaryDisabled={reason?.id == 0}
        onSecondaryPress={async () => {
          await dispatch(
            setReason({
              code: "",
              id: 0,
            })
          );
          setReasonModal(false);
        }}
        onPrimaryPress={() => {
          handleRejectStock(
            orderDetails,
            showToast,
            dispatch,
            rejectStock,
            reason,
            rejectCallback,
            strings,
            sampleDataState,
            stockRoomDetail
          );

          setTimeout(() => {
            Toast.hide();
            props.navigation.goBack();
          }, 5000);

          setReasonModal(false);
        }}
        btnWrapper={{ justifyContent: "flex-end" }}
        titleText={{ textAlign: "left" }}
      >
        <ReasonCode
          containerStyle={{
            marginVertical: SIZES.radius * 1.25,
          }}
          required={true}
          reasonCodeType="receive.stock"
          from="masterCode"
          reason={reason}
          showToast={showToast}
          setReason={async (val: any) => await dispatch(setReason(val))}
        />
      </DecisionModal>
      {/* Prodtuct Detail */}
      <ProductDetails
        itemDetailsRef={productDetailsRef}
        productDetailsList={productDetails}
      />
      {isShowPrintBarcode && (
        <PrintBarcodeModal
          isShow={isShowPrintBarcode}
          ref={isPrintBarcode}
          didCloseModal={() => setIsShowPrintBarcode(false)}
          data={barcodeData}
          receiveData={receiveRespData}
          filteredData={successFilteredData}
          goBack={() => props.navigation.goBack()}
        />
      )}
      <Loader show={productDetailsLoading || isLoading || showLoader} />
      <ConfirmationAlert
        onTapNo={() => {}}
        onTapYes={() => {
          storage.removeData("receiveCount");
          dispatch(
            setIsShowConfirmationAlert({
              isShow: false,
              data: confirmationAlertInfo?.data,
            })
          );
          props.navigation.goBack();
        }}
        onBack={() => {}}
      />
      <EditProduct
        btmSheetRef={btmSheetRef}
        onClose={() => btmSheetRef?.current?.close()}
        orderDetails={orderDetails}
        title={receiveTitle}
        deliveryNote={notes ?? ""}
        setNotes={(res: any) => setNotes(() => res)}
        onSuccesfullyAddedNotes={() => {
          //btmSheetRef?.current?.close()
          let timeout = 300;
          setShowLoader(true);
          setTimeout(() => {
            setShowLoader(false);
            props.navigation.goBack();
          }, timeout);
        }}
        itemID={itemData?.id ?? ""}
      />
      {/* <View style={styles.toastContainer}> */}
      <ToastComponent />
      {/* </View>  */}
      {/* Toast */}
      <ModalToastWithTwoButtons
        isShow={isShowToasReft}
        onClose={() => {
          setIsShowToast(false);
          setModalData({
            filteredOrderData: [],
            receiveStatus: "",
            orderLinesData: [],
          });
        }}
        title={strings["ime.stock.received"]}
        description={
          strings["ime.selected.products.have.been.received.successfully"] ??
          "SD"
        }
        onPressLeft={() =>
          onPressSaveRecipt(
            orderDetails,
            modalData.filteredOrderData,
            modalData.receiveStatus
          )
        }
        onPressRight={async () => {
          await clearTimeout(timerRef?.current);
          onHitSave(true);
          Toast.hide();
          setSuccessFilteredData(modalData.filteredOrderData);
          await setBarcodeData(modalData.orderLinesData);
          clickOnPrintBarcode();
        }}
      />
    </SafeAreaView>
  );
};

export default ReceiveDetails;
