import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

export default StyleSheet.create({
  container: {
    paddingTop: SIZES.padding,
    paddingBottom: SIZES.radius,
    borderBottomColor: COLORS.gray2,
    marginHorizontal: SIZES.padding,
  },

  flexRowContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  headerSpacer: {
    marginTop: hp(2),
  },

  spacer: {
    marginVertical: hp(1.2),
  },

  itemChildContainer: {
    width: wp(45),
    margin: wp(0.3),
    paddingVertical: hp(0.8),
  },

  itemTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },

  qtyTitles: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_regular,
    textAlign: "center",
  },

  qtyInputStyle: {
    width: wp(10),
    height: wp(10),
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_regular,
    textAlign: "center",
  },

  qtyValues: {
    marginTop: SIZES.padding,
  },

  font16: {
    fontSize: FONTS.h2_1,
  },

  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingTop: SIZES.tip,
  },

  inputMain: {
    width: "30%",
    alignSelf: "flex-start",
  },

  input: {
    height: hp(4),
    fontSize: FONTS.h1_5,
    padding: 0,
    color: COLORS.abbey,
  },

  qtyTitle: {
    color: COLORS.abbey,
    textAlign: "center",
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  qty: {
    width: wp(10),
    height: hp(4),
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_regular,
    textAlign: "center",
    padding: 0,
  },
});
