import React, { useRef, useState } from "react";
import {
  View,
  Modal,
  TouchableOpacity,
  Pressable,
  Platform,
} from "react-native";
import RNFetchBlob from "react-native-blob-util";
import { useDispatch, useSelector } from "react-redux";
import { receivePrintBarcode } from "../../../../Redux/Action/receiveAction";
import { COLORS } from "../../../../Utils/theme";
import {
  checkStoragePermission,
  hp,
  wp,
} from "../../../../Utils/globalFunction";
import {
  BottomSheetComponent,
  CustomText,
  TextInputComponent,
} from "../../../../Components";
import { ArrowDown, TickIcon } from "../../../../Utils/images";
import styles from "./modalStyle";

type AlertBoxProps = {
  isShow: boolean;
  didCloseModal: () => void;
  ref?: any;
  data?: any;
  receiveData?: any;
  filteredData?: any;
  goBack?: any;
};

const PrintBarcodeModal: React.FC<AlertBoxProps> = (props) => {
  const dispatch = useDispatch<any>();
  const { isShow, ref, didCloseModal, receiveData, filteredData } = props;

  const pdfFormat = [
    {
      id: 0,
      title: "Avery 5161 2 Columns 10 Rows",
      key: "AVERY_5161_2_COLUMNS_10_ROWS",
    },
    {
      id: 1,
      title: "Avery 7162 2 Columns 8 Rows",
      key: "AVERY_7162_2_COLUMNS_8_ROWS",
    },
    {
      id: 2,
      title: "A4 Size",
      key: "AVERY_A4_1_COLUMNS_1_ROWS",
    },
  ];

  const pdfPrintFormat = [
    {
      id: 0,
      title: "1st Row",
      key: "1ST_ROW",
    },
    {
      id: 1,
      title: "2nd Row",
      key: "2ND_ROW",
    },
    {
      id: 2,
      title: "3rd Row",
      key: "3RD_ROW",
    },
    {
      id: 3,
      title: "4th Row",
      key: "4TH_ROW",
    },
    {
      id: 4,
      title: "5th Row",
      key: "5TH_ROW",
    },
    {
      id: 5,
      title: "6th Row",
      key: "6TH_ROW",
    },
    {
      id: 6,
      title: "7th Row",
      key: "7TH_ROW",
    },
    {
      id: 7,
      title: "8th Row",
      key: "8TH_ROW",
    },
  ];

  const strings = useSelector((state: any) => state.languageReducer?.data);
  const btmSheetRef = useRef<any>();
  const printFormRef = useRef<any>();

  const [barcodeType, setBarcodeType] = useState<any>(0);

  const [selectedKey, setSelectedCKey] = useState<any>(
    "AVERY_5161_2_COLUMNS_10_ROWS"
  );
  const [selectdFormat, setSelectedFormat] = useState<any>(pdfFormat[0]);
  const [printFormKey, setPrintFormKey] = useState<any>("1ST_ROW");
  const [printFormVal, setPrintFormVal] = useState<any>(pdfPrintFormat[0]);

  const onPressItem = (item: any, type: string) => {
    switch (type) {
      case "selectPdf":
        setSelectedFormat(item);
        setSelectedCKey(item?.key);
        break;
      case "selectPrintFrom":
        setPrintFormKey(item?.key);
        setPrintFormVal(item);
        break;

      default:
        break;
    }
  };

  const onSelectFormat = (
    btmSheetRef: any,
    data: any,
    height: number,
    type: string,
    headerText: string
  ) => {
    return (
      <BottomSheetComponent
        customStyles={{ container: styles.bottomSheetContainer }}
        bottomSheetRef={btmSheetRef}
        height={hp(height)}
      >
        <View style={styles.headerContainer}>
          <CustomText
            accessibilityLabel="print-barcode-headerItem-headerName"
            style={styles.headerText}
          >
            {headerText}
          </CustomText>
          <TouchableOpacity
            accessibilityLabel="print-barcode-headerItem-close-button"
            onPress={() => btmSheetRef.current.close()}
          >
            <CustomText
              accessibilityLabel="print-barcode-headerItem-close-button-text"
              style={styles.closeBtn}
            >
              {strings["close"]}
            </CustomText>
          </TouchableOpacity>
        </View>
        <View
          style={{ paddingTop: hp(1) }}
          accessibilityLabel="print-barcode-selection-view"
        >
          {data &&
            data?.map((v: any, i: number) => {
              return (
                <TouchableOpacity
                  accessibilityLabel="print-barcode-select-pdf-button"
                  style={styles.selectItemContainer}
                  onPress={() => onPressItem(v, type)}
                >
                  <CustomText
                    accessibilityLabel="print-barcode-select-pdf-text"
                    style={styles.itemText}
                  >
                    {v.title}
                  </CustomText>
                  {type == "selectPdf"
                    ? selectedKey === v?.key && __renderCheck()
                    : printFormKey === v?.key && __renderCheck()}
                </TouchableOpacity>
              );
            })}
        </View>
      </BottomSheetComponent>
    );
  };

  const __renderCheck = () => (
    <TickIcon
      height={hp(2)}
      width={hp(2)}
      fill={COLORS.scienceBlue}
      style={{
        marginRight: wp(2),
      }}
    />
  );

  const PrintBarCode = () => (
    <>
      <View>
        <TextInputComponent
          title={strings["select.pdf.format"]}
          onPressRightIcon={() => btmSheetRef.current.open()}
          onPressLeftIcon={() => console.log("left icon pressed")}
          RightIcon={ArrowDown}
          value={selectdFormat?.title ?? pdfFormat[0]?.title}
          editable={false}
          main={styles.orgTxtContainerStyle}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
        />
        <TextInputComponent
          title={strings["print.from"]}
          onPressRightIcon={() => printFormRef.current.open()}
          onPressLeftIcon={() => console.log("left icon pressed")}
          RightIcon={ArrowDown}
          value={printFormVal?.title ?? pdfPrintFormat[0].title}
          editable={false}
          main={styles.orgTxtContainerStyle}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
        />
      </View>

      {onSelectFormat(
        btmSheetRef,
        pdfFormat,
        35,
        "selectPdf",
        strings["select.pdf.format"]
      )}
      {onSelectFormat(
        printFormRef,
        pdfPrintFormat,
        50,
        "selectPrintFrom",
        strings["print.from"]
      )}
    </>
  );

  const getLabelsCount = (
    productId: any,
    batchProducts: any,
    batchIndex?: any,
    propsDataItem?: any
  ) => {
    let count: any;

    filteredData.map((item: any) => {
      if (item.product?.id == productId) {
        if (item.product.uomManagementEnabled == 0) {
          count =
            batchProducts.length > 0
              ? batchProducts[batchIndex]?.receivedBatchQty
              : propsDataItem?.receivedQty;
        } else {
          count =
            batchProducts.length > 0
              ? batchProducts[batchIndex]?.receivedBatchQty *
                Number(item?.product?.vendorUnit)
              : propsDataItem?.receivedQty * Number(item?.product?.vendorUnit);
        }
      }
    });
    return count;
  };

  const getProductsArray = () => {
    const productsArray = props?.data?.map((item: any) => {
      let matchedData =
        receiveData.batchIdList[`${item?.id + "_" + item?.stockReceiptId}`] ??
        receiveData.batchIdList[`${item?.id}`];
      return {
        id: item?.product?.id,
        labelsCount:
          item?.product?.batches.length > 0
            ? 0
            : getLabelsCount(item?.product?.id, [], 0, item),
        batches:
          item?.product?.batches.length > 0
            ? matchedData.map((id: any, index: number) => {
                return {
                  id: id,
                  labelsCount: getLabelsCount(
                    item?.product?.id,
                    item?.product?.batches,
                    index
                  ),
                };
              })
            : [],
      };
    });

    return productsArray;
  };

  const callPrintFunc = async () => {
    let barcodeParams = {
      products: getProductsArray(),
      stockrooms: null,
      users: null,
      costCenters: null,
      departments: null,
      reasonCodes: null,
      barcodeGenTypes: ["PRODUCT_CATALOG_NUMBER"],
      fieldMapping: [],
      zebraTemplateId: null,
      pdfTypeId: barcodeType == 0 ? selectedKey : null,
      startingRowNumber: barcodeType == 0 ? printFormVal.id + 1 : 1,
      barcodeFileType: null,
      infoSheetType: null,
    };
    didCloseModal();
    props?.goBack();
    await dispatch(
      receivePrintBarcode(barcodeParams, async (res: any) => {
        if (await checkStoragePermission()) {
          const storageDir =
            Platform.OS == "ios"
              ? RNFetchBlob.fs.dirs.DocumentDir
              : RNFetchBlob.fs.dirs.DownloadDir;

          let pdfLocation = storageDir + "/Barcode-labels.pdf";

          await RNFetchBlob.fs
            .writeFile(pdfLocation, res?.data?.data?.barcodePdf, "base64")
            .then(() => {
              Platform.OS == "ios"
                ? RNFetchBlob.ios.openDocument(pdfLocation)
                : RNFetchBlob.android
                    .addCompleteDownload({
                      title: "Barcode-labels.pdf",
                      description: "Download complete",
                      mime: "application/pdf",
                      path: pdfLocation,
                      showNotification: true,
                    })
                    .then(() =>
                      RNFetchBlob.android.actionViewIntent(
                        pdfLocation,
                        "application/pdf"
                      )
                    );
            });
        }
      })
    );
  };

  return (
    <Modal
      animationType="fade"
      transparent
      visible={isShow}
      ref={ref}
      onRequestClose={didCloseModal}
    >
      <View
        accessible={true}
        accessibilityLabel="alertbox_main_container"
        style={styles.container}
      >
        <View
          accessible={true}
          accessibilityLabel="alertbox_sub_container"
          style={styles.modal}
        >
          <CustomText
            accessibilityLabel="alertbox_left_button_title"
            style={styles.headerText}
          >
            {strings["im.print.barcodes"]}
          </CustomText>
          <View
            accessible={true}
            accessibilityLabel="alertbox_child_container"
            style={styles.btnWrapperContainer}
          >
            <Pressable onPress={() => setBarcodeType(0)}>
              <CustomText
                accessibilityLabel="alertbox_left_button_title"
                style={[
                  styles.buttonText,
                  {
                    color: barcodeType == 0 ? COLORS.scienceBlue : COLORS.gray,
                    borderBottomWidth: barcodeType == 0 ? hp(0.2) : 0,
                  },
                ]}
              >
                {strings["pdf.formats"]}
              </CustomText>
            </Pressable>
          </View>

          {barcodeType == 0 && PrintBarCode()}

          <View style={styles.tabsContainer}>
            <TouchableOpacity
              style={styles.nonActiveBtnContainer}
              onPress={() => {
                didCloseModal();
                props.goBack();
              }}
            >
              <CustomText style={styles.nonActiveTabText}>
                {strings["cancel"]}
              </CustomText>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.activeBtnContainer}
              onPress={() => {
                callPrintFunc();
              }}
            >
              <CustomText style={styles.activeTabText}>
                {strings["print"]}
              </CustomText>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default PrintBarcodeModal;
