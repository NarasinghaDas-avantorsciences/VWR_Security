import React, { useEffect, useState, useCallback } from "react";
import { View, StyleProp, ViewStyle } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import { setProductLoader } from "../../../../Redux/Action/searchAction";
import styles from "./styles";
import {
  AddBatch,
  ListItem,
  QtyController,
  CustomText,
  TextInputComponent,
  AlertModal,
} from "../../../../Components";
import Calender from "../../../../Components/Calender";
import {
  getReceiveRemainingQty,
  hp,
  wp,
} from "../../../../Utils/globalFunction";
import { setReceiveLimtiFlag } from "../../../../Redux/Action/receiveAction";

type RecieveListItemProps = {
  item: any;
  id?: string;
  freeze?: boolean;
  bottomBorder?: boolean;
  leftIcon?: any;
  rightIcon?: any;
  containerStyle?: StyleProp<ViewStyle>;
  handleOnSelect?: any;
  headerContent?: any;
  handleAvailQty?: any;
  showBatch?: boolean;
  handleBatch?: any;
  handleBatchDelete?: any;
  disabledList?: boolean;
  receiveTab?: boolean;
  isDeliveryNoteAvailable?: boolean;
  sampleDataState?: any;
  setDeliveryDataCallback?: any;
  userDeliveryNoteAvailable?: boolean;
  onSelectItemCall?: any;
};

const RecieveListItem: React.FC<RecieveListItemProps> = ({
  item,
  id,
  freeze = false,
  bottomBorder = true,
  leftIcon,
  rightIcon,
  containerStyle,
  headerContent,
  showBatch,
  handleOnSelect,
  handleAvailQty,
  handleBatch,
  handleBatchDelete,
  disabledList = true,
  receiveTab,
  isDeliveryNoteAvailable,
  sampleDataState,
  setDeliveryDataCallback,
  userDeliveryNoteAvailable,
  onSelectItemCall,
}) => {
  const dispatch = useDispatch<any>();
  const [qty, setQty] = useState<string>("0");
  const [remainingQty, setRemainingQty] = useState<string>(
    item?.remainingQuanityStr
  );
  const [rejectedQty, setRejectedQty] = useState<string>(item?.rejectedQtyStr);
  const [receivedQty, setReceivedQty] = useState<string>(item?.receivedQtyStr);
  const [batchData, setBatchData] = useState<any>([]);
  const [multiplier, setMultiplier] = useState(null);
  const [visible, setVisible] = useState(false);
  const [focusedDate, setFocusedDate] = useState(moment().format("MM-DD-YYYY"));
  const [mainQtyDisabled, setMainQtyDisabled] = useState(false);
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const { dateFormat, stockRoomDetail } = useSelector(
    (state: any) => state.userReducer
  );

  useEffect(() => {
    if (item?.receivedQtyStr.includes("X")) {
      let qtyArr = item?.receivedQtyStr.replace(/\s+/g, "").split("X");
      setReceivedQty(qtyArr[0]);
    } else if (receivedQty == null) {
      setReceivedQty("0");
    }

    if (item?.rejectedQtyStr.includes("X")) {
      let qtyArr = item?.rejectedQtyStr.replace(/\s+/g, "").split("X");
      setRejectedQty(qtyArr[0]);
    } else if (rejectedQty == null) {
      setRejectedQty("0");
    }
  }, []);

  useEffect(() => {
    (async function () {
      if (item?.remainingQuanityStr.includes("X")) {
        let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
        setQty(qtyArr[0]);
        setMultiplier(qtyArr[1]);
        setRemainingQty(qtyArr[0]);
      } else if (item?.receiveRemainingQty) {
        setQty(`${item?.receiveRemainingQty}`);
      }
    })();
  }, [item]);

  const topLimitReached = (dataItem: any) => {
    let qtyArr1: string = "";
    let qtyArr2: string = "";
    if (dataItem?.remainingQuanityStr.includes("X")) {
      qtyArr1 = dataItem?.remainingQuanityStr.replace(/\s+/g, "").split("X");
    } else {
      qtyArr1 = dataItem?.remainingQuanityStr;
    }

    if (dataItem?.orderQtyStr.includes("X")) {
      qtyArr2 = dataItem?.orderQtyStr.replace(/\s+/g, "").split("X");
    } else {
      qtyArr2 = dataItem?.orderQtyStr;
    }

    if (
      Number(qty) +
        Number(dataItem?.orderQtyStr.includes("X") ? qtyArr2[0] : qtyArr2) ==
      Number(
        dataItem?.remainingQuanityStr.includes("X") ? qtyArr1[0] : qtyArr1
      ) +
        Number(dataItem?.orderQtyStr.includes("X") ? qtyArr2[0] : qtyArr2)
    ) {
      return false;
    } else {
      return true;
    }
  };

  const getRemainingQty = () => {
    //console.log("..", item);
    let qtyArr1: string = "";
    let qtyArr2: string = "";
    if (item?.remainingQuanityStr.includes("X")) {
      qtyArr1 = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
      if (
        item?.product?.maxStockQtyForDisplay &&
        item?.product?.maxStockQtyForDisplay.includes("X")
      ) {
        qtyArr2 = item?.product?.maxStockQtyForDisplay
          .replace(/\s+/g, "")
          .split("X");
      }
    } else {
      qtyArr1 = item?.remainingQuanityStr;
    }

    let difference =
      Number(item?.remainingQuanityStr.includes("X") ? qtyArr1[0] : qtyArr1) -
      Number(item?.newSelectedQty ?? 0);

    if (difference <= 0) {
      return 0;
    } else {
      return qtyArr2[1] !== undefined
        ? difference + " X " + qtyArr2[1]
        : difference;
    }
  };

  const getReceivedQty = () => {
    return item?.newSelectedQty ?? (receiveTab ? getReceiveTabQty() : qty);
  };

  const getReceiveTabQty = () => {
    let receiveQtyArr = item?.receivedQtyStr.replace(/\s+/g, "").split("X");
    return receiveQtyArr[0];
  };

  const changeInputValue = async (
    dataItem: any,
    value: string,
    type: string
  ) => {
    let sampleDataSet = {
      id: dataItem?.stockReceiptDetails?.id,
      [type]: value,
    };
    let sampleDataSetArr = sampleDataState;
    let selectedIndex = sampleDataSetArr.findIndex(
      (item: any) => item.id == dataItem?.stockReceiptDetails?.id
    );
    if (selectedIndex == -1) {
      sampleDataSetArr.push(sampleDataSet);
    } else {
      let dataSet = {
        ...sampleDataSetArr[selectedIndex],
        [type]: value,
      };
      sampleDataSetArr.splice(selectedIndex, 1);
      sampleDataSetArr.push(dataSet);
    }

    setDeliveryDataCallback(sampleDataSetArr);
  };

  const _getDeliverynotedProductExpiryDate = (itm: any) => {
    let dtValue =
      !checkifExpiryEnabled() && itm?.isPouApproved
        ? ""
        : sampleDataState[
            sampleDataState.findIndex(
              (dataItem: any) => dataItem?.id == itm.stockReceiptDetails?.id
            )
          ]?.expiryDate;
    dtValue = dtValue
      ? dtValue != "" && moment(dtValue, "YYYY-MM-DD").format("MM-DD-YYYY")
      : "";
    console.log(dtValue);
    return String(dtValue);
  };

  const __renderCalander = (item: any) => (
    <Calender
      changeDate={(date: any) => {
        date = moment(date).format("YYYY-MM-DD");
        //let incomingDate = moment(date).toLocaleString();
        changeInputValue(item, date, "expiryDate");
      }}
      selectedDate={focusedDate}
      onClose={() => setVisible(!visible)}
    />
  );

  const checkifBatchEnabled = () => {
    if (
      stockRoomDetail?.isBatchManagementEnabled &&
      (item?.batchManagementEnabled || item?.product?.batchManagementEnabled)
    ) {
      return true;
    } else {
      return false;
    }
  };

  const checkifExpiryEnabled = () => {
    if (
      stockRoomDetail?.isExpiryManagementEnabled &&
      (item?.expiryDateManagementenabled ||
        item?.product?.expiryDateManagementenabled)
    ) {
      return true;
    } else {
      return false;
    }
  };

  return (
    <View
      accessible={true}
      accessibilityLabel="receive-list-item"
      style={[
        styles.container,
        bottomBorder && { borderBottomWidth: bottomBorder ? 1 : 0 },
        containerStyle,
      ]}
    >
      <ListItem
        key={id}
        leftIcon={leftIcon}
        onPress={handleOnSelect}
        headerContent={headerContent}
        rightIcon={rightIcon}
        disabled={disabledList}
      >
        <View style={[styles.flexRowContainer, styles.spacer]}>
          <View style={[styles.itemChildContainer]}>
            <CustomText
              style={styles.itemTitleText}
              accessibilityLabel="receive-list-item-vendor-label"
            >
              {strings["vendor"]}
            </CustomText>
            <CustomText
              style={styles.itemValueText}
              accessibilityLabel="receive-list-item-vendor"
            >
              {item?.product?.vendorName}
            </CustomText>
          </View>
          <View style={[styles.itemChildContainer]}>
            <CustomText
              style={styles.itemTitleText}
              accessibilityLabel="receive-list-item-location-label"
            >
              {strings["location"]}
            </CustomText>
            <CustomText
              style={styles.itemValueText}
              accessibilityLabel="receive-list-item-location"
            >
              {item?.product?.locationName ?? "-"}
            </CustomText>
          </View>
        </View>

        <View style={styles.flexRowContainer}>
          <View>
            <CustomText
              style={styles.qtyTitles}
              accessibilityLabel="receive-list-item-ordered-qty-label"
            >
              {strings["ime.ordered.qty"]}
            </CustomText>

            <CustomText
              style={[
                styles.qtyTitles,
                styles.qtyValues,
                styles.font16,
                { maxWidth: wp(26) },
              ]}
              accessibilityLabel="receive-list-item-ordered-qty"
            >
              {item?.orderQtyStr}
            </CustomText>
          </View>
          <View>
            <CustomText
              style={styles.qtyTitles}
              accessibilityLabel="receive-list-item-received-qty-label"
            >
              {strings["ime.received.qty"]}
            </CustomText>

            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <QtyController
                onChange={(val: React.SetStateAction<string>) => {
                  onSelectItemCall(val);
                  setQty(val);

                  setRemainingQty(
                    multiplier
                      ? `${
                          item?.orderedQty / multiplier -
                          Number(val) -
                          Number(receivedQty)
                        }`
                      : `${
                          item?.orderedQty - Number(val) - Number(receivedQty)
                        }`
                  );
                  handleAvailQty(val, item?.id);
                }}
                inputValue={getReceivedQty()}
                initialValue={
                  multiplier
                    ? item?.orderedQty / multiplier -
                      Number(rejectedQty) -
                      Number(item?.receivedQty)
                    : item?.orderedQty -
                      Number(rejectedQty) -
                      Number(item?.receivedQty)
                }
                showLabel={false}
                disable={
                  freeze ||
                  item?.isReceivedQtyDisabled ||
                  (isDeliveryNoteAvailable && receiveTab)|| //Added by kiran 
                  receiveTab ||
                  mainQtyDisabled ||
                  !item?.isPouApproved ||
                  showBatch //Added by kiran DPIM - https://jira.vwr.com/browse/DPIM-4943
                }
                topLimit={
                  Number(getReceivedQty()) >=
                  Number(getReceiveRemainingQty(item)) - Number(rejectedQty)
                }
              />
              {multiplier && (
                <CustomText
                  style={[styles.qtyTitles, styles.font16, { maxWidth: wp(8) }]}
                >
                  X {multiplier}
                </CustomText>
              )}
            </View>
          </View>
          <View>
            <CustomText
              style={styles.qtyTitles}
              accessibilityLabel="receive-list-item-remaining-qty-label"
            >
              {strings["ime.remaining.qty"]}
            </CustomText>

            <CustomText
              style={[
                styles.qtyTitles,
                styles.qtyValues,
                styles.font16,
                { maxWidth: wp(26) },
              ]}
              accessibilityLabel="receive-list-item-remainnig-qty"
            >
              {getRemainingQty()}
            </CustomText>
          </View>
        </View>
      </ListItem>

      {!isDeliveryNoteAvailable && showBatch && (
        <AddBatch
          item={item}
          onChange={(
            data: any,
            batchId: any,
            itemId: any,
            isSelectedCallback: boolean
          ) => {
            let blockData = data?.filter(
              (item: any) => Number(item.actualQty) > 0
            );
            handleBatch(data, batchId, itemId);
            isSelectedCallback && onSelectItemCall(Number(blockData.length));
          }}
          onDelete={handleBatchDelete}
          updateActualQty={(val: any) => {
            setQty(val);
            item["receiveRemainingQty"] = val;
            handleAvailQty(val, item?.id);
          }}
          disabled={freeze || !item?.isPouApproved}
          freeze={freeze}
          from="receive"
          setLoader={(val: boolean) => {
            //  dispatch(setProductLoader(val))
          }}
          topLimitValue={
            multiplier
              ? item?.orderedQty / multiplier - Number(rejectedQty)
              : item?.orderedQty - Number(rejectedQty)
          }
          formatedData={batchData}
          setFormatedData={setBatchData}
          data={(item?.receiveBatchDetails?.length != 0
            ? item?.receiveBatchDetails?.map((i: any) => {
                const { batchNo, receivedQty, id, expiryDt } = i;

                if (receivedQty != 0 && receivedQty != null) {
                  return {
                    batchNo,
                    actualQty: receivedQty,
                    id,
                    expiryDate: expiryDt,
                  };
                }
              })
            : []
          )?.filter((item: any) => item)}
          receiveTabActive={receiveTab}
          setMainQtyDisabledState={(value: any) => setMainQtyDisabled(value)}
        />
      )}

      {isDeliveryNoteAvailable && showBatch && (
        <View style={styles.item}>
          <TextInputComponent
            title={strings["batch.no"]}
            editable={
              receiveTab ? false : freeze ? false : checkifBatchEnabled()
            }
            disabled={
              receiveTab ? true : freeze ? true : !checkifBatchEnabled()
            }
            main={styles.inputMain}
            inputStyle={styles.input}
            inputMain={{
              height: hp(4),
            }}
            placeholder={strings["batch.no"]}
            value={
              sampleDataState[
                sampleDataState.findIndex(
                  (dataItem: any) =>
                    dataItem?.id == item.stockReceiptDetails?.id
                )
              ]?.batchNo
            }
            onChangeText={(val) => {
              changeInputValue(item, val, "batchNo");
            }}
          />
          <TextInputComponent
            title={strings["ime.scanner.Exp.Date"]}
            pointerEvents="none"
            editable={false}
            disabled={
              receiveTab ? true : freeze ? true : !checkifExpiryEnabled()
            }
            value={_getDeliverynotedProductExpiryDate(item)}
            main={styles.inputMain}
            inputStyle={styles.input}
            inputMain={{
              height: hp(4),
              alignItems: "center",
            }}
            placeholder={!item?.isPouApproved ? strings["date"] : ""}
            onChangeText={(val) => {
              changeInputValue(item, val, "expiryDate");
            }}
            onPressRightIcon={() => {
              let dateValue =
                sampleDataState[
                  sampleDataState.findIndex(
                    (dataItem: any) =>
                      dataItem?.id == item.stockReceiptDetails?.id
                  )
                ]?.expiryDate;

              let momentDate = moment(
                dateValue ?? new Date(),
                "YYYY-MM-DD"
              ).format("MM-DD-YYYY");
              setFocusedDate(momentDate);
              setVisible(!visible);
            }}
          />
          <View>
            <CustomText allowFontScaling={false} style={styles.qtyTitle}>
              {strings["ime.qty"]}
            </CustomText>
            <QtyController
              showLabel={false}
              onChange={async (val: string, setInputVal: any = null) => {
                onSelectItemCall(val);
                val = Number(val).toString();
                changeInputValue(item, val, "qty");
                setInputVal(val);
                setQty(val);
                handleAvailQty(val, item?.id);
              }}
              inputStyle={styles.qty}
              inputValue={
                item?.newSelectedQty ?? (receiveTab ? getReceiveTabQty() : qty)
              }
              remainingVal={getRemainingQty()}
              topLimitValue={
                multiplier
                  ? item?.orderedQty / multiplier - Number(rejectedQty)
                  : item?.orderedQty - Number(rejectedQty)
              }
              // topLimit={topLimitReached(item)}
              topLimit={false}
              disable={receiveTab ? true : freeze}
              containerStyle={{ top: -4 }}
              isReceiveBatch={true}
            />
          </View>
        </View>
      )}
      <AlertModal
        isShow={visible}
        customStyles={{
          width: wp(95),
          borderRadius: 4,
          alignSelf: "center",
          paddingVertical: hp(1),
        }}
      >
        {__renderCalander(item)}
      </AlertModal>
    </View>
  );
};

export default RecieveListItem;
