import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

export default StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    paddingHorizontal: wp(5),
    height: hp(45),
    backgroundColor: "rgba(0,0,0,0.5)",
  },

  modal: {
    backgroundColor: COLORS.white,
    borderRadius: hp(1),
    alignItems: "center",
    elevation: 5,
    width: "100%",
    minHeight: hp(12),
    height: hp(45),
    justifyContent: "center",
  },

  childrenContainer: {
    marginVertical: hp(1.2),
    width: "100%",
    paddingHorizontal: wp(1),
    alignItems: "center",
  },

  btnWrapperContainer: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-evenly",
    height: hp(6),
    alignItems: "center",
    marginBottom: hp(2),
  },

  buttonText: {
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center",
    paddingVertical: hp(1),
    fontFamily: FONTFAMILY.averta_semibold,
    borderBottomColor: COLORS.scienceBlue,
  },

  headerText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    paddingVertical: hp(2),
  },

  seperator: {
    width: 1,
    backgroundColor: COLORS.tuna36,
    height: "100%",
  },
  orgTxtContainerStyle: {
    width: wp(90),
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginVertical: wp(1),
    paddingHorizontal: wp(5),
    height: hp(9),
  },
  inputStyle: {
    height: hp(5),
    padding: 0,
    fontSize: FONTS.h1_9,
    color: COLORS.gray,
    left: -wp(2),
    marginRight: wp(4),
    fontFamily: FONTFAMILY.averta_regular,
  },
  inputMainStyle: {
    height: hp(5),
    top: 0,
    borderColor: COLORS.gray,
  },
  tabsContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    width: "100%",
    paddingHorizontal: hp(2),
    paddingBottom: hp(2.5),
    paddingTop: hp(1),
  },
  activeBtnContainer: {
    backgroundColor: COLORS.scienceBlue,
    height: hp(6),
    alignItems: "center",
    justifyContent: "center",
    width: "50%",
  },
  nonActiveBtnContainer: {
    backgroundColor: COLORS.white,
    height: hp(6),
    alignItems: "center",
    justifyContent: "center",
    width: "50%",
  },

  activeTabText: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_6,
    color: COLORS.white,
  },
  nonActiveTabText: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_6,
    color: COLORS.scienceBlue,
  },
  bottomSheetContainer: {
    borderTopLeftRadius: hp(1),
    borderTopRightRadius: hp(1),
  },
  selectItemContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingRight: wp(2),
    alignItems: "center",
  },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginLeft: wp(30),
    alignItems: "center",
  },
  closeBtn: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.blue,
    paddingLeft: wp(6),
    fontFamily: FONTFAMILY.averta_regular,
  },
  itemText: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.gray,
    paddingLeft: wp(6),
    paddingVertical: hp(1),
    fontFamily: FONTFAMILY.averta_regular,
    marginBottom: 0.5,
  },
  circle: {
    width: wp(5),
    height: wp(5),
    borderColor: COLORS.scienceBlue,
    borderRadius: 100,
    marginHorizontal: wp(2),
  },
  selectZebraTypeContainer: {
    backgroundColor: COLORS.white,
    height: hp(5),
    alignItems: "flex-start",
    justifyContent: "center",
    width: "50%",
    flexDirection: "row",
  },
});
