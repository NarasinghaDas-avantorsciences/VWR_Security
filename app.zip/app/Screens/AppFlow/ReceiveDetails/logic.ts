import moment from "moment";
import {
  checkRemainingQtyBool,
  checkifBatchEnabled,
  checkifExpiryEnabled,
  findDateFormat,
  isReceiveProductFreezed,
} from "../../../Utils/globalFunction";

const setSelectAll = async (
  orderDetailsData: any,
  isSelectedAll: boolean,
  setEnableBtnAction: any,
  setIsSelectedAll: any
) => {
  for (let i = 0; i < orderDetailsData?.allOrderDetails.length; i++) {
    orderDetailsData.allOrderDetails[i]["selected"] =
      !isQualityInspected(orderDetailsData?.allOrderDetails[i]) &&
      orderDetailsData?.allOrderDetails[i].isPouApproved &&
      !isSelectedAll;
    // !orderDetailsData.allOrderDetails[i]["selected"];
  }
  for (let i = 0; i < orderDetailsData?.deliveryList.length; i++) {
    orderDetailsData.deliveryList[i]["selected"] =
      !isQualityInspected(orderDetailsData?.deliveryList[i]) &&
      orderDetailsData?.deliveryList[i].isPouApproved &&
      !isSelectedAll;
    // !orderDetailsData.deliveryList[i]["selected"];
  }

  // const filteredArr = orderDetailsData.allOrderDetails.filter(
  //   (obj: any) => obj.selected == true && obj?.product?.freeze == false
  // );

  // const filteredArr_deliveryList = orderDetailsData.deliveryList.filter(
  //   (obj: any) => obj.selected == true && obj?.product?.freeze == false
  // );

  const filteredArr = orderDetailsData.allOrderDetails.filter((obj: any) => {
    return (
      obj.selected == true &&
      !isReceiveProductFreezed(obj?.product) &&
      obj.isPouApproved &&
      checkRemainingQtyBool(obj)
    );
  });

  const filteredArr_deliveryList = orderDetailsData.deliveryList.filter(
    (obj: any) =>
      obj.selected == true &&
      !isReceiveProductFreezed(obj?.product) &&
      obj.isPouApproved &&
      checkRemainingQtyBool(obj)
  );

  if (filteredArr.length > 0) {
    setEnableBtnAction(true);
  } else if (filteredArr_deliveryList?.length > 0) {
    setEnableBtnAction(true);
  } else {
    setEnableBtnAction(false);
  }

  setIsSelectedAll(!isSelectedAll);
};

const getTabCount = (data: any) => {
  let result: any = {};
  let ARRR: any = [];
  let ARRR_received: any = [];

  data?.deliveryList &&
    data.deliveryList.map((item: any, i: number) => {
      if (item?.remainingQuanityStr.includes("X")) {
        let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
        if (Number(qtyArr[0]) == 0) {
          ARRR_received.push(item);
        } else {
          ARRR.push(item);
        }
      } else {
        if (Number(item?.remainingQuanityStr) == 0) {
          ARRR_received.push(item);
        } else {
          ARRR.push(item);
        }
      }
    });

  ARRR.forEach(function (item: any) {
    if (result[item.deliveryNoteNo]) {
      result[item.deliveryNoteNo].push(item);
    } else {
      result[item.deliveryNoteNo] = [item];
    }
  });

  let blockData = [];

  for (let key in result) {
    blockData.push({
      deliveryNote: key,
      result: result[key],
    });
  }

  data?.allOrderDetails &&
    data?.allOrderDetails.map((item: any, i: number) => {
      if (item?.remainingQuanityStr.includes("X")) {
        let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");

        if (Number(qtyArr[0]) == 0) {
          ARRR_received.push(item);
        } else {
          blockData.push(item);
        }
      } else {
        if (Number(item?.remainingQuanityStr) == 0) {
          ARRR_received.push(item);
        } else {
          blockData.push(item);
        }
      }
    });

  return blockData?.length;
};

const selectItemsOnChange = async (
  orderDetailsData: any,
  index: number,
  setEnableBtnAction: any,
  setIsSelectedAll: any,
  setUpdatedOrderList: any,
  dispatch: any,
  keyId: string,
  dataItemID: string,
  deliveryNoteNo?: string | undefined,
  notReceivedData?: any,
  val?: any
) => {
  let sampleData = orderDetailsData;

  if (keyId.includes("_dev")) {
    sampleData.deliveryList.map((item: any) => {
      if (item.deliveryNoteNo == deliveryNoteNo) {
        if (val) {
          item.selected = val > 0 ? true : false;
        } else {
          item.selected = true;
        }
        // item.selected = true;
      }
    });
  } else {
    sampleData.allOrderDetails.map((item: any) => {
      if (item.id == dataItemID) {
        item.selected = val > 0 ? true : false;
        // item.selected = true;
      }
    });
  }

  let filteredDeliveryArr: any[] = [];
  let filteredNormalArr: any[] = [];
  await dispatch(setUpdatedOrderList(sampleData));
  if (keyId.includes("_dev")) {
    filteredDeliveryArr = getFilteredArray(orderDetailsData, false);
    filteredDeliveryArr?.length > 0
      ? setEnableBtnAction(true)
      : setEnableBtnAction(false);
  } else {
    filteredDeliveryArr = getFilteredArray(orderDetailsData, false);
  }

  let dummyDeliveryArray: any = [];

  filteredDeliveryArr.filter((obj: any) => {
    if (obj?.deliveryNote) {
      dummyDeliveryArray.push(obj?.result);
    }
  });

  let selectedItemsArray_del: any = [];

  filteredDeliveryArr.forEach((entry) => {
    if (entry?.deliveryNote) {
      const selectedResults = entry?.result.filter((item) => item.selected);
      selectedItemsArray_del.push(...selectedResults);
    }
  });
  let selectedItemsArray = filteredDeliveryArr.filter(
    (obj: any) => obj.selected == true
  );
  let arrDelivery = filteredDeliveryArr.filter(
    (obj: any) => obj.selected == false
  );
  let arrNormal = filteredNormalArr.filter((obj: any) => obj.selected == false);

  if (selectedItemsArray.length > 0 || selectedItemsArray_del.length > 0) {
    setEnableBtnAction(true);
  } else {
    setEnableBtnAction(false);
  }

  if (arrDelivery.length > 0 || arrNormal.length > 0) {
    setIsSelectedAll(false);
  } else if (arrDelivery.length == 0 && arrNormal.length == 0) {
    setIsSelectedAll(true);
  }

  //ToDo: Need to check
  // let arrDelivery = sampleData.deliveryList.filter(
  //   (obj: any) => obj.selected == true
  // );
  // let arrNormal = sampleData.allOrderDetails.filter(
  //   (obj: any) => obj.selected == true
  // );
  // if (arrDelivery.length + arrNormal.length == notReceivedData.length) {
  //   setIsSelectedAll(true);
  // } else setIsSelectedAll(false);
};

//====== FUNCTION TO GET RECEIVED , NOT RECEIVED ARRAY =================
const getFilteredArray = (orderDetails: any, isReceived: boolean) => {
  let result: any = {};
  let ARRR: any = [];
  let ARRR_received: any = [];

  orderDetails?.deliveryList &&
    orderDetails.deliveryList.map((item: any, i: number) => {
      if (item?.remainingQuanityStr.includes("X")) {
        let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
        if (Number(qtyArr[0]) == 0) {
          ARRR_received.push(item);
        } else {
          ARRR.push(item);
        }
      } else {
        if (Number(item?.remainingQuanityStr) == 0) {
          ARRR_received.push(item);
        } else {
          ARRR.push(item);
        }
      }
    });
  {
    !isReceived
      ? ARRR.forEach(function (item: any) {
          if (result[item.deliveryNoteNo]) {
            result[item.deliveryNoteNo].push(item);
          } else {
            result[item.deliveryNoteNo] = [item];
          }
        })
      : ARRR_received.forEach(function (item: any) {
          if (result[item.deliveryNoteNo]) {
            result[item.deliveryNoteNo].push(item);
          } else {
            result[item.deliveryNoteNo] = [item];
          }
        });
  }

  let blockData = [];

  for (let key in result) {
    blockData.push({
      deliveryNote: key,
      result: result[key],
    });
  }

  orderDetails?.allOrderDetails &&
    orderDetails?.allOrderDetails.map((item: any, i: number) => {
      if (item?.remainingQuanityStr.includes("X")) {
        let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");

        if (Number(qtyArr[0]) == 0) {
          ARRR_received.push(item);
        } else {
          blockData.push(item);
        }
      } else {
        if (Number(item?.remainingQuanityStr) == 0) {
          ARRR_received.push(item);
        } else {
          blockData.push(item);
        }
      }
    });

  return isReceived ? ARRR_received : blockData;
};
//================================================================================

const onSelectItems = async (
  orderDetailsData: any,
  index: number,
  setEnableBtnAction: any,
  setIsSelectedAll: any,
  setUpdatedOrderList: any,
  dispatch: any,
  keyId: string,
  dataItemID: string,
  deliveryNoteNo?: string | undefined,
  notReceivedData?: any
) => {
  let sampleData = orderDetailsData;

  if (keyId.includes("_dev")) {
    sampleData.deliveryList.map((item: any) => {
      if (item.deliveryNoteNo == deliveryNoteNo) {
        item.selected = !item?.selected;
      }
    });
  } else {
    sampleData.allOrderDetails.map((item: any) => {
      if (item.id == dataItemID) {
        item.selected = !item?.selected;
      }
    });
  }

  let filteredDeliveryArr: any[] = [];
  let filteredNormalArr: any[] = [];
  await dispatch(setUpdatedOrderList(sampleData));
  if (keyId.includes("_dev")) {
    filteredDeliveryArr = getFilteredArray(orderDetailsData, false);
    filteredDeliveryArr?.length > 0
      ? setEnableBtnAction(true)
      : setEnableBtnAction(false);
  } else {
    filteredDeliveryArr = getFilteredArray(orderDetailsData, false);
  }

  let dummyDeliveryArray: any = [];

  filteredDeliveryArr.filter((obj: any) => {
    if (obj?.deliveryNote) {
      dummyDeliveryArray.push(obj?.result);
    }
  });

  let selectedItemsArray_del: any = [];

  filteredDeliveryArr.forEach((entry) => {
    if (entry?.deliveryNote) {
      const selectedResults = entry?.result.filter((item) => item.selected);
      selectedItemsArray_del.push(...selectedResults);
    }
  });

  let selectedItemsArray = filteredDeliveryArr.filter(
    (obj: any) => obj.selected == true
  );

  let arrDelivery = filteredDeliveryArr.filter(
    (obj: any) => obj.selected == false
  );
  let arrNormal = filteredNormalArr.filter((obj: any) => obj.selected == false);

  if (selectedItemsArray.length > 0 || selectedItemsArray_del.length > 0) {
    setEnableBtnAction(true);
  } else {
    setEnableBtnAction(false);
  }

  //============================================================================================

  if (arrDelivery.length > 0 || arrNormal.length > 0) {
    setIsSelectedAll(false);
  } else if (arrDelivery.length == 0 && arrNormal.length == 0) {
    setIsSelectedAll(true);
  }
};

const getBatchNo = (id: string, dataArr: any) => {
  let filterData = dataArr.filter((item: any) => item.id == id);

  return filterData.length > 0 ? filterData[0]?.batchNo : null;
};

const getReceivedBatchQty = (id: string, dataArr: any) => {
  let filterData = dataArr.filter((item: any) => item.id == id);
  return filterData.length > 0 ? parseInt(filterData[0]?.qty) : 0;
};

const getExpiryDate = (id: string, dataArr: any) => {
  console.log("EXPIRY dATA ARR: ", dataArr, id);
  // Get the current time with timezone offset
  let currentTime = moment().format("HH:mm:ssZ");
  let filterData = dataArr.filter((item: any) => item.id == id);
  if (filterData[0]?.expiryDate == null) {
    return null;
  }
  let itemExpiryDate = moment(
    filterData[0]?.expiryDate,
    findDateFormat(filterData[0]?.expiryDate)
  ).format("YYYY-MM-DD");

  return filterData.length > 0 ? `${itemExpiryDate}T${currentTime}` : null;
};

const handleRecieveStock = async (
  orderItemId: string,
  orderDetails: any,
  showToast: any,
  successToast: any,
  dispatch: (arg0: any) => void,
  receiveStock: any,
  receiveCallback: any,
  strings: any,
  sampleDataState?: any,
  stockRoomDetail?: any
) => {
  let normalStockArr = orderDetails?.allOrderDetails
    .map((item: any) => {
      if (
        !(isReceiveProductFreezed(item?.product) || isQualityInspected(item))
      ) {
        if (item?.selected) return item;
      }
    })
    .filter((item: any) => item);

  let deliveryStockArr = orderDetails?.deliveryList
    .map((item: any) => {
      if (
        !(isReceiveProductFreezed(item?.product) || isQualityInspected(item))
      ) {
        if (item?.selected) return item;
      }
    })
    .filter((item: any) => item);

  let receiveStockArr = normalStockArr.concat(deliveryStockArr);
  try {
    const orderLines = receiveStockArr.map((item: any) => {
      let batchProducts: any[] = [];
      if (
        item.deliveryNoteNo == null &&
        item?.receiveBatchDetails?.length > 0
      ) {
        //Not having Delivery note
        batchProducts = item?.receiveBatchDetails.map((batch: any) => {
          if (batch?.id?.includes("addedBatch")) {
            const { batchNo, actualQty, expiryDate } = batch;
            if (batchNo == "" && checkifBatchEnabled(item, stockRoomDetail)) {
              showToast(
                strings["error.occured"],
                strings["ime.scanner.batch.empty.msg"]
              );
              throw new Error("Batch No. required");
            } else if (
              expiryDate == "" &&
              checkifExpiryEnabled(item, stockRoomDetail)
            ) {
              showToast(
                strings["error.occured"],
                strings["ime.scanner.expiry.date.empty.msg"]
              );
              throw new Error("Expiry Date required");
            } else if (actualQty == 0) {
              throw new Error(
                strings["ime.receive.stock.enter.quantity.greater.than.zero"]
              );
            }
            return {
              batchNo:
                item.deliveryNoteNo !== null
                  ? getBatchNo(item?.stockReceiptDetails?.id, sampleDataState)
                  : batchNo
                  ? batchNo
                  : null,
              receivedBatchQty:
                item.deliveryNoteNo !== null
                  ? getReceivedBatchQty(
                      item?.stockReceiptDetails?.id,
                      sampleDataState
                    )
                  : parseInt(actualQty),
              expiryDate:
                item.deliveryNoteNo !== null
                  ? getExpiryDate(
                      item?.stockReceiptDetails?.id,
                      sampleDataState
                    )
                  : checkifExpiryEnabled(item, stockRoomDetail)
                  ? `${moment(expiryDate, findDateFormat(expiryDate)).format(
                      "YYYY-MM-DD"
                    )}T${moment().format("HH:mm:ssZ")}`
                  : null
                  ? moment(expiryDate, findDateFormat(expiryDate)).format(
                      "YYYY-MM-DDTHH:mm:ss.SSSZ"
                    )
                  : null,
              newlyCreated: true,
            };
          }
        });
      } else if (item.deliveryNoteNo !== null) {
        batchProducts = sampleDataState.map((batch: any) => {
          const { batchNo, actualQty, expiryDate } = batch;
          if (batchNo == "" && checkifBatchEnabled(item, stockRoomDetail)) {
            showToast(
              strings["error.occured"],
              strings["ime.scanner.batch.empty.msg"]
            );
            throw new Error("Batch No. required");
          } else if (
            (expiryDate == null || expiryDate == "") &&
            checkifExpiryEnabled(item, stockRoomDetail)
          ) {
            showToast(
              strings["error.occured"],
              strings["ime.scanner.expiry.date.empty.msg"]
            );
            throw new Error("Expiry Date required");
          } else if (actualQty == 0) {
            throw new Error(
              strings["ime.receive.stock.enter.quantity.greater.than.zero"]
            );
          }
        });
        if (
          checkifExpiryEnabled(item, stockRoomDetail) ||
          checkifBatchEnabled(item, stockRoomDetail)
        ) {
          batchProducts.push({
            batchNo: getBatchNo(item?.stockReceiptDetails?.id, sampleDataState),
            receivedBatchQty: getReceivedBatchQty(
              item?.stockReceiptDetails?.id,
              sampleDataState
            ),
            expiryDate: checkifExpiryEnabled(item, stockRoomDetail)
              ? getExpiryDate(item?.stockReceiptDetails?.id, sampleDataState)
              : null,
            newlyCreated: true,
          });
        }
      }

      batchProducts = batchProducts.filter((item) => item);
      let sumofReceivedBatchQty = batchProducts.reduce(
        (acc, item) => acc + parseInt(item.receivedBatchQty),
        0
      );
      let receivedQtyUnitStr = item?.remainingQuanityStr;
      let receivedQty = item?.receiveRemainingQty;
      let rejectedQty = item?.rejectedQtyStr;

      if (item?.remainingQuanityStr.includes("X")) {
        let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
        receivedQtyUnitStr = qtyArr[1];
        receivedQty = qtyArr[0];
      }

      if (item?.rejectedQtyStr.includes("X")) {
        let qtyArr = item?.rejectedQtyStr.replace(/\s+/g, "").split("X");
        rejectedQty = qtyArr[0];
      }
      return {
        id: `${item?.id}`,
        receivedQty:
          batchProducts.length > 0
            ? sumofReceivedBatchQty
            : Number(item?.newSelectedQty ?? receivedQty),
        // rejectedQty: Number(rejectedQty),
        rejectedQty: 0,
        receivedQtyUnitStr: Number(receivedQtyUnitStr),
        product: {
          id: item?.product?.id,
          batches: batchProducts,
        },

        ...(receiveStockArr?.stockReceiptDetails !== null && {
          stockReceiptId: item?.stockReceiptDetails?.id,
          // batchNo: getBatchNo(item?.stockReceiptDetails?.id, sampleDataState),
        }),
        ...(receiveStockArr?.stockReceiptDetails !== null &&
          item?.product?.batchManagementEnabled == 1 && {
            batchNo: getBatchNo(item?.stockReceiptDetails?.id, sampleDataState),
          }),
      };
    });

    const params = {
      orders: [
        {
          id: `${orderDetails?.orderId}`,
          orderLines: orderLines,
        },
      ],
    };
    dispatch(
      receiveStock(
        params,
        orderItemId,
        async (res: any, receiveStatus: string) => {
          receiveCallback(res?.data);
          successToast(
            receiveStockArr,
            orderLines,
            receiveStatus == "FULLY_RECEIVED"
              ? "Received Completely"
              : "Partially received"
          );
        },
        async (res: any) => {
          if (typeof res == "object") {
            let errorMessage = res;
            var errorArray = res.split(":");
            if (errorArray != null && errorArray.length > 1) {
              errorMessage = errorArray[1];
              showToast(strings["ime.receive.stock.validation"], errorMessage);
            } else {
              showToast(strings["error.occured"], res?.errorMessage);
            }
          } else {
            //Added by kiran DPIM - https://jira.vwr.com/browse/DPIM-4943 ====
            let errorMessage = res;
            var errorArray = res.split(":");
            if (errorArray != null && errorArray.length > 1) {
              errorMessage = errorArray[1];
            }
            // ==================
            showToast(strings["ime.receive.stock.validation"], errorMessage);
          }
        }
      )
    );
  } catch (e: any) {
    showToast(strings["error.occured"], e.message);
  }
};

const handleRejectStock = async (
  orderDetails: any,
  showToast: any,
  dispatch: (arg0: any) => void,
  rejectStock: any,
  reason: any,
  rejectCallback: any,
  strings: any,
  sampleDataState?: any,
  stockRoomDetail?: any
) => {
  let normalStockArr = orderDetails?.allOrderDetails
    .map((item: any) => {
      if (item?.selected) return item;
    })
    .filter((item: any) => item);

  let deliveryStockArr = orderDetails?.deliveryList
    .map((item: any) => {
      if (item?.selected) return item;
    })
    .filter((item: any) => item);

  let receiveStockArr = normalStockArr.concat(deliveryStockArr);
  try {
    const orderLines = receiveStockArr.map((item: any) => {
      let batchProducts: any[] = [];

      if (
        item.deliveryNoteNo == null &&
        item?.receiveBatchDetails?.length > 0
      ) {
        batchProducts = item?.receiveBatchDetails.map((batch: any) => {
          if (batch?.id?.includes("addedBatch")) {
            const { batchNo, actualQty, expiryDate } = batch;

            if (batchNo == "" && checkifBatchEnabled(item, stockRoomDetail)) {
              showToast(
                strings["error.occured"],
                strings["ime.scanner.batch.empty.msg"]
              );
              throw new Error("Batch No. required");
            } else if (
              expiryDate == "" &&
              checkifExpiryEnabled(item, stockRoomDetail)
            ) {
              showToast(
                strings["error.occured"],
                strings["ime.scanner.expiry.date.empty.msg"]
              );
              throw new Error("Expiry Date required");
            } else if (actualQty == 0) {
              showToast(
                strings["error.occured"],
                strings["ime.scanner.newbatches.empty.msg"] ??
                  "The New Batches can't have Qty as 0!"
              );
              throw new Error("Actual Qty required");
            }

            return {
              batchNo: batchNo ? batchNo : null,
              receivedBatchQty: actualQty,
              expiryDate: expiryDate
                ? moment(expiryDate).format("YYYY-MM-DDTHH:mm:ss.SSSZ")
                : null,
              newlyCreated: true,
            };
          }
        });
      } else if (item.deliveryNoteNo !== null) {
        batchProducts.push({
          batchNo: getBatchNo(item?.stockReceiptDetails?.id, sampleDataState),
          receivedBatchQty: getReceivedBatchQty(
            item?.stockReceiptDetails?.id,
            sampleDataState
          ),
          expiryDate: getExpiryDate(
            item?.stockReceiptDetails?.id,
            sampleDataState
          ),
          newlyCreated: true,
        });
      }

      batchProducts = batchProducts.filter((item) => item);
      let receivedQtyUnitStr = item?.remainingQuanityStr;
      let receivedQty = item?.receiveRemainingQty;
      let rejectedQty = item?.rejectedQtyStr;

      if (item?.remainingQuanityStr.includes("X")) {
        let qtyArr = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
        receivedQtyUnitStr = qtyArr[1];
        receivedQty = qtyArr[0];
      }

      if (item?.receivedQtyStr.includes("X")) {
        let qtyArr = item?.receivedQtyStr.replace(/\s+/g, "").split("X");
        rejectedQty = qtyArr[0];
      }

      return {
        id: `${item?.id}`,
        receivedQty:
          item?.newSelectedQty !== undefined
            ? Number(item?.newSelectedQty)
            : Number(receivedQty),
        rejectedQty:
          item?.newSelectedQty !== undefined
            ? Number(item?.newSelectedQty)
            : Number(receivedQty),
        // rejectedQty: Number(rejectedQty), //Done by ASwin
        receivedQtyUnitStr: Number(receivedQtyUnitStr),
        reasonCodeId: reason?.id,
        product: {
          id: item?.product?.id,
          batches: batchProducts,
        },
        // ...(orderDetails?.deliveryList?.length > 0 && {
        //   stockReceiptId:
        //     orderDetails?.deliveryList[0]?.stockReceiptDetails?.id,
        //   batchNo: getBatchNo(item?.stockReceiptDetails?.id, sampleDataState),
        // }),

        ...(receiveStockArr?.stockReceiptDetails !== null && {
          stockReceiptId: item?.stockReceiptDetails?.id,
          batchNo: getBatchNo(item?.stockReceiptDetails?.id, sampleDataState),
        }),
      };
    });

    const params = {
      orders: [
        {
          id: `${orderDetails?.orderId}`,
          orderLines: orderLines,
        },
      ],
    };
    dispatch(
      rejectStock(
        params,
        async (res: any) => {
          if (res?.data?.failedOrders) {
            showToast(
              strings["error.occured"],
              res?.data?.failureReason.replace(
                `${res?.data?.failedOrders}-`,
                ""
              )
            );
          } else {
            rejectCallback();
            showToast(
              strings["ime.scanner.stock.rejected.msg"] ?? "Stock Rejected",
              strings[
                "ime.receive.stock.selected.products.rejected.successfully"
              ]
            );
          }
        },
        async (res: any) => {
          showToast(strings["error.occured"], res?.data?.label);
        }
      )
    );
  } catch (e: any) {
    console.log(e.message);
  }
};

const handleAvailQty = async (
  val: any,
  id: any,
  orderDetails: any,
  setRecieveOrderDetails: (arg0: any) => any,
  dispatch: (arg0: any) => any,
  isDeliveryNote: boolean
) => {
  try {
    let data = orderDetails;
    let arr = isDeliveryNote
      ? orderDetails?.deliveryList
      : orderDetails?.allOrderDetails;
    let objIndex = arr?.findIndex((obj: { id: any }) => obj?.id == id);
    arr[objIndex]["receiveRemainingQty"] = val;
    await dispatch(setRecieveOrderDetails(data));
  } catch (err: any) {
    console.log(err.message);
  }
};

const handleBatches = async (
  batches: any,
  batchId: string,
  itemId: string,
  orderDetails: any,
  setRecieveOrderDetails: (arg0: any) => any,
  dispatch: (arg0: any) => any,
  isDel: boolean,
  deliveryNoteNo?: string
) => {
  try {
    let data = orderDetails;
    let arr = isDel
      ? orderDetails?.deliveryList
      : orderDetails?.allOrderDetails;

    let arrIndex = isDel
      ? arr?.findIndex(
          (obj: { id: string; deliveryNoteNo: string }) =>
            obj?.deliveryNoteNo == deliveryNoteNo && obj?.id == itemId
        )
      : arr?.findIndex((obj: { id: any }) => obj?.id == itemId);

    let batchIndex = batches?.findIndex(
      (obj: { id: any }) => obj?.id == batchId
    );

    const itemIndex = arr[arrIndex]?.receiveBatchDetails?.findIndex(
      (obj: { id: string }) => obj?.id == batchId
    );

    if (itemIndex >= 0) {
      await arr[arrIndex]?.receiveBatchDetails.map((obj: any) => {
        if (obj?.id == batchId) {
          obj["actualQty"] = batches[batchIndex]["actualQty"];
          obj["batchNo"] = batches[batchIndex]["batchNo"];
          obj["expiryDate"] = batches[batchIndex]["expiryDate"];
        }
      });
    } else {
      if (
        arr[arrIndex]?.receiveBatchDetails === null ||
        !Array.isArray(arr[arrIndex]?.receiveBatchDetails)
      ) {
        arr[arrIndex].receiveBatchDetails = [];
        arr[arrIndex]?.receiveBatchDetails?.push(batches[batchIndex]);
      } else {
        arr[arrIndex]?.receiveBatchDetails?.push(batches[batchIndex]);
      }
    }

    data[isDel ? "deliveryList" : "allOrderDetails"] = arr;

    await dispatch(setRecieveOrderDetails(data));
  } catch (err: any) {
    console.log(err.message, "2");
  }
};

function isQualityInspected(item: any) {
  if (item.isQualityInspected != null) {
    return item.isQualityInspected;
  }
  return false;
}

const handleBatchDelete = async (
  item: any,
  val: any,
  orderDetails: any,
  setRecieveOrderDetails: (arg0: any) => any,
  dispatch: (arg0: any) => any,
  productItem: any
) => {
  let data = orderDetails;
  let arr = orderDetails?.allOrderDetails;

  let objIndex = arr?.findIndex(
    (obj: { id: any }) => obj?.id == productItem?.id
  );

  const findIndex = arr[objIndex]?.receiveBatchDetails.findIndex(
    (obj: { id: any }) => obj?.id === val?.id
  );

  findIndex !== -1 && arr[objIndex]?.receiveBatchDetails.splice(findIndex, 1);

  data["allOrderDetails"] = arr;
  await dispatch(setRecieveOrderDetails(data));
};

export {
  setSelectAll,
  onSelectItems,
  handleRecieveStock,
  handleRejectStock,
  handleAvailQty,
  handleBatches,
  handleBatchDelete,
  isQualityInspected,
  selectItemsOnChange,
};
