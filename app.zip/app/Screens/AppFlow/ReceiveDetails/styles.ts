import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  reasonContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: SIZES.padding,
    marginTop: SIZES.padding,
  },
  contentContainerStyle: {
    flexGrow: 1,
    paddingHorizontal: wp(4),
    paddingBottom: hp(11),
  },

  mainTitle: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2_2,
    fontFamily: FONTFAMILY.averta_bold,
  },

  dateTime: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_regular,
  },

  tabsContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginVertical: hp(2),
  },

  tabBtnContainer: {
    padding: hp(0.5),
  },

  tabText: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_6,
    color: COLORS.abbey,
  },

  activeBtnContainer: {
    borderBottomWidth: 2,
    borderBottomColor: COLORS.scienceBlue,
    borderBottomStartRadius: wp(0.1),
    borderBottomEndRadius: wp(0.1),
  },

  activeTabText: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_6,
    color: COLORS.scienceBlue,
  },

  leftIconContainer: {
    marginRight: wp(4),
  },

  leftIcon: {
    width: wp(20),
    height: wp(20),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: COLORS.gray2,
  },

  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },

  catalogTitle: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
  },

  quantityInfoContainer: {
    paddingVertical: hp(0.5),
  },

  quantityInfoText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    alignSelf: "flex-start",
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
  },

  tagContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: hp(0.4),
  },

  checkboxSelection: { padding: wp(2) },

  rightIcon: { width: wp(6), height: wp(6) },

  flexRowContainer: {
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "center",
  },

  titleDateContainer: { flex: 0.8 },

  editContainer: {
    flex: 0.2,
    alignItems: "flex-end",
    justifyContent: "center",
  },

  selectAll: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_semibold,
    paddingHorizontal: wp(2),
  },

  headerSpacer: {
    marginTop: hp(2),
  },

  scannerBtn: { zIndex: 1, bottom: hp(13) },

  footerMainContainer: { bottom: hp(0) },

  footerBtnContainer: {
    width: wp(20),
    height: hp(6),
  },

  tertiaryBtnContainer: { marginRight: wp(1) },

  clearModalContainer: { height: SIZES.height * 0.2 },

  clearContainer: {
    flex: 1,

    justifyContent: "center",
    alignItems: "center",
  },

  clearOrderTitle: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h2,
    color: COLORS.black,
  },

  clearOrderDesc: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h2,
    color: COLORS.black,
    marginVertical: hp(1),
  },

  cancelContainer: {
    width: wp(45),
    marginTop: hp(1),
    marginLeft: 0,
    borderWidth: 0,
    // marginRight: wp(4),
  },

  cancelText: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    fontSize: FONTS.h2,
  },

  clearOrderContainer: {
    width: wp(30),
    marginTop: hp(1),
  },

  clearOrderText: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.white,
    fontSize: FONTS.h2,
  },

  btmSheetContainer: {
    borderTopLeftRadius: wp(3),
    borderTopRightRadius: wp(3),
    backgroundColor: COLORS.mineShaft,
  },

  toastContainer: { zIndex: 100 },

  // Product Detail
  bottomSheetContainerStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: SIZES.base,
    paddingBottom: SIZES.radius,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.whiteSmoke,
  },
  closeContainer: {
    position: "absolute",
    right: SIZES.base,
    paddingBottom: SIZES.radius,
    color: COLORS.scienceBlue,
    bottom: SIZES.tip * 0.3,
  },
  closeText: { ...FONTS.title, color: COLORS.scienceBlue },
  image: {
    height: SIZES.width * 0.225,
    width: SIZES.width * 0.225,
    // borderWidth: 1,
    // borderColor: COLORS.gray2,
  },
  stockTitle: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
    width: SIZES.width * 0.6,
  },

  selectAllNormalBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
  },
});
