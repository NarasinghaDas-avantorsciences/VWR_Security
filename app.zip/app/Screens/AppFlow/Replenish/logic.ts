import { saveDataToStorage } from "../../../Components/Subheader/logic";
import { Item } from "./index";

const changeQtyLogic = async (
  initialRecommendedData: any,
  dispatch: any,
  setUpdatedRecommendedData: any,
  index: number,
  value: string
) => {
  let sampleData = initialRecommendedData;
  sampleData[index].selectedQty = value;
  await dispatch(setUpdatedRecommendedData(sampleData));
};
const changeCommentLogic = async (
  initialRecommendedData: any,
  dispatch: any,
  setUpdatedRecommendedData: any,
  index: number,
  text: string
) => {
  let sampleData = initialRecommendedData;
  sampleData[index].enteredComment = text;
  await dispatch(setUpdatedRecommendedData(sampleData));
};

const deleteProduct = async (
  initialRecommendedData: any,
  dispatch: any,
  setUpdatedRecommendedData: any,
  data: Item,
  changeStateToDefault: any
) => {
  const filteredItems = initialRecommendedData.filter(
    (item: Item) => item.id !== data?.id
  );
  if (filteredItems.length == 0) {
    changeStateToDefault();
  }
  await dispatch(setUpdatedRecommendedData(filteredItems));
};

const getFooterButtonText = (replenishPrivilege: string, strings: any) => {
  if (replenishPrivilege == "request") {
    return strings["request.order"];
  } else {
    return strings["replenish"];
  }
};

const resetStates = (
  setClearModal: any,
  onSearch: any,
  setSelectAll: any,
  setTapOnAddtoOrder: any,
  setShowVWR: any,
  setIsCorrected: any,
  setIsCShowSubSearch: any,
  setUpdatedRecommendedData: any
) => {
  setClearModal(false);
  onSearch("");
  setSelectAll();
  setTapOnAddtoOrder(false);
  setShowVWR(true);
  setIsCorrected(false);
  setIsCShowSubSearch(false);
  setUpdatedRecommendedData([]);
};

const resetOfflineStates = (
  setOfflineProducts: any,
  setCurrentOfflineProductsIndex: any,
  setMatchFoundProducts: any,
  setOfflineBatchProducts: any,
  setMatchNotFoundProducts: any,
  setIsBatchSaved: any,
  showOfflineCollection: any,
  internet: any,
  setIsReplenishUpdating: any,
  setOfflineDuplicateProducts?: any
) => {
  setOfflineProducts([]);
  setCurrentOfflineProductsIndex(null);
  setMatchFoundProducts([]);
  setOfflineBatchProducts([]);
  setMatchNotFoundProducts([]);
  setIsBatchSaved(false);
  showOfflineCollection(!internet);
  setIsReplenishUpdating(false);
  setOfflineDuplicateProducts(null);
};

const handleFooterNavigation = async (
  initialRecommendedData: Item[],
  replenishPrivilege: string,
  userData: { id: string },
  dispatch: any,
  replenishRequestOrder: any,
  setCorrectStockList: any,
  setCheckoutFilteredData: any,
  setNavigatedRoute: any,
  setVisibleCheckout: any,
  setUpdatedRecommendedData: any,
  getUserPrice:any,
  changeStateToDefault: any,
  navigation: any,
  showToast: any,
  Strings: any
) => {
  let isFilteredData = initialRecommendedData.filter(
    (item: Item) =>
      item.selected === true &&
      (item?.selectedQty ?? parseInt(item?.orderedQuantity)) > 0
  );
  if (replenishPrivilege === "request") {
    let replenishProducts = initialRecommendedData
      .filter((item: Item) => item.selected === true)
      .map((item: Item) => ({
        id: item.id,
        qty: item.selectedQty,
        type: item.type,
        comment: item.enteredComment,
      }));

    let replenishReqParams = {
      selectedUserId: userData?.id,
      replenishProducts: replenishProducts,
    };

    await dispatch(
      replenishRequestOrder(
        replenishReqParams,
        async (res: any) => {
          if (res.status == "200") {
            await dispatch(setCorrectStockList([]));
            await saveDataToStorage("replenish_offline_data", []);

            showToast(
              Strings["ime.scanner.replenish.request.alert.title"] ??
                "REPLENISH REQUESTED!",
              Strings["ime.scanner.replenish.request.success.msg"] ??
                "The selected products were requested successfully!",
              () => {
                setUpdatedRecommendedData([]);
                changeStateToDefault();
                navigation.navigate("Dashboard");
              },
              res?.data?.data,
              true
            );
          }
        },
        async (res: any) => {
          showToast(Strings["ime.scanner.error.occured.msg"], res?.data?.label);
        }
      )
    );
  } else {
    if (isFilteredData?.length > 0) {
      setCheckoutFilteredData(isFilteredData);
      setNavigatedRoute("CheckoutScreen");
      const replenishProductsData = isFilteredData?.map((item: { id: any, selectedQty?: any }) => ({
        id: item.id,
        qty: item.selectedQty,
      }));
     dispatch(getUserPrice(replenishProductsData));
      setVisibleCheckout(true);
    } else {
      showToast("Error", "Please check quantity.");
    }
  }
};

export {
  changeQtyLogic,
  changeCommentLogic,
  deleteProduct,
  getFooterButtonText,
  handleFooterNavigation,
  resetStates,
  resetOfflineStates,
};
