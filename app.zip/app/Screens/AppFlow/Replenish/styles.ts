import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  scannerBtn: { bottom: hp(12) },

  contentContainerStyle: {
    flexGrow: 1,
    paddingHorizontal: wp(4),
    paddingBottom: hp(6),
  },

  mainBtnTextStyle: { fontSize: FONTS.h1_7, color: COLORS.scienceBlue },

  buttonStyle: {
    width: "100%",
    marginBottom: hp(2),
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.blue,
  },

  subHeaderTextContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 6,
  },

  itemChildHeaderText: {
    fontSize: FONTS.h1_7,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    alignItems: "center",
  },

  recomentedText: { ...FONTS.title2, fontSize: FONTS.h2, lineHeight: 20 },

  selectDeselectText: {
    ...FONTS.title2,
    fontSize: FONTS.h1_5,
    marginHorizontal: wp(2),
  },

  dataContainer: { paddingBottom: hp(10) },

  leftIconContainer: { marginRight: wp(4) },

  leftIcon: {
    width: wp(18),
    height: wp(18),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: COLORS.gray2,
  },

  flexRowCenter: { flexDirection: "row", alignItems: "center" },

  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },

  tagContainer: { marginHorizontal: wp(2) },

  openOrderContainer: {
    borderWidth: 1,
    borderRadius: wp(10),
    borderColor: COLORS.chelseaGem3,
    backgroundColor: COLORS.sandyBeach,
    paddingHorizontal: wp(2),
  },

  openOrder: {
    color: COLORS.chelseaGem,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },

  qtyInfoContainer: { paddingVertical: hp(0.8), alignSelf: "flex-start" },

  itemSubHeaderStyle: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
  },

  itemContainerStyle: {
    marginVertical: hp(1.8),
    borderBottomWidth: 1,
    paddingBottom: hp(1),
    borderColor: COLORS.whiteSmoke,
  },

  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  itemChildContainer: {
    width: SIZES.width * 0.4,
    marginVertical: wp(0.5),
    paddingVertical: 8,
  },

  commentInputStyle: {
    width: wp(42),
    alignSelf: "flex-start",
    backgroundColor: COLORS.white,
    marginRight: wp(4),
  },

  inputStyle: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h1_5,
    color: COLORS.abbey,
    left: -wp(2),
  },

  inputMainStyle: {
    height: hp(4),
    top: 0,
    borderColor: COLORS.gray2,
    borderWidth: 0.8,
  },

  qtyTitleStyle: { marginRight: wp(3) },

  bottomSheetContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: SIZES.base,
    paddingVertical: SIZES.radius,
    borderBottomWidth: 1,
    borderTopWidth: 1,
    borderBottomColor: COLORS.whiteSmoke,
    borderTopColor: COLORS.whiteSmoke,
    backgroundColor: COLORS.white,
  },

  stockTitle: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
    width: SIZES.width * 0.62,
    marginRight: SIZES.width * 0.03,
    textAlign: "center",
  },

  closeContainer: {
    right: SIZES.base,
    color: COLORS.scienceBlue,
  },

  selectedItemContainer: {
    paddingBottom: hp(10),
    paddingHorizontal: wp(5),
  },

  selectedItemContainerStyle: {
    marginVertical: hp(1.8),
    paddingBottom: hp(1),
  },

  commentMain: {
    marginTop: hp(5),
  },

  selectedItemButtonContainer: {
    marginVertical: wp(0.5),
    paddingVertical: 8,
    justifyContent: "space-around",
  },

  buttonsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: SIZES.base,
  },

  mainText: { ...FONTS.title, color: COLORS.white },

  inactiveOpacity: {
    opacity: 0.5,
    backgroundColor: COLORS.gray4,
  },

  disabledOpacity: {
    opacity: 0.5,
  },

  footerMainContainer: { bottom: 0 },

  outlinedBtnText: { color: COLORS.gray },

  outlinedBtnContainer: { borderWidth: 0 },

  emptyContainer: { alignItems: "center", justifyContent: "center" },

  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },
});
