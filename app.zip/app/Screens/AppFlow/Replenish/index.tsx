import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  View,
  Image,
  Keyboard,
  TouchableOpacity,
  Platform,
  Pressable,
  BackHandler,
} from "react-native";
import { Toast } from "react-native-toast-message/lib/src/Toast";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { useDispatch, useSelector } from "react-redux";
import {
  useFocusEffect,
  useIsFocused,
  useNavigation,
  useRoute,
} from "@react-navigation/native";
import {
  AddVwrProduct,
  AnimatedSearch,
  BottomSheetComponent,
  ClearSelectionAlert,
  Footer,
  Header,
  ListItem,
  Loader,
  MainButton,
  ProductDetails,
  ProductInfoDetails,
  QtyController,
  ReplenishListItem,
  ScannerButton,
  SubSearchComponent,
  Subheader,
  SwipableItem,
  TextInputComponent,
  ToastComponent,
} from "../../../Components";
import Text from "../../../Components/CustomText";
import ReplenishCheckoutScreen from "../ReplenishCheckoutScreen";
import ReplenishStockCorrection from "../ReplenishStockCorrection";
import {
  actionTypes,
  addItemsToOrderList,
  clearAddVwrStockRoomData,
  getInitialRecommendedProducts,
  getUserPrice,
  replenishRequestOrder,
  resetPriceState,
  setLoader,
  setUpdatedRecommendedData,
} from "../../../Redux/Action/replenishAction";
import {
  emptyProductData,
  getProductDetails,
  getProductList,
  getProductListFromBarcode,
  setProductLoader,
} from "../../../Redux/Action/searchAction";
import { setCorrectStockList } from "../../../Redux/Action/stockCorrection";
import * as storage from "../../../Service/AsyncStoreConfig";
import {
  Checkbox,
  DefaultProductImage,
  Locked,
  Search,
  Unselected,
} from "../../../Utils/images";
import { COLORS, SIZES } from "../../../Utils/theme";
import {
  checkUomCondition,
  hp,
  isDeviceTablet,
  wp,
  isReplenishProductFreezed,
  getReplenishReceiptRequest,
} from "../../../Utils/globalFunction";
import { useDebounceHook } from "../../../Hooks";
import {
  changeCommentLogic,
  changeQtyLogic,
  deleteProduct,
  getFooterButtonText,
  handleFooterNavigation,
  resetStates,
} from "./logic";
import styles from "./styles";
import OfflineToast from "../../../Components/Offline";
import ConfirmationAlert from "../../../Components/ConfirmationPopup";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import RNHTMLtoPDF from "react-native-html-to-pdf";
import ReactNativeBlobUtil from "react-native-blob-util";
import { ModalToast } from "../../../Components/ModalToast";

export type Item = {
  id: string;
  title: string;
  selected: boolean;
  description: string;
  catalogNo: string;
  uomId: string;
  imageURL: string | null;
  vendorName: string;
  locationName: string;
  maxStockQty: string;
  backlogQty: string;
  type: string;
  orderedQuantity: string;
  availableQty?: number;
  selectedQty?: number;
  enteredComment?: string;
  freeze?: boolean;
  purchasePrice?: number | undefined;
  uomManagementEnabled?: number;
  stockRoomUOMUnit?: string;
  kpiEnabled?: boolean;
  orderedQtyUOMDisplay?: string;
  maxStockQtyForDisplay?: any;
  vendorUOMUnit?: string;
};

const Replenish = (props: any) => {
  const isTablet = isDeviceTablet();
  const dispatch = useDispatch<any>();
  const navigation = useNavigation<any>();
  const routes = useRoute();
  const [selectedSearchItemIndex, setSelectedSearchItemIndex] = useState(0);
  const [clearModal, setClearModal] = useState(false);
  const [navigatedRoute, setNavigatedRoute] = useState("");
  const [searchKey, setSearchKey] = useState("");
  const [tapOnAddtoOrder, setTapOnAddtoOrder] = useState(false);
  const [showVWR, setShowVWR] = useState(true);
  const [isCShowSubSearch, setIsCShowSubSearch] = useState(false);
  const [isSelectedAll, setIsSelectedAll] = useState(true);
  const [filterText, setFilterText] = useState("");
  const [isCorrected, setIsCorrected] = useState(false);
  const [quantity, setQuantity] = useState(0);
  const [searchBarcode, setSearchBarcode] = useState(false);
  const [modalData, setModalData] = useState({
    title: "",
    description: "",
    isSaveReceipt: false,
    onPress: () => {},
  });
  const [visibleCheckout, setVisibleCheckout] = useState(false);
  const [isFilteredCheckoutData, setCheckoutFilteredData] = useState<any>();
  const [selectedSearchItem, setSelectedSearchItem] = useState<Item | null>(
    null
  );
  const { correctStockList } = useSelector(
    (state: any) => state.stockCorrectionReducer
  );
  const [isShowToasReft, setIsShowToast] = useState(false);

  const [flag, setFlag] = useState(0);
  const { internet } = useSelector((state: any) => state.loginReducer);
  const [count, setCount] = useState(10);
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const profileData = useSelector((state: any) => state.accountReducer?.data);
  const productsData = useSelector(
    (state: any) => state.searchReducer?.searchList
  );
  const { initialRecommendedData, addVwrToStockroomData, isLoading } =
    useSelector((state: any) => state.replenishReducer);
  const { productDetailsLoading, productDetails } = useSelector(
    (state: any) => state.searchReducer
  );
  const {
    replenishPrivilege,
    stockRoomDetail,
    isOnHand,
    isPutAway,
    isConsumption,
    confirmationAlertInfo,
    selectedTitle,
    selectedSubTitle,
    soldToNumber,
    shipToNumber,
  } = useSelector((state: any) => state.userReducer);
  //itemDetailsRef2
  const itemDetailsRef2 = useRef<any>(null); //productdetail page add to list
  const itemDetailsRef = useRef<any>(null); //productdetail page
  const refRBSheet_addVWR = useRef<any>();
  const bottomSheetRef = useRef<any>(null);
  const debouncedSearchTerm = useDebounceHook(searchKey, 800);
  const [isKPI, setIsKPI] = useState(false);
  const [timeString, setTimeString] = useState("h:mm:ss A");
  const isFocused = useIsFocused();
  const { dateFormat, timeFormat } = useSelector(
    (state: any) => state.userReducer
  );
  const [isLoadingData, setIsLoading] = useState(false);
  const { currency } = useSelector((state: any) => state.userReducer);

  const getStockLevelData = async () => {
    await storage.getItem("stocklevel").then((res: any) => {
      dispatch(setCorrectStockList(JSON.parse(res)));
    });
  };

  useEffect(() => {
    if (timeFormat?.toUpperCase() == "24Hours".toUpperCase())
      setTimeString("H:mm:ss");
    else setTimeString("h:mm:ss A");
  }, []);
  
  useEffect(() => {
    const backAction = async () => {
      let asyncData;
      await storage.getItem("replenishCount").then((res) => {
        asyncData = res;
      });
      console.log(Number(asyncData), "..");
      if (Number(asyncData) > 0) {
        dispatch(
          setIsShowConfirmationAlert({
            isShow: true,
            data: confirmationAlertInfo?.data,
          })
        );
      } else {
        props.navigation.navigate("Dashboard");
      }
      return true;
    };

    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );

    return () => backHandler.remove();
  }, []);
  // useEffect(() => {
  //   const backHandler = BackHandler.addEventListener(
  //     "hardwareBackPress",
  //     backAction
  //   );
  //   return () => backHandler.remove();
  // }, []);
  // const backAction = () => {
  //   props.navigation.navigate("Dashboard");
  //   return true;
  // };

  useFocusEffect(
    useCallback(() => {
      setIsSelectedAll(true);
      if (searchKey === "") {
        if (props?.route?.params?.fromScreen == "stockLevel") {
          // setShowVWR(false); DPIM-5125
          setShowVWR(true);
        } else {
          setShowVWR(true);
        }
      }
      if (props?.route?.params?.fromScreen == "stockLevel") {
        // setIsKPI(true);
        // setShowVWR(false); DPIM-5125
        setShowVWR(true);
        if (isOnHand) {
          getStockLevelData();
          setIsCorrected(false);
          setIsKPI(true);
          // dispatch(
          //   addItemsToOrderList(props?.route?.params?.data, [], "array")
          // );
        }
        if (isConsumption) {
          getRecommendedData();
          setTapOnAddtoOrder(true);
          setSearchKey("");
          setIsSelectedAll(true);
        } else if (isPutAway) {
          dispatch(setUpdatedRecommendedData(props?.route?.params?.data));
          setTapOnAddtoOrder(true);
        }
      } else if (props?.route?.params?.fromScreen == "ReplenishOffline") {
        setShowVWR(true);
        if (isOnHand) {
          getofflineData(); // Added for DPIM - 5090
          setIsCorrected(false);
          // dispatch(
          //   addItemsToOrderList(props?.route?.params?.data, [], "array")
          // );
        }
        if (isConsumption) {
          getRecommendedData();
          setTapOnAddtoOrder(true);
          setSearchKey("");
          setIsSelectedAll(true);
        } else if (isPutAway) {
          // dispatch(setUpdatedRecommendedData(props?.route?.params?.data));
          setTapOnAddtoOrder(true);
        }
      } else if (isConsumption) {
        setIsKPI(false);
        getRecommendedData();
        setIsCorrected(false);
        setTapOnAddtoOrder(false);
      } else {
        setTapOnAddtoOrder(false);
        setIsCorrected(false);
        dispatch(setUpdatedRecommendedData([]));
        dispatch(setCorrectStockList([]));
      }
    }, [props?.route?.params?.fromScreen])
  );

  const getofflineData = async () => {
    let offlineData: any[] = [];

    await storage.getItem("offlineData").then((res: any) => {
      offlineData = JSON.parse(res);
    });

    await dispatch(
      getInitialRecommendedProducts(
        props?.route?.params?.fromScreen,
        props?.route?.params?.fromScreen == "ReplenishOffline"
          ? offlineData
          : []
      )
    );
    await storage.removeData("stocklevel");
  };

  useFocusEffect(
    useCallback(() => {
      if (addVwrToStockroomData !== null && initialRecommendedData !== null) {
        let findIndex =
          initialRecommendedData &&
          initialRecommendedData?.findIndex(
            (item: any) => item.catalogNo == addVwrToStockroomData.catalogNo
          );

        let addVwrList: any = [];
        if (findIndex == -1) {
          addVwrList = [
            ...initialRecommendedData,
            { ...addVwrToStockroomData, selected: true, type: "ONETIME" },
          ];
        } else {
          let data = initialRecommendedData;
          data[findIndex].selectedQty = addVwrToStockroomData.selectedQty;
          addVwrList = data;
        }

        dispatch(setUpdatedRecommendedData(addVwrList));
        setTapOnAddtoOrder(true);
        setShowVWR(true);
        dispatch(clearAddVwrStockRoomData());
      }

      if (addVwrToStockroomData == null && initialRecommendedData == null) {
        let addVwrList = [
          { ...addVwrToStockroomData, selected: true, type: "ONETIME" },
        ];
        dispatch(setUpdatedRecommendedData(addVwrList));
        setTapOnAddtoOrder(true);
        setShowVWR(true);
        dispatch(clearAddVwrStockRoomData());
      }
    }, [addVwrToStockroomData])
  );
  useEffect(() => {
    if (!internet) {
      const state = navigation.getState();
      const routeName = state.routes?.[state.index]?.name;
      if (routeName == "Replenish") {
        if (initialRecommendedData.length) {
          navigation.navigate("Dashboard");
        } else navigation.navigate("ReplenishOffline");
      }
    }
  }, [internet]);
  useEffect(() => {
    if (debouncedSearchTerm) {
      dispatch(getProductList(debouncedSearchTerm));
    } else {
      dispatch(setProductLoader(false));
    }
  }, [debouncedSearchTerm]);

  useEffect(() => {
    const unsubscribe = props.navigation.addListener("focus", () => {
      setSearchKey("");
      Keyboard.dismiss();
    });
    return unsubscribe;
  }, [initialRecommendedData]);

  useFocusEffect(
    useCallback(() => {
      dispatch(setIsShowConfirmationAlert({}));
      if (props?.route?.params?.fromScreen == undefined)
        setTapOnAddtoOrder(false);
      if (isConsumption && navigatedRoute !== "CheckoutScreen")
        if (isCorrected && tapOnAddtoOrder) {
          getRecommendedData();
          setIsCorrected(false);
          setTapOnAddtoOrder(false);
        }

      setSelectedSearchItem(null);
      setSelectedSearchItemIndex(0);

      return async () => {
        await dispatch(setUpdatedRecommendedData([]));
        await dispatch(emptyProductData());
      };
    }, [])
  );

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      handleKeyboardDidShow
    );
    const keyboardDidHideListener = Keyboard.addListener(
      "keyboardDidHide",
      handleKeyboardDidHide
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, [showVWR]);

  const handleKeyboardDidShow = (event: KeyboardEvent) => {};
  const handleKeyboardDidHide = (event: KeyboardEvent) => {
    Keyboard.dismiss();
  };

  const getRecommendedData = async () => {
    dispatch(setLoader(true));
    let stocklevelData: any[] = [];
    let offlineData: any[] = [];
    await storage.getItem("stocklevel").then((res: any) => {
      stocklevelData = JSON.parse(res);
    });

    await storage.getItem("offlineData").then((res: any) => {
      offlineData = JSON.parse(res);
    });

    await dispatch(
      getInitialRecommendedProducts(
        props?.route?.params?.fromScreen,
        props?.route?.params?.fromScreen == "ReplenishOffline"
          ? offlineData
          : stocklevelData
      )
    );
    await storage.removeData("stocklevel");
    setIsSelectedAll(true);
  };

  const onSearch = (text: string) => {
    setSearchKey(text);
    if (text?.length > 0 || tapOnAddtoOrder) setShowVWR(false);
    else {
      if (props?.route?.params?.fromScreen == "stockLevel") {
        setShowVWR(false);
      } else {
        setShowVWR(true);
      }
    }
  };

  const setSelectAll = async () => {
    initialRecommendedData.map((item: Item) => {
      const isFrozen = isReplenishProductFreezed(item);
      item.selected = isFrozen ? false : !isSelectedAll;
    });

    setIsSelectedAll(!isSelectedAll);
  };

  const onSelectItems = async (data: any, index: number) => {
    let sampleData = initialRecommendedData;
    sampleData[index].selected = !sampleData[index]?.selected;
    await dispatch(setUpdatedRecommendedData(sampleData));
    const filteredArr = sampleData.filter((obj: any) => obj.selected == true);
    const freezItems = sampleData.filter(
      (obj: any) => isReplenishProductFreezed(obj) == true
    );
    if (
      filteredArr?.length + freezItems?.length ==
      initialRecommendedData?.length
    )
      setIsSelectedAll(true);
    else setIsSelectedAll(false);
  };

  const onChangeComment = async (text: string, index: number) => {
    changeCommentLogic(
      initialRecommendedData,
      dispatch,
      setUpdatedRecommendedData,
      index,
      text
    );
  };

  const changeQty = async (value: string, index: number) => {
    changeQtyLogic(
      initialRecommendedData,
      dispatch,
      setUpdatedRecommendedData,
      index,
      value
    );
  };

  const getQtyValue = (item: Item | any) => {
    if (isOnHand && isCorrected) {
      if (item?.kpiEnabled == true) {
        return String(item?.selectedQty ?? item?.orderedQuantity);
      } else {
        if (item?.selectedQty) {
          return String(item?.selectedQty ?? item?.orderedQuantity);
        } else {
          if (item?.selectedQty == "") {
            return "0";
          } else {
            return item?.maxStockQty - (item?.actualQty ?? 0) <= 0
              ? "0"
              : String(item.maxStockQty - (item?.actualQty ?? 0));
          }
        }
      }
    } else {
      return String(item?.selectedQty ?? item?.orderedQuantity);
    }
  };

  const updateChekbox = async (value: string, item: any, index: number) => {
    let sampleData = initialRecommendedData;
    sampleData[index].selected = value == "0" ? false : true;
    await dispatch(setUpdatedRecommendedData(sampleData));
    const filteredArr = sampleData.filter((obj: any) => obj.selected == true);
    const freezItems = sampleData.filter(
      (obj: any) => isReplenishProductFreezed(obj) == true
    );
    if (
      filteredArr?.length + freezItems?.length ==
      initialRecommendedData?.length
    )
      setIsSelectedAll(true);
    else setIsSelectedAll(false);
  };

  const getProductFromApi = async (searchKey: any) => {
    dispatch(
      getProductListFromBarcode(
        searchKey,
        1,
        (res: any) => {
          // if (res?.data[0]?.catalogNo == searchKey) {
          if (
            res?.data[0]?.catalogNo == searchKey ||
            res?.data[0]?.vendorCatalogNo == searchKey ||
            res?.data[0]?.custCatalogNo == searchKey
          ) {
            renderItemFromBarcode(res?.data[0]);
          } else {
            Toast.show({
              type: "alertToast",
              text1: strings["ime.scanner.error.occured.msg"],
              text2: "Product does not exist!",
              position: "bottom",
              bottomOffset: SIZES.padding * 2,
            });
            dispatch(setLoader(false));
          }
        },
        (res: any) => {
          dispatch(setLoader(false));

          console.log(res);
        }
      )
    );
  };
  const renderItemFromBarcode = async (item: any) => {
    setSearchBarcode(true);
    item["selectedQty"] = parseInt(item?.orderedQuantity);
    setSelectedSearchItem(item);
    await bottomSheetRef.current?.open();
    setQuantity(parseInt(item?.orderedQuantity));
    setSelectedSearchItemIndex(0);
    dispatch(setLoader(false));
  };

  const renderItem = (item: any, index: number) => {
    return (
      <SwipableItem
        key={index}
        id={item.id}
        onPressRight={() => tapOnDelete(item)}
      >
        <ReplenishListItem
          disabled={true}
          item={item}
          onPressItemDescription={async () => {
            itemDetailsRef?.current?.open();
            await dispatch(getProductDetails(item?.id));
            dispatch(setProductLoader(false));
          }}
          onPressItemCheckbox={() => onSelectItems(item, index)}
          onChangeComment={(text: string) => onChangeComment(text, index)}
          onChangeQty={(v: string) => {
            changeQty(v, index);
            updateChekbox(v, item, index);
          }}
          inputQtyValue={getQtyValue(item)}
          index={index}
        />
      </SwipableItem>
    );
  };

  const productInfo = (item: Item) => {
    return (
      <ProductInfoDetails
        vendorName={item?.vendorName}
        locationName={item?.locationName ?? "-"}
        requiredQty={item?.maxStockQty ?? "-"}
        transitQty={item?.backlogQty ?? "-"}
      />
    );
  };

  const renderItemHeader = (item: Item, isSearch: boolean = false) => {
    return (
      <>
        <Text
          style={styles.catalogNumber}
          accessibilityLabel="product-catalog-number"
        >
          {item?.catalogNo}
        </Text>
        {!isSearch ? (
          <TouchableOpacity
            onPress={async () => {
              // this header is also showing the add product bottom sheet header,
              // issue in showing productdetails in Add to list sheet need to resolve.
              itemDetailsRef2?.current?.open();
              await dispatch(getProductDetails(item?.id));
              dispatch(setProductLoader(false));
            }}
          >
            <Text
              style={styles.itemHeaderContent}
              accessibilityLabel="product-description"
            >
              {item?.description}
            </Text>
          </TouchableOpacity>
        ) : (
          <Text
            style={styles.itemHeaderContent}
            accessibilityLabel="product-description"
          >
            {item?.description}
          </Text>
        )}

        {checkUomCondition(item) && (
          <View
            style={styles.qtyInfoContainer}
            accessibilityLabel="product-unit-container"
          >
            <Text
              style={styles.itemSubHeaderStyle}
              accessibilityLabel="product-unit"
            >
              {item?.uomManagementEnabled == 1
                ? item.stockRoomUOMUnit !== null
                  ? `(${item.stockRoomUOMUnit})`
                  : ""
                : item.uomId !== null
                ? `(${item.uomId})`
                : ""}
            </Text>
          </View>
        )}
      </>
    );
  };

  const addToOrder = async (data: Item) => {
    setSearchKey("");
    setTapOnAddtoOrder(true);
    setShowVWR(true);
    await dispatch(setLoader(true));
    await dispatch(addItemsToOrderList(data, initialRecommendedData, "object"));
    await dispatch(emptyProductData());
    bottomSheetRef.current.close();
  };
  useFocusEffect(
    useCallback(() => {
      dispatch(emptyProductData());
    }, [searchKey == ""])
  );

  const selectedItemOrderQty = (item: any) => {
    return String(item?.orderedQuantity);
  };

  const renderSelectedItem = (item: any, index: number) => {
    return (
      <ListItem
        key={index}
        //onPress={() => bottomSheetRef.current.open()}
        leftIcon={
          <View
            style={styles.leftIconContainer}
            accessible={true}
            accessibilityLabel="seletedItem-Image-container"
          >
            {item?.imageURL ? (
              <Image
                source={{ uri: item.imageURL.replace("http://", "https://") }}
                style={styles.leftIcon}
                resizeMode={"contain"}
                accessible={true}
                accessibilityLabel="selectedItem-Image"
              />
            ) : (
              <DefaultProductImage width={wp(18)} height={wp(18)} />
            )}
          </View>
        }
        headerContent={renderItemHeader(item)}
        customStyles={{ container: styles.selectedItemContainerStyle }}
        rightIcon={
          isReplenishProductFreezed(item) && (
            <Locked
              accessible={true}
              accessibilityLabel="replenish-listitem-locked-image"
            />
          )
        }
      >
        <View
          style={styles.flexRowContainer}
          accessible={true}
          accessibilityLabel="seletedItem-commentInput-container"
        >
          {productInfo(item)}
          {stockRoomDetail?.isCommentsEnabled && (
            <TextInputComponent
              title={strings["comment"]}
              disableRightIcon={true}
              disableLeftIcon={true}
              placeholder={
                strings["ime.scanner.enter.comment"] ?? "Enter comment"
              }
              editable={true}
              onChangeText={(text: string) => (item["enteredComment"] = text)}
              inputStyle={styles.inputStyle}
              inputMain={styles.inputMainStyle}
              main={styles.commentMain}
            />
          )}
        </View>
        <View
          style={[styles.selectedItemButtonContainer, styles.flexRowCenter]}
          accessible={true}
          accessibilityLabel="seletedItem-button-container"
        >
          <QtyController
            inputValue={selectedItemOrderQty(item)}
            onChange={(v: string) => {
              item["selectedQty"] = v;
              setQuantity(parseInt(v));
            }}
            titleStyle={styles.qtyTitleStyle}
          />
          <View
            style={styles.buttonsContainer}
            accessible={true}
            accessibilityLabel="addToOrder-button"
          >
            <MainButton
              title={strings["ime.add.to.order"] ?? "Add to Order"}
              buttonTextStyle={styles.mainText}
              onChangeBtnPress={() => addToOrder(item)}
              buttonStyle={
                (quantity == 0 || isReplenishProductFreezed(item)) &&
                styles.inactiveOpacity
              }
              disabled={
                quantity == 0
                  ? true
                  : isReplenishProductFreezed(item)
                  ? true
                  : false
              }
            />
          </View>
        </View>
        <ProductDetails
          itemDetailsRef={itemDetailsRef2}
          productDetailsList={productDetails}
          isShowPrice={stockRoomDetail?.isReplishIndividual}
        />
      </ListItem>
    );
  };

  const productBottomSheet = (data: Item, index: number) => {
    return (
      <BottomSheetComponent
        height={SIZES.height - (isTablet ? SIZES.padding : SIZES.padding * 2)}
        bottomSheetRef={bottomSheetRef}
      >
        <Header
          title={
            data?.description.length > 20
              ? data?.description.slice(0, 19) + "..."
              : data?.description
          }
          titleStyle={styles.stockTitle}
          container={styles.bottomSheetContainer}
          onRightIconPress={() => {
            setSearchBarcode(false);
            bottomSheetRef.current?.close();
          }}
          statusBar={false}
          statusBarContainerStyle={Platform.OS === "android" && { height: 0 }}
          statusBarColor={COLORS.white}
          iconLeft={false}
          iconRight={true}
          RightIcon={() => (
            <Text style={styles.closeContainer}>{strings["close"]}</Text>
          )}
        />
        {!internet && (
          <View
            style={{
              alignItems: "center",
            }}
          >
            <OfflineToast login={false} />
          </View>
        )}
        <View
          style={styles.selectedItemContainer}
          accessible={true}
          accessibilityLabel="selectedItem-container"
        >
          {renderSelectedItem(data, index)}
        </View>
      </BottomSheetComponent>
    );
  };

  const renderSearchItems = (item: Item, index: number) => {
    return (
      <ListItem
        key={index}
        onPress={async () => {
          item["selectedQty"] = parseInt(item?.orderedQuantity);
          setSelectedSearchItem(item);
          setQuantity(parseInt(item?.orderedQuantity));
          setSelectedSearchItemIndex(index);
          await bottomSheetRef.current?.open();
        }}
        leftIcon={
          <View
            style={styles.leftIconContainer}
            accessible={true}
            accessibilityLabel="searchProduct-Image-container"
          >
            {item?.imageURL ? (
              <Image
                source={{ uri: item.imageURL.replace("http://", "https://") }}
                style={styles.leftIcon}
                resizeMode={"contain"}
                accessible={true}
                accessibilityLabel="searchProduct-Image"
              />
            ) : (
              <DefaultProductImage width={wp(18)} height={wp(18)} />
            )}
          </View>
        }
        headerContent={renderItemHeader(item, true)}
        customStyles={{ container: styles.itemContainerStyle }}
        rightIcon={
          isReplenishProductFreezed(item) && (
            <Locked
              accessible={true}
              accessibilityLabel="searchProduct-item-locked-image"
            />
          )
        }
      >
        <View
          style={styles.flexRowContainer}
          accessible={true}
          accessibilityLabel="searchProduct-info"
        >
          {productInfo(item)}
        </View>
        {selectedSearchItem &&
          productBottomSheet(selectedSearchItem, selectedSearchItemIndex)}
      </ListItem>
    );
  };

  const tapOnDelete = async (data: Item) => {
    deleteProduct(
      initialRecommendedData,
      dispatch,
      setUpdatedRecommendedData,
      data,
      changeStateToDefault
    );
  };

  const _renderList = () => {
    let isShow = searchKey?.length > 0;
    if (!isShow && !(isOnHand || isPutAway)) {
      let data = initialRecommendedData;
      let filteredData =
        data &&
        data?.filter(
          (item: Item) =>
            item?.description
              .toLowerCase()
              .includes(filterText.toLowerCase()) ||
            item?.catalogNo.toLowerCase().includes(filterText.toLowerCase()) ||
            item?.vendorName.toLowerCase().includes(searchKey.toLowerCase())
        );

      if (filteredData?.length == 0) {
        setTimeout(() => {
          return (
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>
                {strings["no.records.found"]}
              </Text>
            </View>
          );
        }, 2000);
      } else {
        filteredData = filteredData?.slice(0, count);
        return (
          filteredData &&
          filteredData?.map((item: any, index: number) => {
            return renderItem(item, index);
          })
        );
      }
    } else if ((isOnHand || isPutAway) === true && !isShow) {
      let data = initialRecommendedData;
      let filteredData =
        data &&
        data?.filter(
          (item: Item) =>
            item?.description
              .toLowerCase()
              .includes(filterText.toLowerCase()) ||
            item?.catalogNo.toLowerCase().includes(filterText.toLowerCase()) ||
            item?.vendorName.toLowerCase().includes(searchKey.toLowerCase())
        );
      return (
        filteredData &&
        filteredData?.map((item: any, index: number) => {
          return renderItem(item, index);
        })
      );
    } else {
      let filteredData = productsData && productsData?.data;
      return (
        filteredData &&
        filteredData?.map((item: any, index: number) => {
          return renderSearchItems(item, index);
        })
      );
    }
  };

  const checkReplenishDisabled = () => {
    let filterdArr =
      initialRecommendedData &&
      initialRecommendedData?.filter(
        (item: Item) => item.selected === true && item?.selectedQty != 0
      );

    if (filterdArr?.length == 0) return true;
    else return false;
  };
  useEffect(() => {
    if (modalData?.title && modalData.description) {
      setIsShowToast(true);
      setTimeout(() => {
        setIsShowToast(false);
        modalData?.title == strings["ime.scanner.error.occured.msg"]
          ? null
          : navigation.navigate("Dashboard");
      }, 8000);
    }
  }, [modalData]);
  const showToast = (
    text1: string,
    text2: string,
    onHideToast?: any,
    data: any,
    isSaveReceipt: boolean
  ) => {
    setModalData({
      title: text1,
      description: text2,
      isSaveReceipt,
      onPress: () => {
        printTicket(data);
      },
    });

    // Toast.show({
    //   type: "alertButton",
    //   text1: text1,
    //   text2: text2,
    //   position: "bottom",
    //   bottomOffset: SIZES.padding * 2,
    //   onHide: () => {
    //     // printTicket(data);
    //     onHideToast?.();
    //   },
    //   onPress: () => {
    //     printTicket(data);
    //   },
    // });
  };
  const printTicket = async (data) => {
    const pdfOptions = {
      html: getReplenishReceiptRequest(
        data,
        selectedTitle,
        selectedSubTitle,
        timeString,
        dateFormat?.date,
        soldToNumber,
        shipToNumber,
        currency
      ),
      fileName: `pdf_${data?.transactionId}`,
      directory: "Documents",
    };
    const file = await RNHTMLtoPDF.convert(pdfOptions);
    if (file?.filePath) {
      if (Platform.OS === "android") {
        ReactNativeBlobUtil.android.actionViewIntent(
          file?.filePath,
          "application/pdf"
        );
      } else {
        ReactNativeBlobUtil.ios.previewDocument(file?.filePath);
      }
    }
    console.log("pdfOptions", pdfOptions);
  };

  const changeStateToDefault = () => {
    setVisibleCheckout(false);
    resetStates(
      setClearModal,
      onSearch,
      setSelectAll,
      setTapOnAddtoOrder,
      setShowVWR,
      setIsCorrected,
      setIsCShowSubSearch,
      setUpdatedRecommendedData
    );
  };

  const footerButtonNavigation = async () => {
    handleFooterNavigation(
      initialRecommendedData,
      replenishPrivilege,
      profileData,
      dispatch,
      replenishRequestOrder,
      setCorrectStockList,
      setCheckoutFilteredData,
      setNavigatedRoute,
      setVisibleCheckout,
      setUpdatedRecommendedData,
      getUserPrice,
      changeStateToDefault,
      navigation,
      showToast,
      strings
    );
  };
  const resetProductData = (value: any) => {
    dispatch(setProductLoader(value));
    dispatch(emptyProductData());
  };

  const onPressLeftIcon = () => {
    Keyboard.dismiss();
    navigation.getParent("Drawer").openDrawer();
  };

  const getCount = () => {
    let count =
      initialRecommendedData &&
      initialRecommendedData?.filter((item: Item) => item.selected).length;
    // storage.setItem("replenishCount", JSON.stringify(count));

    if (Number(count) <= 0) {
      storage.removeData("replenishCount");
    } else {
      storage.setItem("replenishCount", JSON.stringify(count));
    }
    return count;
  };

  const renderFooter = () => {
    if ((isPutAway && tapOnAddtoOrder) || !isPutAway) {
      return (
        <Footer
          mainbuttonTitle={getFooterButtonText(replenishPrivilege, strings)}
          secondaryButtonTitle={strings["ime.scanner.clear"] ?? "Clear"}
          secondaryButtonDisabled={!initialRecommendedData?.length}
          count={getCount()}
          mainButtonDisabled={checkReplenishDisabled()}
          mainButtonStyle={checkReplenishDisabled() && styles.disabledOpacity}
          onChangePrimaryBtnPress={() => footerButtonNavigation()}
          onChangeSecondaryBtnPress={() => setClearModal(true)}
          mainContainerStyle={styles.footerMainContainer}
          outlinedBtnTextStyle={styles.outlinedBtnText}
          outlinedBtnContainerStyle={styles.outlinedBtnContainer}
        />
      );
    } else {
      return null;
    }
  };
  const isCloseToBottom = ({
    layoutMeasurement,
    contentOffset,
    contentSize,
  }: any) => {
    const paddingToBottom = 20;
    return (
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom
    );
  };

  const fetchData = () => {
    const all = initialRecommendedData?.filter(
      (item: Item) =>
        item?.description.toLowerCase().includes(filterText.toLowerCase()) ||
        item?.catalogNo.toLowerCase().includes(filterText.toLowerCase()) ||
        item?.vendorName.toLowerCase().includes(searchKey.toLowerCase())
    );
    if (count < all?.length) {
      setIsLoading(true);
      setCount((prv) => prv + 10);
      setTimeout(() => {
        setIsLoading(false);
      }, 1000);
    }
  };
  if (visibleCheckout) {
    return (
      <ReplenishCheckoutScreen
        clearState={changeStateToDefault}
        setNavigatedRoute={setNavigatedRoute}
        data={isFilteredCheckoutData}
        isSelectedAll={isSelectedAll}
        onClose={() => setVisibleCheckout(false)}
      />
    );
  } else {
    return (
      <View
        style={styles.container}
        accessible={true}
        accessibilityLabel="replenish-container"
      >
        <Header
          title={
            (strings["replenish"] || "replenish") +
            ` ${
              isOnHand
                ? strings["ime.scanner.on.hand"]
                  ? " " + strings["ime.scanner.on.hand"]
                  : " On-Hand"
                : isPutAway
                ? " " + strings["put.away"]
                : ""
            }`
          }
          onLeftIconPress={() => onPressLeftIcon()}
          statusBar={true}
          statusBarColor={"blue"}
          iconLeft={true}
          iconRight={true}
        />
        <Subheader />
        {isOnHand && !isCorrected ? (
          <ReplenishStockCorrection
            initialRecommendedData={initialRecommendedData}
            setIsCorrected={setIsCorrected}
            setTapOnAddtoOrder={setTapOnAddtoOrder}
            setIsSelectedAll={setIsSelectedAll}
            setShowVWR={setShowVWR}
            isKPI={isKPI ? isKPI : false}
            fromScreen={props?.route?.params?.fromScreen}
          />
        ) : (
          <>
            <KeyboardAwareScrollView
              keyboardDismissMode="on-drag"
              showsVerticalScrollIndicator={false}
              alwaysBounceVertical={false}
              contentContainerStyle={styles.contentContainerStyle}
              accessible={true}
              accessibilityLabel="replenish-content-container"
              keyboardShouldPersistTaps="handled"
              scrollEventThrottle={400}
              onScroll={({ nativeEvent }) => {
                if (isCloseToBottom(nativeEvent) && !isLoadingData) {
                  fetchData();
                }
              }}
            >
              <AnimatedSearch
                idLabel={"Replenish"}
                search={searchKey}
                onSearch={(text: string) => {
                  if (searchKey != text) {
                    resetProductData(!!text);
                    onSearch(text);
                  }
                }}
                placeholder={
                  strings["ime.scanner.search.stockroom.products"] ??
                  "Search stockroom products"
                }
                clearText={() => {
                  dispatch(emptyProductData());
                  onSearch("");
                  // Keyboard.dismiss();
                }}
                onBarcodeDetected={(barcode) => {
                  // resetProductData(!!barcode);
                  getProductFromApi(barcode);
                  // onSearch(barcode);
                }}
                onCancel={() => {
                  onSearch("");
                  Keyboard.dismiss();
                }}
              />

              {showVWR && (
                <MainButton
                  accessibilityLabel="Replenish-addVwr-product"
                  title={strings["add.vwr.product"]}
                  buttonTextStyle={styles.mainBtnTextStyle}
                  buttonStyle={styles.buttonStyle}
                  onChangeBtnPress={() => refRBSheet_addVWR.current.open()}
                />
              )}

              {searchKey?.length <= 0 &&
                (isConsumption || tapOnAddtoOrder) &&
                initialRecommendedData?.length > 0 && (
                  <View
                    style={styles.subHeaderTextContainer}
                    accessible={true}
                    accessibilityLabel="recommended-header"
                  >
                    <Text
                      style={[
                        styles.itemChildHeaderText,
                        styles.recomentedText,
                      ]}
                      accessibilityLabel="recommended-header-label"
                    >
                      {!tapOnAddtoOrder
                        ? strings["ime.scanner.recommended"] ?? "Recommended"
                        : strings["order"] ?? "Order"}{" "}
                      {tapOnAddtoOrder &&
                        `(${
                          initialRecommendedData?.filter(
                            (item: Item) => item.selected
                          ).length
                        })`}
                    </Text>

                    <View
                      style={styles.subHeaderTextContainer}
                      accessible={true}
                      accessibilityLabel="recommended-header-right"
                    >
                      <TouchableOpacity
                        accessible={true}
                        accessibilityLabel="recommended-header-search"
                        onPress={() => setIsCShowSubSearch(!isCShowSubSearch)}
                      >
                        <Search height={hp(2.5)} width={hp(2.5)} />
                      </TouchableOpacity>

                      <Text
                        style={[
                          styles.itemChildHeaderText,
                          styles.selectDeselectText,
                        ]}
                        accessibilityLabel="recommended-header-selectAll"
                      >
                        {isSelectedAll
                          ? strings["ime.scanner.deselect.all"] ??
                            "Deselect All"
                          : strings["ime.select.all"] ?? "Select All"}
                      </Text>
                      {isSelectedAll ? (
                        <Checkbox onPress={() => setSelectAll()} />
                      ) : (
                        <Unselected onPress={() => setSelectAll()} />
                      )}
                    </View>
                  </View>
                )}

              {isCShowSubSearch && (
                <SubSearchComponent
                  search={filterText}
                  onSearch={(text: string) => setFilterText(text)}
                  placeholder={strings["search"]}
                  clearText={() => setFilterText("")}
                  cancelPressed={() => {
                    setFilterText("");
                    setIsCShowSubSearch(!isCShowSubSearch);
                  }}
                />
              )}

              <View
                style={styles.dataContainer}
                accessible={true}
                accessibilityLabel="replenish-productList"
              >
                {_renderList()}
              </View>
            </KeyboardAwareScrollView>
            {renderFooter()}

            <AddVwrProduct
              refRBSheet_addVWR={refRBSheet_addVWR}
              productDetailsSheetRef={itemDetailsRef}
              showToast={(isShow: boolean, data: any) => {
                setIsShowToast(isShow);
                setTimeout(() => {
                  setIsShowToast(false);
                }, 6000);
                setModalData({
                  title: data?.title ?? "",
                  description: data?.description ?? "",
                  isSaveReceipt: false,
                  onPress: () => {},
                });
              }}
            />

            <ClearSelectionAlert
              isShow={clearModal}
              didCloseModal={() => {
                setClearModal(false);
              }}
              outlinedButtonTitle={strings["cancel"]}
              mainButtonTitle={strings["ime.scanner.Clear.Order"]}
              didMainButtonTitleClicked={() => {
                navigation.navigate("Dashboard");
                changeStateToDefault();
              }}
              didOutlinedButtonClicked={() => setClearModal(false)}
              orderTitle={strings["ime.scanner.Clear.this.order"]}
              orderDesc={
                strings[
                  "ime.scanner.All.products.in.this.order.will.be.removed."
                ]
              }
            />

            <ToastComponent />
            <ProductDetails
              itemDetailsRef={itemDetailsRef}
              productDetailsList={productDetails}
              isShowPrice={stockRoomDetail?.isReplishIndividual}
            />

            <ScannerButton
              onBarcodeDetected={(barcode) => {
                bottomSheetRef.current?.open();

                resetProductData(!!barcode);
                getProductFromApi(barcode);
                // onSearch(barcode);
              }}
              mainButtonStyle={
                (isPutAway && tapOnAddtoOrder) || !isPutAway
                  ? styles.scannerBtn
                  : null
              }
            />
          </>
        )}
        <Loader show={productDetailsLoading || isLoading} />

        <ConfirmationAlert
          onTapNo={() => {}}
          onTapYes={() => {
            storage.removeData("replenishCount");
            dispatch(
              setIsShowConfirmationAlert({
                isShow: false,
                data: confirmationAlertInfo?.data,
              })
            );
            props.navigation.navigate("Dashboard");
            dispatch(resetPriceState());
          }}
        />
        {/* Toast */}
        <ModalToast
          isShow={isShowToasReft}
          onClose={() => {
            setIsShowToast(false);
            setModalData({
              title: "",
              description: "",
              isSaveReceipt: false,
              onPress: () => {},
            });
            modalData?.title == strings["ime.scanner.error.occured.msg"]
              ? null
              : navigation.navigate("Dashboard");
          }}
          title={modalData.title}
          discription={modalData.description}
          isSaveReceipt={modalData.isSaveReceipt}
          onPress={modalData.onPress}
        />
        {selectedSearchItem &&
          searchBarcode &&
          productBottomSheet(selectedSearchItem, selectedSearchItemIndex)}
      </View>
    );
  }
};

export default Replenish;
