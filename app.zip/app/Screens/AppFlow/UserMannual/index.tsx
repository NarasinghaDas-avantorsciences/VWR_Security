import React, { useRef, useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { View, StatusBar, Platform } from "react-native";
import { useSelector } from "react-redux";
import { Header } from "../../../Components";
import CustomText from "../../../Components/CustomText";
import styles from "./styles";
import { COLORS } from "../../../Utils/theme";
import { LeftArrow } from "../../../Utils/images";
import { hp } from "../../../Utils/globalFunction";
import Pdf from "react-native-pdf";
interface UserManualProps {
  onFinish: () => void;
}

const UserManual: React.FC<UserManualProps> = ({ onFinish }) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const [isMoveToPage, setIsMoveToPage] = useState(false);
  const source =
    Platform.OS === "ios"
      ? require("../../../Utils/sample.pdf")
      : { uri: "bundle-assets://sample.pdf", cache: true };
  var refPDF: any = useRef();
  const pageName = useSelector(
    (state: any) => state.navigationRouteReducer?.data
  );
  useEffect(() => {
    if (pageName == "Help") {
      setIsMoveToPage(true);
    }
  }, []);

  function setPdfPage() {
    if (pageName != "Help" && !isMoveToPage) {
      switch (pageName) {
        case "Consume":
          refPDF.setPage(23);
          break;
        case "Receive":
          refPDF.setPage(36);
          break;
        case "Replenish":
          refPDF.setPage(27);
          break;
        case "Approvals":
          refPDF.setPage(45);
          break;
        case "StockCorrection":
          refPDF.setPage(58);
          break;
        case "Account":
          refPDF.setPage(10);
          break;
        default:
          break;
      }
      setIsMoveToPage(true);
    }
  }
  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: "white",
      }}
      edges={["left", "right", "top", "bottom"]}
    >
      <StatusBar translucent={true} backgroundColor={"transparent"} />
      <Header
        title={Strings["ime.user.manual"] ?? "User Manual"}
        titleStyle={styles.headerTitle}
        container={styles.headerContainer}
        onLeftIconPress={onFinish}
        onRightIconPress={onFinish}
        statusBar={true}
        statusBarColor={COLORS.white}
        iconLeft={true}
        iconRight={true}
        LeftIcon={() => <LeftArrow height={hp(2)} width={hp(2)} />}
        RightIcon={() => (
          <CustomText style={styles.rightIcon}>{Strings["close"]}</CustomText>
        )}
      />
      <View style={{ flex: 1 }}>
        <Pdf
          source={source}
          fitPolicy={0}
          enablePaging={true}
          ref={(pdf) => {
            refPDF = pdf;
          }}
          onLoadComplete={(numberOfPages, filePath) => {
            setPdfPage();
          }}
          onPageChanged={(page, numberOfPages) => {
            console.log(`Current page: ${page}`);
          }}
          onError={(error) => {
            console.log(error);
          }}
          onPressLink={(uri) => {
            console.log(`Link pressed: ${uri}`);
          }}
          style={styles.pdf}
        />
      </View>
    </SafeAreaView>
  );
};

export default UserManual;
