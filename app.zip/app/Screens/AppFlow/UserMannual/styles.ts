import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";

export default StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: COLORS.white,
    },
  
    headerTitle: {
      fontFamily: FONTFAMILY.averta_semibold,
      fontSize: FONTS.h2_2,
      color: COLORS.abbey,
    },
  
    headerContainer: { backgroundColor: COLORS.white },
  
    rightIcon: {
      fontSize: FONTS.h2,
      color: COLORS.scienceBlue,
      fontFamily: FONTFAMILY.averta_regular,
    },
    pdf: {
      flex:1,
      width:wp(100),
      height:hp(100),
  }
})