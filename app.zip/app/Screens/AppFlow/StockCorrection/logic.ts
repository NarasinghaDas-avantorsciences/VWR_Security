import moment from "moment";
import * as storage from "../../../Service/AsyncStoreConfig";

const handleStockCorrect = async (
  correctStockList: any[],
  showToast: any,
  reason: { code: string; id: any },
  setReason: Function,
  data: { id: any },
  dateFormat: { date: string; hours: string },
  dispatch: (arg0: any) => void,
  replenishStockCorrection: (
    arg0: {
      page: null;
      reasonCode: { id?: undefined } | { id: any };
      user: { id: any };
      stockRoomId: any;
      products: any;
      type: string;
    },
    arg1: (res: any) => Promise<void>,
    arg2: (res: any) => Promise<void>
  ) => any,
  setCorrectStockList: (arg0: never[]) => any,
  Strings: any
) => {
  const org: any = await storage.getItem("org");
  const correctStockArr = correctStockList
    .map((item: any) => {
      if (item?.isSelected) return item;
    })
    .filter((item: any) => item);

  try {
    const products = correctStockArr.map((item: any) => {
      let batchProducts;

      if (item?.batches?.length > 0) {
        batchProducts = item?.batches.map((batch: any) => {
          const { batchNo, actualQty, expiryDate, availableQty, id } = batch;

          if (item?.batchManagementEnabled != 0 && batchNo == "") {
            throw showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.batch.empty.msg"]
            );
          } else if (
            item?.expiryDateManagementenabled != 0 &&
            expiryDate == ""
          ) {
            throw showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.expiry.date.empty.msg"]
            );
          } else if (id?.includes("addedBatch") && actualQty == 0) {
            throw showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.new.batchs.zero.qty.msg"] ??
                "The New Batchs can't have Qty as 0!"
            );
          }

          return {
            id: id?.includes("addedBatch") ? null : id,
            batchNo: batchNo ? batchNo : null,
            availableQty: availableQty ? availableQty : "0",
            actualQty: actualQty ? actualQty : availableQty,
            expiryDate: expiryDate
              ? moment(expiryDate).format(dateFormat?.date)
              : null,
          };
        });
      }

      return {
        id: item?.id,
        availableQty: item?.availableQty,
        actualQty: item?.actualQty ? item?.actualQty : 0,
        reasonCode: {
          id: item?.reasonCode?.id,
          reasonCode: item?.reasonCode?.code,
        },
        ...(item?.batches?.length > 0 && { batchProducts }),
      };
    });

    const params = {
      page: null,
      reasonCode: reason?.code == "" ? {} : { id: reason?.id },
      user: {
        id: data?.id,
      },
      stockRoomId: JSON.parse(org).stockroomId,
      products,
      type: "[CorrectStockCorrection] correct stock correction",
    };

    dispatch(
      replenishStockCorrection(
        params,
        async (res: any) => {
          if (res.status == "200") {
            dispatch(setCorrectStockList([]));
            dispatch(
              setReason({
                code: "",
                id: 0,
              })
            );
            showToast(
              Strings["stock.corrected"] ?? "Stock Corrected!",
              Strings["ime.scanner.corrected.success.msg"] ??
                "The selected products were corrected successfully."
            );
          }
        },
        async (res: any) => {
          showToast(Strings["ime.scanner.error.occured.msg"], res?.data?.label);
        }
      )
    );
  } catch (e: any) {
    console.log(e.message);
  }
};

const handleAvailQty = async (
  val: any,
  id: any,
  correctStockList: any,
  setCorrectStockList: (arg0: any) => any,
  dispatch: (arg0: any) => any
) => {
  let arr = correctStockList;
  let objIndex = arr.findIndex((obj: { id: any }) => obj?.id == id);
  arr[objIndex]["actualQty"] = val;

  await dispatch(setCorrectStockList(arr));
};

const handleBatches = async (
  batches: any,
  batchId: string,
  itemId: string,
  correctStockList: any,
  setCorrectStockList: (arg0: any) => any,
  dispatch: (arg0: any) => any
) => {
  let arr = correctStockList;

  let arrIndex = arr?.findIndex((obj: { id: any }) => obj?.id == itemId);

  let batchIndex = batches?.findIndex((obj: { id: any }) => obj?.id == batchId);

  const itemIndex = arr[arrIndex]?.batches.findIndex(
    (obj: { id: string }) => obj?.id == batchId
  );

  if (itemIndex >= 0) {
    await arr[arrIndex]?.batches.map((obj: any) => {
      if (obj?.id == batchId) {
        obj["actualQty"] = batches[batchIndex]["actualQty"];
        obj["batchNo"] = batches[batchIndex]["batchNo"];
        obj["expiryDate"] = batches[batchIndex]["expiryDate"];
      }
    });
  } else {
    arr[arrIndex]?.batches?.push(batches[batchIndex]);
  }

  await dispatch(setCorrectStockList(arr));
};

const handleBatchDelete = async (
  item: any,
  val: any,
  correctStockList: any,
  setCorrectStockList: (arg0: any) => any,
  dispatch: (arg0: any) => any,
  selectedItem: any
) => {
  let arr = correctStockList;

  let objIndex = arr?.findIndex(
    (obj: { id: any }) => obj?.id == selectedItem?.id
  );

  const findIndex = arr[objIndex]?.batches.findIndex(
    (obj: { id: any }) => obj?.id === val?.id
  );

  findIndex !== -1 && arr[objIndex]?.batches.splice(findIndex, 1);

  await dispatch(setCorrectStockList(arr));
};

export { handleStockCorrect, handleAvailQty, handleBatches, handleBatchDelete };
