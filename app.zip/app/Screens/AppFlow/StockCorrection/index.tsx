import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  TouchableOpacity,
  View,
  Pressable,
  BackHandler,
  Keyboard,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { useFocusEffect } from "@react-navigation/native";
import Toast from "react-native-toast-message";
import {
  Header,
  Subheader,
  SearchBar,
  ReasonCode,
  BottomSheetComponent,
  MainButton,
  StockListItem,
  Footer,
  ToastComponent,
  ProductDetails,
  Loader,
  ClearSelectionAlert,
  ScannerButton,
  AnimatedSearch,
} from "../../../Components";
import Text from "../../../Components/CustomText";
import {
  hp,
  wp,
  isDeviceTablet,
  isProductFreezed,
  checkifExpiryEnabled,
  checkifBatchEnabled,
} from "../../../Utils/globalFunction";
import { useDebounceHook } from "../../../Hooks";
import { Search, Unselected, Checkbox, Locked } from "../../../Utils/images";
import { COLORS, SIZES } from "../../../Utils/theme";
import styles from "./styles";
import {
  setReason,
  getReasonCode,
  setCorrectStockList,
  setSelectedStock,
} from "../../../Redux/Action/stockCorrection";
import {
  getProductDetails,
  getProductList,
  setProductLoader,
  emptyProductData,
  getProductBatchDetails,
  getProductListFromBarcode,
} from "../../../Redux/Action/searchAction";
import { replenishStockCorrection } from "../../../Redux/Action/replenishAction";
import {
  handleStockCorrect,
  handleAvailQty,
  handleBatches,
  handleBatchDelete,
} from "./logic";
import { useIsFocused } from "@react-navigation/native";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import ConfirmationAlert from "../../../Components/ConfirmationPopup";
import * as storage from "../../../Service/AsyncStoreConfig";

const StockCorrection = (props: any) => {
  const isTablet = isDeviceTablet();
  const dispatch = useDispatch<any>();
  const isFocused = useIsFocused();

  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const productsData = useSelector(
    (state: any) => state.searchReducer?.searchList
  );
  const { correctStockList, reason, selectedStock } = useSelector(
    (state: any) => state.stockCorrectionReducer
  );
  const { productDetails, productDetailsLoading } = useSelector(
    (state: any) => state.searchReducer
  );
  const {
    stockRoomDetail,
    org_details,
    selectedStockRoom,
    dateFormat,
    confirmationAlertInfo,
  } = useSelector((state: any) => state.userReducer);
  const { data } = useSelector((state: any) => state.accountReducer);
  const { isLoading } = useSelector((state: any) => state.replenishReducer);

  const [search, setSearch] = useState("");
  const [isSelectedAll, setSelectAll] = useState(true);
  const [clearModal, setClearModal] = useState(false);
  const [confirmationModel, setConfirmationModal] = useState(false);
  const stockRef = useRef<any>();
  const outterProductDetailsRef = useRef<any>(null);
  const innerProductDetailsRef = useRef<any>(null);

  const debouncedSearchTerm = useDebounceHook(search, 800);
  const reasonSuffix =
    stockRoomDetail?.stockroomType == "Regular"
      ? false
      : org_details?.showSapSetting;

  useEffect(() => {
    if (debouncedSearchTerm) {
      dispatch(getProductList(debouncedSearchTerm));
    } else {
      dispatch(setProductLoader(false));
    }
  }, [debouncedSearchTerm]);

  const getProductFromApi = async (searchKey: any) => {
    dispatch(
      getProductListFromBarcode(
        searchKey,
        null,
        (res: any) => {
          // if (res?.data[0]?.catalogNo == searchKey) {
          if (
            res?.data[0]?.catalogNo == searchKey ||
            res?.data[0]?.vendorCatalogNo == searchKey ||
            res?.data[0]?.custCatalogNo == searchKey
          ) {
            renderItemFromBarcode(res?.data[0]);
            dispatch(setProductLoader(false));
          } else {
            Toast.show({
              type: "alertToast",
              text1: Strings["ime.scanner.error.occured.msg"],
              text2: "Product does not exist!",
              position: "bottom",
              bottomOffset: SIZES.padding * 2,
            });
            dispatch(setProductLoader(false));
          }
        },
        (res: any) => {
          dispatch(setProductLoader(false));

          console.log(res);
        }
      )
    );
  };

  useEffect(() => {
    dispatch(
      getReasonCode(
        { codeType: "stock.correction" },
        stockRoomDetail?.stockroomType
      )
    );
  }, [isFocused]);
  useFocusEffect(
    useCallback(() => {
      dispatch(setIsShowConfirmationAlert({}));
    }, [])
  );

  useFocusEffect(
    useCallback(() => {
      return async () => {
        setSearch("");
        await dispatch(emptyProductData());
        await dispatch(setCorrectStockList([]));
        await dispatch(
          setReason({
            code: "",
            id: 0,
          })
        );
      };
    }, [])
  );

  useEffect(() => {
    const backAction = async () => {
      let asyncData;
      await storage.getItem("stockCorrectionCount").then((res) => {
        asyncData = res;
      });

      if (Number(asyncData) > 0) {
        dispatch(
          setIsShowConfirmationAlert({
            isShow: true,
            data: confirmationAlertInfo?.data,
          })
        );
      } else {
        props.navigation.navigate("Dashboard");
      }
      return true;
    };

    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );

    return () => backHandler.remove();
  }, []);

  const showToast = async (text1: string, text2: string) => {
    Toast.show({
      type: "alertToast",
      text1: text1,
      text2: text2,
      position: "bottom",
      bottomOffset: SIZES.padding * 2,
    });
  };

  const stockCorrect = () => {
    handleStockCorrect(
      correctStockList,
      showToast,
      reason,
      setReason,
      data,
      dateFormat,
      dispatch,
      replenishStockCorrection,
      setCorrectStockList,
      Strings
    );
    resetProductData(false);
  };

  const availQty = async (val: any, id: any) => {
    handleAvailQty(val, id, correctStockList, setCorrectStockList, dispatch);
  };

  const batchUpdates = async (
    batches: any,
    batchId: string,
    itemId: string
  ) => {
    handleBatches(
      batches,
      batchId,
      itemId,
      correctStockList,
      setCorrectStockList,
      dispatch
    );
  };

  const batchDelete = async (item: any, val: any, selectedItem: any) => {
    handleBatchDelete(
      item,
      val,
      correctStockList,
      setCorrectStockList,
      dispatch,
      selectedItem
    );
  };

  const handleAddToStockList = async () => {
    let item = selectedStock;
    let batches;
    let arr = correctStockList;

    if (selectedStock?.batches.length > 0) {
      let avlbQty = 0;
      batches = selectedStock?.batches?.filter((el: any) => {
        let isAvbl = el?.availableQty != 0 && el?.availableQty != null;
        avlbQty = isAvbl ? avlbQty + el?.availableQty : avlbQty;
        return isAvbl;
      });
      item["batches"] = batches;
      //item["actualQty"] = avlbQty;
      item["actualQty"] = "";
    }

    const found = arr?.some((el: any) => el?.id === selectedStock?.id);

    if (!found) {
      arr?.unshift({
        ...(item ? item : selectedStock),
        isSelected: true,
      });
    } else {
      showToast(
        Strings["ime.attention"],
        Strings["tooltip.add.product.disabled"]
      );
    }

    await dispatch(setCorrectStockList(arr));
    setSearch("");

    await stockRef.current.close();
  };

  const handleSelectstock = async (item: any) => {
    let flag = 0;
    let arr = correctStockList;
    let objIndex = arr.findIndex((obj: { id: any }) => obj?.id == item?.id);
    arr[objIndex].isSelected = !item?.isSelected;

    arr.map((list: { isSelected: boolean }) => {
      if (list?.isSelected) {
        flag += 1;
      }
    });

    if (flag == arr.length) {
      setSelectAll(true);
    } else {
      setSelectAll(false);
    }
    await dispatch(setCorrectStockList(arr));
  };

  const _renderList = (key: string) => {
    if (key === "search") {
      const filteredData = productsData && productsData?.data;
      return (
        filteredData &&
        filteredData.map((item: any, index: number) => {
          return renderItem(item, index, key);
        })
      );
    } else {
      return (
        correctStockList &&
        correctStockList?.map((item: any, index: number) => {
          return renderItem(item, index, key);
        })
      );
    }
  };

  const errorCallBack = (err) => {
    //setLoader(false);
    if (err?.errorMessage) {
      Toast.show({
        type: "alertToast",
        text1: err?.errorMessage,
      });
    } else {
      Toast.show({
        type: "alertToast",
        text1: Strings["ime.attention"],
        text2: "Error occured while fetching the batch",
      });
    }
  };

  async function showSearchProductDetails(item: any) {
    await dispatch(setSelectedStock(item));
    await stockRef.current.open();
  }

  const updateCheckboxStatus = async (value: string, dataItem: any) => {
    let flag = 0;
    let arr = correctStockList;
    let objIndex = arr.findIndex((obj: { id: any }) => obj?.id == dataItem?.id);
    arr[objIndex].isSelected = true;
    // value == "0" ? false : true;

    arr.map((list: { isSelected: boolean }) => {
      if (list?.isSelected) {
        flag += 1;
      }
    });

    if (flag == arr.length) {
      setSelectAll(true);
    } else {
      setSelectAll(false);
    }
    await dispatch(setCorrectStockList(arr));
  };

  const renderItem = (item: any, index: number, key: string) => {
    return (
      <StockListItem
        key={`${index}`}
        item={item}
        from={"stockCorrection"}
        containerStyle={{ marginHorizontal: 0 }}
        showToast={showToast}
        show={key == "search" ? false : true}
        required={true}
        showBatch={
          checkifExpiryEnabled(item, stockRoomDetail) ||
          checkifBatchEnabled(item, stockRoomDetail)
        }
        reasonCodeType="stock.correction"
        handleOnSelect={
          key == "search"
            ? async () => {
                if (reason?.code != "") {
                  item["reasonCode"] = reason;
                }
                if (
                  item?.expiryDateManagementenabled != 0 ||
                  item?.batchManagementEnabled != 0
                ) {
                  await dispatch(
                    getProductBatchDetails(
                      item?.id ?? "",
                      (data: any) => {
                        item["batches"] = data;
                        showSearchProductDetails(item);
                      },
                      errorCallBack
                    )
                  );
                } else {
                  showSearchProductDetails(item);
                }
              }
            : async () => {
                outterProductDetailsRef.current.open();
                await dispatch(getProductDetails(item?.id));
                await dispatch(setProductLoader(false));
              }
        }
        handleAvailQty={availQty}
        handleBatch={batchUpdates}
        handleBatchDelete={batchDelete}
        rightIcon={
          key == "stock" ? (
            <Pressable
              accessible={true}
              accessibilityLabel="stock-correction-selected-unselcted"
              onPress={() => handleSelectstock(item)}
            >
              {item?.isSelected ? <Checkbox /> : <Unselected />}
            </Pressable>
          ) : isProductFreezed(item) ? (
            <Locked
              accessible={true}
              accessibilityLabel="StockCorrection-listitem-locked-image"
            />
          ) : null
        }
        updateCheckbox={(value: string) => updateCheckboxStatus(value, item)}
        disableListPress={key == "search" ? false : true}
      />
    );
  };
  const resetProductData = (value) => {
    dispatch(setProductLoader(value));
    dispatch(emptyProductData());
  };
  const _renderProductDetails = (itemDetailsRef: any) => (
    <ProductDetails
      itemDetailsRef={itemDetailsRef}
      productDetailsList={productDetails}
    />
  );

  const getCount = () => {
    let count =
      correctStockList &&
      correctStockList?.filter((item: { isSelected: any }) => item.isSelected)
        .length;
    storage.setItem("stockCorrectionCount", JSON.stringify(count));
    return `${
      correctStockList?.filter((item: { isSelected: any }) => item.isSelected)
        .length
    }`;
  };

  const noDataFound = () => {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>{Strings["no.records.found"]}</Text>
      </View>
    );
  };
  const renderItemFromBarcode = async (item: any) => {
    if (reason?.code != "") {
      item["reasonCode"] = reason;
    }
    if (
      item?.expiryDateManagementenabled != 0 ||
      item?.batchManagementEnabled != 0
    ) {
      await dispatch(
        getProductBatchDetails(
          item?.id ?? "",
          (data: any) => {
            item["batches"] = data;
            showSearchProductDetails(item);
          },
          errorCallBack
        )
      );
    } else {
      showSearchProductDetails(item);
    }
  };

  return (
    <View style={styles.container}>
      <Header
        title={Strings.stock_correction || "stock_correction"}
        onLeftIconPress={() => {
          Keyboard.dismiss();
          props.navigation.getParent("Drawer").openDrawer();
        }}
        statusBar={true}
        statusBarColor={"blue"}
        iconLeft={true}
        iconRight={true}
      />

      <Subheader />

      <ReasonCode
        idLabel={"stock-correction"}
        containerStyle={styles.reasonContainer}
        reasonCodeType="stock.correction"
        from="masterCode"
        reason={reason}
        showToast={showToast}
        setReason={async (val: any) => await dispatch(setReason(val))}
      />
      {/* <SearchBar
        idLabel="stock-correction"
        search={search}
        containerStyle={styles.searchBarContainerStyle}
        onSearch={(text) => {
          resetProductData(text != "");
          setSearch(text);
        }}
        placeholder={
          Strings?.["ime.scanner.Search.Products"] ?? "Search Products"
        }
        onBarcodeDetected={(barcode) => {
          resetProductData(!!barcode);
          setSearch(barcode);
        }}
      /> */}
      <AnimatedSearch
        idLabel={"stock-correction"}
        search={search}
        onSearch={(text: string) => {
          resetProductData(!!text);
          setSearch(text);
        }}
        containerStyle={styles.searchBarContainerStyle}
        cancelBtnStyle={{ paddingRight: wp(5) }}
        placeholder={
          Strings["ime.scanner.search.stockroom.products"] ??
          "Search stockroom products"
        }
        clearText={() => {
          setSearch("");
          // Keyboard.dismiss();
        }}
        onBarcodeDetected={async (barcode) => {
          resetProductData(!!barcode);
          await getProductFromApi(barcode.replace(/[\x00-\x1F\x7F]/g, ""));
          // setSearch(barcode.replace(/[\x00-\x1F\x7F]/g, ""));
        }}
        onCancel={() => {
          setSearch("");
          Keyboard.dismiss();
        }}
        from={"stockCorrection"}
      />

      {/* Stock correct/Product Search */}
      {search != "" || correctStockList?.length == 0 ? (
        <>
          {productsData.length != 0 && search != "" ? (
            <KeyboardAwareScrollView
              accessible={true}
              accessibilityLabel="stock-correction-search-result"
              keyboardDismissMode="interactive"
              keyboardShouldPersistTaps="always"
              showsVerticalScrollIndicator={false}
              alwaysBounceVertical={false}
              contentContainerStyle={styles.dataContainer}
              onScroll={() => Keyboard.dismiss()}
            >
              {_renderList("search")}
            </KeyboardAwareScrollView>
          ) : (
            noDataFound()
          )}
        </>
      ) : (
        <>
          {correctStockList?.length != 0 && search == "" ? (
            <KeyboardAwareScrollView
              accessible={true}
              accessibilityLabel="stock-correction-list"
              contentContainerStyle={styles.contentContainerStyle}
              keyboardShouldPersistTaps="always"
              keyboardDismissMode="on-drag"
              enableResetScrollToCoords={false}
              keyboardOpeningTime={Number.MAX_SAFE_INTEGER}
            >
              <View
                style={[
                  styles.subHeaderTextContainer,
                  { paddingHorizontal: wp(4) },
                ]}
              >
                <Text
                  accessible={true}
                  accessibilityLabel="stock-correction-list-count"
                  style={[styles.itemChildHeaderText, styles.recomentedText]}
                >
                  {Strings["stock.correction"] ?? "Stock Correction"} (
                  {
                    correctStockList?.filter(
                      (item: { isSelected: any }) => item.isSelected
                    ).length
                  }
                  )
                </Text>

                <View style={styles.subHeaderTextContainer}>
                  <Search height={hp(2.5)} width={hp(2.5)} />
                  <Text
                    style={[
                      styles.itemChildHeaderText,
                      styles.selectDeselectText,
                    ]}
                    accessible={true}
                    accessibilityLabel="stock-correction-select-deselect"
                  >
                    {isSelectedAll
                      ? Strings["ime.scanner.deselect.all"] ?? "Deselect All"
                      : Strings["ime.select.all"] ?? "Select All"}
                  </Text>
                  {isSelectedAll ? (
                    <Checkbox
                      onPress={async () => {
                        let arr = correctStockList;
                        arr.map((v: any) =>
                          Object.assign(v, { isSelected: false })
                        );
                        await dispatch(setCorrectStockList(arr));
                        setSelectAll(false);
                      }}
                    />
                  ) : (
                    <Unselected
                      onPress={async () => {
                        let arr = correctStockList;
                        arr.map((v: any) =>
                          Object.assign(v, { isSelected: true })
                        );
                        await dispatch(setCorrectStockList(arr));
                        setSelectAll(true);
                      }}
                    />
                  )}
                </View>
              </View>

              <View style={styles.dataContainer}>{_renderList("stock")}</View>
            </KeyboardAwareScrollView>
          ) : (
            noDataFound()
          )}
        </>
      )}

      {/* Footer */}
      {correctStockList?.length != 0 && search == "" && (
        <Footer
          mainbuttonTitle={Strings["correct.stock"] ?? "Correct Stock"}
          secondaryButtonTitle={Strings["ime.scanner.clear"] ?? "Clear"}
          secondaryButtonDisabled={!correctStockList?.length}
          count={getCount()}
          mainButtonDisabled={
            correctStockList.filter(
              (item: { isSelected: any }) => item.isSelected
            ).length == 0
              ? true
              : false
          }
          mainButtonStyle={{
            backgroundColor:
              correctStockList.filter(
                (item: { isSelected: any }) => item.isSelected
              ).length == 0
                ? COLORS.gray4
                : COLORS.scienceBlue,
          }}
          mainButtonTextStyle={{}}
          onChangePrimaryBtnPress={() => {
            let correctStockArr = correctStockList
              .map((item: any) => {
                if (item?.isSelected) return item;
              })
              .filter((item: any) => item);

            let reasonCodeArr = correctStockArr.filter(
              (item: any) => item?.reasonCode
            );
            let newFilterArr: any = [];
            correctStockList.map((item: any, i: number) => {
              let Arr = item?.batches.filter(
                (item: any) => item?.actualQty == null || item?.actualQty == ""
              );
              console.log("..");

              newFilterArr = newFilterArr.concat(Arr);
            });

            let nonBatchArr: any = [];
            correctStockList.map((item: any, i: number) => {
              if (item?.batches?.length == 0 || item?.batches == null) {
                if (item?.actualQty == null || item?.actualQty == "") {
                  nonBatchArr.push(item);
                }
              }
            });

            if (reasonCodeArr?.length != correctStockArr?.length) {
              showToast(
                Strings["ime.scanner.error.occured.msg"],
                Strings["ime.scanner.Reason.Code.msg"]
              );
              return;
            }
            if (newFilterArr?.length > 0 || nonBatchArr.length > 0) {
              showToast(
                Strings["ime.scanner.error.occured.msg"],
                "The Actual Quantity is required"
              );
              return;
            }

            let isSap = correctStockArr.some(
              (item: { reasonCode: { dontSyncWithSap: string } }) =>
                item?.reasonCode?.dontSyncWithSap == "N"
            );

            if (reasonSuffix && isSap) {
              setConfirmationModal(true);
              return;
            }
            stockCorrect();
          }}
          onChangeSecondaryBtnPress={() => setClearModal(true)}
          mainContainerStyle={styles.footerMainContainer}
          outlinedBtnTextStyle={styles.outlinedBtnText}
          outlinedBtnContainerStyle={styles.outlinedBtnContainer}
        />
      )}

      {/* Add Stock BottomSheet */}
      <BottomSheetComponent
        height={SIZES.height - (isTablet ? SIZES.padding : SIZES.padding * 2)}
        bottomSheetRef={stockRef}
        didCloseModal={async () => {
          let item = selectedStock;
          item["reasonCode"] = "";
          await dispatch(setSelectedStock(item));
        }}
      >
        <View style={styles.bottomSheetContainer}>
          <Text style={styles.stockTitle} numberOfLines={1}>
            {selectedStock?.description}
          </Text>
        </View>

        <KeyboardAwareScrollView
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          showsVerticalScrollIndicator={false}
          alwaysBounceVertical={false}
          contentContainerStyle={styles.contentContainerStyle}
        >
          <StockListItem
            item={selectedStock}
            id={`${selectedStock?.id}`}
            showToast={showToast}
            handleOnSelect={async () => {
              innerProductDetailsRef?.current?.open();
              await dispatch(getProductDetails(selectedStock?.id));
              await dispatch(setProductLoader(false));
            }}
            from="addToList"
            reasonCodeType="stock.correction"
            handleReasonCode={async (item: any) =>
              await dispatch(setSelectedStock(item))
            }
            handleAvailQty={async (val: any, id: any) => {
              let item = selectedStock;
              item["actualQty"] = val;
              await dispatch(setSelectedStock(item));
            }}
            show={true}
            freeze={isProductFreezed(selectedStock)}
            showBatch={false}
            bottomBorder={false}
            rightIcon={isProductFreezed(selectedStock) ? <Locked /> : null}
            disableListPress={true}
          />

          <View style={styles.buttonsContainer}>
            <TouchableOpacity
              style={styles.cancelButtonContainer}
              onPress={() => {
                let item = selectedStock;
                item["actualQty"] = "";
                dispatch(setSelectedStock(item));
                stockRef.current.close();
              }}
            >
              <Text style={styles.cancelText}>{Strings.cancel}</Text>
            </TouchableOpacity>

            <MainButton
              title={
                Strings["ime.add.to.list"]
                  ? "+ " + Strings["ime.add.to.list"]
                  : "+ Add to list"
              }
              accessibilityLabel="stockCorrection-AddToListButton"
              buttonTextStyle={styles.mainText}
              onChangeBtnPress={handleAddToStockList}
              disabled={isProductFreezed(selectedStock)}
              buttonStyle={
                isProductFreezed(selectedStock) && {
                  backgroundColor: COLORS.gray4,
                }
              }
            />
          </View>
        </KeyboardAwareScrollView>

        {/* Inner Product Details */}
        {_renderProductDetails(innerProductDetailsRef)}
      </BottomSheetComponent>

      {/* Outter Product Details */}
      {_renderProductDetails(outterProductDetailsRef)}

      {/* Loader */}
      <Loader show={productDetailsLoading || isLoading} />

      {/* Clear model */}
      <ClearSelectionAlert
        isShow={clearModal}
        didCloseModal={() => {
          setClearModal(false);
        }}
        outlinedButtonTitle={"Cancel"}
        mainButtonTitle={Strings["ime.scanner.Clear.Order"]}
        didMainButtonTitleClicked={async () => {
          setClearModal(false);
          setSelectAll(true);
          await dispatch(setReason(""));
          await dispatch(emptyProductData());
          await dispatch(setCorrectStockList([]));
        }}
        didOutlinedButtonClicked={() => setClearModal(false)}
        orderTitle={Strings["ime.scanner.Clear.list"]}
        orderDesc={
          Strings["ime.scanner.All.products.in.this.list.will.be.removed"]
        }
      />

      {/* Reason code confirmation model */}
      <ClearSelectionAlert
        isShow={confirmationModel}
        didCloseModal={() => {
          setConfirmationModal(false);
        }}
        outlinedButtonTitle={Strings["cancel"]}
        didOutlinedButtonClicked={() => setConfirmationModal(false)}
        mainButtonTitle={Strings["yes"]}
        didMainButtonTitleClicked={async () => {
          setConfirmationModal(false);
          stockCorrect();
        }}
        orderTitle={Strings["sync.with.sap"]}
        orderDesc={Strings["returning.stock.with.this.reason.code"]}
      />
      {/* Toast */}
      <ToastComponent />
      <ScannerButton
        mainButtonStyle={
          correctStockList?.length != 0 && search == ""
            ? styles.scannerBtn
            : null
        }
        onBarcodeDetected={async (barcode) => {
          resetProductData(!!barcode);
          await getProductFromApi(barcode);
          // resetProductData(!!barcode);
          // setSearch(barcode);
        }}
        onSearch={(text) => {
          resetProductData(text);
          setSearch(text);
        }}
      />
      <ConfirmationAlert
        onTapNo={() => {}}
        onTapYes={() => {
          dispatch(
            setIsShowConfirmationAlert({
              isShow: false,
              data: confirmationAlertInfo?.data,
            })
          );
          storage.setItem("stockCorrectionCount", JSON.stringify(0));
          props.navigation.navigate("Dashboard");
        }}
        onBack={() => console.warn("")}
      />
    </View>
  );
};

export default StockCorrection;
