import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { isDeviceTablet } from "../../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  mainInput: {
    marginVertical: hp(1),
    width: wp(90),
  },
  mainInputTop: {
    marginVertical: hp(1),
    width: wp(90),
    marginTop: hp(3),
  },
  rowContainer: {
    borderBottomWidth: 1,
    borderBottomColor: COLORS.alto,
    backgroundColor: COLORS.white,
  },
  scanStyle: {
    marginBottom: hp(2),
    marginRight: wp(2),
    position: "absolute",
    zIndex: 0,
  },
  inputStyle: {
    padding: 0,
    textAlign: "left",
    paddingLeft: 0,
    marginLeft: 0,
  },
  searchInput: {
    backgroundColor: COLORS.whiteSmoke,
    paddingHorizontal: wp(3),
  },
  itemMain: {
    borderBottomWidth: 0.4,
    borderBottomColor: COLORS.alto,
    paddingVertical: hp(1.3),
    flexDirection: "row",
  },
  itemTitle: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_8,
    color: COLORS.abbey,
  },
  searchHeader: {
    flexDirection: "row",
    paddingHorizontal: 0,
    alignItems: "center",
    marginRight: isDeviceTablet() ? wp(2) : wp(5),
    marginLeft: isDeviceTablet() ? wp(2) : wp(5),
  },
  headerTitle: {
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h2,
    color: COLORS.abbey,
    flex: 1,
    textAlign: "center",
    alignSelf: "center",
  },
  searchMain: {
    // width: "90%",
    // alignSelf: "center",
    paddingHorizontal: wp(3),
    marginVertical: isDeviceTablet() ? wp(2) : wp(4),
  },
  animatedSearchContainer: {
    width: "100%",
    marginLeft: wp(1),
  },
  listMain: {
    width: "90%",
    alignSelf: "center",
  },
  dataContainer: { paddingBottom: hp(10), marginHorizontal: 16 },
  leftIconContainer: { marginRight: wp(4) },

  commentInputStyle: {
    width: wp(42),
    alignSelf: "flex-start",
    backgroundColor: COLORS.white,
    marginRight: wp(4),
  },

  input_Style: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h1_5,
    color: COLORS.whiteSmoke,
    left: -wp(2),
  },
  qtyWrapper: {
    paddingTop: hp(1),
    flexDirection: "row",
    alignItems: "center",
  },
  inputMainStyle: { height: hp(4), top: 0, borderColor: COLORS.whiteSmoke },
  multipierText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_regular,
  },
  leftIcon: { width: wp(20), height: wp(20) },

  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },

  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },

  qtyInfoContainer: { paddingVertical: hp(0.8) },

  itemSubHeaderStyle: {
    alignSelf: "flex-start",
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
  },
  inactiveOpacity: {
    opacity: 0.5,
    backgroundColor: COLORS.gray4,
  },
  itemContainerStyle: {
    marginVertical: hp(1.8),
    borderBottomWidth: 1,
    paddingBottom: hp(1),
    borderColor: COLORS.whiteSmoke,
  },

  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  locationMain: {
    width: "50%",
    marginTop: hp(2),
  },
  itemText: {
    ...FONTS.title2,
    color: COLORS.gray,
    marginBottom: SIZES.tip,
  },
  valueText: { ...FONTS.body, color: COLORS.gray },
  addBatchContainerStyle: {
    paddingBottom: 0,
  },
  flexRowCenter: { flexDirection: "row", alignItems: "center" },
  itemChildContainer: {
    width: "50%",
    marginVertical: wp(0.5),
    paddingVertical: 8,
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },
  searchBarContainer: {
    paddingHorizontal: wp(4),
    marginVertical: wp(1),
  },
  subHeaderTextContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 6,
    paddingHorizontal: wp(2),
    marginLeft: wp(2.5),
  },

  itemChildHeaderText: {
    fontSize: FONTS.h1_7,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    alignItems: "center",
  },

  recomentedText: { ...FONTS.title2, fontSize: FONTS.h2, lineHeight: 20 },

  selectDeselectText: {
    ...FONTS.title2,
    fontSize: FONTS.h1_5,
    marginHorizontal: wp(2),
  },
  bottomSheetContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: SIZES.radius,
    borderBottomWidth: 1,
    borderTopWidth: 1,
    borderBottomColor: COLORS.whiteSmoke,
    borderTopColor: COLORS.whiteSmoke,
    width: wp(90),
    alignSelf: "center",
  },
  stockTitle: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
  },
  buttonsContainer: {
    paddingVertical: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  cancelButtonContainer: {
    width: "50%",
    alignItems: "center",
  },
  cancelText: { ...FONTS.body, color: COLORS.gray },
  mainText: { ...FONTS.title, color: COLORS.white },

  footerMainContainer: { bottom: 0 },

  outlinedBtnText: { color: COLORS.gray },

  outlinedBtnContainer: { borderWidth: 0 },
  clearModalContainer: { height: SIZES.height * 0.2 },
  clearContainer: {
    flex: 1,

    justifyContent: "center",
    alignItems: "center",
  },

  clearOrderTitle: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h2,
    color: COLORS.black,
  },

  clearOrderDesc: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h2,
    color: COLORS.black,
    marginVertical: hp(1),
  },

  cancelContainer: {
    width: wp(45),
    marginTop: hp(1),
    marginLeft: 0,
    borderWidth: 0,
  },

  clearOrderContainer: {
    width: wp(30),
    marginTop: hp(1),
  },

  clearOrderText: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.white,
    fontSize: FONTS.h2,
  },

  commentContainer: {
    width: "50%",
  },
  comment: {
    fontSize: FONTS.h1_8,
    fontFamily: FONTFAMILY.averta_regular,
    color: COLORS.abbey,
    paddingHorizontal: wp(1),
    backgroundColor: COLORS.white,
    borderWidth: 0.6,
    borderColor: COLORS.lightGray,
    width: wp(40),
    height: hp(4),
    justifyContent: "center",
    paddingVertical: 0,
  },
  // itemText: {
  //   color: COLORS.gray,
  //   marginBottom: SIZES.tip
  // },

  qtyTitleStyle: { marginRight: wp(3) },
  inputMain: {
    //minWidth: "30%",
    maxWidth: "50%",
    alignSelf: "flex-start",
    marginTop: wp(2),
    flex: 1,
    marginRight: wp(8),
  },
  input: {
    height: hp(4),
    width: "100%",
    fontSize: FONTS.h1_5,
    padding: 0,
    color: COLORS.abbey,
  },
  avl: {
    fontSize: FONTS.h1_5,
    padding: 0,
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
  },
  emptyContainer: { alignItems: "center", justifyContent: "center" },
  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },
});
