import {
  filterByMultipleKeys,
  filterDataByName,
} from "../../../Utils/globalFunction";

const onChangeSearchFieldLogic = ({ searchKey, DATA }: any) => {
  const filteredData = filterDataByName(DATA, "title", searchKey);
  return filteredData as [any];
};

const onChangeSearchFieldLogicByDescription = ({ searchKey, DATA }: any) => {
  console.log("searchKey", searchKey);
  console.log("productData", DATA);
  const filteredData = filterDataByName(DATA, "description", searchKey);
  console.log("filteredData", filteredData);
  return filteredData as [any];
};

const onDropDownSheetSelectedTitleLogic = ({ DATA, selected }: any) => {
  return DATA[selected]?.title ?? "";
};

const onSelectItemsClickedLogic = (itemsArrays: any, index: number) => {
  var updatedData = itemsArrays;
  updatedData[index].selected = !updatedData[index].selected;
  const filteredArray = updatedData.filter((obj) => obj.selected == true);
  return { filteredArray, updatedData };
};

const onSelectAllItemsClickedLogic = (
  itemsArrays: any,
  isSelectedAll: Boolean
) => {
  let updatedData = itemsArrays;
  for (let i = 0; i < updatedData.length; i++) {
    updatedData[i]["selected"] = isSelectedAll;
  }
  return updatedData;
};

// Utility function to check if a description contains the search key
const descriptionContainsSearchKey = (
  description: string,
  searchKey: string
) => {
  return description.toLowerCase().includes(searchKey.toLowerCase());
};

// Function to filter products based on the search key
const filterProductsBySearchKey = (products: any[], searchKey: string) => {
  return products.filter((item) =>
    descriptionContainsSearchKey(item.description, searchKey) 
    || descriptionContainsSearchKey(item.catalogNo, searchKey) 
    || descriptionContainsSearchKey(item.vendorCatalogNo || "", searchKey) 
    || descriptionContainsSearchKey(item.custCatalogNo || "", searchKey) 
  );
};

const onChangeProductSearchFieldLogic = async (
  searchKey: string,
  addedProduct: any[],
  productList: { data: any },
  products: any[],
  setSearchKey: (arg0: string) => void,
  setProducts: any
) => {
  setSearchKey(searchKey);
  if (searchKey?.length) {
    if (addedProduct?.length) {
      const notAddedProducts = products.filter(
        (item) => !addedProduct.some((i) => i.id === item.id)
      );
      const dataFilter = filterProductsBySearchKey(notAddedProducts, searchKey);
      setProducts(dataFilter);
    } else {
      const data = filterProductsBySearchKey(products, searchKey);
      setProducts(data);
    }
  } else {
    setProducts(productList?.data);
  }
};

export {
  onChangeSearchFieldLogic,
  onDropDownSheetSelectedTitleLogic,
  onSelectItemsClickedLogic,
  onSelectAllItemsClickedLogic,
  onChangeSearchFieldLogicByDescription,
  onChangeProductSearchFieldLogic,
};
