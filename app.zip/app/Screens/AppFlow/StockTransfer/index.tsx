import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  View,
  ScrollView,
  Image,
  TouchableOpacity,
  Platform,
  Pressable,
  BackHandler,
  Keyboard,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import RNHTMLtoPDF from "react-native-html-to-pdf";
import ReactNativeBlobUtil from "react-native-blob-util";
import {
  AnimatedSearch,
  CustomText,
  ProductDetails,
  ProductInfoDetails,
} from "../../../Components";
import {
  emptyProductData,
  getProductDetails,
  getProductListFromBarcode,
  setProductLoader,
} from "../../../Redux/Action/searchAction";
import Text from "../../../Components/CustomText";
import Header from "../../../Components/Header";
import TextInputComponent from "../../../Components/TextInput";
import Subheader from "../../../Components/Subheader";
import ScannerButton from "../../../Components/ScannerButton";
import BottomSheetComponent from "../../../Components/BottomSheet";
import SearchBar from "../../../Components/SearchBar";
import { onChangeProductSearchFieldLogic } from "./logic";
import {
  Footer,
  ListItem,
  QtyController,
  StockListItem,
  ToastComponent,
  ClearSelectionAlert,
  Loader,
} from "../../../Components";
import {
  findDateFormat,
  getStockTransferTicket,
  hp,
  isDeviceTablet,
  wp,
} from "../../../Utils/globalFunction";
import { COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import {
  ArrowDown,
  Checkbox,
  TickIcon,
  Unselected,
  DefaultProductImage,
  PICountLocked,
} from "../../../Utils/images";
import styles from "./styles";
import { MainButton } from "../../../Components";
import Toast from "react-native-toast-message";
import { toggleApprovalToast } from "../../../Redux/Action/approvalsAction";
import * as storage from "../../../Service/AsyncStoreConfig";
import {
  getBatches,
  getDataList,
  onstockTransfer,
} from "../../../Redux/Action/stockTransfer";
import { useFocusEffect, useIsFocused } from "@react-navigation/native";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import ConfirmationAlert from "../../../Components/ConfirmationPopup";
import moment from "moment";

const StockTransfer = (props: any) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { productList, loader } = useSelector(
    (state: any) => state?.stockTransfer
  );
  const [products, setProducts] = useState<any>(null); //searchProductData
  const [searchProductData, setSearchProductData] = useState<any>([]);
  const bottomSheetRef = useRef<any>(null);
  const [selected, setSelected] = useState<any>(null);
  const [sheetTitle, setSheetTitle] = useState<any>("");
  const [sourceStockRoom, setSourceStockRoom] = useState<any>("");
  const [searchKey, setSearchKey] = useState("");
  const [blockData, setBlockData] = useState<any>();
  const [isSelectedAll, setIsSelectedAll] = useState(false);
  const [selectedStock, setSelectedStock] = useState<any>();
  const stockRef = useRef<any>(null);
  const [footer, setFooter] = useState(false);
  const [showClearAlert, setClearAlert] = useState<boolean>(false);
  const [destination, setDestination] = useState<any>("");
  const [area, setArea] = useState<any>("");
  const stockRoomsData = useSelector(
    (state: any) => state.userReducer?.stockRooms
  );
  const { confirmationAlertInfo } = useSelector(
    (state: any) => state.userReducer
  );
  const itemDetailsRef = useRef<any>(null);
  const [stockRooms, setStockRooms] = useState<any>();
  const [selectedType, setSelectedType] = useState<any>(null);
  const dispatch = useDispatch<any>();
  const [locations, setLocations] = useState<any>([]);
  const [addedProduct, setAddedProduct] = useState<any>([]);
  const [quantity, setQuantity] = useState(0);
  const [selectedSearchItem, setSelectedSearchItem] = useState<null>(null);
  const [selectedSearchItemIndex, setSelectedSearchItemIndex] = useState(0);
  const isFocused = useIsFocused();
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const [selectedBatches, setSelectedBatches] = useState<any>([]);
  const [limit, setLimit] = useState<any>(10);
  const [roomsSerach, setRoomsSerach] = useState<any>("");
  const productBottomSheetRef = useRef<any>();
  const { productDetails, productDetailsLoading } = useSelector(
    (state: any) => state.searchReducer
  );
  let lastScrollTime = 0;
  const debounceInterval = 600;
  const [sheet, setSheet] = useState<any>(false);
  const { dateFormat } = useSelector((state: any) => state.userReducer);

  useEffect(() => {
    setProducts(productList?.data);
  }, [productList]);

  useEffect(() => {
    fillStockRooms(stockRoomsData?.stockroomHierarchy);
  }, [stockRoomsData]);

  const fillStockRooms = (data: any) => {
    let newArr: any = [];
    data.forEach((item: { childStockroom: any | any[] }, index: any) => {
      if (item?.childStockroom?.length) {
        newArr?.push(item);
        item?.childStockroom?.map((childitem: any) => {
          newArr?.push(childitem);
        });
        // newArr?.push(item?.childStockroom[0]);
      } else {
        newArr?.push(item);
      }
    });
    setStockRooms(newArr);
  };

  useEffect(() => {
    const unsubscribe = props.navigation.addListener("focus", () => {});
    if (isFocused) {
      setAddedProduct([]);
      setSearchKey("");
      setSearchProductData([]);
      getOrg();
    }
    return unsubscribe;
  }, [isFocused]);

  useFocusEffect(
    useCallback(() => {
      dispatch(
        setIsShowConfirmationAlert({
          isShow: false,
          data: confirmationAlertInfo?.data,
          stockTransferCount: addedProduct?.length,
        })
      );
    }, [addedProduct?.length])
  );

  useEffect(() => {
    const backAction = async () => {
      let asyncData;
      await storage.getItem("stockTransferCount").then((res) => {
        asyncData = res;
      });

      if (Number(asyncData) > 0) {
        dispatch(
          setIsShowConfirmationAlert({
            isShow: true,
            data: confirmationAlertInfo?.data,
          })
        );
      } else {
        props.navigation.goBack();
      }
      return true;
    };
    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );
    return () => backHandler.remove();
  }, []);

  const onChangeProductSearchField = async (searchKey: string) => {
    onChangeProductSearchFieldLogic(
      searchKey,
      addedProduct,
      productList,
      productList?.data?.filter(
        (item: { status: string }) => item?.status?.toLowerCase() != "offline"
      ),
      setSearchKey,
      setProducts
    );
  };
  const onChangeSearch = (res: string) => {
    const data = stockRooms?.filter(
      (item: any) => item?.id == res || item?.stockroomName == res
    );
    if (data?.length) {
      setBlockData([{ ...data[0] }]);
      setRoomsSerach(data[0]?.stockroomName);
    } else {
      setRoomsSerach(res);
    }
  };

  const onChangeSearchField = (searchKey: string) => {
    setRoomsSerach(searchKey);
    if (!searchKey?.length) {
      setBlockData(stockRooms);
    }
  };

  useEffect(() => {
    getOrg();
    return () => {
      setClearAlert(false);
      setAddedProduct([]);
      setFooter(false);
      setSelectedBatches([]);
      setSourceStockRoom("");
      setDestination("");
      setArea("");
    };
  }, [isFocused]);

  useFocusEffect(
    useCallback(() => {
      dispatch(setIsShowConfirmationAlert({}));
    }, [])
  );

  const getProducts = (id) => {
    const url = `?limit=${limit}&offset=0&filterOutOfStock=false`;
    dispatch(getDataList(id, url));
  };

  const onLoadData = () => {
    if (limit < productList?.totalCount) {
      const url = `?limit=${limit + 10}&offset=0&filterOutOfStock=false`;
      dispatch(getDataList(sourceStockRoom?.id, url));
      setLimit(limit + 10);
    }
  };
  const getProductFromApi = async (searchKey: any) => {
    dispatch(
      getProductListFromBarcode(
        searchKey,
        null,
        async (res: any) => {
          // if (res?.data[0]?.catalogNo == searchKey) {
          if (
            res?.data[0]?.catalogNo == searchKey ||
            res?.data[0]?.vendorCatalogNo == searchKey ||
            res?.data[0]?.custCatalogNo == searchKey
          ) {
            // renderItemFromBarcode(res?.data[0]);

            if (!res?.data[0]?.freeze) {
              onItemSelect(res?.data[0], 0);
            } else {
              Toast.show({
                type: "alertToast",
                text1: strings["ime.scanner.error.occured.msg"],
                text2: "Product does not exist!",
                position: "bottom",
                bottomOffset: SIZES.padding * 2,
              });
            }
            // setChildState?.(null);
            // await setSelectedItem(res?.data[0]);
            // bottomSheetRef?.current?.open();
            dispatch(setProductLoader(false));
          } else {
            Toast.show({
              type: "alertToast",
              text1: Strings["ime.scanner.error.occured.msg"],
              text2: "Product does not exist!",
              position: "bottom",
              bottomOffset: SIZES.padding * 2,
            });
            dispatch(setProductLoader(false));
          }
        },
        (res: any) => {
          dispatch(setProductLoader(false));

          console.log(res);
        }
      )
    );
  };

  const getOrg = () => {
    storage.getItem("org").then((res: any) => {
      const orgData = JSON.parse(res);
      const currentstockRooms = stockRoomsData || stockRooms;
      for (let i = 0; i < currentstockRooms?.stockroomHierarchy?.length; i++) {
        if (
          currentstockRooms?.stockroomHierarchy[i]?.id == orgData?.stockroomId
        ) {
          setSourceStockRoom({
            name: currentstockRooms?.stockroomHierarchy[i]?.stockroomName,
            id: currentstockRooms?.stockroomHierarchy[i]?.id,
          });
          getProducts(currentstockRooms?.stockroomHierarchy[i]?.id);
        } else {
          for (
            let k = 0;
            k <
            currentstockRooms?.stockroomHierarchy[i]?.childStockroom?.length;
            k++
          ) {
            if (
              currentstockRooms?.stockroomHierarchy[i]?.childStockroom[k]?.id ==
              orgData?.stockroomId
            ) {
              setSourceStockRoom({
                name: currentstockRooms?.stockroomHierarchy[i]?.childStockroom[
                  k
                ]?.stockroomName,
                id: currentstockRooms?.stockroomHierarchy[i]?.childStockroom[k]
                  ?.id,
              });
              getProducts(
                currentstockRooms?.stockroomHierarchy[i]?.childStockroom[k]?.id
              );
            }
          }
        }
      }
    });
  };

  const onHideToast = () => {
    dispatch(toggleApprovalToast(false));
  };

  const onCancel = () => {
    setSelected(null);
    setSheetTitle("");
    setTimeout(() => {
      bottomSheetRef?.current?.close();
    }, 200);
  };

  const onSelect = (item: {
    stockroomName: any;
    id: any;
    locationName: any;
    stagingArea: any;
  }) => {
    if (selectedType == 1) {
      setSourceStockRoom({
        name: item?.stockroomName,
        id: item?.id,
      });
      clearSearch();
      getProducts(item?.id);
      setDestination(null);
      setAddedProduct([]);
      setSelectedBatches([]);
      setFooter(false);
    } else if (selectedType == 2) {
      setDestination({
        name: item?.stockroomName,
        id: item?.id,
      });
      // setAddedProduct([]);
      // setFooter(false);
      // setSelectedBatches([]);

      // dispatch(
      //   getLocation(item?.id, (res: { data: any }) => {
      //     setLocations(res?.data);
      //   })
      // );
    } else if (selectedType == 3) {
    } else if (selectedType == 4) {
      setArea({
        name: item?.stagingArea,
        id: item?.id,
      });
    }
    bottomSheetRef.current.close();
  };

  const checkSockrooms = (item) => {
    if (selectedType == 1) {
      if (item?.id == destination?.id) {
        return false;
      } else {
        return true;
      }
    } else if (selectedType == 2) {
      if (item?.id == sourceStockRoom?.id) {
        return false;
      } else {
        return true;
      }
    }
  };

  const showErrorToast = (text1: string, text2: string) => {
    Toast.show({
      type: "alertToast",
      text1: text1,
      text2: text2,
      position: "bottom",
    });
  };

  const onSelectBarcodeItem = (key: any) => {
    let data = productList?.data?.filter(
      (item: { status: string }) => item?.catalogNo == key
    );
    if (data?.length == 1 && !data[0]?.freeze) {
      onItemSelect(data[0], 0);
    } else {
      Toast.show({
        type: "alertToast",
        text1: strings["ime.scanner.error.occured.msg"],
        text2: "Product does not exist!",
        position: "bottom",
        bottomOffset: SIZES.padding * 2,
      });
    }
  };

  const onItemSelect = (item: any, index: number) => {
    setSheet(true);
    dispatch(
      getBatches(item?.id, (res) => {
        setSelectedSearchItem(item);
        setQuantity(parseInt(item?.orderedQuantity));
        setSelectedSearchItemIndex(index);
        setSelectedStock({
          ...item,
          batches: res?.data,
        });
        stockRef.current.open();
      })
    );
  };

  const onSelectItems = (data: any, i: number) => {
    const dataindex = addedProduct.findIndex(
      (item: any, index) => item?.id == data?.id
    );
    let dataObj = Object.assign([], addedProduct);
    dataObj[dataindex] = {
      ...dataObj[dataindex],
      isSelected: dataObj[dataindex]?.isSelected ? false : true,
    };
    setAddedProduct([...dataObj]);
    checkSelected();
  };

  const checkSelected = () => {
    const data = addedProduct?.filter(
      (item: { isSelected: any }) => item?.isSelected
    );
    if (data?.length == data?.length) {
      setIsSelectedAll(true);
    } else {
      setIsSelectedAll(false);
    }
  };

  const setSelectAll = async () => {
    setAddedProduct(
      addedProduct.map((item, index) => ({
        ...item,
        isSelected: !isSelectedAll,
      }))
    );
    setIsSelectedAll(!isSelectedAll);
  };

  const onClear = () => {
    setProducts(productList?.data);
    setClearAlert(false);
    setAddedProduct([]);
    setFooter(false);
    setSelectedBatches([]);
  };

  const __selectedPRoducts = () => {
    const data = addedProduct?.filter((item) => item?.isSelected);
    return data;
  };

  function filterQty(batchId: number, id: number) {
    const data = selectedBatches?.filter(
      (item: any) => item?.batchId == batchId && item?.id == id
    );
    return data;
  }
  const totalQty = (id: string) => {
    // let totalQty = 0;
    // for (let i = 0; i < selectedBatches.length; i++) {
    //   if (selectedBatches[i]?.id == id) {
    //     totalQty = Number(totalQty) + Number(selectedBatches[i]?.requiredQty);
    //   }
    // }
    // return totalQty
    const used = selectedBatches.reduce(
      (accumulator: number, i: { [x: string]: any }) => {
        if (i?.id == id) {
          const total = accumulator + Number(i["requiredQty"]);
          return total;
        } else {
          return accumulator; // Don't reset the accumulator here
        }
      },
      0
    );
    return used;
  };

  function onChangeQty(batchId: number, qty: string) {
    if (filterQty(batchId, selectedStock?.id)?.length) {
      const dataindex = selectedBatches.findIndex((item: any) => {
        return item?.batchId == batchId && item?.id == selectedStock?.id;
      });
      let data = Object.assign([], selectedBatches);
      data[dataindex] = {
        ...data[dataindex],
        requiredQty: qty,
      };

      setSelectedBatches([...data]);
    } else {
      setSelectedBatches([
        ...selectedBatches,
        {
          batchId: batchId,
          requiredQty: qty,
          id: selectedStock?.id,
        },
      ]);
    }
  }
  const __renderCheck = () => (
    <TickIcon
      height={hp(2)}
      width={hp(2)}
      fill={COLORS.scienceBlue}
      style={{
        marginRight: wp(2),
      }}
    />
  );
  const onPendingItemQTYchange = (id, status) => {
    const dataindex = addedProduct.findIndex((item: any) => item?.id == id);
    let dataObj = Object.assign([], addedProduct);
    dataObj[dataindex] = {
      ...dataObj[dataindex],
      isSelected: status,
    };
    setAddedProduct([...dataObj]);
    checkSelected();
  };

  function onChangeSelectedQty(batchId: number, qty: string, productId: any) {
    if (Number(qty) == 0 && Number(totalQty(productId)) == 1) {
      onPendingItemQTYchange(productId, false);
    } else {
      onPendingItemQTYchange(productId, true);
    }

    if (filterQty(batchId, productId)?.length) {
      const dataindex = selectedBatches.findIndex((item: any) => {
        return item?.batchId == batchId && item?.id == productId;
      });
      let data = Object.assign([], selectedBatches);
      data[dataindex] = {
        ...data[dataindex],
        requiredQty: qty,
      };
      setSelectedBatches([...data]);
    }
  }

  const leftQty = () => {
    const used = selectedBatches.reduce(
      (accumulator: any, i: { [x: string]: any }) => {
        if (i?.id == selectedStock?.id) {
          const total = Number(accumulator) + Number(i["requiredQty"]);
          return total;
        } else {
          return 0;
        }
      },
      0
    );
    const total = selectedStock?.availableQty - used;
    return total;
  };

  const leftQtyById = (product: any) => {
    const used = selectedBatches.reduce(
      (accumulator: any, i: { [x: string]: any }) => {
        if (i?.id == product?.id) {
          const total = Number(accumulator) + Number(i["requiredQty"]);
          return total;
        } else {
          return 0;
        }
      },
      0
    );
    const total = product?.availableQty - used;
    return total;
  };

  const getDetail = async (id) => {
    productBottomSheetRef?.current?.open();
    await dispatch(getProductDetails(id));
    await dispatch(setProductLoader(false));
  };

  const checkSearch = (data: string | any[]) => {
    let dataArray = [];
    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      if (
        item?.stockroomName?.toLowerCase().includes(roomsSerach.toLowerCase())
      ) {
        if (selectedType == 2) {
          item?.id != sourceStockRoom?.id && dataArray?.push(item);
        } else {
          dataArray?.push(item);
        }
      } else if (item?.childStockroom?.length) {
        for (let j = 0; j < item?.childStockroom.length; j++) {
          const child = item?.childStockroom[j];
          if (
            child?.stockroomName
              ?.toLowerCase()
              .includes(roomsSerach.toLowerCase())
          ) {
            if (selectedType == 2) {
              item?.id != sourceStockRoom?.chaildId && dataArray?.push(item);
            } else {
              dataArray?.push(item);
            }
          }
        }
      }
    }
    return dataArray?.length;
  };

  const renderDropDownItems = (item: any, index: number) => {
    return (
      <View>{checkSockrooms(item) && __renderStockRoom(item, index)}</View>
    );
  };

  const renderDropDownItemsIst = (item: any, index: number) => {
    return <View>{__renderStockRoom(item, index)}</View>;
  };

  const renderItemHeader = (item: any) => {
    return (
      <>
        <Text
          style={styles.catalogNumber}
          accessibilityLabel="product-catalog-number"
        >
          {item?.catalogNo}
        </Text>
        <Text
          style={styles.itemHeaderContent}
          accessibilityLabel="product-description"
        >
          {item?.description}
        </Text>
        {
          /*checkUomCondition(item) && (*/
          <View
            style={styles.qtyInfoContainer}
            accessibilityLabel="product-unit-container"
          >
            <Text
              style={styles.itemSubHeaderStyle}
              accessibilityLabel="product-unit"
            >
              ({item?.uomId})
              {/*item?.uomManagementEnabled == 1
                ? item.stockRoomUOMUnit !== null
                  ? `(${item.stockRoomUOMUnit})`
                  : ""
                : item.uomId !== null
                ? `(${item.uomId})`
                : ""
                */}
            </Text>
          </View>
          /* )*/
        }
      </>
    );
  };

  const productInfo = (item: any) => {
    return (
      <ProductInfoDetails
        vendorName={item?.vendorName}
        locationName={item?.locationName ?? "-"}
        requiredQty={item?.maxStockQty ?? "-"}
        transitQty={item?.backlogQty ?? "-"}
        isFromStockTransfer={true}
      />
    );
  };

  const renderSearchItems = (item: any, index: number) => {
    return (
      <ListItem
        key={index}
        onPress={async () => {
          if (!item?.freeze && item?.status?.toLowerCase() != "offline") {
            onItemSelect(item, index);
          }
        }}
        leftIcon={
          <View
            style={styles.leftIconContainer}
            accessible={true}
            accessibilityLabel="searchProduct-Image-container"
          >
            {item?.imageURL ? (
              <Image
                source={{ uri: item.imageURL.replace("http://", "https://") }}
                style={styles.leftIcon}
                resizeMode={"contain"}
              />
            ) : (
              <DefaultProductImage width={wp(20)} height={wp(20)} />
            )}
          </View>
        }
        headerContent={renderItemHeader(item)}
        customStyles={{ container: styles.itemContainerStyle }}
        rightIcon={
          item?.freeze || item?.status?.toLowerCase() == "offline" ? (
            <PICountLocked />
          ) : null
        }
      >
        <View
          style={styles.flexRowContainer}
          accessible={true}
          accessibilityLabel="searchProduct-info"
        >
          {productInfo(item)}
        </View>
      </ListItem>
    );
  };
  const renderItem = (item: any, index: number) => {
    return (
      <ListItem
        onPress={() => {
          // stockRef.current.open();
          // setSelectedStock(item);
        }}
        leftIcon={
          <View
            style={styles.leftIconContainer}
            accessible={true}
            accessibilityLabel="stockTransfer-listItem-leftIcon"
          >
            {item?.imageURL ? (
              <Image
                source={{ uri: item.imageURL.replace("http://", "https://") }}
                style={styles.leftIcon}
                resizeMode={"contain"}
              />
            ) : (
              <DefaultProductImage width={wp(20)} height={wp(20)} />
            )}
          </View>
        }
        headerContent={
          <View
            accessible={true}
            accessibilityLabel="stockTransfer-header-contaoner"
          >
            <Text
              style={styles.catalogNumber}
              accessibilityLabel="stockTransfer-header-catalogNo"
            >
              {item?.catalogNo}
            </Text>
            <TouchableOpacity
              onPress={async () => {
                itemDetailsRef?.current?.open();
                await dispatch(getProductDetails(item?.id));
                dispatch(setProductLoader(false));
              }}
            >
              <Text
                style={styles.itemHeaderContent}
                accessibilityLabel="stockTransfer-header-description"
              >
                {item?.description}
              </Text>
            </TouchableOpacity>

            <View style={styles.qtyInfoContainer}>
              <Text
                style={styles.itemSubHeaderStyle}
                accessible={true}
                accessibilityLabel="stockTransfer-header-unit"
              >
                {item?.uomId}
              </Text>
            </View>
          </View>
        }
        rightIcon={
          <TouchableOpacity
            onPress={() => onSelectItems(item, index)}
            accessible={true}
            accessibilityLabel="stockTransfer-header-unit"
          >
            {item?.isSelected ? <Checkbox /> : <Unselected />}
          </TouchableOpacity>
        }
        customStyles={{ container: styles.itemContainerStyle }}
      >
        <View style={styles.flexRowContainer}>
          <View style={[styles.itemChildContainer]}>
            <CustomText style={styles.itemChildTitleText}>
              {strings["ime.avail.qty"]}
            </CustomText>
            <CustomText style={styles.itemChildValueText}>
              {item?.availableQty} ({item?.uomId})
            </CustomText>
          </View>
          <View style={[styles.itemChildContainer]}>
            <CustomText style={styles.itemChildTitleText}>
              {strings["vendor"]}
            </CustomText>
            <CustomText style={styles.itemChildValueText}>
              {item?.vendorName}
            </CustomText>
          </View>
        </View>
        <View style={styles.locationMain}>
          <CustomText style={styles.itemText}>{strings["location"]}</CustomText>
          <CustomText style={styles.valueText}>{item?.locationName}</CustomText>
        </View>

        {item?.batches?.length &&
        (item?.batchManagementEnabled || item?.expiryDateManagementenabled) ? (
          <View>
            {item?.batches?.map((batch, index) =>
              filterQty(batch?.id, item?.id)?.length
                ? __renderBatch(batch, index, item, false)
                : null
            )}
          </View>
        ) : (
          <View
            style={[
              //styles.itemChildContainer,
              { paddingVertical: 8 },
              styles.flexRowCenter,
              isDeviceTablet() ? { flexWrap: "nowrap" } : { flexWrap: "wrap" },
            ]}
            accessible={true}
            accessibilityLabel="list-item-child-container"
          >
            <View style={styles.qtyWrapper}>
              <QtyController
                title={"Transfer \nQty"}
                inputValue={
                  filterQty(0, item?.id)?.length
                    ? filterQty(0, item?.id)[0]?.requiredQty
                    : 0
                }
                limit={leftQtyById(item)}
                approval={true}
                availableQty={item?.availableQty}
                onChange={(v: string) => onChangeSelectedQty(0, v, item?.id)}
                showToast={showErrorToast}
                stockTransfer={true}
              />
              <CustomText
                style={styles.multipierText}
                accessibilityLabel="list-item-multiplier"
              >
                {item?.orderedQtyUOMDisplay}
              </CustomText>
            </View>
          </View>
        )}
      </ListItem>
    );
  };
  const noDataFound = () => {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>{Strings["no.records.found"]}</Text>
      </View>
    );
  };

  const renderBottomSheetChildren = () => (
    <TouchableOpacity
      accessible={true}
      accessibilityLabel="renderChildItem-container"
      style={{
        height: "85%",
      }}
    >
      <View
        accessible={true}
        accessibilityLabel="renderChildItem-content-container"
      >
        <View
          style={styles.searchHeader}
          accessible={true}
          accessibilityLabel="cancel-button-container"
        >
          <Text
            style={styles.headerTitle}
            numberOfLines={1}
            accessibilityLabel="cancel-button-left-label"
          >
            {sheetTitle}
          </Text>
          <TouchableOpacity
            onPress={() => onCancel()}
            accessible={true}
            accessibilityLabel="cancel-button"
          >
            <Text
              style={[
                styles.itemTitle,
                {
                  color: COLORS.scienceBlue,
                },
              ]}
              accessibilityLabel="cancel-button-label"
            >
              {Strings["cancel"]}
            </Text>
          </TouchableOpacity>
        </View>
        {/* <SearchBar
          search={roomsSerach ?? ""}
          onSearch={(text: string) => onChangeSearchField(text)}
          containerStyle={styles.searchMain}
          placeholder={Strings["search"]}
          stockTransferData={blockData?.length}
          from={"stocktransfer"}
          // isBarCodeVisible={selectedType == 1}
          isBarCodeVisible={true}
          onBarcodeDetected={(res) => onChangeSearch(res)}
        /> */}
        <AnimatedSearch
          idLabel={"stocktransfer"}
          search={roomsSerach ?? ""}
          onSearch={(text: string) => onChangeSearchField(text)}
          containerStyle={[styles.searchMain]}
          cancelBtnStyle={{ paddingRight: wp(5) }}
          placeholder={strings["search"] ?? "Search"}
          clearText={() => {
            onChangeSearchField("");
            setRoomsSerach("");
            // Keyboard.dismiss();
          }}
          onBarcodeDetected={(barcode) => {
            onChangeSearch(barcode);
          }}
          onCancel={() => {
            onChangeSearchField("");
            setRoomsSerach("");
            Keyboard.dismiss();
          }}
          from="stocktransfer"
        />
      </View>
      <ScrollView>
        <TouchableOpacity
          style={styles.listMain}
          accessible={true}
          accessibilityLabel="renderChildItem-list-container"
        >
          {roomsSerach && !checkSearch(blockData)
            ? noDataFound()
            : blockData?.map((item, index) =>
                selectedType == 1
                  ? renderDropDownItemsIst(item, index)
                  : renderDropDownItems(item, index)
              )}
        </TouchableOpacity>
      </ScrollView>
    </TouchableOpacity>
  );

  const _renderList = () => {
    if (addedProduct?.length > 0 && !searchKey?.length) {
      const data = addedProduct;
      return data?.map((item: any, index: number) => renderItem(item, index));
    } else {
      let filteredData = products?.filter(
        (item: any) => item?.status?.toLowerCase() != "offline"
      );
      return filteredData?.map((item: any, index: number) => {
        return renderSearchItems(item, index);
      });
    }
  };

  const __renderBatch = (
    batch: any,
    i: number,
    item: any,
    isSheet: boolean = true
  ) =>
    batch?.availableQty ? (
      <View
        key={i}
        style={{
          flex: 1,
          ...(!isSheet && {
            borderBottomWidth: 0.3,
            borderBottomColor: COLORS.abbey,
          }),
        }}
      >
        <View
          style={[
            {
              flexDirection: "row",
              alignSelf: "center",
              ...(isSheet && { width: "90%" }),
            },
          ]}
        >
          <TextInputComponent
            title={Strings["batch.no"]}
            main={styles.inputMain}
            inputStyle={styles.input}
            inputMain={{
              height: hp(4),
            }}
            placeholder={Strings["batch.no"]}
            value={batch?.batchNo}
            onChangeText={() => {}}
            editable={false}
            disabled={true}
          />
          <TextInputComponent
            title={"Exp.Date"}
            editable={false}
            main={styles.inputMain}
            inputStyle={styles.input}
            inputMain={{
              height: hp(4),
            }}
            // placeholder={Strings["batch.no"]}
            // value={batch?.expiryDate}
            value={moment(batch?.expiryDate).format(dateFormat.date)}
            onChangeText={() => {}}
            disabled={true}
          />
        </View>
        <View
          style={[
            {
              flexDirection: "row",
              alignSelf: "center",
              width: "90%",
              // justifyContent: "center",
              marginTop: hp(1),
              alignItems: "center",
              ...(isSheet && {
                borderBottomWidth: 0.3,
                borderBottomColor: COLORS.abbey,
              }),
            },
          ]}
        >
          <View style={styles.itemChildContainer}>
            <CustomText style={styles.avl}>
              Avail qty {"\n"}
              {batch?.availableQty}
            </CustomText>
          </View>
          <QtyController
            title={"Transfer \nQty"}
            inputValue={
              filterQty(batch?.id, item?.id)?.length
                ? filterQty(batch?.id, item?.id)[0]?.requiredQty
                : 0
            }
            onChange={(v: string) => {
              isSheet
                ? onChangeQty(batch?.id, v)
                : onChangeSelectedQty(batch?.id, v, item?.id);
            }}
            inputStyle={
              {
                // height: hp(5),
              }
            }
            limit={isSheet ? leftQty() : leftQtyById(item)}
            approval={true}
            availableQty={batch?.availableQty}
            showToast={showErrorToast}
            stockTransfer={true}
          />
        </View>
      </View>
    ) : null;

  const __renderStockRoom = (item, index) => {
    if (
      item?.stockroomName?.toLowerCase().includes(roomsSerach.toLowerCase())
    ) {
      return __renderItem(item, index);
    }
  };

  const __renderItem = (item, index) => (
    <TouchableOpacity
      onPress={() => onSelect(item, null)}
      accessible={true}
      accessibilityLabel="renderItem-container"
      key={index}
      style={[
        styles.itemMain,
        selected === index && {
          justifyContent: "space-between",
          alignItems: "center",
        },
      ]}
    >
      <Text
        style={[
          styles.itemTitle,
          { width: "90%" },
          selected === index && {
            color: COLORS.abbey,
            fontFamily: FONTFAMILY.averta_semibold,
          },
          selectedType == 1 &&
            sourceStockRoom?.name == item?.stockroomName && {
              fontFamily: FONTFAMILY.averta_bold,
            },
          selectedType == 2 &&
            destination?.name == item?.stockroomName && {
              fontFamily: FONTFAMILY.averta_bold,
            },
        ]}
        numberOfLines={1}
        accessibilityLabel="renderItem-title-text"
      >
        {selectedType == 3
          ? item?.locationName
          : selectedType == 4
          ? item?.stagingArea
          : item?.stockroomName}
      </Text>
      {selectedType == 1 && sourceStockRoom?.name == item?.stockroomName
        ? __renderCheck()
        : null}
      {selectedType == 2 && destination?.name == item?.stockroomName
        ? __renderCheck()
        : null}
    </TouchableOpacity>
  );

  const __renderSheet = () => (
    <BottomSheetComponent
      height={hp(90)}
      bottomSheetRef={stockRef}
      didCloseModal={() => setSheet(false)}
    >
      <ScrollView>
        <Pressable>
          <View
            style={styles.bottomSheetContainer}
            accessible={true}
            accessibilityLabel="stockTransfer-addtoList-container"
          >
            <View />
            <Text
              style={[
                styles.stockTitle,
                {
                  maxWidth: wp(60),
                },
              ]}
              numberOfLines={1}
              accessibilityLabel="stockTransfer-addtoList-headerText"
            >
              {selectedStock?.description}
            </Text>
            <TouchableOpacity
              onPress={() => {
                const batches = selectedBatches.filter(
                  (item: any) => item?.id != selectedStock?.id
                );
                setSelectedBatches(batches);
                stockRef?.current?.close();
              }}
              accessible={true}
              accessibilityLabel="close-button"
            >
              <Text
                style={styles.stockTitle}
                numberOfLines={1}
                accessibilityLabel="close-button-text"
              >
                Close
              </Text>
            </TouchableOpacity>
          </View>
          <StockListItem
            from="stockTransfer"
            item={selectedStock}
            handleOnSelect={() => getDetail(selectedStock?.id)}
            show={false}
            location={true}
            comment={false}
            commentText={selectedStock?.enteredComment ?? ""}
            bottomBorder={false}
            reasonCodeType=""
            handleCommentBox={(text: string) => {
              selectedStock["enteredComment"] = text;
            }}
          />
          {selectedStock?.batches?.length &&
          (selectedStock?.batchManagementEnabled ||
            selectedStock?.expiryDateManagementenabled)
            ? selectedStock?.batches?.map((item, index) =>
                __renderBatch(item, index, selectedStock)
              )
            : null}
          <View
            style={styles.buttonsContainer}
            accessible={true}
            accessibilityLabel="addToList-button-container"
          >
            <View
              style={styles.cancelButtonContainer}
              accessible={true}
              accessibilityLabel="addToList-quantity-controller"
            >
              {(!selectedStock?.batches?.length ||
                !(
                  selectedStock?.batchManagementEnabled ||
                  selectedStock?.expiryDateManagementenabled
                )) && (
                <QtyController
                  title={"Transfer \nQty"}
                  inputValue={
                    filterQty(0, selectedStock?.id)?.length
                      ? filterQty(0, selectedStock?.id)[0]?.requiredQty
                      : 0
                  }
                  onChange={(v: string) => onChangeQty(0, v)}
                  inputStyle={
                    {
                      // height: hp(6),
                    }
                  }
                  limit={leftQty()}
                  approval={true}
                  availableQty={selectedStock?.availableQty}
                  showToast={showErrorToast}
                  stockTransfer={true}
                />
              )}
            </View>
            <MainButton
              title={
                Strings["ime.add.to.list"]
                  ? "+ " + Strings["ime.add.to.list"]
                  : "+ Add to list"
              }
              buttonTextStyle={styles.mainText}
              onChangeBtnPress={() => {
                setAddedProduct([
                  {
                    ...selectedStock,
                    isSelected: true,
                  },
                  ...addedProduct,
                ]);
                setFooter(true);
                dispatch(emptyProductData());
                setSearchKey("");
                setSelectedStock("");
                stockRef?.current?.close();

                const data = addedProduct?.filter(
                  (item: { isSelected: any }) => item?.isSelected
                );
                if (data?.length == data?.length) {
                  setIsSelectedAll(true);
                }
              }}
              buttonStyle={
                totalQty(selectedStock?.id) == 0 && { backgroundColor: "gray" }
              }
              disabled={totalQty(selectedStock?.id) == 0}
            />
          </View>
        </Pressable>
      </ScrollView>
      <ProductDetails
        itemDetailsRef={productBottomSheetRef}
        productDetailsList={productDetails}
      />
      {sheet && <ToastComponent />}
    </BottomSheetComponent>
  );
  const clearSearch = () => {
    if (searchKey?.length) {
      setProducts(productList?.data);
      setRoomsSerach("");
      setSearchKey("");
    }
  };
  const openSheet = (type) => {
    // clearSearch();
    // setRoomsSerach(searchKey);
    bottomSheetRef?.current?.open();
    if (type == 1) {
      setBlockData(stockRooms);
      setSheetTitle(Strings["source.stockroom"]);
    } else if (type == 2) {
      setBlockData(stockRooms);
      // setSheetTitle(Strings["destination.stockRoom.name"]);
      setSheetTitle("Destination stockroom");
    } else if (type == 3) {
      setBlockData(locations);
      setSheetTitle(
        Strings["Destination Location"]
          ? Strings["Destination Location"]
          : "Destination Location"
      );
    } else if (type == 4) {
      const data = locations?.filter((item) => item?.stagingArea);
      setBlockData(data);
      setSheetTitle(Strings["staging_area"]);
    }
    setSelectedType(type);
  };

  const addDropDownViews = () => {
    // if ((addedProduct?.length ?? 0) == 0) {
    return (
      <View style={{ backgroundColor: "clear" }}>
        <TextInputComponent
          title={Strings["source.stockroom"]}
          RightIcon={ArrowDown}
          onPressRightIcon={() => openSheet(1)}
          value={sourceStockRoom?.name}
          editable={false}
          main={styles.mainInputTop}
          rightIconWidth={hp(1.7)}
          inputStyle={styles.inputStyle}
          required={true}
          placeholder={Strings["select"]}
          inputMain={{ height: hp(4) }}
        />
        <TextInputComponent
          title={Strings["destination.stockroom"]}
          // title={"Destination Stockroom"}
          RightIcon={ArrowDown}
          onPressRightIcon={() => openSheet(2)}
          value={destination?.name}
          editable={false}
          main={styles.mainInput}
          rightIconWidth={hp(1.7)}
          inputStyle={styles.inputStyle}
          required={true}
          placeholder={Strings["select"]}
          inputMain={{ height: hp(4) }}
        />
        {/* <TextInputComponent
          title={
            Strings["Destination Location"]
              ? Strings["Destination Location"]
              : "Destination Location"
          }
          RightIcon={ArrowDown}
          onPressRightIcon={() => openSheet(3)}
          value={destinationLocation?.name}
          editable={false}
          main={styles.mainInput}
          rightIconWidth={hp(1.7)}
          inputStyle={styles.inputStyle}
          required={true}
          placeholder="Select"
        />
        <TextInputComponent
          title={Strings["staging_area"]}
          RightIcon={ArrowDown}
          onPressRightIcon={() => openSheet(4)}
          value={area?.name}
          editable={false}
          main={styles.mainInput}
          rightIconWidth={hp(1.7)}
          inputStyle={styles.inputStyle}
          required={false}
          placeholder={Strings["select"]}
        /> */}
      </View>
    );
    // }
  };
  const addSelectAllHeader = () => {
    return (
      <View
        style={styles.subHeaderTextContainer}
        accessible={true}
        accessibilityLabel="stockTransfer-headerText-container"
      >
        <Text
          style={[styles.itemChildHeaderText, styles.recomentedText]}
          accessibilityLabel="stockTransfer-header-label"
        >
          {Strings["stock.transfer.scanner"] ?? "Stock Transfer"}
        </Text>

        <View
          style={styles.subHeaderTextContainer}
          accessible={true}
          accessibilityLabel="stockTransfer-selectAll-container"
        >
          <Text
            style={[styles.itemChildHeaderText, styles.selectDeselectText]}
            accessibilityLabel="stockTransfer-selectAll-label"
          >
            {isSelectedAll &&
            __selectedPRoducts()?.length == addedProduct?.length
              ? Strings["ime.scanner.deselect.all"] ?? "Deselect All"
              : Strings["ime.select.all"] ?? "Select All"}
          </Text>
          {isSelectedAll &&
          __selectedPRoducts()?.length == addedProduct?.length ? (
            <Checkbox onPress={() => setSelectAll()} />
          ) : (
            <Unselected onPress={() => setSelectAll()} />
          )}
        </View>
      </View>
    );
  };
  const isCloseToBottom = ({
    layoutMeasurement,
    contentOffset,
    contentSize,
  }: any) => {
    const paddingToBottom = 20;
    return (
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom
    );
  };

  const onPressPrintPickPicket = async (
    data: any,
    sourceStockRoom: string,
    destinationStockRoom: string,
    batches: any,
    passedProducts: any
  ) => {
    const pdfOptions = {
      html: getStockTransferTicket(
        data,
        sourceStockRoom,
        destinationStockRoom,
        batches,
        passedProducts
      ),
      fileName: `file`,
      directory: "Documents",
    };
    const file = await RNHTMLtoPDF.convert(pdfOptions);
    if (file?.filePath) {
      if (Platform.OS === "android") {
        ReactNativeBlobUtil.android.actionViewIntent(
          file?.filePath,
          "application/pdf"
        );
      } else {
        ReactNativeBlobUtil.ios.previewDocument(file?.filePath);
      }
    }
  };

  const successCallBack = (
    res: any,
    selectedData: any,
    passedProducts: any
  ) => {
    if (res) {
      const batches = selectedBatches;
      setAddedProduct([]);
      setSelectedBatches([]);
      setSelectedStock([]);
      setDestination("");
      getOrg();
      Toast.show({
        type: "alertApprovalsBottomToast",
        text1: "STOCK TRANSFERRED!",
        text2: "The selected products were transferred successfully!",
        props: {
          buttonTitle: Strings["ime.print.pick.ticket"],
          onPress: () =>
            onPressPrintPickPicket(
              selectedData,
              sourceStockRoom?.name,
              destination?.name,
              batches,
              passedProducts
            ),
        },
        position: "bottom",
      });
      setFooter(!footer);
    }
  };

  const errorCallBack = (err) => {
    if (err?.errorMessage) {
      var parts = err?.errorMessage.split(":");
      var result = parts[1].trim();
      showErrorToast(Strings["ime.scanner.error.occured.msg"], result);
    } else {
      showErrorToast(
        Strings["ime.scanner.error.occured.msg"],
        "Something went wrong"
      );
    }
    console.log("er-----", err?.errorMessage);
  };

  const onTransfer = () => {
    if (!sourceStockRoom?.id || !destination?.id) {
      showErrorToast(
        Strings["ime.scanner.error.occured.msg"],
        "Please select all required dropdown fields"
      );
    } else {
      const selectedData = addedProduct?.filter(
        (item: any) => item?.isSelected
      );
      if (selectedData?.length) {
        let products: any = [];
        for (let i = 0; i < selectedData?.length; i++) {
          const item = selectedData[i];
          const total = totalQty(item?.id);
          if (total == 0) {
            showErrorToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings[
                "ime.please.enter.valid.transfer.quantity.for.selected.products"
              ]
            );
            return;
          }
          if (item?.batches?.length) {
            let batches = [];
            for (let j = 0; j < item?.batches?.length; j++) {
              const batch = item?.batches[j];
              if (filterQty(batch?.id, item?.id)?.length) {
                const obj = filterQty(batch?.id, item?.id)[0];
                batches.push({
                  id: obj?.batchId,
                  requiredQty: obj?.requiredQty,
                });
              }
            }
            products.push({
              id: item.id,
              requiredQty: total,
              batches: batches,
            });
          } else {
            const data = selectedBatches?.filter((i: any) => i?.id == item?.id);
            products.push({
              id: item.id,
              requiredQty: data?.length ? data[0]?.requiredQty : 0,
              batches: [],
            });
          }
        }
        const body = {
          sourceStockroomId: `${sourceStockRoom?.id}`,
          destinationStockroomId: `${destination?.id}`,
          products: products,
        };
        console.log("body", body);
        dispatch(
          onstockTransfer(
            body,
            (res: any) => successCallBack(res, selectedData, products),
            errorCallBack
          )
        );
      } else {
        showErrorToast(
          Strings["ime.scanner.error.occured.msg"],
          strings["alert.select.product"]
        );
      }
    }
  };
  const getCount = () => {
    let count = addedProduct?.length;
    storage.setItem("stockTransferCount", JSON.stringify(count));

    return count;
  };
  return (
    <View style={{ flex: 1 }}>
      <Header
        title={Strings["stock.transfer.scanner"] ?? "Stock Transfer"}
        onLeftIconPress={() => {
          Keyboard.dismiss();
          props.navigation.getParent("Drawer").openDrawer();
        }}
        statusBar={true}
        statusBarColor={"blue"}
        iconLeft={true}
        iconRight={true}
      />
      <Subheader distance={10} rowContainer={styles.rowContainer} />
      <ScrollView
        style={styles.container}
        accessible={true}
        accessibilityLabel="stockTransfer-container"
        keyboardShouldPersistTaps={"handled"}
        onScroll={({ nativeEvent }) => {
          Keyboard?.dismiss();
          if (isCloseToBottom(nativeEvent)) {
            const currentTime = Date.now();
            if (currentTime - lastScrollTime > debounceInterval) {
              lastScrollTime = currentTime;
              onLoadData();
            }
          }
        }}
        scrollEventThrottle={400}
      >
        {addDropDownViews()}
        <View
          style={{ paddingVertical: hp(3) }}
          accessible={true}
          accessibilityLabel="stockTransfer-content-container"
        >
          {/* {addedProduct.length == 0 && ( */}
          {/* <SearchBar
            search={searchKey}
            placeholder={Strings["ime.scanner.search"] ?? "Search products"}
            containerStyle={styles.searchBarContainer}
            onBarcodeDetected={(barcode) => {
              onChangeProductSearchField(barcode);
            }}
            onSearch={(text: string) => onChangeProductSearchField(text)}
            stockTransferData={
              products?.filter(
                (item: any) => item?.status?.toLowerCase() != "offline"
              )?.length
            }
            from={"stocktransfer"}
            cancel={!!searchKey}
          /> */}
          <AnimatedSearch
            idLabel={"Stocktransfer_main"}
            search={searchKey ?? ""}
            onSearch={(text: string) => onChangeProductSearchField(text)}
            containerStyle={[styles.searchBarContainer]}
            cancelBtnStyle={{ paddingRight: wp(5) }}
            placeholder={strings["search"] ?? "Search"}
            clearText={() => {
              onChangeProductSearchField("");
              setSearchKey("");
              // Keyboard.dismiss();
            }}
            onBarcodeDetected={async (barcode) => {
              // onSelectBarcodeItem(barcode);
              await getProductFromApi(barcode);

              // onChangeProductSearchField(barcode);
              // onItemSelect(item, index);
            }}
            onCancel={() => {
              onChangeProductSearchField("");
              setSearchKey("");
              Keyboard.dismiss();
            }}
            from="stocktransfer"
          />
          {/* )} */}
          {searchKey == "" && addedProduct.length > 0 && addSelectAllHeader()}
          <ScrollView
            style={[styles.dataContainer]}
            showsVerticalScrollIndicator={false}
            accessible={true}
            accessibilityLabel="stockTransfer-renderList"
          >
            {_renderList()}
            {products?.filter(
              (item: any) => item?.status?.toLowerCase() != "offline"
            )?.length <= 0 && noDataFound()}
          </ScrollView>
        </View>
      </ScrollView>
      <BottomSheetComponent
        bottomSheetRef={bottomSheetRef}
        didCloseModal={() => {
          setRoomsSerach("");
        }}
      >
        {renderBottomSheetChildren()}
      </BottomSheetComponent>

      <ScannerButton
        mainButtonStyle={[
          styles.scanStyle,
          addedProduct?.length && {
            marginBottom: hp(8),
          },
        ]}
        // onBarcodeDetected={(barcode) => onChangeProductSearchField(barcode)}
        // onBarcodeDetected={(barcode) => onSelectBarcodeItem(barcode)}
        onBarcodeDetected={async (barcode) => await getProductFromApi(barcode)}
      />
      <ClearSelectionAlert
        isShow={showClearAlert}
        didCloseModal={() => {
          setClearAlert(false);
          setFooter(false);
        }}
        outlinedButtonTitle={"Cancel"}
        mainButtonTitle={strings["ime.scanner.Clear.Order"]}
        didMainButtonTitleClicked={() => {
          onClear();
        }}
        didOutlinedButtonClicked={() => setClearAlert(false)}
        orderTitle={Strings["ime.scanner.Clear.this.order"]}
        orderDesc={
          Strings["ime.scanner.All.products.in.this.order.will.be.removed."]
        }
      />

      {__renderSheet()}
      {footer && (
        <Footer
          mainbuttonTitle={Strings["ime.transfer.stock"] ?? "Transfer Stock"}
          secondaryButtonTitle={Strings["ime.scanner.clear"] ?? "Clear"}
          secondaryButtonDisabled={!addedProduct?.length}
          count={getCount()}
          mainButtonStyle={{}}
          mainButtonTextStyle={{}}
          onChangePrimaryBtnPress={() => onTransfer()}
          onChangeSecondaryBtnPress={() => setClearAlert(true)}
          mainContainerStyle={styles.footerMainContainer}
          outlinedBtnTextStyle={styles.outlinedBtnText}
          outlinedBtnContainerStyle={styles.outlinedBtnContainer}
          mainButtonDisabled={
            !addedProduct?.filter((item: any) => item?.isSelected)?.length
          }
        />
      )}
      <Loader show={loader} />
      <ConfirmationAlert
        onTapNo={() => {}}
        onTapYes={() => {
          dispatch(
            setIsShowConfirmationAlert({
              isShow: false,
              data: confirmationAlertInfo?.data,
            })
          );
          props.navigation.goBack();
        }}
        onBack={() => {}}
      />
      {!sheet && <ToastComponent />}
      <ProductDetails
        itemDetailsRef={itemDetailsRef}
        productDetailsList={productDetails}
        isShowPrice={true}
      />
    </View>
  );
};

export default StockTransfer;
