import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  TouchableOpacity,
  View,
  ScrollView,
  FlatList,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import styles from "./styles";
import {
  Header,
  Subheader,
  Footer,
  ListItemCheckButton,
  SearchBar,
  BottomSheetComponent,
  MainButton,
  ReasonCode,
  Loader,
  DecisionModal,
  ToastComponent,
  ClearSelectionAlert,
  ProductDetails,
  CustomText,
  PICountListItem,
  TopTabs,
} from "../../../../Components";
import TextInputComponent from "../../../../Components/TextInput";
import { BlueTick } from "../../../../Utils/images";
import { COLORS, FONTFAMILY, SIZES } from "../../../../Utils/theme";
import { ArrowDown } from "../../../../Utils/images";
import { useSelector, useDispatch } from "react-redux";
import { hp, wp } from "../../../../Utils/globalFunction";
import {
  getPIProductsList,
  savePICount,
  completePICount,
  setUpdatedPendingProducts,
  setUpdatedConfirmProducts,
  setLoader,
  resetAllPIConfirmProducts,
  resetAllPIPendingProducts,
} from "../../../../Redux/Action/picountAction";
import {
  getReasonCode,
  setReasonCode,
} from "../../../../Redux/Action/stockCorrection";
import { HalfLoader } from "../../../../Components/Loader";
import moment from "moment";
import Toast from "react-native-toast-message";
import { useFocusEffect, useIsFocused } from "@react-navigation/native";
import {
  handleAvailQtyLogic,
  handleBatchDeleteLogic,
  handleBatchesLogic,
  onCompletePICountLogic,
  onSavePICountLogic,
  onSelectReasonCodeLogic,
} from "./logic";
import { setIsShowConfirmationAlert } from "../../../../Redux/Action/userAction";
import ConfirmationAlert from "../../../../Components/ConfirmationPopup";
const PICountLists = ({ ...props }: any) => {
  const isFocused = useIsFocused();
  const itemDetailsRef = useRef<any>(null);
  const piCountData = useSelector((state: any) => state.picontReducer);
  const {
    piCountConfirmedProductsList,
    piCountPendingProductsList,
    piCountNoData,
  } = useSelector((state: any) => state.picontReducer);
  const [defPending, setDefPending] = useState(null);
  const [defConfirm, setDefConfirm] = useState(null);
  const [showLoader, setShowLoader] = useState(false);
  const [saveLoader, setSaveLoader] = useState<any>(false);
  const [completeLoader, setCompleteLoader] = useState<any>(false);
  const [clearModal, setClearModal] = useState(false);
  const [isNoPendingdata, setIsNoPendingdata] = useState(false);
  const [isNoConfirmdata, setIsNoConfirmdata] = useState(false);
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const [reasonCodes, setreasonCodes] = useState([]);
  const profileData = useSelector((state: any) => state.accountReducer?.data);
  const [selectedReasonCode, setSelectedReasonCode] = useState({
    code: "",
    id: null,
  });

  const Tabs = [
    {
      name: Strings["ime.pending"],
      count: piCountPendingProductsList?.length
        ? piCountData?.totalCount ?? 0
        : 0,
      id: 1,
      // component: RenderAll,
    },
    {
      name: Strings["confirm"] ?? "Confirm",
      count: piCountConfirmedProductsList?.length
        ? piCountData?.totalCount ?? 0
        : 0,
      id: 2,
      // component: RenderReady,
    },
  ];
  const { stockRoomDetail, dateFormat, org_details, confirmationAlertInfo } =
    useSelector((state: any) => state.userReducer);
  const [selectedIndex, setSelectedIndex] = useState(1);
  const [selectedProductItem, setSelectedProductItem] = useState(null);
  const bottomSheetRef = useRef<any>(null);
  const addCodeBottomSheetRef = useRef<any>(null);
  const [search, setSearch] = useState("");
  const [productSearchKey, setProductSearchKey] = useState("");
  const [confirmationModel, setConfirmationModal] = useState(false);
  const [isSAPCheckingDone, setisSAPCheckingDone] = useState(false);
  const [isHandlingScroll, setIsHandlingScroll] = useState(false);
  const [pageSize, setPageSize] = useState(10);
  useEffect(() => {
    dispatch(
      getReasonCode(
        { codeType: "stock.correction" },
        stockRoomDetail?.stockroomType
      )
    );
  }, []);

  useFocusEffect(
    useCallback(() => {
      dispatch(setIsShowConfirmationAlert({}));
    }, [])
  );
  useEffect(() => {
    if (!!isSAPCheckingDone)
      setTimeout(() => {
        onSavePiCountPressed(2);
      }, 800);
  }, [isSAPCheckingDone]);
  useEffect(() => {
    if (selectedIndex == 1)
      setIsNoPendingdata(!piCountPendingProductsList?.length);
    if (selectedIndex == 2)
      setIsNoConfirmdata(!piCountConfirmedProductsList?.length);
    if (defPending?.length == 0) {
      let upPrdts = JSON.parse(JSON.stringify(piCountPendingProductsList));
      setDefPending(upPrdts);
    }
    if (defConfirm?.length == 0) {
      let upCPrdts = JSON.parse(JSON.stringify(piCountConfirmedProductsList));
      setDefConfirm(upCPrdts);
    }
  }, [selectedIndex, piCountPendingProductsList, piCountConfirmedProductsList]);

  useEffect(() => {
    const unsubscribe = props.navigation.addListener("focus", () => {
      setSelectedReasonCode({
        code: "",
        id: null,
      });
      setPageSize(10);
      setSelectedIndex(1);
      changeUpdatedConfirmProducts(null);
      setisSAPCheckingDone(false);
      changeUpdatedPendingProducts(null);
      setDefPending(null);
      setDefConfirm(null);
      setShowLoader(false);
    });
    if (isFocused) {
      dispatch(setLoader(true));
      setTimeout(() => {
        dispatch(
          getPIProductsList({
            piCountId: piCountData?.selectedPiCountValue?.id,
            pageSize,
            selectedReasonCode: {
              code: "",
              id: null,
            },
            isAllSelected: false,
            selectedIndex: selectedIndex,
          })
        );
      }, 300);
    }
    return unsubscribe;
  }, [isFocused]);

  const onSelectReasonCode = (itemIndex) => {
    onSelectReasonCodeLogic(reasonCodes, itemIndex, setReasonCode);
  };

  const setFormatedData = async (value, id) => {
    let updatedProducts;
    if (selectedIndex == 1) {
      updatedProducts = piCountPendingProductsList?.length
        ? [...piCountPendingProductsList]
        : null;
      const index = updatedProducts?.findIndex((item) => item.id == id);
      if (index !== -1) {
        updatedProducts[index].batchProducts = value;
      }
      changeUpdatedPendingProducts(updatedProducts);
    } else {
      const index = piCountConfirmedProductsList?.findIndex(
        (item) => item.id == id
      );
      if (index !== -1) {
        piCountConfirmedProductsList[index].formatedData = value;
        piCountConfirmedProductsList[index].batchProducts = value;
      }
      changeUpdatedConfirmProducts(piCountConfirmedProductsList);
    }
  };

  const changeUpdatedPendingProducts = async (data) => {
    await dispatch(setUpdatedPendingProducts(data));
  };
  const changeUpdatedConfirmProducts = async (data) => {
    await dispatch(setUpdatedConfirmProducts(data));
  };
  const addReasonCode = () => {
    bottomSheetRef.current.close();
    addCodeBottomSheetRef.current.open();
  };
  const onProductLevelReasonCodeSelected = (value, index) => {
    const newProducts =
      selectedIndex == 1
        ? piCountPendingProductsList
        : piCountConfirmedProductsList;
    newProducts[index].reasonCode = value;
    selectedIndex == 1
      ? changeUpdatedPendingProducts(newProducts)
      : changeUpdatedConfirmProducts(newProducts);
    setisSAPCheckingDone(false);

    bottomSheetRef.current.close();
  };
  const itemSeparator = () => {
    return (
      <View
        accessible={true}
        accessibilityLabel="item_separator"
        style={styles.separator}
      />
    );
  };
  const itemFooter = () => {
    return (
      <View
        accessible={true}
        accessibilityLabel="footer_component"
        style={styles.itemFooter}
      />
    );
  };
  const getLists = (array: any) => {
    return array?.map((item, index) => {
      const product = item?.product;
      const uomId =
        product?.uomManagementEnabled == 1
          ? product?.stockRoomUOMUnit
          : product?.uomId;

      let batches = item?.batchProducts?.map((i: any) => {
        const { batchNo, actualQty, availableQty, id, expiryDate } = i;
        return {
          batchNo: batchNo ?? "",
          actualQty: actualQty ?? "",
          availableQty: availableQty ?? 0,
          id: id ?? null,
          expiryDate: expiryDate ?? "",
        };
      });
      const variationQty = getVariationQty(item);
      return (
        <PICountListItem
          product={product}
          item={item}
          index={index}
          uomId={uomId}
          batches={batches}
          styles={styles}
          selectedIndex={selectedIndex}
          variationQty={variationQty}
          onProductNameClicked={onProductNameClicked}
          isBatchEnabled={checkifBatchEnabled(item)}
          isExpiryEnabled={checkifExpiryEnabled(item)}
          onPendingItemCheckPressed={onPendingItemCheckPressed}
          onConfirmedItemCheckPressed={onConfirmedItemCheckPressed}
          handleBatch={handleBatch}
          handleBatchDelete={handleBatchDelete}
          handleAvailQty={handleAvailQty}
          setFormatedData={setFormatedData}
          updateProductLevelQty={updateProductLevelQty}
          onProductLevelReasonCodeSelected={onProductLevelReasonCodeSelected}
          showToast={showToast}
        />
      );
    });
  };
  // const getSelectedProductCount = (products) => {
  //   return products?.filter((product) => product?.isSelected)?.length;
  // };
  const isAllPendingProductsSelected = () => {
    return piCountPendingProductsList?.every((product) => product?.isSelected);
  };

  const isAllConfirmedProductsSelected = () => {
    return piCountConfirmedProductsList?.every(
      (product) => product?.isSelected
    );
  };
  const onProductNameClicked = async (item) => {
    setSelectedProductItem(item);
    itemDetailsRef?.current?.open();
  };
  const checkifBatchEnabled = (item) => {
    let value = false;
    let product = item.product;
    if (
      !!stockRoomDetail?.isBatchManagementEnabled &&
      !!product?.batchManagementEnabled
    ) {
      /**Stock room level "isBatchManagementEnabled"  should be true to display the batches in the screen*/
      /**Product level "batchManagementEnabled"   should be true to display the batches in the screen also based on the
                * 1. batch enabled true, exp date false -- batch no existing show, existing date don't show, field should be disabled.
                   2. batch enabled false, exp date true -- exp date existing show, existing batch no don't show, it should be disabled.
                   3. batch enabled false, exp date false -- no batch, all products normal
                   4. batch enabled true, exp date true -- add to batch, batch visible with exp date and batch no. We have to validate on batch product level also, by using "batchManagementEnabled": 0,
                   "expiryDateManagementenabled": 0
    */
      value = true;
      return value;
    }
  };
  const checkifExpiryEnabled = (item) => {
    let value = false;
    let product = item.product;
    if (
      !!stockRoomDetail?.isExpiryManagementEnabled &&
      !!product?.expiryDateManagementenabled
    ) {
      /**Stock room level  "isExpiryManagementEnabled" should be true to display the batches in the screen*/
      /**Product level   "expiryDateManagementenabled" should be true to display the batches in the screen also based on the
       */
      value = true;
      return value;
    }
  };

  const onGlobalReasonCodeSelected = (item) => {
    setisSAPCheckingDone(false);
    setSelectedReasonCode(item);
  };
  useEffect(() => {
    resetAllReasonCode();
  }, [selectedReasonCode]);

  const resetAllReasonCode = () => {
    const newProducts = piCountPendingProductsList?.length
      ? [...piCountPendingProductsList]
      : null;
    newProducts?.forEach((product) => {
      product.reasonCode = selectedReasonCode;
    });
    changeUpdatedPendingProducts(newProducts);
    bottomSheetRef.current.close();
  };
  const resetProductsData = async (shoulGoBack: boolean) => {
    setSelectedReasonCode("");
    setPageSize(10);
    setSelectedIndex(selectedIndex);
    setisSAPCheckingDone(false);
    if (shoulGoBack) {
      props.navigation.goBack();
    } else {
      if (selectedIndex == 1) {
        dispatch(resetAllPIPendingProducts());
      } else {
        dispatch(resetAllPIConfirmProducts());
      }
      dispatch(
        getPIProductsList({
          piCountId: piCountData?.selectedPiCountValue?.id,
          pageSize: 10,
          selectedReasonCode: {
            code: "",
            id: null,
          },
          isAllSelected: false,
          selectedIndex: selectedIndex,
        })
      );
      // selectedIndex == 1
      //   ? changeUpdatedPendingProducts(null)
      //   : changeUpdatedConfirmProducts(null);
      // setShowLoader(true);
      // setTimeout(async () => {
      //   if (selectedIndex == 1) {
      //     let upPPrdts = JSON.parse(JSON.stringify(defPending));
      //     await changeUpdatedPendingProducts(upPPrdts);
      //   } else {
      //     let upCPrdts = JSON.parse(JSON.stringify(defConfirm));
      //     await changeUpdatedConfirmProducts(upCPrdts);
      //   }
      //   setShowLoader(false);
      // }, 1500);
    }
  };
  /**
   * Pagination
   */
  const isCloseToBottom = ({
    layoutMeasurement,
    contentOffset,
    contentSize,
  }: any) => {
    const paddingToBottom = 20;
    return (
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom
    );
  };
  const handleScroll = () => {
console.log("--------------reach end")

    const newProducts =
      selectedIndex == 1
        ? piCountPendingProductsList
        : piCountConfirmedProductsList;
    if (!piCountData.loader && newProducts?.length < piCountData?.totalCount) {
      loadMoreData();
    } else {
      setIsHandlingScroll(false);
    }
  };
  const loadMoreData = () => {
    dispatch(
      getPIProductsList({
        piCountId: piCountData?.selectedPiCountValue?.id,
        pageSize: pageSize + 10,
        limit: 10,
        total: piCountData?.totalCount,
        selectedReasonCode: selectedReasonCode,
        isAllSelected:
          selectedIndex == 1
            ? isAllPendingProductsSelected()
            : isAllConfirmedProductsSelected(),
        selectedIndex: selectedIndex,
      })
    );
    setPageSize((prv) => pageSize + 10);
    setTimeout(() => {
      setIsHandlingScroll(false);
    }, 500);
  };
  /*******************************************/
  const handleAvailQty = (val: any, id: any) => {
    // toggleSelectionOnBatchQty(id);
    handleAvailQtyLogic(
      val,
      id,
      selectedIndex,
      changeUpdatedPendingProducts,
      changeUpdatedConfirmProducts,
      dispatch,
      selectedIndex == 1
        ? piCountPendingProductsList
        : piCountConfirmedProductsList
    );
  };
  const handleBatch = (batches: any, batchId: string, itemId: string) => {
    handleBatchesLogic(
      selectedIndex == 1
        ? piCountPendingProductsList
        : piCountConfirmedProductsList,
      batches,
      batchId,
      itemId,
      selectedIndex,
      changeUpdatedPendingProducts,
      changeUpdatedConfirmProducts,
      dispatch
    );
  };
  const handleBatchDelete = async (batchitem: any, val: any, item: any) => {
    handleBatchDeleteLogic(
      batchitem,
      val,
      selectedIndex,
      piCountPendingProductsList,
      piCountConfirmedProductsList,
      changeUpdatedPendingProducts,
      changeUpdatedConfirmProducts,
      dispatch,
      item
    );
  };
  const onConfirmedItemCheckPressed = (index: any, value?: any) => {
    // let productsArray = [...piCountConfirmedProductsList];
    // productsArray[index].isSelected =
    //   value == 0 ? false : !productsArray[index].isSelected;
    // changeUpdatedConfirmProducts(productsArray);
  };
  const onPendingItemCheckPressed = (index: any, value?: any) => {
    // const updatedProducts = piCountPendingProductsList;
    // updatedProducts[index] = {
    //   ...updatedProducts[index],
    // isSelected: value == 0 ? false : !updatedProducts[index].isSelected,
    // };
    // changeUpdatedPendingProducts(updatedProducts);
  };
  const toggleSelectionOnQty = (value, pIndex, bIndex?: any) => {
    if (selectedIndex == 1) {
      if (parseInt(value) == 0) {
        onPendingItemCheckPressed(pIndex, value);
      } else if (
        parseInt(value) > 0 &&
        !piCountPendingProductsList[pIndex].isSelected
      ) {
        onPendingItemCheckPressed(pIndex, value);
      }
    } else {
      if (parseInt(value) == 0) {
        onConfirmedItemCheckPressed(pIndex, value);
      } else if (
        parseInt(value) > 0 &&
        !piCountConfirmedProductsList[pIndex].isSelected
      ) {
        onConfirmedItemCheckPressed(pIndex, value);
      }
    }
  };

  // const toggleSelectionOnBatchQty = (id) => {
  //   if (selectedIndex === 1) {
  //     const pIndex = piCountPendingProductsList?.findIndex(
  //       (item) => item.id === id
  //     );
  //     const batches = piCountPendingProductsList[pIndex]?.batchProducts;
  //     const flag = batches?.every((item) => !!parseInt(item.actualQty));
  //     if (!flag && !!piCountPendingProductsList[pIndex].isSelected) {
  //       onPendingItemCheckPressed(pIndex);
  //     } else if (flag && !piCountPendingProductsList[pIndex].isSelected) {
  //       onPendingItemCheckPressed(pIndex);
  //     }
  //   } else {
  //     const pIndex = piCountConfirmedProductsList?.findIndex(
  //       (item) => item.id === id
  //     );
  //     const batches = piCountConfirmedProductsList[pIndex]?.batchProducts;
  //     const flag = batches?.every((item) => !!parseInt(item.actualQty));

  //     if (!flag && !!piCountConfirmedProductsList[pIndex].isSelected) {
  //       onConfirmedItemCheckPressed(pIndex);
  //     } else if (flag && !piCountConfirmedProductsList[pIndex].isSelected) {
  //       onConfirmedItemCheckPressed(pIndex);
  //     }
  //   }
  // };
  const updateProductLevelQty = (value, pIndex) => {
    toggleSelectionOnQty(value, pIndex);

    if (value != "" && value != null)
      if (selectedIndex == 1) {
        const updatedProducts = piCountPendingProductsList;
        updatedProducts[pIndex] = {
          ...updatedProducts[pIndex],
          actualQty: value,
        };
        changeUpdatedPendingProducts(updatedProducts);
      } else {
        const updatedProducts = piCountConfirmedProductsList;
        updatedProducts[pIndex] = {
          ...updatedProducts[pIndex],
          actualQty: value,
        };
        changeUpdatedConfirmProducts(updatedProducts);
      }
  };
  const keyExtractor = (item) => item.id?.toString();
  const RenderConfirmComponent = () => {
    const isAllSelected = isAllConfirmedProductsSelected();
    return (
      <View
        style={{
          height: "65%",
        }}
      >
        {/* <ScrollView
          onScroll={({ nativeEvent }) => {
            if (!isHandlingScroll && isCloseToBottom(nativeEvent)) {
              setIsHandlingScroll((prv) => true);
              handleScroll();
            }
          }}
          scrollEventThrottle={400}
        > */}
          {piCountConfirmedProductsList?.length
            ? getLists(piCountConfirmedProductsList)
            : (piCountConfirmedProductsList?.length == 0 ||
                !piCountConfirmedProductsList) &&
              noDataFound()}
          {/* //  !piCountData.loader && !showLoader && noDataFound()} */}
        {/* </ScrollView> */}
      </View>
    );
  };

  console.log("piCountNoData", piCountNoData);

  const RenderComponent = () => {
    return piCountPendingProductsList?.length ? (
      <View
        style={{
          height: "65%",
        }}
      >
        <ReasonCode
          containerStyle={styles.reasonContainer}
          reasonCodeType="stock.correction"
          from={"masterCode"}
          reason={selectedReasonCode}
          setReason={onGlobalReasonCodeSelected}
          showToast={showToast}
        />
        <View
          accessible={true}
          accessibilityLabel="tools_container"
          style={styles.toolsContainer}
        >
          <View
            accessible={true}
            accessibilityLabel="alternate_picount_container"
          >
            <CustomText
              accessibilityLabel="selected_pi_count_name"
              allowFontScaling={false}
              style={styles.demoMobilePiCount}
            >
              {piCountData?.selectedPiCountValue?.piCountName}
            </CustomText>
            <CustomText
              accessible={true}
              accessibilityLabel="select_alternate_pi_count_button"
              allowFontScaling={false}
              style={styles.alternateMobilePiCount}
              onPress={() => {
                setSelectedReasonCode({
                  code: "",
                  id: null,
                });
                dispatch(resetAllPIPendingProducts());
                dispatch(resetAllPIConfirmProducts());
                props.navigation.navigate("PiCount");
              }}
            >
              {Strings["ime.scanner.Select.Alternate.PI.Count"]}
            </CustomText>
          </View>
        </View>
        {/* <ScrollView
          onScroll={({ nativeEvent }) => {
            if (!isHandlingScroll && isCloseToBottom(nativeEvent)) {
              setIsHandlingScroll((prv) => true);
              handleScroll();
            }
          }}
          scrollEventThrottle={400}
          // keyboardShouldPersistTaps="handled"
          // keyboardDismissMode="on-drag"
        > */}
          {/* <KeyboardAvoidingView behavior="height"> */}
            {getLists(piCountPendingProductsList)}
          {/* </KeyboardAvoidingView> */}
        {/* </ScrollView> */}
      </View>
    ) : (
      <View
        accessible={true}
        accessibilityLabel="tools_container"
        style={styles.toolsContainer_noData}
      >
        <View
          accessible={true}
          accessibilityLabel="alternate_picount_container"
        >
          <CustomText
            accessibilityLabel="selected_pi_count_name"
            allowFontScaling={false}
            style={styles.demoMobilePiCount}
          >
            {piCountData?.selectedPiCountValue?.piCountName}
          </CustomText>
          <CustomText
            accessible={true}
            accessibilityLabel="select_alternate_pi_count_button"
            allowFontScaling={false}
            style={styles.alternateMobilePiCount}
            onPress={() => {
              props.navigation.navigate("PiCount");
            }}
          >
            {Strings["ime.scanner.Select.Alternate.PI.Count"]}
          </CustomText>
        </View>
        <View
          style={{
            justifyContent: "center",
            width: "100%",
            paddingVertical: hp(10),
          }}
        >
          {(piCountPendingProductsList?.length == 0 ||
            !piCountPendingProductsList) &&
            noDataFound()}
          {/* {!piCountData.loader && piCountNoData && noDataFound()} */}
        </View>
      </View>
    );
  };

  const _renderItem = ({ item, index }) => {
    return (
      <TouchableOpacity
        accessible={true}
        accessibilityLabel="select_reason_code_item_button"
        onPress={() => {
          showProductList(index);
        }}
        style={styles.itemContainer}
      >
        <CustomText
          allowFontScaling={false}
          accessibilityLabel="reasoncode_name_value"
          style={{
            ...styles.renderItemTitle,
            fontFamily: item.isSelected
              ? FONTFAMILY.averta_bold
              : FONTFAMILY.averta_regular,
          }}
        >
          {item.name}
        </CustomText>
        {!!item.isSelected && (
          <BlueTick
            height={hp(2)}
            width={hp(2)}
            color="red"
            style={styles.checkIcon}
          />
        )}
      </TouchableOpacity>
    );
  };
  const onChangeCloseBtnPress = () => {
    bottomSheetRef.current.close();
  };
  const onChangeCancelBtnPress = () => {
    addCodeBottomSheetRef.current.close();
  };
  const getVariationQty = (prdt) => {
    let variationQty = 0;
    variationQty =
      (prdt.actualQty ?? 0) - (parseInt(prdt.product.availableQty) ?? 0);
    return prdt.actualQty == null
      ? selectedIndex == 1
        ? ""
        : 0
      : variationQty ?? 0;
  };
  const showToast = (text1: string, text2: string) => {
    Toast.show({
      type: "alertToast",
      text1: text1,
      text2: text2,
      position: "bottom",
      bottomOffset: SIZES.padding * 2,
    });
  };
  const onSavePiCountPressed = async () => {
    const reasonSuffix =
      stockRoomDetail?.stockroomType == "Regular"
        ? false
        : org_details?.showSapSetting;
    onSavePICountLogic(
      piCountPendingProductsList,
      piCountData,
      isSAPCheckingDone,
      reasonSuffix,
      setConfirmationModal,
      showToast,
      checkifBatchEnabled,
      checkifExpiryEnabled,
      moment,
      dateFormat,
      getVariationQty,
      selectedReasonCode,
      profileData,
      onSaveValidationSuccessCallBack,
      Strings
    );
  };
  const onCompleteeValidationSuccessCallBack = (params, index) => {
    setCompleteLoader(true);
    dispatch(
      completePICount(
        params,
        (res) => {
          setCompleteLoader(false);

          dispatch(resetAllPIConfirmProducts());
          dispatch(resetAllPIPendingProducts());
          Toast.show({
            type: "alertToast",
            text1:
              Strings["ime.scanner.pi.count.completed"] ?? "PI COUNT COMPLETED",
            text2:
              Strings["ime.scanner.pi.count.completed.succesfully"] ??
              "PI count completed succesfully",
            position: "bottom",
          });
          setTimeout(() => {
            props.navigation.goBack();
          }, 1000);
        },
        () => {
          setCompleteLoader(false);
        }
      )
    );
  };
  const onSaveValidationSuccessCallBack = (params, index) => {
    setSaveLoader(true);
    dispatch(
      savePICount(
        params,
        (res) => {
          onSuccessCallback(index);
        },
        () => {
          setSaveLoader(false);
        }
      )
    );
  };
  const onSuccessCallback = async (index) => {
    dispatch(resetAllPIPendingProducts());
    setSelectedReasonCode({ code: "", id: null });

    setSaveLoader(false);
    setSelectedIndex(index);
    dispatch(setLoader(true));
    dispatch(
      getPIProductsList({
        piCountId: piCountData?.selectedPiCountValue?.id,
        pageSize: 10,
        selectedReasonCode: selectedReasonCode,
        isAllSelected: false,
        selectedIndex: selectedIndex,
      })
    );
  };
  const onCompletePICountPressed = () => {
    onCompletePICountLogic(
      piCountConfirmedProductsList,
      piCountData,
      showToast,
      checkifBatchEnabled,
      checkifExpiryEnabled,
      moment,
      dateFormat,
      getVariationQty,
      selectedReasonCode,
      profileData,
      onCompleteeValidationSuccessCallBack,
      Strings
    );
  };
  const showProductList = (index: Number) => {
    onSelectReasonCode(index);
    bottomSheetRef.current.close();
  };

  const getTabData = () => {
    switch (selectedIndex) {
      case 1:
        return <>{RenderComponent()}</>;
      case 2:
        return <>{RenderConfirmComponent()}</>;

      default:
        break;
    }
  };
  const saveButtonText = saveLoader ? (
    <HalfLoader />
  ) : (
    Strings["ime.scanner.Save.PI.Count"] ?? "Save PI Count"
  );
  const completeButtonText = completeLoader ? (
    <HalfLoader />
  ) : (
    Strings["ime.scanner.Complete.PI.Count"] ?? "Complete PI Count"
  );
  const noDataFound = () => {
    if (
      !piCountData.loader &&
      !showLoader &&
      ((selectedIndex == 1 && isNoPendingdata) ||
        (selectedIndex == 2 && isNoConfirmdata))
    )
      return (
        <View style={styles.emptyDataContainer}>
          <CustomText style={styles.emptyText}>
            {Strings["no.records.found"]}
          </CustomText>
        </View>
      );
    else return <View />;
  };
  return (
    <View
      accessible={true}
      accessibilityLabel="screen_main_container"
      style={styles.container}
    >
      <Header
        title={Strings["pi.count"]}
        onLeftIconPress={() => {
          Keyboard.dismiss();
          props.navigation.getParent("Drawer").openDrawer();
        }}
        onRightIconPress={() => console.log("")}
        statusBar={true}
        statusBarColor={"blue"}
        iconLeft={true}
        iconRight={true}
      />
      <Subheader
        onChangePress={() => console.log("Change btn pressed")}
        distance={10}
        rowContainer={styles.rowContainer}
      />
      <TopTabs
        Tabs={Tabs}
        selectedIndex={selectedIndex}
        setSelectedIndex={setSelectedIndex}
        style={styles}
      />
         <KeyboardAvoidingView behavior="padding" style={{ height: hp(68) }}>
         <ScrollView style={{ flex: 1 }}
          onScroll={({ nativeEvent }) => {
            if (!isHandlingScroll && isCloseToBottom(nativeEvent)) {
              setIsHandlingScroll((prv) => true);
              handleScroll();
            }
          }}
         >
          {getTabData()}
          </ScrollView>
        </KeyboardAvoidingView>
      <Footer
        mainButtonDisabled={
          (selectedIndex == 1 && !piCountPendingProductsList?.length) ||
          (selectedIndex == 2 && !piCountConfirmedProductsList?.length) ||
          saveLoader ||
          completeLoader
        }
        count={
          selectedIndex == 1
            ? piCountPendingProductsList
              ? piCountPendingProductsList?.length
              : 0 // getSelectedProductCount(piCountPendingProductsList)
            : piCountConfirmedProductsList
            ? piCountConfirmedProductsList?.length
            : 0 // getSelectedProductCount(piCountConfirmedProductsList)
        }
        mainbuttonTitle={
          selectedIndex == 1 ? saveButtonText : completeButtonText
        }
        tertiaryButtonTitle={Strings["ime.scanner.clear"] ?? "Clear"}
        tertiaryryButtonDisabled={
          selectedIndex == 1
            ? !piCountPendingProductsList?.length
            : !piCountConfirmedProductsList?.length
        }
        mainButtonStyle={
          selectedIndex == 1 ? null : styles.footerMainButtonStyle
        }
        outlinedBtnContainerStyle={styles.footerBtnContainer}
        tertiaryBtnContainerStyle={styles.tertiaryBtnContainer}
        onChangeSecondaryBtnPress={() => console.log("d")}
        onChangePrimaryBtnPress={() => {
          if (selectedIndex === 1) {
            onSavePiCountPressed();
          } else {
            onCompletePICountPressed();
          }
        }}
        onChangeTertiaryBtnPress={() => {
          setClearModal(true);
        }}
        mainContainerStyle={styles.footerContainerStyle}
      />
      <BottomSheetComponent
        bottomSheetRef={addCodeBottomSheetRef}
        closeOnDragDown={false}
        height={hp(30)}
        customStyles={styles.addCodeBottomSheetContainer}
      >
        <ScrollView
          keyboardShouldPersistTaps="handled"
          nestedScrollEnabled={true}
          style={styles.rendercomponentContainer}
        >
          <View
            accessible={true}
            accessibilityLabel="popup_header_container"
            style={styles.headerContainer}
          >
            <View style={styles.emptyContainer} />
            <CustomText
              accessibilityLabel="add_reasoncode_popup_title"
              allowFontScaling={false}
              style={styles.headerTitle}
            >
              {Strings["ime.add.reason.code"]}
            </CustomText>
            <View
              accessible={true}
              accessibilityLabel="popup_cancel_button_container"
              style={styles.buttonContainer}
            >
              <TouchableOpacity
                accessible={true}
                accessibilityLabel="add_reasoncode_bottom_sheet_close_button"
                style={styles.secondaryPressableContainer}
                onPress={() => onChangeCancelBtnPress()}
              >
                <CustomText
                  accessibilityLabel="add_reasoncode_cancel_label"
                  allowFontScaling={false}
                  style={styles.addCodeSecondaryPressableText}
                >
                  {Strings["cancel"]}
                </CustomText>
              </TouchableOpacity>
            </View>
          </View>
          <View
            accessible={true}
            accessibilityLabel="input_container"
            style={{}}
          >
            <TextInputComponent
              title={Strings["source.stockroom"]}
              // RightIcon={ArrowDown}
              onPressRightIcon={() => console.log("right icon pressed")}
              value={""}
              placeholder={Strings["ime.scanner.New.reason.code"]}
              placeholderTextColor={COLORS.abbey}
              editable={true}
              main={{ ...styles.mainAddCodeInputTop, marginTop: wp(8) }}
              // rightIconWidth={hp(1.7)}
              inputStyle={styles.inputStyle}
              // required={true}
              autoFocus
              titleStyle={{ color: COLORS.fastGray }}
            />
            <TextInputComponent
              title={Strings["select.code.type"]}
              RightIcon={ArrowDown}
              onPressRightIcon={() => console.log("right icon pressed")}
              value={Strings["im.select"]}
              editable={false}
              main={{ ...styles.mainAddCodeInputTop }}
              rightIconWidth={hp(1.7)}
              inputStyle={styles.inputStyle}
              required={true}
              titleStyle={{ color: COLORS.fastGray }}
            />
          </View>
        </ScrollView>
      </BottomSheetComponent>
      <BottomSheetComponent
        bottomSheetRef={bottomSheetRef}
        closeOnDragDown={false}
        height={hp(50)}
        customStyles={styles.bottomsheetContainer}
      >
        <ScrollView
          nestedScrollEnabled={true}
          keyboardShouldPersistTaps="handled"
          style={styles.renderBottomSheetContainer}
        >
          <View
            accessible={true}
            accessibilityLabel="popup_header_container"
            style={styles.headerContainer}
          >
            <View style={styles.emptyContainer} />
            <CustomText
              accessibilityLabel=""
              allowFontScaling={false}
              style={styles.headerTitle}
            >
              {Strings["pi.count"]}
            </CustomText>
            <View
              accessible={true}
              accessibilityLabel="popup_close_button_container"
              style={styles.buttonContainer}
            >
              <TouchableOpacity
                accessible={true}
                accessibilityLabel="reasoncode_bottom_sheet_close_button"
                style={styles.secondaryPressableContainer}
                onPress={() => onChangeCloseBtnPress()}
              >
                <CustomText
                  allowFontScaling={false}
                  style={styles.secondaryPressableText}
                >
                  {Strings["close"]}
                </CustomText>
              </TouchableOpacity>
            </View>
          </View>
          <SearchBar
            search={search}
            placeholder={Strings["search"]}
            onSearch={() => {}}
            containerStyle={styles.searchContainerStyle}
            onSearch={(value) => setSearch(value)}
          />
          <FlatList
            data={reasonCodes}
            renderItem={_renderItem}
            style={styles.flatListStyle}
            ItemSeparatorComponent={itemSeparator}
          />
        </ScrollView>
        <MainButton
          accessibilityLabel="add_reasoncode_button"
          title={Strings["ime.add.reason.code"]}
          buttonStyle={styles.buttonStyle}
          onChangeBtnPress={addReasonCode}
        />
      </BottomSheetComponent>
      <ProductDetails
        itemDetailsRef={itemDetailsRef}
        productDetailsList={selectedProductItem?.product}
        isShowPrice={stockRoomDetail?.isReplishIndividual}
      />
      <DecisionModal
        show={clearModal}
        title={"Are you sure you want to clear?"}
        description={
          Strings["ime.any.information.entered.desc"] ??
          "Any information you have entered on the form will be deleted."
        }
        secondaryBtnText={Strings["no"]}
        primaryBtnText={Strings["yes"]}
        onSecondaryPress={() => setClearModal(false)}
        onPrimaryPress={() => {
          setClearModal(false);
          setTimeout(() => {
            resetProductsData(false);
          }, 300);
        }}
        btnContainer={styles.btnContainer}
        btnWrapper={styles.btnWrapper}
      />
      <ClearSelectionAlert
        isShow={confirmationModel}
        didCloseModal={() => {
          setisSAPCheckingDone(false);
          setConfirmationModal(false);
        }}
        outlinedButtonTitle={Strings["cancel"]}
        didOutlinedButtonClicked={() => {
          setisSAPCheckingDone(false);
          setConfirmationModal(false);
        }}
        mainButtonTitle={Strings["yes"]}
        didMainButtonTitleClicked={async () => {
          setisSAPCheckingDone(true);
          setConfirmationModal(false);
        }}
        orderTitle={Strings["ime.scanner.Sync.with.SAP"]}
        orderDesc={Strings["ime.scanner.Sync.with.SAP.msg"]}
      />
      <ToastComponent />
      <ConfirmationAlert
        onTapNo={() => {}}
        onTapYes={() => {
          dispatch(
            setIsShowConfirmationAlert({
              isShow: false,
              data: confirmationAlertInfo?.data,
            })
          );
          resetProductsData(true);
        }}
        onBack={() => {}}
      />
      <Loader show={showLoader || piCountData.loader} />
    </View>
  );
};

export default PICountLists;
