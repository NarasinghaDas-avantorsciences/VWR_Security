const onSelectReasonCodeLogic = async (
  reasonCodes: any,
  itemIndex: any,
  setreasonCodes: any
) => {
  try {
    let reasonCodeArray = reasonCodes;
    reasonCodeArray.map((item, index) => {
      item.isSelected = false;
    });
    reasonCodeArray[itemIndex].isSelected = true;
    setreasonCodes(reasonCodeArray);
  } catch (error) {
    // Handle storage error
    onError(error);
  }
};

const handleAvailQtyLogic = async (
  val: any,
  id: any,
  selectedIndex: any,
  changeUpdatedPendingProducts: any,
  changeUpdatedConfirmProducts: any,
  dispatch: any,
  products: any
) => {
  await products.map((item) => {
    if (item.id === id) {
      item.actualQty = !val ? 0 : parseInt(val);
    }
  });
  if (selectedIndex == 1 && products?.length)
    changeUpdatedPendingProducts(products);
  else changeUpdatedConfirmProducts(products);
};

const handleBatchesLogic = async (
  products: any,
  batches: any,
  batchId: any,
  itemId: any,
  selectedIndex: any,
  changeUpdatedPendingProducts: any,
  changeUpdatedConfirmProducts: any,
  dispatch: any
) => {
  let arr = products;

  let arrIndex = arr?.findIndex((obj: { id: any }) => obj?.id == itemId);

  let batchIndex = batches?.findIndex((obj: { id: any }) => obj?.id == batchId);

  const itemIndex = arr[arrIndex]?.batchProducts.findIndex(
    (obj: { id: string }) => obj?.id == batchId
  );

  if (itemIndex >= 0) {
    await arr[arrIndex]?.batchProducts.map((obj: any) => {
      if (obj?.id == batchId) {
        obj["actualQty"] = batches[batchIndex]["actualQty"];
        obj["batchNo"] = batches[batchIndex]["batchNo"];
        obj["expiryDate"] = batches[batchIndex]["expiryDate"];
      }
    });
  } else {
    arr[arrIndex]?.batchProducts?.push(batches[batchIndex]);
  }
  selectedIndex == 1 && arr?.length
    ? changeUpdatedPendingProducts(arr)
    : changeUpdatedConfirmProducts(arr);
};

const handleBatchDeleteLogic = async (
  batchItem: any,
  val: any,
  selectedIndex: any,
  products: any,
  confirmedProducts: any,
  changeUpdatedPendingProducts: any,
  changeUpdatedConfirmProducts: any,
  dispatch: any,
  item: any
) => {
  let arr = selectedIndex == 1 ? products : confirmedProducts;

  let objIndex = arr.findIndex((obj: { id: any }) => obj?.id == item?.id);
  const findIndex = arr[objIndex]?.batchProducts?.findIndex(
    (obj: { id: any }) => obj?.id === val?.id
  );
  findIndex !== -1 && arr[objIndex]?.batchProducts?.splice(findIndex, 1);
  console.warn(findIndex);

  selectedIndex == 1 && arr?.length
    ? changeUpdatedPendingProducts([...arr])
    : changeUpdatedConfirmProducts([...arr]);

  // let arr = selectedIndex == 1 ? [...products] : [...confirmedProducts];

  // let findIndex = -1;
  // arr.map((item, index) => {
  //   if (item.batchProducts?.length) {
  //     findIndex = item.batchProducts.findIndex(
  //       (obj: { id: any }) => obj?.id == batchitem?.id
  //     );
  //     if (findIndex != -1) {
  //       item.batchProducts?.splice(findIndex, 1);
  //     }
  //   }
  // });

  // // const findIndex = arr[objIndex]?.batchProducts?.findIndex(
  // //   (obj: { id: any }) => obj?.id === val?.id
  // // );

  // // findIndex !== -1 && arr[objIndex]?.batchProducts?.splice(findIndex, 1);
  // selectedIndex == 1 && arr?.length
  //   ? changeUpdatedPendingProducts([...arr])
  //   : changeUpdatedConfirmProducts([...arr]);
};

const onSavePICountLogic = async (
  products: any,
  piCountData: any,
  isSAPCheckingDone: any,
  reasonSuffix: any,
  setConfirmationModal: any,
  showToast: any,
  checkifBatchEnabled: any,
  checkifExpiryEnabled: any,
  moment: any,
  dateFormat: any,
  getVariationQty: any,
  selectedReasonCode: any,
  profileData: any,
  onSaveValidationSuccessCallBack: any,
  Strings: any
) => {
  let flag = 1;
  if (!products?.every((p: any) => p.reasonCode?.code)) {
    flag = 0;
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      Strings["ime.scanner.reason.code.required.msg"] ??
        "The reason code is required for all stocks!"
    );
  } else if (products?.length < piCountData.totalCount) {
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      "Please enter valid actual quantity for all the batches/products"
    );
  } else if (!isSAPCheckingDone && !!reasonSuffix) {
    let isSap = false;

    isSap = products.some(
      (item: { reasonCode: { dontSyncWithSap: string } }) =>
        item?.reasonCode?.dontSyncWithSap == "N"
    );

    if (isSap) {
      setConfirmationModal(true);
      flag = 0;
    }
  }

  if (flag == 1) {
    const selectedProducts = products?.map((item: any) => {
      let batches = [];

      if (
        (!!checkifBatchEnabled(item) || !!checkifExpiryEnabled(item)) &&
        item?.batchProducts?.length
      ) {
        item?.batchProducts.map((batch: any) => {
          const { batchNo, actualQty, expiryDate, availableQty, id } = batch;

          if (batchNo == "" && !!checkifBatchEnabled(item)) {
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.batch.empty.msg"]
            );
            // throw new Error("batchNo occured");
            flag = 0;
          } else if (
            (!expiryDate || expiryDate == "") &&
            !!checkifExpiryEnabled(item)
          ) {
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.expiry.date.empty.msg"]
            );
            // throw new Error("expiryDate occured");
            flag = 0;
          } else if (
            (actualQty == null || actualQty == "") &&
            !id?.includes("addedBatch")
          ) {
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              "Please enter valid actual quantity for all the batches/products"
            );
            // throw new Error("actualQty occured");
            flag = 0;
          }
          if (
            !id?.includes("addedBatch") ||
            (id?.includes("addedBatch") && actualQty != 0)
          )
            batches.push({
              id: id?.includes("addedBatch") ? null : id,
              availableQty: id?.includes("addedBatch")
                ? 0
                : availableQty
                ? availableQty
                : "0",
              batchNo: batchNo,
              actualQty: actualQty,
              expiryDate: expiryDate
                ? moment(expiryDate).format(dateFormat?.date)
                : null,
            });
        });
      } else {
        if (item.actualQty == null || item.actualQty == "") {
          showToast(
            Strings["ime.scanner.error.occured.msg"],
            "Please enter valid actual quantity for all the batches/products"
          );
          flag = 0;
          // throw new Error("actualQty occured");
        }
      }
      let qty = 0;

      if (batches?.length) {
        batches.forEach((item) => {
          const itemActualQty = parseInt(item?.actualQty)
            ? parseInt(item?.actualQty)
            : 0;
          qty = qty + itemActualQty;
        });
      } else {
        qty = item.actualQty;
      }
      return {
        reasonCode: { id: item.reasonCode.id },
        availableQty: item.product.availableQty,
        actualQty: qty,
        variationQty: getVariationQty(item),
        id: item.id,
        ...{ batchProducts: batches?.length ? batches : [] },
      };
    });

    if (selectedProducts?.length && flag == 1) {
      const params = {
        reasonCode: { id: selectedReasonCode?.id },
        user: { id: profileData.id },
        products: selectedProducts,
        selectedPICountId: piCountData?.selectedPiCountValue?.id,
      };
      onSaveValidationSuccessCallBack(params, 2);
    }
  }
};

const onCompletePICountLogic = async (
  confirmedProducts: any,
  piCountData: any,
  showToast: any,
  checkifBatchEnabled: any,
  checkifExpiryEnabled: any,
  moment: any,
  dateFormat: any,
  getVariationQty: any,
  selectedReasonCode: any,
  profileData: any,
  onCompleteeValidationSuccessCallBack: any,
  Strings: any
) => {
  let flag = 1;
  if (confirmedProducts?.length < piCountData.totalCount) {
    flag = 0;
    showToast(
      Strings["ime.scanner.error.occured.msg"],
      "Some of the products are missing!"
    );
  }
  if (flag == 1) {
    const selectedProducts = confirmedProducts.map((item: any) => {
      let batches;

      if (
        (!!checkifBatchEnabled(item) || !!checkifExpiryEnabled(item)) &&
        item?.batchProducts?.length
      ) {
        batches = item?.batchProducts.map((batch: any) => {
          const { batchNo, actualQty, expiryDate, availableQty, id } = batch;

          if (batchNo == "" && !!checkifBatchEnabled(item)) {
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.batch.empty.msg"]
            );
            flag = 0;
          } else if (
            (!expiryDate || expiryDate == "") &&
            !!checkifExpiryEnabled(item)
          ) {
            showToast(
              Strings["ime.scanner.error.occured.msg"],
              Strings["ime.scanner.expiry.date.empty.msg"]
            );
            flag = 0;
          }
          //  else if (actualQty == null || actualQty == "") {
          //   showToast(Strings["ime.scanner.error.occured.msg"], "Please enter valid actual quantity for all the batches/products");
          //   flag = 0;
          // }
          return {
            id: id?.includes("addedBatch") ? null : id,
            availableQty: id?.includes("addedBatch")
              ? 0
              : availableQty
              ? availableQty
              : "0",
            batchNo: batchNo,
            actualQty: actualQty ? actualQty : availableQty,
            expiryDate: expiryDate
              ? moment(expiryDate).format(dateFormat?.date)
              : null,
          };
        });
      }
      // else {
      //   if ((item.actualQty = null || item.actualQty == "")) {
      //     showToast(Strings["ime.scanner.error.occured.msg"], "Please enter va lid actual quantity for all the batches/products");
      //     flag = 0;
      //   }
      // }
      let qty = 0;

      if (batches?.length) {
        batches.forEach((item) => {
          const itemActualQty = parseInt(item.actualQty)
            ? parseInt(item.actualQty)
            : 0;
          qty = qty + itemActualQty;
        });
      } else {
        qty = item.actualQty;
      }
      return {
        reasonCode: { id: item.reasonCode.id },
        availableQty: item.product.availableQty,
        actualQty: qty,
        variationQty: getVariationQty(item),
        id: item.id,
        ...{ batchProducts: batches?.length ? batches : [] },
      };
    });
    if (selectedProducts?.length && flag == 1) {
      const params = {
        reasonCode: { id: selectedReasonCode?.id },
        user: { id: profileData.id },
        products: selectedProducts,
        selectedPICountId: piCountData?.selectedPiCountValue?.id,
      };
      console.log(JSON.stringify(params));

      onCompleteeValidationSuccessCallBack(params);
    }
  }
};

const onError = (error: any) => {
  console.error("Error storing pi count data:", error);
};

export {
  onSelectReasonCodeLogic,
  handleAvailQtyLogic,
  handleBatchDeleteLogic,
  handleBatchesLogic,
  onSavePICountLogic,
  onCompletePICountLogic,
};
