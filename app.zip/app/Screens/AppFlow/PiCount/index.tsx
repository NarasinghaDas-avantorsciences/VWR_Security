import React, { useState, useRef, useEffect, useCallback } from "react";
import { TouchableOpacity, View, FlatList, Keyboard } from "react-native";
import styles from "./styles";
import {
  BottomSheetComponent,
  Header,
  Subheader,
  TextInputComponent,
  MainButton,
  ToastComponent,
  CustomText,
  Loader,
  AnimatedSearch,
} from "../../../Components";
import { HalfLoader } from "../../../Components/Loader";
import {
  ArrowDown,
  UnselectedCheckBox,
  BlueCheckedBox,
  BlueTick,
  PICountLocked,
  GreyCheckedBox,
  Cross,
} from "../../../Utils/images";
import { COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import {
  setSelectedPICount,
  getPICountList,
  getPiCountLocations,
  createNewPICount,
  startPICount,
  getPIProductsList,
  setLoader,
  resetAllPIPendingProducts,
  resetAllPIConfirmProducts,
} from "../../../Redux/Action/picountAction";
import { useSelector, useDispatch } from "react-redux";
import { filterDataByName, wp, hp } from "../../../Utils/globalFunction";
import { getAccountDetails } from "../../../Redux/Action/accountAction";
import Toast from "react-native-toast-message";
import {
  onSelectPiCountLogic,
  onSelectAllLocationsLogic,
  onSaveLogic,
  resetStateLogic,
  startPICountLogic,
} from "./logic";

import { useFocusEffect, useIsFocused } from "@react-navigation/native";
import { setIsShowConfirmationAlert } from "../../../Redux/Action/userAction";
import ConfirmationAlert from "../../../Components/ConfirmationPopup";

const PiCount = (props: any) => {
  const isFocused = useIsFocused();

  const [search, setSearch] = useState("");
  const [isSaveLoader, setIsSaveLoader] = useState(false);
  const dispatch = useDispatch<any>();
  const [selectedPiCountValue, setSelectedPiCountValue] = useState("");
  const [selectedPiCountId, setSelectedPiCountId] = useState("");
  const [newPICountName, setNewPICountName] = useState("");
  const userData = useSelector((state: any) => state.userReducer);
  const { confirmationAlertInfo } = useSelector(
    (state: any) => state.userReducer
  );
  const profileData = useSelector((state: any) => state.accountReducer?.data);
  const [PICounts, setPiCounts] = useState(); //data
  const [filteredPICounts, setfilteredPiCounts] = useState([]); //data
  const [locations, setLocations] = useState([]);
  const piCountData = useSelector((state: any) => state.picontReducer);
  const bottomSheetRef = useRef<any>(null);
  const createPICountBottomSheetRef = useRef<any>(null);
  const Strings = useSelector((state: any) => state.languageReducer?.data);

  useEffect(() => {
    const unsubscribe = props.navigation.addListener("focus", () => {
      setSelectedPiCountValue("");
      dispatch(setSelectedPICount(null));
      dispatch(getPIProductsList(null));
    });

    // Perform any actions or fetch data when the screen is focused
    if (isFocused) {
      // Your logic here
      setSelectedPiCountValue("");
      getAccountData();
      dispatch(getPICountList());
      dispatch(getPiCountLocations());
      dispatch(setSelectedPICount(null));
      dispatch(getPIProductsList(null));
    }

    // Clean up any subscriptions or resources if needed
    return unsubscribe;
  }, [isFocused]);
  useFocusEffect(
    useCallback(() => {
      dispatch(setIsShowConfirmationAlert({}));
    }, [])
  );

  const getAccountData = () => {
    /**
     * Get user account details from API
     * */
    dispatch(getAccountDetails());
  };

  useEffect(() => {
    /**
     * Populate products array and locations array in the state
     * */

    if (piCountData?.piCountList) {
      setPiCounts(piCountData?.piCountList);
    }
    if (piCountData?.piCountLocationsList) {
      const locs = getPICountLocation();

      const updatedLocations = piCountData.piCountLocationsList.map((item) => {
        if (locs.some((loc) => loc.id === item.id)) {
          return { ...item, isExisting: true };
        }
        return item;
      });

      setLocations(updatedLocations);
    }
  }, [piCountData]);

  useEffect(() => {}, [userData]);

  const onSelectPiCount = (itemIndex: any) => {
    onSelectPiCountLogic(
      PICounts,
      itemIndex,
      setPiCounts,
      setSelectedPiCountValue,
      setSelectedPiCountId,
      setSelectedPICount,
      dispatch,
      navigateToList,
      piCountData?.piCountList
    );
  };

  const checkIfPicountSelected = () => {
    if (PICounts?.length) {
      const selectedPI = PICounts?.filter((item: any, index: number) => {
        return item.isSelected === true;
      });
      return selectedPI?.length;
    }
  };

  const showToast = (text1: string, text2: string) => {
    Toast.show({
      type: "alertToast",
      text1: text1,
      text2: text2,
      position: "bottom",
      bottomOffset: SIZES.padding * 2,
    });
  };

  const onSelectLocations = (itemIndex) => {
    const updatedLocations = [...locations];
    updatedLocations[itemIndex].isSelected =
      !updatedLocations[itemIndex].isSelected;
    setLocations(updatedLocations);
  };

  const onSelectAllLocations = () => {
    onSelectAllLocationsLogic(locations, setLocations, isAllLocationSelected);
  };

  const onSavePICount = () => {
    onSaveLogic(
      locations,
      newPICountName,
      showToast,
      profileData,
      userData,
      successCallBack,
      Strings
    );
  };
  const resetState = () => {
    resetStateLogic(setIsSaveLoader, setNewPICountName, onChangeCloseBtnPress);
  };
  const successCallBack = (params: any) => {
    setIsSaveLoader(true);
    dispatch(
      createNewPICount(
        params,
        (res: any) => {
          setIsSaveLoader(false);
          showToast(
            Strings["pi.count"],
            Strings["PI Count Location Created"] ?? "PI Count Location Created"
          );
          setTimeout(() => {
            resetState();
          }, 2000);
        },
        (error: any) => {
          setIsSaveLoader(false);
          showToast(
            Strings["ime.scanner.error.occured.msg"],
            Strings["alert.pi.already.exists"]
          );
        }
      )
    );
  };

  const isAllLocationSelected = () => {
    return locations?.length > 0
      ? locations
          .filter((location) => !location.isExisting)
          .every((location) => location.isSelected)
      : false;
  };
  const isAllLocationsExisting = () => {
    return locations?.length > 0
      ? locations.every((location) => location.isExisting)
      : false;
  };
  const Dropdown = ({ title, value }) => {
    return (
      <View
        accessible={true}
        accessibilityLabel="dropdown_container"
        style={styles.dropdownContainer}
      >
        <CustomText
          accessibilityLabel="dropdown_title"
          allowFontScaling={false}
          style={styles.dropdownTitle}
        >
          {title}
        </CustomText>
        <TextInputComponent
          RightIcon={ArrowDown}
          onPressRightIcon={() => {
            bottomSheetRef?.current?.open();
          }}
          allowFontScaling={false}
          value={value}
          editable={false}
          main={styles.mainInputTop}
          rightIconWidth={hp(1.7)}
          inputStyle={styles.inputStyle}
          rightIconHeight={hp(3)}
          placeholder={Strings["select"]}
          inputMain={styles.inputMainStyle}
          placeholderTextColor={COLORS.abbey}
          titleStyle={{ color: COLORS.abbey }}
          pointerEvents="none"
        />
      </View>
    );
  };

  const onCreateNewPICount = async () => {
    onChangeSearchField("");
    setLocations([]);
    await dispatch(getPiCountLocations());
    setNewPICountName("");
    setTimeout(() => {
      createPICountBottomSheetRef.current.open();
    }, 500);
  };

  const onStartPICount = () => {
    onChangeSearchField("");
    startPICountLogic(selectedPiCountId, startPI);
  };
  const navigateToList = () => {
    bottomSheetRef.current?.close?.();
    dispatch(resetAllPIPendingProducts());
    dispatch(resetAllPIConfirmProducts());
    dispatch(setLoader(true));
    setTimeout(() => {
      props.navigation.navigate("PICountLists", {
        id: selectedPiCountId,
        piCountName: selectedPiCountValue,
      });
    }, 1000);
  };
  const startPI = (params: any) => {
    bottomSheetRef.current.close();
    dispatch(
      startPICount(
        params,
        () => {
          dispatch(resetAllPIPendingProducts());
          dispatch(resetAllPIConfirmProducts());
          setfilteredPiCounts([]);
          setSearch("");
          dispatch(setLoader(true));

          setTimeout(() => {
            props.navigation.navigate("PICountLists", {
              id: selectedPiCountId,
              piCountName: selectedPiCountValue,
            });
          }, 1000);
        },
        () => {}
      )
    );
  };

  const itemSeparator = () => {
    return <View style={styles.separator} />;
  };
  const footerComponent = () => {
    return <View style={styles.footerComponent} />;
  };
  const showPIcountList = (index: Number) => {
    onSelectPiCount(index);
  };

  const onChangeCloseBtnPress = () => {
    onChangeSearchField("");
    bottomSheetRef.current.close();
  };

  const onChangeCreatePICountCloseBtnPress = () => {
    createPICountBottomSheetRef.current.close();
  };

  const _renderLocationItem = (item, index) => {
    let isExistingLocation = item.isExisting;
    return (
      <TouchableOpacity
        accessible={true}
        accessibilityLabel="select_location_item_button"
        onPress={() => {
          if (!isExistingLocation) onSelectLocations(index);
        }}
        style={[styles.locationItemContainer]}
      >
        {!!isExistingLocation ? (
          <GreyCheckedBox height={wp(4)} width={wp(4)} />
        ) : !!item.isSelected ? (
          <BlueCheckedBox height={wp(4)} width={wp(4)} />
        ) : (
          <UnselectedCheckBox height={wp(4)} width={wp(4)} />
        )}
        <CustomText
          accessibilityLabel="location_name"
          allowFontScaling={false}
          style={{
            ...styles.renderLocationItemTitle,
            fontFamily: item.isSelected
              ? FONTFAMILY.averta_bold
              : FONTFAMILY.averta_regular,
          }}
        >
          {item.locationName}
        </CustomText>
      </TouchableOpacity>
    );
  };

  const _renderItem = ({ item, index }) => {
    return (
      <TouchableOpacity
        accessible={true}
        accessibilityLabel={`${item.piCountName}-select_pi_count_item_button-${index}`}
        onPress={() => {
          onChangeSearchField("");
          showPIcountList(index);
        }}
        style={styles.itemContainer}
      >
        {!!item.freezed && <PICountLocked />}

        <CustomText
          accessibilityLabel={`${item.piCountName}-${index}-pi_count_name`}
          allowFontScaling={false}
          style={{
            ...styles.renderItemTitle,
            fontFamily: item.isSelected
              ? FONTFAMILY.averta_bold
              : FONTFAMILY.averta_regular,
            marginLeft: !!item.freezed ? wp(2) : 0,
          }}
        >
          {item.piCountName}
        </CustomText>
        {!!item.isSelected && (
          <BlueTick
            height={hp(2)}
            width={hp(2)}
            color="red"
            style={styles.checkIcon}
          />
        )}
      </TouchableOpacity>
    );
  };

  const onChangeSearchField = async (searckKey: string) => {
    setSearch(searckKey);
    const filteredData: any = filterDataByName(
      piCountData?.piCountList,
      "piCountName",
      searckKey
    );
    if (searckKey == "") await setPiCounts(piCountData?.piCountList);
    // else await setfilteredPiCounts(filteredData);
    else await setPiCounts(filteredData);
  };
  const noDataFound = () => {
    return (
      <View style={styles.emptyContainer}>
        <CustomText style={styles.emptyText}>
          {Strings["no.records.found"]}
        </CustomText>
      </View>
    );
  };
  const getPICountLocation = () => {
    let locs = [];

    // Loop through each item in the PICounts array
    PICounts?.forEach((item) => {
      if (item.locations && item.locations.length) {
        // Loop through each location item in the current PICounts item
        item.locations.forEach((location) => {
          // Check if the location already exists in the locs array
          const existingLocation = locs.find((loc) => loc.id === location.id);
          if (!existingLocation) {
            // If the location does not exist, add it to the locs array
            locs.push(location);
          }
        });
      }
    });

    return locs;
  };

  return (
    <View style={styles.container}>
      <Header
        title={Strings["pi.count"] || "pi.count"}
        onLeftIconPress={() => {
          Keyboard.dismiss();
          props.navigation.getParent("Drawer").openDrawer();
        }}
        statusBar={true}
        statusBarColor={"blue"}
        iconLeft={true}
        iconRight={true}
      />
      <Subheader distance={10} rowContainer={styles.rowContainer} />
      <Dropdown
        title={Strings["pi.count"] || "pi.count"}
        value={selectedPiCountValue}
      />
      <BottomSheetComponent
        bottomSheetRef={bottomSheetRef}
        closeOnDragDown={false}
        height={hp(50)}
        customStyles={{ wrapper: styles.bottomsheetContainer }}
        onOpen={() => onChangeSearchField("")}
      >
        <View
          style={styles.headerContainer}
          accessible={true}
          accessibilityLabel="pi-count-headerContainer"
        >
          <View style={{ flex: 1 }} />
          <CustomText
            accessibilityLabel="pi_count_popup-title"
            allowFontScaling={false}
            style={styles.headerTitle}
          >
            {Strings["pi.count"]}
          </CustomText>
          <View
            accessible={true}
            accessibilityLabel="pi_count_bottom_sheet_close_btn-container"
            style={styles.buttonContainer}
          >
            <TouchableOpacity
              style={styles.secondaryPressableContainer}
              onPress={() => onChangeCloseBtnPress()}
              accessible={true}
              accessibilityLabel="pi_count_bottom_sheet_close_btn"
            >
              <CustomText
                accessibilityLabel="pi_count_popupop_close_label-btn"
                allowFontScaling={false}
                style={styles.secondaryPressableText}
              >
                {Strings["close"]}
              </CustomText>
            </TouchableOpacity>
          </View>
        </View>
        <AnimatedSearch
          idLabel="pi-count-search"
          search={search}
          onSearch={(text: string) => onChangeSearchField(text)}
          placeholder={Strings["search"]}
          containerStyle={styles.searchContainerStyle}
          clearText={() => {
            onChangeSearchField("");
          }}
          onBarcodeDetected={(barcode) => {
            onChangeSearchField(barcode);
          }}
          onCancel={() => {
            onChangeSearchField("");
            Keyboard.dismiss();
          }}
          isShowEmptyMsg={false}
          isShowScan={false}
        />

        <FlatList
          // data={search ? filteredPICounts : PICounts}
          data={PICounts}
          renderItem={_renderItem}
          style={styles.picountFlatListStyle}
          ItemSeparatorComponent={itemSeparator}
          ListFooterComponent={footerComponent}
          ListEmptyComponent={noDataFound}
          keyboardShouldPersistTaps="always"
          keyboardDismissMode="interactive"
        />
        {/*</ScrollView>*/}
        <MainButton
          accessibilityLabel="start_pi_count_button"
          title={
            checkIfPicountSelected()
              ? Strings["start.pi"]
              : Strings["ime.scanner.Create.New.PI.Count"] ?? "Create PI Count"
          }
          buttonStyle={styles.buttonStyle}
          onChangeBtnPress={() =>
            checkIfPicountSelected() ? onStartPICount() : onCreateNewPICount()
          }
        />
        <BottomSheetComponent
          bottomSheetRef={createPICountBottomSheetRef}
          closeOnDragDown={true}
          height={hp(100)}
          customStyles={{ wrapper: styles.createBottomsheetContainer }}
        >
          <View style={styles.headerContainer}>
            <View style={{ flex: 1 }} />
            <CustomText
              accessibilityLabel="create_pi_count_popup_title"
              allowFontScaling={false}
              style={styles.createHeaderTitle}
            >
              {Strings["create.pi.count"]}
            </CustomText>
            <View
              accessible={true}
              accessibilityLabel="create_pi_count_bottom_sheet_cancel_button"
              style={styles.buttonContainer}
            >
              <TouchableOpacity
                style={styles.secondaryPressableContainer}
                onPress={() => onChangeCreatePICountCloseBtnPress()}
              >
                <CustomText
                  accessibilityLabel="create_pi_count_popup_cancel_label"
                  allowFontScaling={false}
                  style={styles.createSecondaryPressableText}
                >
                  {Strings["cancel"]}
                </CustomText>
              </TouchableOpacity>
            </View>
          </View>
          <TextInputComponent
            title={Strings["ime.pi.count.name"]}
            // RightIcon={ArrowDown}
            value={newPICountName}
            onChangeText={(value) => setNewPICountName(value)}
            placeholder={Strings["enter.pi.count.name"]}
            placeholderTextColor={COLORS.abbey}
            editable={true}
            main={{
              ...styles.mainAddCodeInputTop,
            }}
            RightIcon={Cross}
            onPressRightIcon={(isClear?: boolean) =>
              isClear && setNewPICountName("")
            }
            // rightIconWidth={hp(1.7)}
            inputStyle={styles.inputStyle}
            inputMain={styles.inputMainStyle}
            titleStyle={{ color: COLORS.abbey }}
            returnKeyLabel={Strings["save"] ?? "Save"}
            returnKeyType="done"
            onSubmitEditing={onSavePICount}
            required={true}
          />

          <View style={styles.locationPickerContainer}>
            <TouchableOpacity
              accessible={true}
              accessibilityLabel="select_all_locations_checkbox"
              disabled={isAllLocationsExisting()}
              onPress={() => {
                onSelectAllLocations();
              }}
            >
              {isAllLocationsExisting() ? (
                <GreyCheckedBox height={wp(4)} width={wp(4)} />
              ) : isAllLocationSelected() ? (
                <BlueCheckedBox height={wp(4)} width={wp(4)} />
              ) : (
                <UnselectedCheckBox height={wp(4)} width={wp(4)} />
              )}
            </TouchableOpacity>
            <CustomText
              accessibilityLabel="select_all_locations_label"
              allowFontScaling={false}
              style={styles.locationPickerTitle}
            >
              {isAllLocationSelected()
                ? Strings["deselect.all.locations"] ?? "Deselect all locations"
                : Strings["select.all.locations"]}
            </CustomText>
          </View>
          {/* <View style={styles.locationsFlatListStyle}> */}
          {/* {locations?.length > 0 &&
              locations.map((item, index) => {
                return _renderLocationItem(item, index);
              })} */}
          <FlatList
            data={locations}
            renderItem={({ item, index }) => _renderLocationItem(item, index)}
            contentContainerStyle={styles.flatListStyle}
            ItemSeparatorComponent={itemSeparator}
            ListFooterComponent={footerComponent}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
          />
          {/* </View> */}
          {/*</ScrollView>*/}
          <MainButton
            accessibilityLabel="save_new_picount_button"
            title={isSaveLoader ? <HalfLoader /> : Strings["save"]}
            buttonStyle={styles.buttonStyle}
            onChangeBtnPress={onSavePICount}
            disabled={isAllLocationsExisting()}
          />
          <ToastComponent />
        </BottomSheetComponent>
      </BottomSheetComponent>
      <Loader show={piCountData.loader} />
      <ConfirmationAlert
        onTapNo={() => {}}
        onTapYes={() =>
          dispatch(
            setIsShowConfirmationAlert({
              isShow: false,
              data: confirmationAlertInfo?.data,
            })
          )
        }
        onBack={() => console.warn("AJJJJJ")}
      />
    </View>
  );
};

export default PiCount;
