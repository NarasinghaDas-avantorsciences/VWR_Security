import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY } from "../../../Utils/theme";
import { hp, wp, isDeviceTablet } from "../../../Utils/globalFunction";

export default StyleSheet.create({
  rendercomponentContainer: { flexGrow: 1 },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
    zIndex: 1000,
  },
  mainAddCodeInputTop: {
    width: wp(90),
    marginTop: wp(10),
  },
  emptyContainer: { alignItems: "center", justifyContent: "center" },
  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },

  locationsFlatListStyle: { marginHorizontal: wp(10), marginTop: wp(3) },
  buttonStyle: {
    alignSelf: "center",
    width: wp(90),
    marginBottom: wp(4),
    borderRadius: 4,
    position: "absolute",
    bottom: hp(2),
  },
  checkIcon: {
    color: COLORS.scienceBlue,
    marginRight: wp(2),
  },
  itemContainer: {
    flexDirection: "row",
    flexWrap: "wrap",

    alignItems: "center",
    justifyContent: "space-between",
    marginVertical: wp(1.8),
  },
  locationItemContainer: {
    flexDirection: "row",
    flexWrap: "wrap",

    alignItems: "center",
    // justifyContent: 'space-between',
    marginVertical: wp(1.8),
  },
  bottomsheetContainer: { width: "100%", height: 120 },
  createBottomsheetContainer: { width: "100%", height: "100%" },
  flatListStyle: { marginHorizontal: wp(8) },
  picountFlatListStyle: { marginHorizontal: wp(5), marginBottom: wp(22) },
  searchContainerStyle: {
    marginVertical: wp(4),
    marginHorizontal: wp(4),
  },
  buttonContainer: { flex: 1, alignItems: "flex-end" },
  secondaryPressableContainer: {
    justifyContent: "center",
    alignItems: "center",
    padding: hp(1),
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: COLORS.gray2,
    width: wp(100),
    marginTop: hp(0.6),
  },
  footerComponent: {
    height: 100,
    width: wp(100),
  },
  secondaryPressableText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_9,
  },
  createSecondaryPressableText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_8,
  },
  headerContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: wp(4),
    marginTop: isDeviceTablet() ? wp(1) : wp(0),
    borderBottomWidth: 1,
    borderBottomColor: COLORS.grayLight,
    paddingVertical: hp(1.5),
  },
  dropdownContainer: {
    flexDirection: "row",
    marginTop: wp(4),
    width: "90%",
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "space-between",
  },
  dropdownTitle: {
    fontSize: FONTS.h1_9,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    width:wp(27)
  },
  renderItemTitle: {
    fontSize: FONTS.h1_7,
    color: COLORS.abbey,
    flex: 1,
  },
  renderLocationItemTitle: {
    fontSize: FONTS.h1_7,
    color: COLORS.abbey,
    marginStart: wp(2.5),
    marginBottom: wp(1),
  },
  headerTitle: {
    fontSize: FONTS.h2_1,
    textAlign: "center",
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    marginRight: wp(3),
  },
  createHeaderTitle: {
    fontSize: FONTS.h1_9,
    textAlign: "center",
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.scienceBlue,
    marginRight: wp(3),
  },
  rowContainer: {
    borderBottomWidth: 1,
    borderBottomColor: COLORS.alto,
    backgroundColor: COLORS.white,
  },
  mainInputTop: {
    width: wp(60),
  },
  inputStyle: {
    fontSize: FONTS.h1_9,
    fontFamily: FONTFAMILY.averta_regular,
    color: COLORS.abbey,
  },
  inputMainStyle: {
    height: hp(6),
    borderColor: COLORS.gray2,
    borderWidth: 0.8,
  },

  locationPickerTitle: {
    fontSize: FONTS.h1_9,
    fontFamily: FONTFAMILY.averta_regular,
    color: COLORS.abbey,
    marginStart: wp(3),
  },
  locationPickerContainer: {
    marginHorizontal: wp(4),
    marginTop: wp(8),
    flexDirection: "row",
    flexWrap: "wrap",

    alignItems: "center",
  },
  locationPickerTitleContainer: {
    flexDirection: "row",
    flexWrap: "wrap",

    alignItems: "center",
  },

  cancelSearch: {
    position: "absolute",
    marginHorizontal: 16,
    textAlign: "center",
    justifyContent: "center",
    alignSelf: "center",
    right: -10,
  },

  cancelSearchText: {
    color: COLORS.blue,
    marginLeft: wp(10),
  },
});
