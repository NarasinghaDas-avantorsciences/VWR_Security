const onSelectPiCountLogic = async (
  PICounts: any,
  itemIndex: any,
  setPiCounts: any,
  setSelectedPiCountValue: any,
  setSelectedPiCountId: any,
  setSelectedPICount: any,
  dispatch: any,
  navigateToList: any,
  fullPICountList: any
) => {
  try {
    let selectedItem = PICounts[itemIndex];
    selectedItem.isSelected = selectedItem.isSelected ? false : true;
    let fullArrayIndex = itemIndex;

    if (
      fullPICountList.length != PICounts.length &&
      fullPICountList.length > PICounts.length
    ) {
      const index = fullPICountList.findIndex(
        (x: { id: any; piCountName: any }) =>
          x.id === selectedItem.id && x.piCountName === selectedItem.piCountName
      );
      if (index != -1) fullArrayIndex = index;
    }

    fullPICountList.map((item: { isSelected: boolean }, index: any) => {
      if (index != fullArrayIndex) item.isSelected = false;
    });

    fullPICountList[fullArrayIndex].isSelected = selectedItem.isSelected;
    setPiCounts(fullPICountList);

    if (selectedItem.isSelected) {
      setSelectedPiCountValue(selectedItem?.piCountName);
      setSelectedPiCountId(selectedItem?.id);
      dispatch(setSelectedPICount(selectedItem));
    } else {
      setSelectedPiCountValue("");
      setSelectedPiCountId("");
      dispatch(setSelectedPICount(null));
    }

    if (selectedItem.freezed) {
      navigateToList();
    }

    /*
    let PICountsArray = [...PICounts];
    PICountsArray.map((item, index) => {
      if (index != itemIndex) item.isSelected = false;
    });
    PICountsArray[itemIndex].isSelected = !PICountsArray[itemIndex].isSelected;
    setPiCounts(PICountsArray);
    if (PICountsArray[itemIndex].isSelected) {
      setSelectedPiCountValue(PICountsArray[itemIndex]?.piCountName);
      setSelectedPiCountId(PICountsArray[itemIndex]?.id);
      dispatch(setSelectedPICount(PICountsArray[itemIndex]));
    } else {
      setSelectedPiCountValue("");
      setSelectedPiCountId("");
      dispatch(setSelectedPICount(null));
    }
    if (PICountsArray[itemIndex].freezed) {
      navigateToList();
    }*/
  } catch (error) {
    // Handle storage error
    onError(error);
  }
};
const onSelectAllLocationsLogic = async (
  locations: any,
  setLocations: any,
  isAllLocationSelected: any
) => {
  try {
    const updatedLocations = [...locations];
    let flag = isAllLocationSelected();
    updatedLocations.map((item, index) => {
      if (!item.isExisting) item.isSelected = !flag;
    });
    setLocations(updatedLocations);
  } catch (error) {
    // Handle storage error
    onError(error);
  }
};
const resetStateLogic = async (
  setIsSaveLoader: any,
  setNewPICountName: any,
  onChangeCloseBtnPress: any
) => {
  try {
    setIsSaveLoader(false);
    setNewPICountName("");
    onChangeCloseBtnPress();
  } catch (error) {
    // Handle storage error
    onError(error);
  }
};
const startPICountLogic = async (selectedPiCountId: any, startPI: any) => {
  try {
    if (!!selectedPiCountId) {
      const params = {
        selectedPICountId: selectedPiCountId,
      };
      startPI(params);
    }
  } catch (error) {
    // Handle storage error
    onError(error);
  }
};
const onSaveLogic = async (
  locations: any,
  newPICountName: any,
  showToast: any,
  profileData: any,
  userData: any,
  successCallBack: any,
  Strings: any
) => {
  try {
    const selectedLocations = locations
      .filter((location) => location.isSelected && !location.isExisting)
      .map((location) => location);
    if (!newPICountName) {
      showToast(
        Strings["ime.scanner.error.occured.msg"],
        "Please enter PI Count name."
      );
    } else if (selectedLocations?.length == 0) {
      showToast(
        Strings["ime.scanner.error.occured.msg"],
        "Please select at least one location"
      );
    } else {
      const params = {
        userID: profileData?.id,
        stockRoomId: userData.selectedStockRoom?.id,
        piCountName: newPICountName,
        orgId: userData.selectedOrg.id,
        locations: selectedLocations,
        isReplenish: false,
      };

      successCallBack(params);
    }
  } catch (error) {
    // Handle storage error
    onError(error);
  }
};

const onError = (error: any) => {
  console.error("Error storing pi count data:", error);
};

export {
  onSelectPiCountLogic,
  onSelectAllLocationsLogic,
  onSaveLogic,
  resetStateLogic,
  startPICountLogic,
};
