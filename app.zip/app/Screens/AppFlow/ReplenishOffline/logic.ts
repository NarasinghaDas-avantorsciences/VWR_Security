import * as storage from "../../../Service/AsyncStoreConfig";
const getStorageDataLogic = async (setOfflineProducts: any) => {
  try {
    await storage.getItem("replenish_offline_data").then((res: any) => {
      if (res) {
        const dataJSON = JSON.parse(res);
        setOfflineProducts(dataJSON);
      }
    });
  } catch (error) {}
};
const checkifBatchEnabledLogic = (item: any, stockRoomDetail: any) => {
  let value = false;
  let product = item;
  if (
    !!stockRoomDetail?.isBatchManagementEnabled &&
    !!product?.batchManagementEnabled
  ) {
    value = true;
  }
  return value;
};
const checkifExpiryEnabledLogic = (item: any, stockRoomDetail: any) => {
  let value = false;
  let product = item;
  if (
    !!stockRoomDetail?.isExpiryManagementEnabled &&
    !!product?.expiryDateManagementenabled
  ) {
    value = true;
  }
  return value;
};
export {
  getStorageDataLogic,
  checkifBatchEnabledLogic,
  checkifExpiryEnabledLogic,
};
