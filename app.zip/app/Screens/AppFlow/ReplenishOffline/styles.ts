import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../../Utils/theme";
import { hp, wp } from "../../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },

  contentContainer: {
    flex: 1,
    paddingHorizontal: hp(2),
  },

  headerContainer: {
    paddingTop: hp(4),
    alignItems: "center",
  },

  headerText: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
    textAlign: "center",
  },

  subHeaderTextContainer: {
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "center",
    paddingVertical: hp(2),
  },

  itemChildHeaderText: {
    fontSize: FONTS.h1_7,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    alignItems: "center",
  },

  selectDeselectText: {
    ...FONTS.title2,
    fontSize: FONTS.h1_5,
    marginHorizontal: wp(2),
  },

  renderListItemContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: hp(1),
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: COLORS.abbey,
    justifyContent: "space-between",
  },

  itemChildContainer: {
    width: SIZES.width * 0.4,
    // marginVertical: wp(0.5),
    paddingVertical: hp(1),
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
  },

  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  indexStyle: {
    color: COLORS.black,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_regular,
    paddingRight: wp(2),
  },

  qtyTitleStyle: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h2,
  },

  checkbox: {
    width: hp(4),
    height: hp(4),
    justifyContent: "center",
    alignItems: "flex-end",
  },

  listContainer: {
    paddingBottom: hp(16),
  },

  footerMainContainer: { bottom: 0, borderTopWidth: 0 },

  outlinedBtnText: { color: COLORS.gray },

  outlinedBtnContainer: { borderWidth: 0 },

  scannerBtn: { bottom: hp(12) },
});
