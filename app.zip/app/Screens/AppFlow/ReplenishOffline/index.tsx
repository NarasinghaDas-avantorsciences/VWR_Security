import React, { useCallback, useEffect, useRef, useState } from "react";
import { Keyboard, View } from "react-native";
import {
  useFocusEffect,
  useIsFocused,
  useNavigation,
} from "@react-navigation/native";
import { useSelector } from "react-redux";
import { Toast } from "react-native-toast-message/lib/src/Toast";
import {
  ClearSelectionAlert,
  Header,
  Loader,
  Subheader,
  ToastComponent,
} from "../../../Components";
import styles from "./styles";
import { SIZES } from "../../../Utils/theme";
import OfflineConsumeView from "../Consume/OfflineConsumeView";
import { resetOfflineStates } from "../Replenish/logic";
import * as storage from "../../../Service/AsyncStoreConfig";
import OfflineToast from "../../../Components/Offline";
import {
  checkifBatchEnabledLogic,
  checkifExpiryEnabledLogic,
  getStorageDataLogic,
} from "./logic";
import { saveDataToStorage } from "../../../Components/Subheader/logic";

type ReplenishOfflineProps = {};

const ReplenishOffline: React.FC<ReplenishOfflineProps> = (props) => {
  const navigation = useNavigation();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const bottomSheetRef = useRef<any>(null);
  const [offlineProducts, setOfflineProducts] = useState([]);
  const [currentOfflineProductsIndex, setCurrentOfflineProductsIndex] =
    useState(null);
  const [matchFoundProducts, setMatchFoundProducts] = useState([]);
  const [offlineDuplicateProducts, setOfflineDuplicateProducts] =
    useState(null);
  const [isDataUpdating, setIsDataUpdating] = useState(false);
  const [offlineBatchProducts, setOfflineBatchProducts] = useState([]);
  const [isBatchSaved, setIsBatchSaved] = useState(false);
  const [matchNotFoundProducts, setMatchNotFoundProducts] = useState([]);
  const [isVisibleClearOrder, setIsVisibleClearOrder] = useState(false);
  const [clearModalData, setClearModalData] = useState({
    title: "",
    buttonTitle: "",
    desc: "",
    buttonPress: () => {},
  });
  const { internet } = useSelector((state: any) => state.loginReducer);
  const { stockRoomDetail } = useSelector((state: any) => state.userReducer);

  const isFocused = useIsFocused();
  const [offlineCollection, showOfflineCollection] = useState(false);
  const { isOnHand, isPutAway } = useSelector(
    (state: any) => state.userReducer
  );
  const getStorageData = async () => {
    getStorageDataLogic(setOfflineProducts);
  };

  useFocusEffect(
    useCallback(() => {
      changeStateToDefault();
    }, [])
  );

  const checkifTheItemExistInOrder = (id: any, barcode?: any) => {
    return offlineProducts?.some((item) => item.catalogNo == barcode);
  };
  const showToast = (
    text1: string,
    text2: string,
    duration?: any,
    onHideToast?: any,
    onPressBtn?: any
  ) => {
    Toast.show({
      type: "alertToast",
      text1: text1,
      text2: text2,
      position: "bottom",
      bottomOffset: SIZES.padding * 2,
      // visibilityTime: duration,
      onHide: onHideToast,
    });
  };
  const onPressClearOrder = async () => {
    changeStateToDefault();
    navigation.navigate("Dashboard");
    await saveDataToStorage("replenish_offline_data", []);
    await saveDataToStorage("offlineData", []);
    setIsVisibleClearOrder(false);
  };
  useFocusEffect(
    useCallback(() => {
      if (!!internet) {
        const state = navigation.getState();
        const routeName = state.routes?.[state.index]?.name;
        storage.getItem("replenish_offline_data").then((res: any) => {
          if (!JSON.parse(res)?.length) {
            navigation.navigate("Replenish");
          }
        });
        // if (routeName == "ReplenishOffline" && !offlineProducts?.length) {
        //   // navigation.navigate("Replenish");
        // }
      }
    }, [internet])
  );
  const changeStateToDefault = async () => {
    resetOfflineStates(
      setOfflineProducts,
      setCurrentOfflineProductsIndex,
      setMatchFoundProducts,
      setOfflineBatchProducts,
      setMatchNotFoundProducts,
      setIsBatchSaved,
      showOfflineCollection,
      internet,
      setIsDataUpdating,
      setOfflineDuplicateProducts
    );
    await getStorageData();
  };
  const checkifBatchEnabled = (item) => {
    checkifBatchEnabledLogic(item, stockRoomDetail);
  };
  const checkifExpiryEnabled = (item) => {
    checkifExpiryEnabledLogic(item, stockRoomDetail);
  };
  return (
    <View
      style={styles.container}
      accessible={true}
      accessibilityLabel="replenishOffline-container"
    >
      <Header
        title={
          Strings["replenish"] +
          ` ${
            isOnHand
              ? Strings["ime.scanner.on.hand"]
                ? " " + Strings["ime.scanner.on.hand"]
                : " On-Hand"
              : isPutAway
              ? " " + Strings["put.away"]
              : ""
          }`
        }
        onLeftIconPress={() => {
          Keyboard.dismiss();
          navigation.getParent("Drawer").openDrawer();
        }}
        statusBar={true}
        statusBarColor={"blue"}
        iconLeft={true}
        iconRight={true}
      />
      {!internet && (
        <View
          style={{
            alignItems: "center",
          }}
          accessible={true}
          accessibilityLabel="offline-toast-container"
        >
          <OfflineToast login={false} />
        </View>
      )}
      <Subheader />
      {
        <OfflineConsumeView
          from="replenish"
          setIsBatchSaved={setIsBatchSaved}
          isBatchSaved={isBatchSaved}
          setProducts={setOfflineProducts}
          products={offlineProducts}
          navigation={navigation}
          currentIndex={currentOfflineProductsIndex}
          setCurrentIndex={setCurrentOfflineProductsIndex}
          setIsVisibleClearOrder={setIsVisibleClearOrder}
          showOfflineCollection={showOfflineCollection}
          checkifTheItemExistInOrder={checkifTheItemExistInOrder}
          showToast={showToast}
          matchFoundProducts={matchFoundProducts}
          offlineBatchProducts={offlineBatchProducts}
          matchNotFoundProducts={matchNotFoundProducts}
          setMatchNotFoundProducts={setMatchNotFoundProducts}
          setMatchFoundProducts={setMatchFoundProducts}
          setOfflineBatchProducts={setOfflineBatchProducts}
          setClearModalData={setClearModalData}
          onPressClearOrder={onPressClearOrder}
          checkifBatchEnabled={checkifBatchEnabled}
          checkifExpiryEnabled={checkifExpiryEnabled}
          bottomSheetRef={bottomSheetRef}
          getStorageData={getStorageData}
          isConsume={false}
          offlineDuplicateProducts={offlineDuplicateProducts}
          setOfflineDuplicateProducts={setOfflineDuplicateProducts}
          setIsDataUpdating={setIsDataUpdating}
        />
      }

      <ClearSelectionAlert
        isShow={isVisibleClearOrder}
        didCloseModal={() => {
          setIsVisibleClearOrder(false);
        }}
        outlinedButtonTitle={Strings["ime.cancel"]}
        mainButtonTitle={clearModalData?.buttonTitle}
        didMainButtonTitleClicked={clearModalData?.buttonPress}
        didOutlinedButtonClicked={() => setIsVisibleClearOrder(false)}
        orderTitle={clearModalData?.title}
        orderDesc={clearModalData?.desc}
      />
      <Loader show={isDataUpdating} />
      <ToastComponent />
    </View>
  );
};

export default ReplenishOffline;
