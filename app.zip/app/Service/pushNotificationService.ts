import NavigationService from "../Navigation/NavigationService";

export const pushNotificationNavigationService = (notification: any) => {
  /*
      Consume Request
      Order Request
      POU Order Request
      Out Of Stock
      Running Low
  */
  let navigationTitle =
    (notification?.title ?? "").length > 0 ? notification?.title.trim() : "";
  let id = notification?.data?.orderId ?? "";
  if (
    navigationTitle.toUpperCase() == "Consume Request".toUpperCase() ||
    navigationTitle.toUpperCase() == "Order Request".toUpperCase() ||
    navigationTitle.toUpperCase() == "POU Order Request".toUpperCase()
  ) {
    handleApprovalsNavigation(navigationTitle, id);
    return;
  } else if (navigationTitle.toUpperCase() == "Out Of Stock".toUpperCase()) {
    NavigationService.navigate("StockLevel", {
      route: 0,
      replenish:
        true /*checkUserPrivileges(userPrivilege, "replenish.scanner"),*/,
      fromPushNotification: true,
    });
  } else if (navigationTitle.toUpperCase() == "Running Low".toUpperCase()) {
    setTimeout(() => {
      NavigationService.navigate("StockLevel", {
        route: 1,
        replenish:
          true /*checkUserPrivileges(userPrivilege, "replenish.scanner"),*/,
        fromPushNotification: true,
      });
    }, 100);
  }
};

const handleApprovalsNavigation = (navigationTitle: any, id: string) => {
  //props.navigation.navigate("Approvals")
  NavigationService.navigate("Approvals");

  /*
    if (id.length == 0){
      return
    }

    let screen =
      navigationTitle == "Consume Request"
        ? 1
        : navigationTitle == "Order Request"
        ? 2
        : 3;
      
    if (screen == 1) {
      let url = `?limit=${10}&sortBy=createdDate:desc`;
      console.log("url navigator", url);
      dispatch(
        getConsumeList(url, navigationTitle, true, (data: any) => {
          console.log("getConsumeList", data?.consumeReqHdrDtl);
          const item = data?.consumeReqHdrDtl.filter(
            (items: any) => items?.consumeRequestId == parseInt(id)
          ); //Getting an array of dic
          console.log("getConsumeList -- item", item);
          if (item != null) {
            if (item.length > 0) {
              dispatch(
                getDetail(
                  `api/stock/consume/requests/${item[0]?.consumeRequestId}`,
                  navigationTitle,
                  item[0],
                  screen
                )
              );
            }
          }
        })
      );
    } else if (screen == 2) {
      let url = `?limit=${10}&sortBy=createdDate:desc`;
      dispatch(
        getOrderList(url, navigationTitle, true, (data: any) => {
          const item = data?.orderApprovalHdr.filter(
            (items: any) => items?.orderId == parseInt(id)
          );
          if (item != null) {
            if (item.length > 0) {
              dispatch(
                getDetail(
                  `api/approvals/orders/${item[0]?.orderId}`,
                  navigationTitle,
                  item[0],
                  screen
                )
              );
            }
          }
        })
      );
    } else {
      let url = `?limit=${10}&sortBy=createdDate:desc`;
      dispatch(
        getPOUList(url, navigationTitle, true, (data: any) => {
          const item = data?.orderApprovalHdr.filter(
            (item: any) => item?.orderId == parseInt(id)
          );
          if (item != null) {
            if (item.length > 0) {
              dispatch(
                getDetail(
                  `api/approvals/pouOrders/${item[0]?.orderId}`,
                  navigationTitle,
                  item[0],
                  screen
                )
              );
            }
          }
        })
      );
    }*/
};
