import RNExitApp from "react-native-exit-app";
const rnBiometrics = new ReactNativeBiometrics({
  allowDeviceCredentials: true,
});

import ReactNativeBiometrics, { BiometryTypes } from "react-native-biometrics";

const authenticate = async (callBack: any) => {
  rnBiometrics.isSensorAvailable().then((resultObject) => {
    const { available, biometryType } = resultObject;
    if (available && biometryType === BiometryTypes.TouchID) {
      rnBiometrics
        .simplePrompt({
          promptMessage: "Unlock Inventory Manager",
          fallbackPromptMessage: "Retry",
        })
        .then((resultObject) => {
          const { success } = resultObject;
          if (success) {
            callBack(resultObject);
          } else {
            callBack(resultObject);
            // RNExitApp.exitApp();
          }
        })
        .catch(() => {
          callBack(resultObject);
          // RNExitApp.exitApp();
        });
    } else if (available && biometryType === BiometryTypes.FaceID) {
      rnBiometrics
        .simplePrompt({
          promptMessage: "Unlock Inventory Manager",
          fallbackPromptMessage: "Retry",
        })
        .then((resultObject) => {
          const { success } = resultObject;
          if (success) {
            callBack(resultObject);
          } else {
            callBack(resultObject);
            // RNExitApp.exitApp();
          }
        })
        .catch(() => {
          callBack(resultObject);
          // RNExitApp.exitApp();
        });
    } else if (available && biometryType === BiometryTypes.Biometrics) {
      rnBiometrics
        .simplePrompt({ promptMessage: "Unlock Inventory Manager", })
        .then((resultObject) => {
          const { success } = resultObject;
          if (success) {
            callBack(resultObject);
          } else {
            callBack(resultObject);
            // RNExitApp.exitApp();
          }
        })
        .catch(() => {

          rnBiometrics
            .simplePrompt({ promptMessage: "Unlock Inventory Manager" })
            .then((resultObject) => {
              const { success } = resultObject;
              if (success) {
                callBack(resultObject);
              } else {
                // RNExitApp.exitApp();
                callBack(resultObject);
              }
            });
        });
    } else {
    }
  });
};

export default authenticate;
