import PushNotification, { Importance } from "react-native-push-notification";
import { Platform, PermissionsAndroid, PermissionStatus } from "react-native";
import PushNotificationIOS from "@react-native-community/push-notification-ios";
import { pushNotificationService } from "./pushNotificationService";
import messaging from "@react-native-firebase/messaging";
import AsyncStorage from "@react-native-async-storage/async-storage";

export const pushNotificationServiceHandler = (notification) => {
  // PushNotification.configure({
  //   // (optional) Called when Token is generated (iOS and Android)
  //   onRegister: function (token) {
  //     console.log("onRegister:", token);
  //     if (Platform.OS == "ios") {
  //       //requestPermissions();
  //     } else {
  //       if (token.token) {
  //         AsyncStorage.setItem("fcmToken", token.token);
  //       }
  //       console.log("token:", token);
  //     }
  //   },
  //   // (required) Called when a remote is received or opened, or local notification is opened
  //   onNotification: function (notification) {
  //     pushNotificationService(notification);
  //     if (notification.userInteraction) {
  //       const dic = notification.data["gcm.n.analytics_data"];
  //       const title =
  //         (notification.title ?? "").length > 0
  //           ? notification.title
  //           : dic["google.c.a.c_l"] ?? "";
  //       const splitArray = title.split("#");
  //       if (splitArray.length > 0) {
  //         let navigationTitle = splitArray[0];
  //         let id = splitArray.length > 1 ? splitArray[1] : "";
  //         pushNotificationNavigaitonHandler(navigationTitle, id);
  //       }
  //     }
  //     // process the notification
  //     // (required) Called when a remote is received or opened, or local notification is opened
  //     if (Platform.OS == "ios")
  //       notification.finish(PushNotificationIOS.FetchResult.NoData);
  //   },
  //   // (optional) Called when Registered Action is pressed and invokeApp is false, if true onNotification will be called (Android)
  //   onAction: function (notification) {
  //     console.log("onAction:", notification.action);
  //     console.log("onAction--==NOTIFICATION:", notification);
  //     // process the action
  //   },
  //   // (optional) Called when the user fails to register for remote notifications. Typically occurs when APNS is having issues, or the device is a simulator. (iOS)
  //   onRegistrationError: function (err) {
  //     console.error("onRegistrationError ", err.message, err);
  //   },
  //   // IOS ONLY (optional): default: all - Permissions to register.
  //   permissions: {
  //     alert: true,
  //     badge: true,
  //     sound: true,
  //   },
  //   // Should the initial notification be popped automatically
  //   // default: true
  //   popInitialNotification: true,
  //   /**
  //    * (optional) default: true
  //    * - Specified if permissions (ios) and token (android and ios) will requested or not,
  //    * - if not, you must call PushNotificationsHandler.requestPermissions() later
  //    * - if you are not using remote notification or do not have Firebase installed, use this:
  //    *     requestPermissions: Platform.OS === 'ios'
  //    */
  //   requestPermissions: false,
  // });
};
export const requestUserPermission = async (callBack) => {
  //await messaging().ios.registerForRemoteNotifications();
  if (Platform.OS == "ios") {
    if (!messaging().isDeviceRegisteredForRemoteMessages) {
      await messaging().registerDeviceForRemoteMessages();
    } else {
      const authStatus = await messaging().requestPermission({
        alert: true,
        badge: true,
        sound: true,
      });
      const enabled =
        authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
        authStatus === messaging.AuthorizationStatus.PROVISIONAL;
      if (enabled) {
        fetchTokens(callBack);
      } else {
        callBack(false);
      }
    }
  } else {
    const authStatus = await messaging().requestPermission({
      alert: true,
      badge: true,
      sound: true,
    });
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;
    if (enabled) {
      fetchTokens(callBack);
    } else {
      callBack(false);
    }
  }
};

export const requestUserPermissionBool =  async() => {
  //await messaging().ios.registerForRemoteNotifications();
  if (Platform.OS == "ios") {
    const authStatus = await messaging().requestPermission({
      alert: true,
      badge: true,
      sound: true,
    });
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;
      console.log('-- 3 step--')
      return enabled
  } else {
    const authStatus = await messaging().requestPermission({
      alert: true,
      badge: true,
      sound: true,
    });
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;
      return enabled
  }
};




export const hasNotificaitonPermission = async () => {
  if (Platform.OS == "ios") {
    const authStatus = await messaging().hasPermission();
    return (
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL
    );
  } else {
    const authStatus = await messaging().requestPermission({
      alert: true,
      badge: true,
      sound: true,
    });
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;
    if (enabled) {
      return true;
    } else {
      return false;
    }
  }
};

function fetchTokens(callBack) {
  if (Platform.OS == "ios") {
    getAPNSToken(callBack);
  } else {
    getFcmToken(callBack);
  }
}

const getFcmToken = async (callBack) => {
  const fcmToken = await messaging().getToken();
  if (fcmToken) {
    await AsyncStorage.setItem("fcmToken", fcmToken);
    callBack(true);
  } else {
    console.log("Notification failed token", fcmToken);
    callBack(false);
  }
};

const getAPNSToken = async (callBack) => {
  const apnsToken = await messaging().getAPNSToken();
  console.log("Notification Device token APNS", apnsToken);
  if (apnsToken) {
    await AsyncStorage.setItem("apnsToken", apnsToken);
    getFcmToken(callBack);
  } else {
    callBack(false);
    console.log("Notification failed token", apnsToken);
  }
};
