import { actionTypes } from "../Action/navigationRouteAction";

interface ActionProps {
    type: any;
    data: string;
  }

  const initialState = {
    data: '',
  };

  const navigationRouteReducer = (state = initialState, action: ActionProps) => {
    switch (action.type) {
      case actionTypes.SET_PREVIOUS_PAGE:
        return {
          ...state,
          data: action.data,
        };
        case actionTypes.CLEAR_DATA:
        return {
          ...initialState
        };
      default:
        return state;
    }
  };
  
  export default navigationRouteReducer;