import { actionTypes } from "../Action/stockTransfer";

interface ActionProps {
  type: any;
  data: JSON;
  value:boolean
}

const initialState = {
  productList: {},
  loader:false
};

const stockTransferReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_STOCKTRANSFER_LOADER:
      return {
        ...state,
        loader: action.value,
      };
    case actionTypes.SET_STOCKTRANSFER_DATA:
      return {
        ...state,
        productList: action.data,
        loader:false
      };
    default:
      return state;
  }
};

export default stockTransferReducer;
