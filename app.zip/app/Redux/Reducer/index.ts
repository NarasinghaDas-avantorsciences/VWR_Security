import { combineReducers } from "redux";
import loginReducer from "./loginReducer";
import languageReducer from "./languageReducer";
import picontReducer from "./picountReducer";
import userReducer from "./userReducer";
import accountReducer from "./accountReducer";
import approvalsReducer from "./approvalsReducer";
import searchReducer from "./searchReducer";
import replenishReducer from "./replenishReducer";
import stockCorrectionReducer from "./stockCorrectionReducer";
import communicationReducer from "./communiticationReducer";
import dashboardReducer from "./dashboardReducer";
import receiveReducer from "./receiveReducer";
import consumeReducer from "./consumeReducer";
import navigationRouteReducer from "./navigationRouteReducer";
import stockTransfer from "./stockTransfer";

const rootReducer =combineReducers({
  loginReducer,
  languageReducer,
  picontReducer,
  userReducer,
  accountReducer,
  approvalsReducer,
  searchReducer,
  replenishReducer,
  stockCorrectionReducer,
  communicationReducer,
  dashboardReducer,
  receiveReducer,
  consumeReducer,
  navigationRouteReducer,
  stockTransfer
});

const appReducer = (state: any, action: any) => {
  if (action.type === "LOGOUT") {


    const resetState = {
      ...state,
      loginReducer: undefined, // Reset loginReducer
      // languageReducer is not reset
      picontReducer: undefined, // Reset picontReducer
      userReducer: undefined, // Reset userReducer
      accountReducer: undefined, // Reset accountReducer
      approvalsReducer: undefined, // Reset approvalsReducer
      searchReducer: undefined, // Reset searchReducer
      replenishReducer: undefined, // Reset replenishReducer
      stockCorrectionReducer: undefined, // Reset stockCorrectionReducer
      communicationReducer: undefined, // Reset communicationReducer
      dashboardReducer: undefined, // Reset dashboardReducer
      receiveReducer: undefined, // Reset receiveReducer
      consumeReducer: undefined, // Reset consumeReducer
      navigationRouteReducer: undefined, // Reset navigationRouteReducer
      stockTransfer: undefined, // Reset stockTransfer
    };
    // Merge the reset state with the non-reset state (languageReducer, etc.)
    state = {
      ...state,
      ...resetState,
    };
    // state = undefined;
  }
  return rootReducer(state, action);
};

export default appReducer;
