import { actionTypes } from "../Action/receiveAction";

interface ActionProps {
  type: string;
  data: JSON | boolean | number | string | any;
}

const initialState = {
  isLoading: false,
  receiveLimitFlag: 0,
  partialReceive: 0,
  readyToReceive: 0,
  pendingDelivery: 0,
  searchListCount: 0,
  allOrderList: null,
  readyOrderList: null,
  partialOrderList: null,
  pendingOrderList: null,
  orderDetails: [],
  receiveStock: null,
  receiveTitle: "",
  deliveryNoteTxt: "",
  receiveDataList: [],
};

const receiveReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_LOADER:
      return {
        ...state,
        isLoading: action.data,
      };
    case actionTypes.SET_RECEIVE_LIMIT_FLAG:
      return {
        ...state,
        receiveLimitFlag: action.data,
      };
    case actionTypes.GET_RECEIVE_KPIS:
      return {
        ...state,
        partialReceive: action.data?.partialReceive ?? 0,
        readyToReceive: action.data?.readyToReceive ?? 0,
        pendingDelivery: action.data?.pendingDelivery ?? 0,
      };
    case actionTypes.RECEIVE_ALL_ORDER_LIST:
      return {
        ...state,
        allOrderList:
          action.data?.offset == 0
            ? action.data?.data
            : state.allOrderList.concat(action.data?.data),
      };
    case actionTypes.RECEIVE_ALL_READY_LIST:
      return {
        ...state,
        readyOrderList:
          action.data?.offset == 0
            ? action.data?.data
            : state.readyOrderList.concat(action.data?.data),
      };
    case actionTypes.RECEIVE_ALL_PARTIAL_LIST:
      return {
        ...state,
        partialOrderList:
          action.data?.offset == 0
            ? action.data?.data
            : state.partialOrderList.concat(action.data?.data),
      };
    case actionTypes.RECEIVE_ALL_PENDING_LIST:
      return {
        ...state,
        pendingOrderList:
          action.data?.offset == 0
            ? action.data?.data
            : state.pendingOrderList.concat(action.data?.data),
      };
    case actionTypes.SET_RECEIVE_DETAILS_TITLE:
      return {
        ...state,
        receiveTitle: action.data,
        orderDetails: [],
      };
    //        deliveryNoteTxt: receiveDetailTitles.length > 1 ? receiveDetailTitles[1] : '',
    case actionTypes.RECEIVE_ORDER_DETAILS:
      return {
        ...state,
        orderDetails: action.data,
      };
    //SET_RECEIVE_DETAILS_DELIVERY_NOTES_TEXT
    case actionTypes.SET_RECEIVE_DETAILS_DELIVERY_NOTES_TEXT:
      return {
        ...state,
        deliveryNoteTxt: action.data,
      };
    case actionTypes.RECEIVE_STOCK_EDIT: {
      let titleParts = state.receiveTitle
        .split("-")
        .map((titlePart) => titlePart.trim());

      let splitArray = action?.data
        ?.split("+add+")
        .map((strValues: string) => strValues.trim());
      let delivryNteArry = splitArray.length > 0 ? splitArray[1] : "";
      let conformationOrderNumber =
        splitArray[0].trim().length > 0 ? splitArray[0].trim() + " - " : "";
      return {
        ...state,
        receiveTitle: `${conformationOrderNumber}${
          titleParts.length > 1 ? titleParts[titleParts.length-1] : titleParts[0]
        }`,
        deliveryNoteTxt: delivryNteArry,
      };
    }
    case actionTypes.SET_UPDATED_ORDERLIST:
      return {
        ...state,
        orderDetails: action.data,
      };
    case actionTypes.RECEIVE_STOCK:
      return {
        ...state,
        receiveStock: action.data,
      };
    case actionTypes.SET_RECEIVE_SEARCH_DATA:
      return {
        ...state,
        receiveDataList: state.receiveDataList.concat(action?.data?.data),
        searchListCount: action.data.totalCount ?? 0,
      };
    case actionTypes.CLEAR_RECEIVE_SEARCH:
      return {
        ...state,
        receiveDataList: [],
      };
    default:
      return state;
  }
};

export default receiveReducer;
