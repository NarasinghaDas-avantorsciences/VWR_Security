import { actionTypes } from "../Action/searchAction";

interface ActionProps {
  type: string;
  value?: JSON;
  loader: boolean;
}

const initialState = {
  searchList: [],
  productDetails: null,
  productDetailsLoading: false,
  loader: false,
  productBatchDetails: false,
};

const searchReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_SEARCH_DATA:
      let responseObj: any = action.value;
      let filteredData = responseObj.data?.filter(
        (item: any) => item.status == "online"
      );
      responseObj["data"] = filteredData;
      return {
        ...state,
        searchList: responseObj,
        loader: action?.loader,
      };
    case actionTypes.EMPTY_SEARCH_LIST:
      return {
        ...state,
        searchList: action.value,
      };
    case actionTypes.SET_PRODUCT_DETAILS_LOADER:
      return {
        ...state,
        productDetailsLoading: action.value,
      };
    case actionTypes.SET_PRODUCT_DETAILS:
      return {
        ...state,
        productDetails: action.value,
        productDetailsLoading: false,
      };
    case actionTypes.SET_PRODUCT_BATCH_DETAILS_LOADER:
      return {
        ...state,
        productBatchDetails: action.value,
      };
    default:
      return state;
  }
};

export default searchReducer;
