import { log } from "react-native-reanimated";
import { actionTypes } from "../Action/loginAction";

interface ActionProps {
  type: string;
  id: string;
  token: string;
  showSplash: boolean;
  value: boolean;
  active: boolean;
}
const initialState = {
  isLoading: true,
  userName: null,
  userToken: null,
  loader: false,
  active: true,
  showSplash: true,
  biometrics: false,
  biometricsHide: false,
  biometricsAvailable: false,
  internet: true,
  showUpdateAlert: false,
  showTokenModal: false,
};

const loginReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.LOGIN:
      return {
        ...state,
        userName: action.id,
        userToken: action.token,
        loader: false,
      };
    case actionTypes.LOGOUT:
      return {
        ...state,
        showTokenModal: false,
        userName: null,
        userToken: null,
        showSplash: false,
        loader: false,
      };
    case actionTypes.SET_LOADER:
      return {
        ...state,
        loader: action.value,
      };
    case actionTypes.RETRIEVE_TOKEN:
      return {
        ...state,
        userToken: action.token,
        showSplash: action.token ? true : false,
      };
    case actionTypes.UPDATE_TOKEN:
      return {
        ...state,
        userToken: action.token,
      };
    case actionTypes.ACTIVE:
      return {
        ...state,
        active: action.active,
      };
    case actionTypes.SET_SPLASH:
      return {
        ...state,
        showSplash: false,
      };
    case actionTypes.BIOMETRICS:
      return {
        ...state,
        biometrics: action.value,
      };
    case actionTypes.BIOMETRICS_HIDE:
      return {
        ...state,
        biometricsHide: action.value,
      };
    case actionTypes.BIOMETRICS_AVAILABLE:
      return {
        ...state,
        biometricsAvailable: action.value,
      };
    case actionTypes.INTERNET:
      return {
        ...state,
        internet: action.value,
      };
    case actionTypes.UPDATE_ALERT:
      return {
        ...state,
        showUpdateAlert: action.value,
      };
    case actionTypes.SHOW_TOKEN_MODAL:
      return {
        ...state,
        showTokenModal: action.value,
      };
    default:
      return state;
  }
};

export default loginReducer;
