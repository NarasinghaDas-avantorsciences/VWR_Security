import { actionTypes } from "../Action/communicationActions";

interface ActionProps {
  value: any;
  type: any;
}

const initialState = {
  notificationList: [],
  notificationCount: 0,
  messagesList: [],
  messagesCount: 0,
  newsList: [],
  newsCount: 0,
  loader: false,
};

const communicationReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.GET_NOTIFICATION_LIST:
      return {
        ...state,
        notificationList: action.value,
      };
    case actionTypes.GET_NOTIFICATION_COUNT:
      return {
        ...state,
        notificationCount: action.value,
      };
    case actionTypes.GET_MESSAGES_LIST:
      return {
        ...state,
        messagesList: action.value,
      };
    case actionTypes.GET_MESSAGES_COUNT:
      return {
        ...state,
        messagesCount: action.value,
      };
    case actionTypes.GET_NEWS_LIST:
      return {
        ...state,
        newsList: action.value,
      };
    case actionTypes.GET_NEWS_COUNT:
      return {
        ...state,
        newsCount: action.value,
      };
    case actionTypes.SET_LOADER:
      return {
        ...state,
        loader: action.value,
      };
    case actionTypes.CLEAR_ALL_NOTIFICATION_DATA:
      return {
        ...state,
        notificationList: [],
        messagesList: [],
        newsList: [],
      };
    default:
      return state;
  }
};

export default communicationReducer;
