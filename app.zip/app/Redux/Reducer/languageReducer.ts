import { actionTypes } from "../Action/languageAction";

interface ActionProps {
  type: any;
  value: JSON;
}

const initialState = {
  data: [],
  languageLoader: false,
  languageList: [],
};

const languageReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_LANGUAGE_DATA:
      return {
        ...state,
        data: action.value ?? [],
        languageLoader: false,
      };
    case actionTypes.SET_LANGUAGE_LIST:
      return {
        ...state,
        languageList: action.value ?? [],
      };
    case actionTypes.SET_LANGUAGE_LOADER:
      return {
        ...state,
        languageLoader: action.value,
      };
    default:
      return state;
  }
};

export default languageReducer;
