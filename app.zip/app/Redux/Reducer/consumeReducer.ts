import { actionTypes } from "../Action/consumeAction";

interface ActionProps {
  type: any;
  data: JSON;
}

const initialState = {
  data: null,
  loader: null,
  departments: []
};

const accountReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_DEPARTMENT_DATA:
      return {
        ...state,
        departments: action.data,
      };
    case actionTypes.SET_CONSUME_DATA:
      return {
        ...state,
        data: action.data,
      };
    case actionTypes.SET_LOADER:
      return {
        ...state,
        loader: action.data,
      };
    default:
      return state;
  }
};

export default accountReducer;
