import { actionTypes } from "../Action/stockCorrection";

interface ActionProps {
  type: any;
  data: JSON;
}

const initialState = {
  reasoncodes: [],
  correctStockList: [],
  selectedStock: {},
  reason: {
    code: "",
    id: 0
  }
};

const stockCorrectionReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_REASONCODE:
      return {
        ...state,
        reasoncodes: action.data,
      };
    case actionTypes.SET_REASON:
      return {
        ...state,
        reason: action.data,
      };
    case actionTypes.SET_CORRECT_STOCK_LIST:
      return {
        ...state,
        correctStockList: action.data,
      };
    case actionTypes.SET_SELECTED_STOCK:
      return {
        ...state,
        selectedStock: action.data,
      };
    default:
      return state;
  }
};

export default stockCorrectionReducer;
