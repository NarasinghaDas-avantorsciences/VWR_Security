import { actionTypes } from "../Action/replenishAction";

interface ActionProps {
  type: string;
  data: JSON | boolean | number | string;
}

const initialState = {
  isLoading: false,
  data: null,
  initialRecommendedData: [],
  userDataList: [],
  userPrice: [],
  costCenterList: [],
  vwrProductSearchData: [],
  addVwrToStockroomData: null,
  replenishRequestOrder: null,
  replenish: null,
  replenishStockCorrect: null,
  customerApprovalIDs: null,
  spclhandlingmsg: [],
  replenishOrderList: [],
};

const replenishReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.RESET_REPLENISH_STATE:
      return {
        ...state,
        isLoading: false,
        data: null,
        initialRecommendedData: [],
        userDataList: [],
        costCenterList: [],
        vwrProductSearchData: null,
        addVwrToStockroomData: null,
        replenishRequestOrder: null,
        replenish: null,
        replenishStockCorrect: null,
        customerApprovalIDs: null,
        spclhandlingmsg: [],
        replenishOrderList: [],
        userPrice: [],
      };
      case actionTypes.RESET_USERP_RICE:
      return {
        ...state,
        userPrice: [],
      };
    case actionTypes.SET_USERS_LIST:
      return {
        ...state,
        userDataList: action.data,
      };
      case actionTypes.SET_USERS_PRICE:
      return {
        ...state,
        userPrice: action.data,
      };
    case actionTypes.SET_COST_CENTERS_LIST:
      return {
        ...state,
        costCenterList: action.data,
      };
    case actionTypes.SET_LOADER:
      return {
        ...state,
        isLoading: action.data,
      };
    case actionTypes.SET_INITIAL_REPLENISH_PRODUCTS:
      return {
        ...state,
        initialRecommendedData: action.data,
      };
    case actionTypes.SET_UPDATED_RECOMMENDED_DATA:
      return {
        ...state,
        initialRecommendedData: action.data,
        isLoading: false,
      };
    case actionTypes.ADD_ITEMS_ORDER_LIST:
      return {
        ...state,
        initialRecommendedData: action.data,
        isLoading: false,
      };
    case actionTypes.SET_VWR_PRODUCT_SEARCH:
      return {
        ...state,
        vwrProductSearchData:
          action.data?.offset == 0
            ? action.data.data
            : state.vwrProductSearchData.concat(action.data.data),
      };
    case actionTypes.ADD_VWR_TO_STOCKROOM:
      return {
        ...state,
        addVwrToStockroomData: action.data,
      };
    case actionTypes.CLEAR_VWR_STOCKROOM_DATA:
      return {
        ...state,
        addVwrToStockroomData: null,
      };
    case actionTypes.REPLENISH:
      return {
        ...state,
        replenish: action.data,
      };
    case actionTypes.REPLENISH_REQUEST_ORDER:
      return {
        ...state,
        replenishRequestOrder: action.data,
      };
    case actionTypes.REPLENISH_STOCK_CORRECT:
      return {
        ...state,
        replenishStockCorrect: action.data,
      };
    case actionTypes.SET_REPLENISH_APPROVAL_IDS:
      return { ...state, customerApprovalIDs: action.data };
    case actionTypes.SET_SPECIAL_HANDLING_MESSAGE:
      return { ...state, spclhandlingmsg: action.data };
    default:
      return state;
  }
};

export default replenishReducer;
