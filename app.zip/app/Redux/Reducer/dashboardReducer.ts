import { actionTypes } from "../Action/dashboardAction";

interface ActionProps {
  type: any;
  value: JSON;
}

const initialState = {
  outOfStock: 0,
  runningLow: 0,
  outOfStockProductList: null,
  runningLowProductList: null,
  loader: false,
};

const dashboardReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_OUT_OF_STOCK:
      return {
        ...state,
        outOfStock: action.value,
      };
    case actionTypes.SET_RUNNING_LOW:
      return {
        ...state,
        runningLow: action.value,
      };
    case actionTypes.SET_OUT_OF_STOCK_PRODUCT_LIST:
      return {
        ...state,
        outOfStockProductList: action.value,
        loader: false,
      };
    case actionTypes.SET_RUNNING_LOW_PRODUCT_LIST:
      return {
        ...state,
        runningLowProductList: action.value,
        loader: false,
      };
    case actionTypes.CLEAR_STOCK_LEVEL_DATA:
      return {
        ...state,
        outOfStockProductList: null,
        runningLowProductList: null,
      };
    case actionTypes.SET_LOADER:
      return {
        ...state,
        loader: action.value,
      };
    default:
      return state;
  }
};

export default dashboardReducer;
