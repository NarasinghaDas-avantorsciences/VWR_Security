import { actionTypes } from "../Action/userAction";

interface ActionProps {
  type: string;
  value: string | number | JSON | object | any;
}

const initialState = {
  org: [],
  org_details: [],
  stockRooms: [],
  userPrivilege: [],
  isOnHand: false,
  isPutAway: false,
  isConsumption: false,
  replenishPrivilege: "order",
  currency: "",
  stockRoomDetail: null,
  replenishModel: "CONSUMPTION_MODEL",
  appVersion: "",
  selectedTitle: "",
  selectedSubTitle: "",
  selectedOrgId: 0,
  selectedRoom: 0,
  soldToNumber: "",
  shipToNumber: "",
  addReasonCodePrivilege: false,
};

const getReplenishUserPrivilege = (userPrivilege: any) => {
  const data = userPrivilege?.filter(
    (item: any) => item?.name === "replenish.scanner"
  );
  let replenishType;
  if (data?.length) {
    replenishType = userPrivilege?.filter(
      (item: any) => item?.parentType === data[0].type
    );
  }

  if (replenishType?.length && replenishType[0].name === "scanner.order") {
    return "order";
  } else {
    return "request";
  }
};

const getAddReasonCodePrivilege = (userPrivilege: any) => {
  const data = userPrivilege?.filter(
    (item: any) => item?.name === "reasoncode.scanner"
  );
  let reasonCodeType;

  if (data?.length) {
    reasonCodeType = userPrivilege?.filter(
      (item: any) => item?.parentType === data[0].type
    );
  }

  if (
    reasonCodeType?.length &&
    reasonCodeType[0].name === "add.reasoncode.scanner"
  ) {
    return true;
  } else {
    return false;
  }
};

const getConsumeUserPrivilege = (userPrivilege: any) => {
  const data = userPrivilege?.filter(
    (item: any) => item?.name === "consume.scanner"
  );
  let consumeType;
  if (data?.length) {
    consumeType = userPrivilege?.filter(
      (item: any) => item?.parentType === data[0].type
    );
  }

  if (consumeType?.length && consumeType[0].name === "scanner.consume") {
    return "consume";
  } else {
    return "request";
  }
};

const getconsumeLogoutPrivilage = (userPrivilege: any) => {
  const data = userPrivilege?.filter(
    (item: any) => item?.name === "consume.scanner"
  );
  let consumeType;
  if (data?.length) {
    consumeType = userPrivilege?.filter(
      (item: any) => item?.parentType === data[0].type
    );
  }

  if (consumeType?.length){ //some time these array contain too many values so we wre filtering again.
    consumeType = consumeType.filter((item: any) => item?.name === "auto.logout.scanner")
    if (consumeType?.length){
      return true;
    } else {
      return false;
    }
  }else{
    return false;
  }
};

const getUserSelectPrivilege = (userPrivilege: any) => {
  const data = userPrivilege?.filter(
    (item: any) => item?.name === "select.user.scanner"
  );

  if (data?.length && data[0].type == "priv_select_user_scanner") {
    return true;
  } else {
    return false;
  }
};

const userReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_ORG:
      return {
        ...state,
        org: action.value,
      };
    case actionTypes.SET_ORG_DETAILS:
      return {
        ...state,
        org_details: action.value,
        repelenishModel: action.value?.replenishModel,
        appVersion: action.value?.appVersion,
        dateFormat: {
          date: action.value?.dateFormat.replaceAll("_", "-"),
          hours: action.value?.timeFormat.replace("_", ""),
        },
        timeFormat: action.value?.timeFormat.replace("_", ""),
      };
    case actionTypes.SET_STOCKROOMS:
      return {
        ...state,
        stockRooms: action.value,
      };
    case actionTypes.SET_USER_PRIVILAGE:
      return {
        ...state,
        userPrivilege: action.value,
        replenishPrivilege: getReplenishUserPrivilege(action.value),
        consumePrivilege: getconsumeLogoutPrivilage(action.value),
        userSelectPrivilege: getUserSelectPrivilege(action.value),
        consumeCustomPrivilage: getConsumeUserPrivilege(action.value),
        addReasonCodePrivilege: getAddReasonCodePrivilege(action.value),
      };
    case actionTypes.SET_SELECTED_ORG_AND_STOCKROOM:
      return {
        ...state,
        selectedOrg: action.value.selectedOrg,
        selectedStockRoom: action.value.selectedStockRoom,
        organizationName: action.value.selectedOrg?.orgName,
        stockroomName: action.value.selectedStockRoom?.stockroomName,
      };

    case actionTypes.SET_ORG_LEVEL_CURRENCY:
      return {
        ...state,
        currency: action.value?.defaultCurrency,
      };
    case actionTypes.STOCK_ROOM_DETAIL:
      return {
        ...state,
        stockRoomDetail: action.value,
        shipToNumber: action.value.customerShipNo,
        soldToNumber: action.value?.soldTo,
        isOnHand:
          state.appVersion !== "Standard"
            ? state.replenishModel === "CONSUMPTION_MODEL"
              ? action.value?.scannerReplenishModel ===
                "ORDER_ACCORDING_TO_INVENTORY_COUNT"
                ? true
                : false
              : false
            : true,
        isPutAway:
          state.appVersion !== "Standard"
            ? state.replenishModel === "CONSUMPTION_MODEL"
              ? action.value?.scannerReplenishModel ===
                  "ORDER_WHAT_IS_MISSING" ||
                action.value?.scannerReplenishModel ===
                  "ORDER_WHAT_IS_MISSING_ECONOMICAL_ROP"
                ? true
                : false
              : false
            : false,
        isConsumption:
          state.appVersion !== "Standard"
            ? state.replenishModel === "CONSUMPTION_MODEL"
              ? action.value?.scannerReplenishModel === "REPLENISH_MODE"
                ? true
                : false
              : false
            : false,
      };
    case actionTypes.TITLE:
      return {
        ...state,
        selectedTitle: action.value,
      };
    case actionTypes.SUBTITLE:
      return {
        ...state,
        selectedSubTitle: action.value,
      };
    case actionTypes.SETSELECTEDORG:
      return {
        ...state,
        selectedOrgId: action.value,
      };
    case actionTypes.SETSELECTEDROOMID:
      return {
        ...state,
        selectedRoom: action.value,
      };
    case actionTypes.CLEARSELECTEDSTOCKORG:
      return {
        ...state,
        //selectedTitle: "",
        //selectedSubTitle: "",
        //selectedOrgId: 0,
        //selectedRoom: 0,
      };
    case actionTypes.SET_CONFIRMATION_ALERT_DETAILS:
      return {
        ...state,
        confirmationAlertInfo: action.value,
      };
    default:
      return state;
  }
};

export default userReducer;
