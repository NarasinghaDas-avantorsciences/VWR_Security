import { actionTypes } from "../Action/accountAction";

interface ActionProps {
  type: any;
  data: JSON;
}

const initialState = {
  data: null,
  isProfileDataLoading: false,
  showTermsAgreed: false,
};

const accountReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_ACCOUNT_DATA:
      return {
        ...state,
        data: action.data,
        isProfileDataLoading: false,
      };
    case actionTypes.SET_LOADER:
      return {
        ...state,
        isProfileDataLoading: action.data,
      };
    case actionTypes.CLEAR_ACCOUNT_DATA:
      return {
        ...initialState,
        data: null,
      };
    case actionTypes.TERMS_AGREED:
      return {
        ...state,
        showTermsAgreed: action.data,
      };
    default:
      return state;
  }
};

export default accountReducer;
