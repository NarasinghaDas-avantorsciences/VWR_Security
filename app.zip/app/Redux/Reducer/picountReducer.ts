import { actionTypes } from "../Action/picountAction";

interface ActionProps {
  type: any;
  selectedPiCountValue: string;
}
const initialState = {
  selectedPiCountValue: null,
  piCountList: [],
  piCountLocationsList: [],
  batches: [],
  loader: false,
  piCountConfirmedProductsList: null,
  piCountPendingProductsList: null,
  piCountProductsList: [],
  piCountNoData: false,
};

const picountReducer = (state = initialState, action: ActionProps) => {
  switch (action.type) {
    case actionTypes.SET_LOADER:
      return {
        ...state,
        loader: action.value,
      };
    case actionTypes.SET_SELECTED_PI_COUNT:
      return {
        ...state,
        selectedPiCountValue: action.data,
      };
    case actionTypes.SET_PI_COUNT_PPRODUCT_BATCHES:
      return {
        ...state,
        batches: action.data,
      };
    case actionTypes.SET_PI_COUNT_LIST:
      return {
        ...state,
        piCountList: action.data,
      };
    case actionTypes.SET_PI_LIST_COUNT:
      return {
        ...state,
        totalCount: action.data,
      };
    case actionTypes.SET_PI_PENDING_PRODUCT_LIST:
      let finalPArray = [];
      if (state.piCountPendingProductsList)
        finalPArray = [...finalPArray, ...state.piCountPendingProductsList];
      if (action.data) finalPArray = [...finalPArray, ...action.data];
      console.log("finalPArray lenth ", finalPArray?.length);
      return {
        ...state,
        piCountPendingProductsList: finalPArray?.length
          ? [...finalPArray]
          : null,
        // state.piCountPendingProductsList
        //   ? [...state.piCountPendingProductsList, ...action.data]
        //   : [...action.data],
        piCountNoData: action.data?.length == 0,
      };
    case actionTypes.UPDATE_PI_PENDING_PRODUCT_LIST:
      return {
        ...state,
        piCountPendingProductsList: [...action.data],
      };

    case actionTypes.UPDATE_PI_CONFIRM_PRODUCT_LIST:
      return {
        ...state,
        piCountConfirmedProductsList: [...action.data],
      };
    case actionTypes.RESET_PI_PENDING_PRODUCTS:
      return {
        ...state,
        piCountPendingProductsList: null,
      };
    case actionTypes.RESET_PI_CONFIRM_PRODUCTS:
      return {
        ...state,
        piCountConfirmedProductsList: null,
      };

    case actionTypes.SET_PI_CONFIRMED_PRODUCT_LIST:
      let finalCArray = [];
      if (state.piCountConfirmedProductsList)
        finalCArray = [...finalCArray, ...state.piCountConfirmedProductsList];
      if (action.data) finalCArray = [...finalCArray, ...action.data];
      console.log("finalCArray lenth ", finalCArray?.length);
      return {
        ...state,
        piCountConfirmedProductsList: finalCArray?.length
          ? [...finalCArray]
          : null,
        // state.piCountConfirmedProductsList
        //   ? [...state.piCountConfirmedProductsList, ...action.data]
        //   : [...action.data],
      };

    case actionTypes.SET_PI_COUNT_LOCATIONS:
      return {
        ...state,
        piCountLocationsList: action.data,
      };

    default:
      return state;
  }
};

export default picountReducer;
