import { useSelector } from "react-redux";
import { Item } from "../../Screens/AppFlow/Replenish";
import { ApiConfig } from "../../Service/Api";
import {
  baseUrl,
  cost_centers,
  get_users_list,
  replenish,
  getReplenishProducts,
  addVwrProductSearch,
  addVwrStockRoomProducts,
  replenishRequest,
  replenishStockCorrect,
  get_replenish_customerApprovalId,
  get_spclhandlingmsg,
  get_user_price_URL,
} from "../../Service/ApiConfig";
import { sortArray } from "../../Utils/globalFunction";
import * as storage from "../../Service/AsyncStoreConfig";

export const actionTypes = {
  ADD_ONE_TIME_COST_CENTER: "ADD_ONE_TIME_COST_CENTER",
  SET_LOADER: "SET_LOADER",
  SET_USERS_LIST: "SET_USERS_LIST",
  SET_USERS_PRICE: "SET_USERS_PRICE",
  SET_COST_CENTERS_LIST: "SET_COST_CENTERS_LIST",
  REPLENISH: "REPLENISH",
  SET_INITIAL_REPLENISH_PRODUCTS: "SET_INITIAL_REPLENISH_PRODUCTS",
  SET_VWR_PRODUCT_SEARCH: "SET_VWR_PRODUCT_SEARCH",
  ADD_VWR_TO_STOCKROOM: "ADD_VWR_TO_STOCKROOM",
  REPLENISH_REQUEST_ORDER: "REPLENISH_REQUEST_ORDER",
  REPLENISH_STOCK_CORRECT: "REPLENISH_STOCK_CORRECT",
  CLEAR_VWR_STOCKROOM_DATA: "CLEAR_VWR_STOCKROOM_DATA",
  SET_REPLENISH_APPROVAL_IDS: "SET_REPLENISH_APPROVAL_IDS",
  SET_SPECIAL_HANDLING_MESSAGE: "SET_SPECIAL_HANDLING_MESSAGE",
  SET_UPDATED_RECOMMENDED_DATA: "SET_UPDATED_RECOMMENDED_DATA",
  ADD_ITEMS_ORDER_LIST: "ADD_ITEMS_ORDER_LIST",
  RESET_REPLENISH_STATE: "RESET_REPLENISH_STATE",
  RESET_USERP_RICE: "RESET_USERP_RICE",
};

export const setLoader = (isLoader: boolean) => {
  return {
    type: actionTypes.SET_LOADER,
    data: isLoader,
  };
};

export const resetReplenishState = () => {
  return {
    type: actionTypes.RESET_REPLENISH_STATE,
  };
};

export const resetPriceState = () => {
  return {
    type: actionTypes.RESET_USERP_RICE,
  };
};


export const getUserPrice = (replenishProductsData:any) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const org: any = await storage.getItem("org");
    console.log("org data",org);
    const args = {"selectedUserId":"","costCenterId":"","replenishProducts":replenishProductsData,"contactEmail":[],"costCenterName":""};
    const header = JSON.stringify({
      orgId: JSON.parse(org)?.orgId,
      stockroomId: JSON.parse(org)?.stockroomId,
    });
    new ApiConfig()
    .postPriceJSON(header,args,baseUrl + get_user_price_URL)
      .then((res: any) => {
        dispatch({
          type: actionTypes.SET_USERS_PRICE,
          data: res?.data,
        });
       console.log("Price api Data Replnes",res?.data);
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
        console.log("Price api Data Failler",ERROR);
      });
  };
};

export const getInitialRecommendedProducts = (
  fromScreen?: string,
  paramData?: any,
  successCallBack?: any,
  errorCallBack?: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(baseUrl + getReplenishProducts)
      .then(async (response: any) => {
        // successCallBack(response);
        let updatedRecommendedProducts;
        if (
          (fromScreen == "stockLevel" || fromScreen == "ReplenishOffline") &&
          response?.data?.data == null
        ) {
          updatedRecommendedProducts = paramData;
        } else if (fromScreen == "stockLevel" && response?.data?.data != null) {
          let respData = response?.data?.data.map((item: any) => {
            return {
              ...item,
              selected: item?.freeze == true ? false : true,
              selectedQty: item.orderedQuantity,
              enteredComment: null,
              type: "RECOMMENDED",
            };
          });

          /**Check if the entries are duplicate */
          //updatedRecommendedProducts = [...respData, ...paramData];

          updatedRecommendedProducts = mergeAndRemoveDuplicates(
            respData,
            paramData
          );
        } else if (response?.data?.data == null && fromScreen != "stockLevel") {
          updatedRecommendedProducts = [];
        } else {
          updatedRecommendedProducts = response?.data?.data.map((item: any) => {
            return {
              ...item,
              selected: item?.freeze == true ? false : true,
              selectedQty: item.orderedQuantity,
              enteredComment: null,
              type: "RECOMMENDED",
            };
          });
          if (fromScreen == "ReplenishOffline") {
            /**Check if the entries are duplicate */

            updatedRecommendedProducts = mergeAndRemoveDuplicates(
              updatedRecommendedProducts,
              paramData
            );
            //  = [
            //   ...updatedRecommendedProducts,
            //   ...paramData,
            // ];
          }
        }

        await dispatch({
          type: actionTypes.SET_INITIAL_REPLENISH_PRODUCTS,
          data: updatedRecommendedProducts,
        });
        await dispatch(setLoader(false));
      })
      .catch((err) => {
        dispatch(setLoader(false));
        errorCallBack(err.response);

        return err;
      });
  };
};
export const mergeAndRemoveDuplicates = (array1, array2) => {
  const mergedArray = [...array1];
  for (const item2 of array2) {
    const index = mergedArray.findIndex((item1) => item1.id === item2.id);
    if (index !== -1) {
      mergedArray[index].selectedQty = item2.selectedQty;
      mergedArray[index].batches = item2.batches;
    } else {
      mergedArray.push(item2);
    }
  }
  return mergedArray;
};

export const setUpdatedRecommendedData = (data: any) => {
  return {
    type: actionTypes.SET_UPDATED_RECOMMENDED_DATA,
    data: data,
  };
};
export const resetRecommendedProducts = (data: any) => {
  return {
    type: actionTypes.SET_INITIAL_REPLENISH_PRODUCTS,
    data: data,
  };
};

export const addItemsToOrderList = (
  data: any,
  initialRecommendedData: any,
  type: string
) => {
  let newList;
  if (type === "object") {
    let dataId = data.id;
    if (initialRecommendedData.length > 0) {
      let selectedIndex = initialRecommendedData.findIndex(
        (x: Item) => x.id == dataId
      );
      if (selectedIndex == -1) {
        newList = [
          ...initialRecommendedData,
          {
            ...data,
            selected: data?.freeze == true ? false : true,
            type: "STOCKED",
          },
        ];
      } else {
        // initialRecommendedData[selectedIndex].selectedQty =
        //   // Number(initialRecommendedData[selectedIndex].selectedQty) +
        //   Number(data.selectedQty);
        initialRecommendedData[selectedIndex].selectedQty = Number(
          data.selectedQty
        );
        console.log("initialRecommendedData merging");
        // //CHANGE COMMENT
        initialRecommendedData[selectedIndex].enteredComment =
          data.enteredComment;

        initialRecommendedData[selectedIndex].selected =
          data?.freeze == true ? false : true;
        newList = initialRecommendedData;
      }
    } else {
      newList = [
        {
          ...data,
          selected: data?.freeze == true ? false : true,
          type: "STOCKED",
        },
      ];
    }
  } else {
    if (initialRecommendedData.length > 0) {
      let sampleData = data?.map((item: Item) => ({
        ...item,
        selected: item?.freeze == true ? false : true,
        type: "STOCKED",
      }));

      newList = [...initialRecommendedData, ...sampleData];
    } else {
      let sampleData = data?.map((item: Item) => ({
        ...item,
        selected: item?.freeze == true ? false : true,
        type: "STOCKED",
      }));
      newList = sampleData;
    }
  }
  return {
    type: actionTypes.ADD_ITEMS_ORDER_LIST,
    data: newList,
  };
};

export const clearOrderedItemList = () => {
  return {
    type: actionTypes.ADD_ITEMS_ORDER_LIST,
    data: [],
  };
};

export const replenishOrder = (
  params: any,
  successCallBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = params;
    new ApiConfig()
      .postJSON(args, baseUrl + replenish)
      .then((res: any) => {
        successCallBack(res);
        dispatch({
          type: actionTypes.REPLENISH,
          data: res?.data,
        });
        dispatch(setLoader(false));
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const addOneTimeCostCenter = (obj: any) => {
  const { data, onSuccess, onFail } = obj;
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = {
      isOneTime: true,
      costCenterName: data?.costCenterName,
    };
    new ApiConfig()
      .postJSON(args, baseUrl + `api/users/${data.userId}` + cost_centers)
      .then((res: any) => {
        onSuccess?.(res?.data);
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        const errorMessage =
          ERROR?.response?.data?.errorMessage || "Something went wrong";
        onFail?.(errorMessage);
        dispatch(setLoader(false));
      });
  };
};

export const getUsersList = () => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(baseUrl + get_users_list)
      .then((res: any) => {
        dispatch({
          type: actionTypes.SET_USERS_LIST,
          data: res?.data?.data?.sort(sortArray),
        });
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const getCostCentersList = (params: any, successCallBack?: any) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(baseUrl + `api/users/${params.id}` + cost_centers)
      .then((res: any) => {
        successCallBack && successCallBack(res?.data);
        dispatch({
          type: actionTypes.SET_COST_CENTERS_LIST,
          data: res?.data,
        });
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const setCostCentersList = () => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_COST_CENTERS_LIST,
      data: [],
    });
  };
};
type SearchVWRProductParamsType = {
  catalogNo: string;
  vendorCatalogNo: string;
  keyword: string;
};

const setUrl = (params: SearchVWRProductParamsType, offset?: number) => {
  if (params.catalogNo === "") {
    if (params.vendorCatalogNo === "")
      return `keyWord=${params.keyword}&offset=${offset}&limit=10`;
    else
      return `vendorCatalogNo=${params.vendorCatalogNo}&offset=${offset}&limit=10`;
  } else if (params.vendorCatalogNo === "") {
    if (params.catalogNo === "")
      return `keyWord=${params.keyword}&offset=${offset}&limit=10`;
    else return `catalogNo=${params.catalogNo}&offset=${offset}&limit=10`;
  } else if (params.keyword === "") {
    if (params.catalogNo === "")
      return `vendorCatalogNo=${params.vendorCatalogNo}&offset=${offset}&limit=10`;
    else return `catalogNo=${params.catalogNo}&offset=${offset}&limit=10`;
  } else
    return `catalogNo=${params.catalogNo}&vendorCatalogNo=${params.vendorCatalogNo}&keyWord=${params.keyword}&offset=${offset}0&limit=10`;
};

export const clearVwrSearchData = () => {
  return {
    type: actionTypes.SET_VWR_PRODUCT_SEARCH,
    data: { data: [], offset: 0 },
  };
};

export const searchVwrProduct = (
  params: SearchVWRProductParamsType,
  offset?: any
) => {
  let filterUrl = setUrl(params, offset * 10);
  const offset1 = offset;
  return async (dispatch: any) => {
    offset1 == 0 && dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(baseUrl + addVwrProductSearch + filterUrl)
      .then((res: any) => {
        dispatch({
          type: actionTypes.SET_VWR_PRODUCT_SEARCH,
          data: { data: res?.data?.prodList, offset: offset1 },
        });
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const clearAddVwrStockRoomData = () => {
  return {
    type: actionTypes.CLEAR_VWR_STOCKROOM_DATA,
  };
};

export const addVwrToStockRoom = (
  params: any,
  quantity: number,
  unitMeasureValue: string,
  uomCode: string,
  currency: string,
  comment: string,
  successCallBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = {
      qty: quantity,
      orderedQuantity: quantity,
      catalogNo: params.catalogNumber,
      vendorCaalogNo: params.supplierCatalogNumber,
      techArticleNo: params.technicalArticleNumber,
      description: params.description,
      uomId: unitMeasureValue,
      purchasePrice: params.listPrice,
      currency: currency,
      vendorName: "VWR",
      uomcode: uomCode,
      referenceField1: "Field1",
      referenceField2: "Field2",
      referenceField3: "Field3",
      referenceField4: "Field4",
      referenceField5: "Field5",
      referenceField6: "Field6",
      referenceField7: "Field7",
      referenceField8: "Field8",
      referenceField9: "Field9",
      referenceCode1: "Code1",
      referenceCode2: "Code2",
      referenceCode3: "Code3",
      referenceCode4: "Code4",
      referenceCode5: "Code5",
      referenceCode6: "Code6",
      referenceCode7: "Code7",
      referenceCode8: "Code8",
      referenceCode9: "Code9",
      referenceCode10: "Code10",
      referenceCode11: "Code11",
      referenceCode12: "Code12",
      isOneTime: 1,
      status: "offline",
    };

    new ApiConfig()
      .postJSON(args, baseUrl + addVwrStockRoomProducts)
      .then((res: any) => {
        if (res?.data?.data !== null) {
          dispatch({
            type: actionTypes.ADD_VWR_TO_STOCKROOM,
            data: {
              ...res?.data?.data,
              enteredComment: comment,
              selectedQty: quantity,
            },
          });
        } else {
          errorCallBack(res?.data?.status);
        }
        dispatch(setLoader(false));
      })
      .catch((err: any) => {
        errorCallBack(err?.response?.data?.errorMessage);
        dispatch(setLoader(false));
      });
  };
};

export const replenishRequestOrder = (
  params: any,
  successCallBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = params;
    new ApiConfig()
      .postJSON(args, baseUrl + replenishRequest)
      .then((res: any) => {
        successCallBack(res);
        dispatch({
          type: actionTypes.REPLENISH_REQUEST_ORDER,
          data: res?.data,
        });
        dispatch(setLoader(false));
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const replenishStockCorrection = (
  params: any,
  successCallBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = params;
    new ApiConfig()
      .postJSON(args, baseUrl + replenishStockCorrect)
      .then((res: any) => {
        successCallBack(res);
        dispatch({
          type: actionTypes.REPLENISH_STOCK_CORRECT,
          data: res?.data,
        });
        dispatch(setLoader(false));
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const getReplenishCustomerApprovalIds = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_replenish_customerApprovalId)
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_REPLENISH_APPROVAL_IDS,
          data: response?.data,
        });
      })
      .catch((ERROR) => {
        console.log("ERROR in getReplenishCustomerApprovalIds", ERROR);
      });
  };
};

export const getSpecialHandlingMessages = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_spclhandlingmsg)
      .then((response: any) => {
        let noneSplMsgHdler = [
          {
            createdBy: "null",
            createdDate: null,
            id: 0,
            modifiedBy: "null",
            modifiedDate: null,
            selected: "N",
            splHandlingCode: "None",
          },
        ];
        // added 'None' splHandldata
        let splHandldata = response?.data?.length > 0 ? response?.data : [];
        dispatch({
          type: actionTypes.SET_SPECIAL_HANDLING_MESSAGE,
          data: noneSplMsgHdler.concat(splHandldata),
        });
      })
      .catch((ERROR) => {
        console.log("ERROR in getSpecialHandlingMessages", ERROR);
      });
  };
};
