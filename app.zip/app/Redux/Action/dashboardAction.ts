import { ApiConfig } from "../../Service/Api";
import {
  baseUrl,
  get_kpi_ProductList,
  get_stock_low,
  get_stock_out,
} from "../../Service/ApiConfig";
export const actionTypes = {
  SET_OUT_OF_STOCK: "SET_OUT_OF_STOCK",
  SET_RUNNING_LOW: "SET_RUNNING_LOW",
  SET_OUT_OF_STOCK_PRODUCT_LIST: "SET_OUT_OF_STOCK_PRODUCT_LIST",
  SET_RUNNING_LOW_PRODUCT_LIST: "SET_RUNNING_LOW_PRODUCT_LIST",
  CLEAR_STOCK_LEVEL_DATA: "CLEAR_STOCK_LEVEL_DATA",
  SET_LOADER: "SET_LOADER",
};
import { removeOfflineProduct } from "../../Utils/globalFunction";

export const getOutOfStock = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_stock_out)
      .then(async (res: any) => {
        dispatch({
          type: actionTypes.SET_OUT_OF_STOCK,
          value: res?.data,
        });
      })
      .catch((ERROR) => {});
  };
};
export const getRunningLowStock = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_stock_low)
      .then(async (res: any) => {
        dispatch({
          type: actionTypes.SET_RUNNING_LOW,
          value: res?.data,
        });
      })
      .catch((ERROR) => {});
  };
};

export const getOutOfProductList = (
  offset: number,
  outOfStockProduct: any,
  selectedAll?: boolean
) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_LOADER,
      value: true,
    });
    new ApiConfig()
      .getJSON(
        baseUrl +
          get_kpi_ProductList +
          `?limit=10&offset=${offset}&sortBy=${"description"}:asc&filterOutOfStock=true&status=online`
      )
      .then(async (res: any) => {
        let data;
        if (res["data"]?.data == null) {
          data = [];
        } else {
          data = res["data"]?.data.map((item: any) => {
            return {
              ...item,
              selected: selectedAll == true ? true : false,
              selectedQty: item.orderedQuantity,
              enteredComment: null,
              type:
                Number(item?.orderedQuantity) > 0 ? "RECOMMENDED" : "STOCKED",
              kpiEnabled: true,
            };
          });
        }
        data = outOfStockProduct.concat(removeOfflineProduct(data));
        dispatch({
          type: actionTypes.SET_OUT_OF_STOCK_PRODUCT_LIST,
          value: data,
        });
      })
      .catch((ERROR) => {
        dispatch({
          type: actionTypes.SET_LOADER,
          value: false,
        });
      });
  };
};

export const getRunningLowProductList = (
  offset: number,
  runningLowProduct: any,
  selectedAll?: boolean
) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_LOADER,
      value: true,
    });
    new ApiConfig()
      .getJSON(
        baseUrl +
          get_kpi_ProductList +
          `?limit=10&offset=${offset}&sortBy=description:asc&filterRunningLow=true&status=online`
      )
      .then(async (res: any) => {
        let data;
        if (res["data"]?.data == null) {
          data = [];
        } else {
          data = res["data"]?.data.map((item: any) => {
            return {
              ...item,
              selected: selectedAll == true ? true : false,
              selectedQty: item.orderedQuantity,
              enteredComment: null,
              type:
                Number(item?.orderedQuantity) > 0 ? "RECOMMENDED" : "STOCKED",
              kpiEnabled: true,
            };
          });
        }
        data = runningLowProduct.concat(removeOfflineProduct(data));
        dispatch({
          type: actionTypes.SET_RUNNING_LOW_PRODUCT_LIST,
          value: data,
        });
      })
      .catch((ERROR) => {
        dispatch({
          type: actionTypes.SET_LOADER,
          value: false,
        });
      });
  };
};

export const setUpdatedOutofStockData = (data: any) => {
  // return {
  //   type: actionTypes.SET_OUT_OF_STOCK_PRODUCT_LIST,
  //   value: data,
  // };
};
export const setUpdatedRunningLowData = (data: any) => {
  // return {
  //   type: actionTypes.SET_OUT_OF_STOCK_PRODUCT_LIST,
  //   value: data,
  // };
};

export const setSelectAllProductData = (data: any, id: number) => {
  return {
    type:
      id == 0
        ? actionTypes.SET_OUT_OF_STOCK_PRODUCT_LIST
        : actionTypes.SET_RUNNING_LOW_PRODUCT_LIST,
    value: data,
  };
};

export const clearStockLevelData = () => {
  return {
    type: actionTypes.CLEAR_STOCK_LEVEL_DATA,
  };
};
