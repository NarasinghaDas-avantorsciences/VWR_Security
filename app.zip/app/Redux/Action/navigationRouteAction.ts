export const actionTypes = {
    SET_PREVIOUS_PAGE: "SET_PREVIOUS_PAGE",
    CLEAR_DATA: "CLEAR_DATA",
};

export const clearNavigationData = () => {
    return {
      type: actionTypes.CLEAR_DATA,
      data: "",
    };
};


export const setNavigationData = (route:string) => {
    return {
      type: actionTypes.SET_PREVIOUS_PAGE,
      data: route,
    };
};