import { ApiConfig } from "../../Service/Api";
import {
  baseUrl,
  consume,
  departments,
  request_consume,
  get_productList,
} from "../../Service/ApiConfig";
import * as storage from "../../Service/AsyncStoreConfig";

export const actionTypes = {
  SET_DEPARTMENT_DATA: "SET_DEPARTMENT_DATA",
  SET_CONSUME_DATA: "SET_CONSUME_DATA",
  SET_LOADER: "SET_LOADER",
  SET_SEARCH_DATA: "SET_SEARCH_DATA",
  SET_PRODUCT_SEARCH_LOADER: "SET_PRODUCT_SEARCH_LOADER",
};

export const setLoader = (isLoader: boolean) => {
  return {
    type: actionTypes.SET_LOADER,
    value: isLoader,
  };
};

export const setProductLoader = (isLoader: boolean) => {
  return {
    type: actionTypes.SET_PRODUCT_SEARCH_LOADER,
    value: isLoader,
  };
};

export const getDepartments = (params: any) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(baseUrl + `api/users/${params.id}/` + departments)
      .then((res: any) => {
        dispatch({
          type: actionTypes.SET_DEPARTMENT_DATA,
          data: res?.data?.data ? res?.data?.data : [],
        });
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const setDepartments = () => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_DEPARTMENT_DATA,
      data: [],
    });
  };
};

export const addOneTimeDepartment = (obj: any) => {
  const { data, onSuccess, onFail } = obj;
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = {
      isOneTimeDept: true,
      departmentName: data?.departmentName,
    };
    new ApiConfig()
      .postJSON(args, baseUrl + `api/users/${data.userId}/` + departments)
      .then((res: any) => {
        onSuccess?.(res?.data);
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        const errorMessage =
          ERROR?.response?.data?.errorMessage || "Something went wrong";
        onFail?.(errorMessage);
        dispatch(setLoader(false));
      });
  };
};

export const consumeStock = (
  params: any,
  callBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(false));
    const args = params;
    new ApiConfig()
      .postJSON(args, baseUrl + consume + `?userId=${params.userId}`)
      .then((res: any) => {
        callBack(res?.data?.data);
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        errorCallBack();
        dispatch(setLoader(false));
      });
  };
};

export const requestConsumeStock = (
  params: any,
  callBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(false));
    const args = params;
    console.log(JSON.stringify(args), params.userId);
    new ApiConfig()
      .postJSON(args, baseUrl + request_consume + `?userId=${params.userId}`)
      .then((res: any) => {
        callBack(res?.data?.data);
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        errorCallBack(ERROR);
        dispatch(setLoader(false));
      });
  };
};
