import { ApiConfig } from "../../Service/Api";
import {
  baseUrl,
  get_notification_list,
  get_news_list,
  get_messages_list,
  get_messages_count,
  get_notification_count,
  get_news_count,
  consumeReceiptDownloadUrl,
} from "../../Service/ApiConfig";

export const actionTypes = {
  GET_NOTIFICATION_LIST: "GET_NOTIFICATION_LIST",
  GET_NOTIFICATION_COUNT: "GET_NOTIFICATION_COUNT",
  PUT_NOTIFICATION_READ: "PUT_NOTIFICATION_READ",
  GET_MESSAGES_LIST: "GET_MESSAGES_LIST",
  GET_MESSAGES_COUNT: "GET_MESSAGES_COUNT",
  PUT_MESSAGES_READ: "PUT_MESSAGES_READ",
  GET_NEWS_LIST: "GET_NEWS_LIST",
  GET_NEWS_COUNT: "GET_NEWS_COUNT",
  SET_LOADER: "SET_LOADER",
  CLEAR_ALL_NOTIFICATION_DATA:'CLEAR_ALL_NOTIFICATION_DATA'
};

export const setLoader = (isLoader: boolean) => {
  return {
    type: actionTypes.SET_LOADER,
    value: isLoader,
  };
};
export const clearAllCommunicationCenterData = () => {
  return {
    type: actionTypes.CLEAR_ALL_NOTIFICATION_DATA,
    value: [],
  };
};

export const getNotificationList = (offset: number, data: any) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getParamsJSON(
        baseUrl +
          get_notification_list +
          `?limit=10&offset=${offset}&sortBy=id:desc`
      )
      .then((response: any) => {
        const parsedResp = JSON.parse(response)
        let dataset = data.concat(parsedResp?.data)
        dispatch({
          type: actionTypes.GET_NOTIFICATION_LIST,
          value: { data: dataset,totalCount:parsedResp?.totalCount },
        });
      })
      .finally(() => {
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const getNotificationCount = () => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getParamsJSON(baseUrl + get_notification_count)
      .then((response: any) => {
        dispatch({
          type: actionTypes.GET_NOTIFICATION_COUNT,
          value: JSON.parse(response),
        });
      })
      .finally(() => {
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};


export const downloadConsumeReceipt = (transactionID:string,callBack: any,errorCallBack:any) => {
  return async (dispatch: any) => {
    new ApiConfig()
      .postJSON({},consumeReceiptDownloadUrl + transactionID)
      .then((response: any) => {
        callBack(response?.data?.data?.consumePdfData ?? '')
      })
      .catch((ERROR) => {
        errorCallBack(ERROR)
      });
  };
};

export const getMessageList = (offset: number, data: any) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getParamsJSON(
        baseUrl +
          get_messages_list +
          `?limit=10&offset=${offset}&sortBy=id:desc`
      )
      .then((response: any) => {
        const parsedResp = JSON.parse(response)
        let dataset = data.concat(parsedResp?.data)
        dispatch({
          type: actionTypes.GET_MESSAGES_LIST,
          value: { data: dataset,totalCount:parsedResp?.totalCount },
        });
      })
      .finally(() => {
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const getMessagesCount = () => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getParamsJSON(baseUrl + get_messages_count)
      .then((response: any) => {
        dispatch({
          type: actionTypes.GET_MESSAGES_COUNT,
          value: JSON.parse(response),
        });
      })
      .finally(() => {
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const getNewsList = (offset: number, data: any) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getParamsJSON(
        baseUrl +
          get_news_list +
          `?limit=10&offset=${offset}&sortBy=createdDate:desc`
      )
      .then((response: any) => {
        const parsedResp = JSON.parse(response)
        let dataset = data.concat(parsedResp?.data);
        dispatch({
          type: actionTypes.GET_NEWS_LIST,
          value: { data: dataset,totalCount:parsedResp?.totalCount },
        });
      })
      .finally(() => {
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const getNewsCount = () => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getParamsJSON(baseUrl + get_news_count)
      .then((response: any) => {
        dispatch({
          type: actionTypes.GET_NEWS_COUNT,
          value: JSON.parse(response),
        });
      })
      .finally(() => {
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const putNotificationRead = (id: number, callBack:any) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .putJSON(
        { markedAsRead: true },
        baseUrl + get_notification_list + `/${id}`
      )
      .then((response: any) => {
        callBack(true)
      })
      .finally(() => {
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        callBack(false)
        dispatch(setLoader(false));
      });
  };
};

export const putMessagesRead = (id: number,callBack:any) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .putJSON(
        { id: id, action: "MARK_AS_READ" },
        baseUrl + get_messages_list + `/${id}`
      )
      .then((response: any) => {
        callBack(true)
      })
      .finally(() => {
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        callBack(false)
        dispatch(setLoader(false));
      });
  };
};

export const putNewsRead = (id: number,callBack:any) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .putJSON(
        { },
      baseUrl + get_news_list + `/${id}`)
      .then((response: any) => {
        callBack(true)
      })
      .finally(() => {
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        console.log('putNewsRead ERROR',ERROR)
        callBack(false)
        dispatch(setLoader(false));
      });
  };
};
