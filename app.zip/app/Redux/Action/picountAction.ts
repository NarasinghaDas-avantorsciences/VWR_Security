import {
  baseUrl,
  pi_count,
  get_pi_count_locations,
} from "../../Service/ApiConfig";
import { ApiConfig } from "../../Service/Api";
import { batch, useSelector } from "react-redux";

export const actionTypes = {
  SET_SELECTED_PI_COUNT: "SET_SELECTED_PI_COUNT",
  SET_PI_COUNT_LIST: "SET_PI_COUNT_LIST",
  SET_PI_LIST_COUNT: "SET_PI_LIST_COUNT",
  UPDATE_PI_PENDING_PRODUCT_LIST: "UPDATE_PI_PENDING_PRODUCT_LIST",
  UPDATE_PI_CONFIRM_PRODUCT_LIST: "UPDATE_PI_CONFIRM_PRODUCT_LIST",
  SET_PI_PENDING_PRODUCT_LIST: "SET_PI_PENDING_PRODUCT_LIST",
  SET_PI_CONFIRMED_PRODUCT_LIST: "SET_PI_CONFIRMED_PRODUCT_LIST",
  RESET_PI_PENDING_PRODUCTS: "RESET_PI_PENDING_PRODUCTS",
  RESET_PI_CONFIRM_PRODUCTS: "RESET_PI_CONFIRM_PRODUCTS",
  SET_INITIAL_PI_PRODUCT_LIST: "SET_INITIAL_PI_PRODUCT_LIST",
  SET_PI_COUNT_LOCATIONS: "SET_PI_COUNT_LOCATIONS",
  SET_PI_COUNT_PPRODUCT_BATCHES: "SET_PI_COUNT_PPRODUCT_BATCHES",
  SET_LOADER: "SET_LOADER",
};

export const setSelectedPICount = (picount: any) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_SELECTED_PI_COUNT,
      data: picount,
    });
  };
};
export const resetAllPIPendingProducts = () => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.RESET_PI_PENDING_PRODUCTS,
      // data: picount,
    });
  };
};
export const resetAllPIConfirmProducts = () => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.RESET_PI_CONFIRM_PRODUCTS,
      // data: picount,
    });
  };
};

export const setUpdatedPendingProducts = (data: any) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.UPDATE_PI_PENDING_PRODUCT_LIST,
      data: data,
    });
  };
};
export const setUpdatedConfirmProducts = (data: any) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.UPDATE_PI_CONFIRM_PRODUCT_LIST,
      data: data,
    });
  };
};

export const setLoader = (isLoader: boolean) => {
  return {
    type: actionTypes.SET_LOADER,
    value: isLoader,
  };
};

export const createNewPICount = (
  params: any,
  callBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(false));
    const args = params;
    new ApiConfig()
      .postJSON(args, baseUrl + pi_count)
      .then((res: any) => {
        callBack(res);
        dispatch(getPICountList());
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        errorCallBack(ERROR);
        dispatch(setLoader(false));
      });
  };
};

export const startPICount = (
  params: any,
  callBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    const args = params;
    dispatch(setLoader(true));

    new ApiConfig()
      .postJSON(args, baseUrl + `${pi_count}/${params.selectedPICountId}/start`)
      .then((res: any) => {
        callBack(res.status);
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));

        errorCallBack(ERROR);
      });
  };
};

export const savePICount = (params: any, callBack: any, errorCallBack: any) => {
  return async (dispatch: any) => {
    const args = params;
    new ApiConfig()
      .postJSON(args, baseUrl + `${pi_count}/${params.selectedPICountId}/save`)
      .then((res: any) => {
        // dispatch(getPICountList());
        callBack(res.data);
      })
      .catch((ERROR) => {
        errorCallBack(ERROR);
      });
  };
};

export const completePICount = (
  params: any,
  callBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(false));
    const args = params;
    new ApiConfig()
      .postJSON(
        args,
        baseUrl + `${pi_count}/${params.selectedPICountId}/complete`
      )
      .then((res: any) => {
        callBack(res.status);
      })
      .catch((ERROR) => {
        errorCallBack(ERROR);
      });
  };
};

export const getPICountList = () => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(baseUrl + pi_count)
      .then((res: any) => {
        res?.data?.map((item) => {
          item.isSelected = false;
        });
        dispatch({
          type: actionTypes.SET_PI_COUNT_LIST,
          data: res?.data,
        });

        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const getPIProductsList = (params) => {
  return async (dispatch: any) => {
    if (params?.piCountId) {
      dispatch(setLoader(true));
      if (params?.pageSize == 10) {
        dispatch({
          type: actionTypes.SET_PI_PENDING_PRODUCT_LIST,
          data: null,
        });
        dispatch({
          type: actionTypes.SET_PI_CONFIRMED_PRODUCT_LIST,
          data: null,
        });
      }
      new ApiConfig()
        .getJSON(
          baseUrl +
            `${pi_count}/${params?.piCountId}/products?limit=${params?.pageSize}&offset=0&product.status=online`
        )
        .then(async (res: any) => {
          let pendingProducts = [];
          let confirmedProducts = [];
          res?.data?.data?.map((item) => {
            item.isSelected = true;
            if (!!item.reasonCode) {
              item.reasonCode = {
                code: item.reasonCode.reasonCode,
                id: item.reasonCode.id,
              };
              confirmedProducts.push(item);
            } else {
              if (
                params.selectedReasonCode.code &&
                params.selectedReasonCode.id
              ) {
                item.reasonCode = {
                  code: params.selectedReasonCode.code,
                  id: params.selectedReasonCode.id,
                };
              }
              if (params.isAllSelected) {
                item.isSelected = true;
              }
              pendingProducts.push(item);
            }
            if (
              item.batchProducts?.length
              // && params.selectedIndex == 1
              // filter batches on both tabs as per final comment
            ) {
              let batches = item?.batchProducts?.filter((i: any) => {
                return params.selectedIndex == 1 //Pending Tab
                  ? parseInt(i?.availableQty) > 0
                  : parseInt(i?.availableQty) > 0 && i?.actualQty != null; //Confirm Tab
              });
              item.batchProducts = batches;
            }
          });

          let filteredPendingProduct = pendingProducts.filter(
            (item: any) => item.product?.status == "online"
          );

          let filteredconfirmedProduct = confirmedProducts.filter(
            (item: any) => item.product?.status == "online"
          );

          let limit = -10;
          if (params?.pageSize && params?.total)
            limit =
              params?.pageSize > params?.total
                ? -(parseInt(params.total) % parseInt(params?.limit)) //get the reminder
                : -params.limit;
          const last10PProducts = filteredPendingProduct.slice(limit); // To implement the pagination
          const last10CProducts = filteredconfirmedProduct.slice(limit); // To implement the pagination

          dispatch({
            type: actionTypes.SET_PI_LIST_COUNT,
            data: res?.data?.totalCount,
          });
          if (!!pendingProducts?.length && !!last10PProducts) {
            dispatch({
              type: actionTypes.SET_PI_PENDING_PRODUCT_LIST,
              data: last10PProducts,
            });
          } else {
            setUpdatedPendingProducts(null);
          }
          if (confirmedProducts?.length && !!last10CProducts) {
            dispatch({
              type: actionTypes.SET_PI_CONFIRMED_PRODUCT_LIST,
              data: last10CProducts,
            });
          } else {
            setUpdatedConfirmProducts(null);
          }
          await dispatch(setLoader(false));
        })
        .catch((ERROR) => {
          dispatch(setLoader(false));
        });
    }
  };
};
export const getPiCountLocations = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_pi_count_locations)
      .then((res: any) => {
        dispatch(setLoader(false));
        res?.data?.data?.map((item) => {
          item.isSelected = false;
        });
        dispatch({
          type: actionTypes.SET_PI_COUNT_LOCATIONS,
          data: res?.data?.data,
        });
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};
