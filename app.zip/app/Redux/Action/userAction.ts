import { ApiConfig } from "../../Service/Api";
import {
  baseUrl,
  getOrgLevelCurrency,
  get_org,
  get_org_details,
  get_stockroom_detail,
  get_stockrooms,
  user_privileges,
} from "../../Service/ApiConfig";
import * as storage from "../../Service/AsyncStoreConfig";

export const actionTypes = {
  SET_LOADER: "SET_LOADER",
  SET_ORG: "SET_ORG",
  SET_STOCKROOMS: "SET_STOCKROOMS",
  SET_SELECTED_ORG_AND_STOCKROOM: "SET_SELECTED_ORG_AND_STOCKROOM",
  SET_USER_PRIVILAGE: "SET_USER_PRIVILAGE",
  SET_ORG_DETAILS: "SET_ORG_DETAILS",
  SET_ORG_LEVEL_CURRENCY: "SET_ORG_LEVEL_CURRENCY",
  STOCK_ROOM_DETAIL: "STOCK_ROOM_DETAIL",
  TITLE: "TITLE",
  SUBTITLE: "SUBTITLE",
  SETSELECTEDORG: "SETSELECTEDORG",
  SETSELECTEDROOMID: "SETSELECTEDROOMID",
  CLEARSELECTEDSTOCKORG: "CLEARSELECTEDSTOCKORG",
  SET_CONFIRMATION_ALERT_DETAILS: "SET_CONFIRMATION_ALERT_DETAILS",
};

export const setSelectedOrgId = (payload: any) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SETSELECTEDORG,
      value: payload,
    });
  };
};
export const setSelectedRoomId = (payload: any) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SETSELECTEDROOMID,
      value: payload,
    });
  };
};

export const clearOrgStockData = () => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.CLEARSELECTEDSTOCKORG,
    });
  };
};

export const setSelectedOrgandStockRoom = (payload: any) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_SELECTED_ORG_AND_STOCKROOM,
      value: payload,
    });
  };
};
export const getOrgDetails = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_org_details)
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_ORG_DETAILS,
          value: response?.data,
        });
      })
      .catch((ERROR) => {
        console.warn("ERROR in getOrgDetails", ERROR);
      });
  };
};

export const getOrgLevelCurrencyData = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + getOrgLevelCurrency)
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_ORG_LEVEL_CURRENCY,
          value: response?.data,
        });
      });
  };
};

export const getOrg = (internet: any) => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_org)
      .then(async (response: any) => {
        dispatch({
          type: actionTypes.SET_ORG,
          value: response?.data,
        });
        await storage.setItem("orgData", JSON.stringify(response?.data));
        dispatch(getStockrooms(internet));
      })
      .catch(async (ERROR) => {
        if (!internet) {
          dispatch(getStockrooms(internet));
          const data: any = await storage.getItem("orgData");
          dispatch({
            type: actionTypes.SET_ORG,
            value: JSON.parse(data),
          });
        }
      });
  };
};

export const getStockrooms = (internet: boolean) => {
  return async (dispatch: any) => {
    storage.getItem("org").then((res: any) => {
      let data = JSON.parse(res);
      data = data?.orgId;
      new ApiConfig()
        .getJSON(baseUrl + get_stockrooms + `${data}/stockrooms`)
        .then(async (response: any) => {
          dispatch({
            type: actionTypes.SET_STOCKROOMS,
            value: response?.data,
          });
          await storage.setItem("stockrooms", JSON.stringify(response?.data));
        })
        .catch(async (ERROR) => {
          if (!internet) {
            const data: any = await storage.getItem("stockrooms");
            dispatch({
              type: actionTypes.SET_STOCKROOMS,
              value: JSON.parse(data),
            });
          }
        });
    });
  };
};
export const getStockroomsnew = (id: number, callback: any) => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_stockrooms + `${id}/stockrooms`)
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_STOCKROOMS,
          value: response?.data,
        });
        callback(response?.data);
      })
      .catch((ERROR) => {
        callback(null);
      });
  };
};

export const getUserPrivilege = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + user_privileges)
      .then((response: any) => {
        dispatch({
          type: "SET_SPLASH",
          value: false,
        });
        dispatch({
          type: actionTypes.SET_USER_PRIVILAGE,
          value: response?.data,
        });
        storage.setItem("privilege", JSON.stringify(response?.data));
      })
      .catch(async (ERROR) => {
        const data = await storage.getItem("privilege");
        dispatch({
          type: actionTypes.SET_USER_PRIVILAGE,
          value: JSON.parse(data),
        });
        dispatch({
          type: "SET_SPLASH",
          value: false,
        });
      });
  };
};

export const getStockroomDetail = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_stockroom_detail)
      .then((response: any) => {
        // Added defaultSplHandlingMsg if there was not '0' for showing as defaultSplHandlingMsg in replensh checkOut screen
        let stckRmData = response?.data ?? null;
        stckRmData.defaultSplHandlingMsg =
          String(stckRmData.defaultSplHandlingMsg) != "0"
            ? stckRmData.defaultSplHandlingMsg + ",0"
            : stckRmData.defaultSplHandlingMsg;
        dispatch({
          type: actionTypes.STOCK_ROOM_DETAIL,
          value: stckRmData,
        });
      })
      .catch((ERROR) => {
        console.log("ERROR in getStockroom detail", ERROR);
      });
  };
};

export const setStockroomDetail = (params = {}) => {
  return async () => {
    new ApiConfig()
      .postJSON(params, baseUrl + "api/user/login")
      .then((response: any) => {
        //console.log('\nsetStockroomDetail---==----=\n',response)
      })
      .catch((ERROR) => {
        console.log("ERROR in nsetStockroomDetail detail", ERROR);
      });
  };
};

export const setIsShowConfirmationAlert = (data: any) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_CONFIRMATION_ALERT_DETAILS,
      value: data,
    });
  };
};
