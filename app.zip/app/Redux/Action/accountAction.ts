import { ApiConfig } from "../../Service/Api";
import { baseUrl, get_account } from "../../Service/ApiConfig";
import AsyncStorage from "@react-native-async-storage/async-storage";

export const actionTypes = {
  SET_ACCOUNT_DATA: "SET_ACCOUNT_DATA",
  CLEAR_ACCOUNT_DATA: "CLEAR_ACCOUNT_DATA",
  SET_LOADER: "SET_LOADER",
  TERMS_AGREED: "TERMS_AGREED",
};

export const clearAccountData = () => {
  return {
    type: actionTypes.CLEAR_ACCOUNT_DATA,
    data: null,
  };
};

export const showTermsAgreedPage = (agreed: boolean) => {
  return {
    type: actionTypes.TERMS_AGREED,
    data: agreed,
  };
};

export const setLoader = (isLoader: boolean) => {
  return {
    type: actionTypes.SET_LOADER,
    value: isLoader,
  };
};

export const getAccountDetails = (callBack: any = null) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(baseUrl + get_account)
      .then((res: any) => {
        dispatch({
          type: actionTypes.SET_ACCOUNT_DATA,
          data: res?.data,
        });
        let result = res?.data;
        let userID = result?.id;
        if (callBack) {
          AsyncStorage.setItem("userAsyncData", JSON.stringify(res?.data));
          callBack(res?.data);
        }
        AsyncStorage.setItem("userID", userID ?? "");
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
        if (callBack) {
          callBack(ERROR);
        }
      });
  };
};
