import { ApiConfig } from "../../Service/Api";
import {
  baseUrl,
  batchProducts,
  get_productDetails,
  get_productList,
  stockRoomLocations,
  stockTransfer,
} from "../../Service/ApiConfig";
import * as storage from "../../Service/AsyncStoreConfig";

export const actionTypes = {
  SET_STOCKTRANSFER_LOADER: "SET_STOCKTRANSFER_LOADER",
  SET_STOCKTRANSFER_DATA: "SET_STOCKTRANSFER_DATA",
};
export const getDataList = (stockRoom, url) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_STOCKTRANSFER_LOADER,
      value: true,
    });
    const org: any = await storage.getItem("org");
    const header = JSON.stringify({
      orgId: JSON.parse(org)?.orgId,
      stockroomId: stockRoom,
    });
    return new ApiConfig()
      .getProductJSON(header, baseUrl + `${get_productList}${url}`)
      .then((response: any) => {
        console.log("res------", response?.data?.totalCount);
        dispatch({
          type: actionTypes.SET_STOCKTRANSFER_DATA,
          data: response?.data,
        });
      })
      .catch((ERROR) => {
        dispatch({
          type: actionTypes.SET_STOCKTRANSFER_LOADER,
          value: false,
        });
      });
  };
};
export const getLocation = (stockRoom, callBack) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_STOCKTRANSFER_LOADER,
      value: true,
    });
    const org: any = await storage.getItem("org");
    const header = JSON.stringify({
      orgId: JSON.parse(org)?.orgId,
      stockroomId: stockRoom,
    });

    return new ApiConfig()
      .getProductJSON(header, baseUrl + stockRoomLocations)
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_STOCKTRANSFER_LOADER,
          value: false,
        });
        callBack(response?.data);
      })
      .catch((ERROR) => {
        dispatch({
          type: actionTypes.SET_STOCKTRANSFER_LOADER,
          value: false,
        });
      });
  };
};

export const onstockTransfer = (
  parms: any,
  callBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_STOCKTRANSFER_LOADER,
      value: true,
    });
    return new ApiConfig()
      .postJSON(parms, baseUrl + stockTransfer)
      .then((response: any) => {
        callBack(response?.data);
        dispatch({
          type: actionTypes.SET_STOCKTRANSFER_LOADER,
          value: false,
        });
      })
      .catch((ERROR) => {
        console.log("ERROR in onstockTransfer ", ERROR?.response?.data);
        errorCallBack(ERROR?.response?.data);
        dispatch({
          type: actionTypes.SET_STOCKTRANSFER_LOADER,
          value: false,
        });
      });
  };
};

export const getBatches = (id, callBack) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_STOCKTRANSFER_LOADER,
      value: true,
    });

    return new ApiConfig()
      .getJSON(baseUrl + `${get_productList}/${id}/${batchProducts}`)
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_STOCKTRANSFER_LOADER,
          value: false,
        });
        callBack(response?.data);
      })
      .catch((ERROR) => {
        dispatch({
          type: actionTypes.SET_STOCKTRANSFER_LOADER,
          value: false,
        });
      });
  };
};
