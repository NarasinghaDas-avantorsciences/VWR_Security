import { ApiConfig } from "../../Service/Api";
import {
  baseUrl,
  get_productDetails,
  get_productList,
} from "../../Service/ApiConfig";
import * as storage from "../../Service/AsyncStoreConfig";

export const actionTypes = {
  SET_SEARCH_DATA: "SET_SEARCH_DATA",
  SET_PRODUCT_DETAILS: "SET_PRODUCT_DETAILS",
  SET_PRODUCT_DETAILS_LOADER: "SET_PRODUCT_DETAILS_LOADER",
  SET_PRODUCT_BATCH_DETAILS_LOADER: "SET_PRODUCT_BATCH_DETAILS_LOADER",
  EMPTY_SEARCH_LIST: "EMPTY_SEARCH_LIST",
};
export const getProductList = (keyword: string, pageSize?: any) => {
  return async (dispatch: any) => {
    dispatch(setProductLoader(true));
    dispatch({
      type: actionTypes.SET_SEARCH_DATA,
      value: [],
      loader: true,
    });
    const org: any = await storage.getItem("org");

    return new ApiConfig()
      .getParamsJSON(
        baseUrl +
          get_productList +
          `?sortBy=id:asc&limit=${
            pageSize ? pageSize : 10
          }&offset=0&stockroomIds=${
            JSON.parse(org)?.stockroomId
          }&catalogNo=&keyword=${keyword}`
      )
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_SEARCH_DATA,
          value: JSON.parse(response),
          loader: false,
        });
        console.log(JSON.stringify(response));
        dispatch(setProductLoader(false));
      })
      .catch((err) => {
        dispatch({
          type: actionTypes.SET_SEARCH_DATA,
          value: [],
          loader: false,
        });
        dispatch(setProductLoader(false));
      });
  };
};

export const getProductListFromBarcode = (
  keyword: string,
  pageSize?: any,
  successCallBack?: any,
  errorCallBack?: any
) => {
  return async (dispatch: any) => {
    dispatch(setProductLoader(true));
    dispatch({
      type: actionTypes.SET_SEARCH_DATA,
      value: [],
      loader: true,
    });
    const org: any = await storage.getItem("org");

    return new ApiConfig()
      .getParamsJSON(
        baseUrl +
          get_productList +
          `?sortBy=id:asc&limit=${
            pageSize ? pageSize : 10
          }&offset=0&stockroomIds=${
            JSON.parse(org)?.stockroomId
          }&catalogNo=&keyword=${keyword}`
      )
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_SEARCH_DATA,
          value: JSON.parse(response),
          loader: false,
        });
        successCallBack(JSON.parse(response));
        dispatch(setProductLoader(false));
      })
      .catch((err) => {
        errorCallBack(err);
        dispatch({
          type: actionTypes.SET_SEARCH_DATA,
          value: [],
          loader: false,
        });
        dispatch(setProductLoader(false));
      });
  };
};

export const emptyProductData = () => {
  return {
    type: actionTypes.EMPTY_SEARCH_LIST,
    value: [],
  };
};

export const setSearchData = (data: any) => {
  return {
    type: actionTypes.SET_SEARCH_DATA,
    data: data,
  };
};

export const setProductLoader = (isLoader: boolean) => {
  return {
    type: actionTypes.SET_PRODUCT_DETAILS_LOADER,
    value: isLoader,
  };
};

export const setProductBatchLoader = (isLoader: boolean) => {
  return {
    type: actionTypes.SET_PRODUCT_BATCH_DETAILS_LOADER,
    value: isLoader,
  };
};

export const getProductDetails = (productId: string) => {
  return async (dispatch: any) => {
    dispatch(setProductLoader(true));
    return new ApiConfig()
      .getJSON(baseUrl + get_productDetails + `${productId}`)
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_PRODUCT_DETAILS,
          value: response?.data?.data,
        });
      })
      .catch((ERROR) => {});
  };
};

export const getOfflineProducts = (
  keyword: string,
  successCallBack?: any,
  errorCallBack?: any
) => {
  return async (dispatch: any) => {
    dispatch(setProductLoader(true));
    dispatch({
      type: actionTypes.SET_SEARCH_DATA,
      value: [],
    });
    const org: any = await storage.getItem("org");

    return new ApiConfig()
      .getJSONWithAuth(
        baseUrl +
          get_productList +
          `?sortBy=id:asc&limit=${10}&offset=0&stockroomIds=${
            JSON.parse(org)?.stockroomId
          }&catalogNo=&keyword=${keyword}`
      )
      .then((response: any) => {
        // let responseObj: any = JSON.parse(response)
        let filteredData = response.data?.data?.filter(
          (item: any) => item.status == "online"
        );
        dispatch(setProductLoader(false));
        successCallBack(filteredData);
      })
      .catch((ERROR) => {
        dispatch(setProductLoader(false));
        errorCallBack(ERROR);
      });
  };
};

export const getProductBatchDetails = (
  productId: string,
  successCallBack: any,
  errorCallBack: Function
) => {
  return async (dispatch: any) => {
    dispatch(setProductLoader(true));
    return new ApiConfig()
      .getJSON(baseUrl + get_productDetails + `${productId}` + "/batchProducts")
      .then((response: any) => {
        successCallBack(response?.data.data ?? []);
        dispatch(setProductLoader(false));
      })
      .catch((ERROR) => {
        errorCallBack(ERROR?.response?.data);
        dispatch(setProductLoader(false));
      });
  };
};
