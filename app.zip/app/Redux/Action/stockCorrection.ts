import { ApiConfig } from "../../Service/Api";
import { addReasonCode, baseUrl, reasonCode } from "../../Service/ApiConfig";
import { filterReasonCodeData } from "../../Utils/globalFunction";

export const actionTypes = {
  SET_REASONCODE: "SET_REASONCODE",
  SET_REASON: "SET_REASON",
  SET_CORRECT_STOCK_LIST: "SET_CORRECT_STOCK_LIST",
  SET_SELECTED_STOCK: "SET_SELECTED_STOCK",
};

export const setSelectedStock = (value: any) => {
  return {
    type: actionTypes.SET_SELECTED_STOCK,
    data: value,
  };
};

export const setCorrectStockList = (value: any) => {
  return {
    type: actionTypes.SET_CORRECT_STOCK_LIST,
    data: value,
  };
};

export const setReason = (value: any) => {
  return {
    type: actionTypes.SET_REASON,
    data: value,
  };
};

export const getReasonCode = (param: any, stockroomType: string) => {
  return async (dispatch: any) => {
    let url =
      baseUrl +
      (!param.codeType
        ? reasonCode
        : param.codeType == "receive.stock"
        ? addReasonCode
        : reasonCode) +
      `?codeType=${param.codeType}`;

    new ApiConfig()
      .getJSON(url)
      .then((res: any) => {
        dispatch({
          type: actionTypes.SET_REASONCODE,
          data:
            param.codeType == "receive.stock"
              ? filterReasonCodeData(res?.data?.data, stockroomType)
              : filterReasonCodeData(res?.data, stockroomType),
        });
      })
      .catch((ERROR) => {
        console.log("ERROR in getReasonCode", ERROR);
      });
  };
};

export const setReasonCode = (
  data: any,
  successCallBack: any,
  errorCallBack?: any,
  stockRoomDetail?: any
) => {
  return async (dispatch: any) => {
    new ApiConfig()
      .postJSON(data, baseUrl + addReasonCode)
      .then((res: any) => {
        dispatch(
          getReasonCode(
            {
              codeType:
                data?.codeType !== undefined
                  ? data?.codeType
                  : data[0]?.codeType,
            },
            stockRoomDetail?.stockroomType
          )
        );
        successCallBack(res?.data);
      })
      .catch((ERROR) => {
        errorCallBack(ERROR?.response?.data);
      });
  };
};
