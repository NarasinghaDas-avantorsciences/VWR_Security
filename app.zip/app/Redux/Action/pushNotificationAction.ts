import { ApiConfig } from "../../Service/Api";
import { useSelector } from "react-redux";
import {
  baseUrl,
  set_push_notification_url,
  set_push_notification_logout_url,
} from "../../Service/ApiConfig";
import { getAccountDetails } from "./accountAction";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { requestUserPermission } from "../../Service/PushNotificationServiceHandler";
//const profileData = useSelector((state: any) => state.accountReducer?.data);

export const pushNotificationAction = (
  userId: string,
  approvalEnabled: boolean,
  runningLowEnabled: boolean,
  outOfStockEnabled: boolean,
  notificationEnabled: boolean,
  callBack: any
) => {
  return async (dispatch: any) => {
    await requestUserPermission(async (val: boolean) => {
      if (!val){
        callBack(false);
        return
      }
      let fcmToken: any = await AsyncStorage.getItem("fcmToken");
      console.log("fcmToken token ", fcmToken);
      if (fcmToken != null) {
        let param = getPusNotificationParam(
          userId,
          getBoolString(approvalEnabled),
          getBoolString(runningLowEnabled),
          getBoolString(outOfStockEnabled),
          getBoolString(notificationEnabled),
          fcmToken,
          false
        );
        new ApiConfig()
          .postJSON(param, baseUrl + set_push_notification_url)
          .then((res: any) => {
            //console.log("pushNotificationAction -- res--- ", res.data);
            callBack(true);
          })
          .catch((ERROR) => {
            callBack(false);
          });
      } else {
        callBack(false);
        //console.log("skip pushNotificationAction  ");
      }
    });
  };
};
export const pushNotificationLogOutAction = () => {
  return async (dispatch: any) => {
    let fcmToken: any = await AsyncStorage.getItem("fcmToken"); //'userID'
    let userId = (await AsyncStorage.getItem("userID")) ?? "";
    if (fcmToken != null) {
      let param = getPusNotificationParam(userId, "Y", "Y", "Y", "Y", fcmToken,true);
      new ApiConfig()
        .postJSON(param, baseUrl + set_push_notification_logout_url)
        .then((res: any) => {
          //console.log("pushNotificationLogOutAction=========", res.data);
        })
        .catch((ERROR) => {
          //console.log("pushNotificationLogOutAction=========", ERROR);
        });
    } else {
      console.log("skip pushNotificationLogOutAction  ");
    }

    //remove all notificaiton related keys from DB
    //await AsyncStorage.removeItem("show_notification_modal")
    await AsyncStorage.removeItem("out_of_stock_notification_enabled")
    await AsyncStorage.removeItem("approvals_notification_enabled")
    await AsyncStorage.removeItem("running_low_notification_enabled")
    await AsyncStorage.removeItem("fcmToken")
    await AsyncStorage.removeItem("userID")
  };
};
function getBoolString(value: boolean) {
  return value ? "Y" : "N";
}
function getPusNotificationParam(
  userId: string,
  approvalEnabled: string,
  runningLowEnabled: string,
  outOfStockEnabled: string,
  notificationEnabled: string,
  fcmToken: any,
  isLogout:boolean,
) {
  let param = {
    'userId': userId,
    'deviceToken': fcmToken,
    'isDeleted': "N",
    'mobileNotificationSetting': {
      'userId': userId,
      'approvalEnabled': approvalEnabled,
      'runningLowEnabled': runningLowEnabled,
      'outOfStockEnabled': outOfStockEnabled,
      'notificationEnabled': notificationEnabled,
      'isDeleted': "N",
    },
  };
  return (isLogout) ? param : {...param,...{settingId:''}}
}
