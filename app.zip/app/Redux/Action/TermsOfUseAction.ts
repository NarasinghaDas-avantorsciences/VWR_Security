import { ApiConfig } from "../../Service/Api";
import { baseUrl, get_terms_of_use , set_license_agreed} from "../../Service/ApiConfig";
import { getAccountDetails } from "./accountAction";

export const actionTypes = {
    GET_TERMS: "GET_TERMS",
};

export const getTermsOfUse = (successCallBack: any,
  errorCallBack: Function) => {
    new ApiConfig().setOrgAsNil()
    return async (dispatch: any) =>  {
        new ApiConfig()
          .getJSONWithAuth(baseUrl + get_terms_of_use)
          .then((res: any) => {
            //console.log ("getTermsOfUse=========",res.data);
            successCallBack(res.data)
          })
          .catch((ERROR) => {
            errorCallBack(ERROR?.response?.data);
          });
      }
}

export const setAcceptDeclineTerms = (hasAgreed:boolean,successCallBack: any,
  errorCallBack: Function) => {
    new ApiConfig().setOrgAsNil()
    return async (dispatch: any) =>  {
        new ApiConfig()
          .putJSON({licenseAgreed: hasAgreed},baseUrl + set_license_agreed)
          .then((res: any) => {
            dispatch(getAccountDetails())
            console.log ("setAcceptDeclineTerms=========", res.data.licenseAgreed);
            const data = res.data;
            successCallBack(data)
            
          })
          .catch((ERROR) => {
            errorCallBack(ERROR?.response?.data);
          });
      }
}