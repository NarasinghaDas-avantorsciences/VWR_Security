import * as storage from "../../Service/AsyncStoreConfig";
import { ApiConfig } from "../../Service/Api";
import { baseUrl, get_languages } from "../../Service/ApiConfig";
import { language } from "../../Utils/languageTemp";
export const actionTypes = {
  SET_LANGUAGE_DATA: "SET_LANGUAGE_DATA",
  SET_LANGUAGE_LIST: "SET_LANGUAGE_LIST",
  SET_LANGUAGE_LOADER: "SET_LANGUAGE_LOADER",
};

export const getLanguages = () => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_LANGUAGE_LOADER,
      value: true,
    });
    new ApiConfig()
      .getJSON(baseUrl + get_languages)
      .then(async (res: any) => {
        dispatch({
          type: actionTypes.SET_LANGUAGE_LIST,
          value: res?.data?.data,
        });
        dispatch(setLanguageData("EN_US/labels"));
        await storage.setItem("language", "EN_US/labels");
        await storage.setItem("languageList", JSON.stringify(res?.data?.data));
      })
      .catch((ERROR) => {
        dispatch({
          type: actionTypes.SET_LANGUAGE_DATA,
          value: language,
        });
        dispatch({
          type: actionTypes.SET_LANGUAGE_LOADER,
          value: false,
        });
      });
  };
};

export const getLanguagesFromDashboard = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + get_languages)
      .then(async (res: any) => {
        dispatch({
          type: actionTypes.SET_LANGUAGE_LIST,
          value: res?.data?.data,
        });
        dispatch(setLanguageData("EN_US/labels"));
        await storage.setItem("language", "EN_US/labels");
        await storage.setItem("languageList", JSON.stringify(res?.data?.data));
      })
      .catch((ERROR) => {
        dispatch({
          type: actionTypes.SET_LANGUAGE_DATA,
          value: language,
        });
      });
  };
};

export const setLanguageData = (url: string) => {
  return async (dispatch: any) => {
    dispatch({
      type: actionTypes.SET_LANGUAGE_LOADER,
      value: true,
    });
    new ApiConfig()
      .getJSON(baseUrl + get_languages + url)
      .then((res: any) => {
        dispatch({
          type: actionTypes.SET_LANGUAGE_DATA,
          value: res?.data,
        });
        storage.setItem("selectedLanguage", JSON.stringify(res?.data));
      })
      .catch(async (ERROR) => {
        const data = await storage.getItem("selectedLanguage");
        dispatch({
          type: actionTypes.SET_LANGUAGE_DATA,
          value: JSON.parse(data),
        });
        dispatch({
          type: actionTypes.SET_LANGUAGE_LOADER,
          value: false,
        });
      });
  };
};
