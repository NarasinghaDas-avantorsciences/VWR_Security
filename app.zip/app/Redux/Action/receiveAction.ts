import RNFetchBlob from "react-native-blob-util";
import { ApiConfig } from "../../Service/Api";
import {
  baseUrl,
  getReceiveKPIs,
  getReceiveList,
  printBarcodeTemplate,
  receiveOrderDetails,
  receiveOrderList,
  receiveValidate,
  setReceiveStock,
  setRejectStock,
} from "../../Service/ApiConfig";

const docPath = RNFetchBlob.fs.dirs.DocumentDir;

export const actionTypes = {
  GET_RECEIVE_KPIS: "GET_RECEIVE_KPIS",
  SET_RECEIVE_LIMIT_FLAG: "SET_RECEIVE_LIMIT_FLAG",
  RECEIVE_ALL_ORDER_LIST: "RECEIVE_ALL_ORDER_LIST",
  RECEIVE_ALL_READY_LIST: "RECEIVE_ALL_READY_LIST",
  RECEIVE_ALL_PARTIAL_LIST: "RECEIVE_ALL_PARTIAL_LIST",
  RECEIVE_ALL_PENDING_LIST: "RECEIVE_ALL_PENDING_LIST",
  SET_LOADER: "SET_LOADER",
  RECEIVE_ORDER_DETAILS: "RECEIVE_ORDER_DETAILS",
  RECEIVE_STOCK_EDIT: "RECEIVE_STOCK_EDIT",
  SET_UPDATED_ORDERLIST: "SET_UPDATED_ORDERLIST",
  RECEIVE_STOCK: "RECEIVE_STOCK",
  SET_RECEIVE_DETAILS_TITLE: "SET_RECEIVE_DETAILS_TITLE",
  SET_RECEIVE_SEARCH_DATA: "SET_RECEIVE_SEARCH_DATA",
  CLEAR_RECEIVE_SEARCH: "CLEAR_RECEIVE_SEARCH",
  PRINT_BARCODE_DATA: "PRINT_BARCODE_DATA",
  SET_RECEIVE_DETAILS_DELIVERY_NOTES_TEXT:
    "SET_RECEIVE_DETAILS_DELIVERY_NOTES_TEXT",
};

export const setLoader = (isLoader: boolean) => {
  return {
    type: actionTypes.SET_LOADER,
    data: isLoader,
  };
};

export const setReceiveLimtiFlag = (value: number) => {
  return {
    type: actionTypes.SET_RECEIVE_LIMIT_FLAG,
    data: value,
  };
};

export const getReceiveHeaderKPIs = () => {
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + getReceiveKPIs)
      .then((response: any) => {
        dispatch({
          type: actionTypes.GET_RECEIVE_KPIS,
          data: response?.data,
        });
      })
      .catch((ERROR) => {
        console.log("ERROR in getReceiveHeaderKPIs", ERROR);
      });
  };
};

export const receiveAllOrderList = (
  offset: number,
  searchKeyword?: string,
  errorCallBack?: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(
        baseUrl +
          receiveOrderList +
          `?limit=10&offset=${
            searchKeyword ? 0 : offset * 10
          }&sortBy=createdOn:desc${
            searchKeyword ? "&internalOrderNo=" + searchKeyword : ""
          }`
      )
      .then((res: any) => {
        dispatch({
          type: actionTypes.RECEIVE_ALL_ORDER_LIST,
          data: { data: res?.data?.data, offset: searchKeyword ? 0 : offset },
        });
        dispatch(setLoader(false));
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const receiveReadyOrderList = (
  offset: number,
  searchKeyword?: string,
  errorCallBack?: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(
        baseUrl +
          receiveOrderList +
          `?limit=10&offset=${
            searchKeyword ? 0 : offset * 10
          }&sortBy=createdOn:desc&filter=readyToReceive${
            searchKeyword ? "&internalOrderNo=" + searchKeyword : ""
          }`
      )
      .then((res: any) => {
        dispatch({
          type: actionTypes.RECEIVE_ALL_READY_LIST,
          data: { data: res?.data?.data, offset: searchKeyword ? 0 : offset },
        });
        dispatch(setLoader(false));
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const receivePartialOrderList = (
  offset: number,
  searchKeyword?: string,
  errorCallBack?: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(
        baseUrl +
          receiveOrderList +
          `?limit=10&offset=${
            searchKeyword ? 0 : offset * 10
          }&sortBy=createdOn:desc&filter=partialReceive${
            searchKeyword ? "&internalOrderNo=" + searchKeyword : ""
          }`
      )
      .then((res: any) => {
        dispatch({
          type: actionTypes.RECEIVE_ALL_PARTIAL_LIST,
          data: { data: res?.data?.data, offset: searchKeyword ? 0 : offset },
        });
        dispatch(setLoader(false));
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const receivePendingOrderList = (
  offset: number,
  searchKeyword?: string,
  errorCallBack?: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(
        baseUrl +
          receiveOrderList +
          `?limit=10&offset=${
            searchKeyword ? 0 : offset * 10
          }&sortBy=createdOn:desc&filter=pendingDelivery${
            searchKeyword ? "&internalOrderNo=" + searchKeyword : ""
          }`
      )
      .then((res: any) => {
        dispatch({
          type: actionTypes.RECEIVE_ALL_PENDING_LIST,
          data: { data: res?.data?.data, offset: searchKeyword ? 0 : offset },
        });
        dispatch(setLoader(false));
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const setReceiveDetailsTitle = (title: string) => {
  return {
    type: actionTypes.SET_RECEIVE_DETAILS_TITLE,
    data: title,
  };
};

export const setReceiveDetailsDeliveryNotesText = (deliveryNoteTxt: string) => {
  return {
    type: actionTypes.SET_RECEIVE_DETAILS_DELIVERY_NOTES_TEXT,
    data: deliveryNoteTxt,
  };
};

export const getReceiveOrderDetails = (
  orderItem: any,
  successCallBack: any,
  errorCallBack?: any
) => {
  //console.log('orderItem:',orderItem)
  return async (dispatch: any) => {
    /*
"userDeliveryNotes": {
        "id": "738",
        "modifiedBy": "null",
        "createdBy": "null",
        "modifiedDate": null,
        "createdDate": null,
        "deliveryNote": "Testy"
    }
*/
    dispatch(
      setReceiveDetailsTitle(
        (orderItem?.editedVwrOrderNo ?? "").trim().length > 0
          ? `${orderItem?.editedVwrOrderNo} - ${orderItem?.internalOrderNo}`
          : orderItem?.internalOrderNo
      )
    );
    dispatch(setLoader(true));
    new ApiConfig()
      .getJSON(baseUrl + receiveOrderDetails + `${orderItem?.id}/orderLines`)
      .then((res: any) => {
        let orderDetails = res?.data;
        let deliveryNoteTxt =
          orderDetails?.userDeliveryNotes?.deliveryNote ?? "";
        //userDeliveryNotes
        orderDetails.allOrderDetails?.forEach((item: any) => {
          item.selected = true;
        });
        orderDetails.deliveryList?.forEach((item: any) => {
          item.selected = true;
        });
        successCallBack(res);
        dispatch(setReceiveDetailsDeliveryNotesText(deliveryNoteTxt));
        dispatch({
          type: actionTypes.RECEIVE_ORDER_DETAILS,
          data: orderDetails,
        });
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const setRecieveOrderDetails = (value: any) => {
  return {
    type: actionTypes.RECEIVE_ORDER_DETAILS,
    data: value,
  };
};

export const receiveStock = (
  params: any,
  receivedOrders: string,
  successCallBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = params;
    new ApiConfig()
      .postJSON(args, baseUrl + receiveValidate)
      .then((res: any) => {
        if (res?.data?.status == "valid") {
          new ApiConfig()
            .postJSON(args, baseUrl + setReceiveStock)
            .then((setReceiveStockResult: any) => {
              dispatch(
                getReceiveStockOrderCurrentStatus(
                  receivedOrders,
                  setReceiveStockResult,
                  successCallBack
                )
              );
              dispatch({
                type: actionTypes.RECEIVE_STOCK,
                data: setReceiveStockResult?.data,
              });
              setTimeout(() => {
                dispatch(setLoader(false));
              }, 300);
            })
            .catch((err) => {
              errorCallBack(err.response);
              dispatch(setLoader(false));
            });
        } else {
          dispatch(setLoader(false));
        }
      })
      .catch((err) => {
        errorCallBack(err.response?.data);
        dispatch(setLoader(false));
      });
  };
};

export const getReceiveStockOrderCurrentStatus = (
  receivedOrders: string,
  setReceiveStockResult: any,
  successCallBack: any
) => {
  console.log("getReceiveStockOrderCurrentStatus");
  return async (dispatch: any) => {
    new ApiConfig()
      .getJSON(baseUrl + receiveOrderList + `/${receivedOrders}`)
      .then((response: any) => {
        dispatch(setLoader(false));
        successCallBack(
          setReceiveStockResult,
          response?.data?.receiveStatus ?? ""
        );
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
        successCallBack(setReceiveStockResult, "");
        console.log("ERROR in getReceiveStockOrderCurrentStatus", ERROR);
      });
  };
};

export const rejectStock = (
  params: any,
  successCallBack: any,
  errorCallBack: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = params;
    new ApiConfig()
      .postJSON(args, baseUrl + setRejectStock)
      .then((res: any) => {
        successCallBack(res);
        dispatch({
          type: actionTypes.RECEIVE_STOCK,
          data: res?.data,
        });
        dispatch(setLoader(false));
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const editConfirmationAndNote = (
  apiParams: any,
  orderId: string,
  successCallBack?: any,
  errorCallBack?: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = apiParams;
    new ApiConfig()
      .putJSON(args, baseUrl + receiveOrderDetails + `${orderId}`)
      .then((res: any) => {
        successCallBack(res);
        // if (res.status == 200 && res?.data?.status == null) {
        //   dispatch({
        //     type: actionTypes.RECEIVE_STOCK_EDIT,
        //     data: apiParams?.vwrOrderNumber + '+add+' + apiParams?.deliveryNoteTxt ?? '',
        //   });

        // }
        dispatch(setLoader(false));
      })
      .catch((err) => {
        console.log(err.response);
        errorCallBack(err.response.data);
        dispatch(setLoader(false));
      });
  };
};

export const setUpdatedOrderList = (orderListData: any) => {
  return {
    type: actionTypes.SET_UPDATED_ORDERLIST,
    data: orderListData,
  };
};

export const getReceiveSearchList = (keyword: string) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    new ApiConfig()
      .getParamsJSON(baseUrl + getReceiveList + `productCatalogNo=${keyword}`)
      .then((response: any) => {
        dispatch(setLoader(false));
      })
      .catch((err) => {
        dispatch(setLoader(false));
      });
  };
};

export const receivePrintBarcode = (
  params: any,
  successCallBack?: any,
  errorCallBack?: any
) => {
  return async (dispatch: any) => {
    dispatch(setLoader(true));
    const args = params;
    new ApiConfig()
      .postJSON(args, baseUrl + printBarcodeTemplate)
      .then((res: any) => {
        dispatch(setLoader(false));
        successCallBack(res);
      })
      .catch((err) => {
        errorCallBack(err.response);
        dispatch(setLoader(false));
      });
  };
};

export const getReceiveData = (
  offset: any,
  selectedIndex: number,
  keyword: string
) => {
  return async (dispatch: any) => {
    let filterkey =
      selectedIndex == 1
        ? ""
        : selectedIndex == 2
        ? "readyToReceive"
        : selectedIndex == 3
        ? "partialReceive"
        : selectedIndex == 4
        ? "pendingDelivery"
        : "";
    let searchUrl =
      filterkey == ""
        ? receiveOrderList +
          "?limit=10&offset=" +
          `${offset * 10}` +
          "&keyword=" +
          `${keyword}`
        : receiveOrderList +
          "?limit=10&offset=" +
          `${offset * 10}` +
          "&filter=" +
          `${filterkey}` +
          "&keyword=" +
          `${keyword}`;

    dispatch(setLoader(true));
    return new ApiConfig()
      .getJSON(baseUrl + searchUrl)
      .then((response: any) => {
        dispatch({
          type: actionTypes.SET_RECEIVE_SEARCH_DATA,
          data: response?.data,
        });
        dispatch(setLoader(false));
      })
      .catch((ERROR) => {
        dispatch(setLoader(false));
      });
  };
};

export const clearReceiveSearch = () => {
  return {
    type: actionTypes.CLEAR_RECEIVE_SEARCH,
  };
};
