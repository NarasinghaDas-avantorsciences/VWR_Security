import { Dimensions } from "react-native";
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from "react-native-responsive-screen";

const { width, height } = Dimensions.get("window");

export const COLORS = {
  black: "#1E1F20",
  transparentBlack: "rgba(0, 0, 0, 0.6)",
  white: "#FFFFFF",
  gray: "#6A6A6A",
  gray2: "#CCCCCC",
  gray3: "#F5F5F5",
  gray4: "#B8B8B8",
  darkGray: "#b1b3b3",
  blue: "#0682FE",
  grayLight: "#EBECF0",
  blackFast: "#0E0D10",
  red: "#AD2531",
  alto: "#E0E0E0",
  doveGray: "#666666",
  abbey: "#53565A",
  scienceBlue: "#0064C8",
  blueLight: "#C1E0FF",
  lightGray: "#8F8F8F",
  whiteSmoke: "#F5F5F5",
  partialBorder: "rgba(163, 103, 0, 0.3)",
  partial: "#FFECCC",
  maroon: "rgba(128, 0, 0, 0.3)",
  lightRed: "#FFE6E6",
  ginger: "#A36700",
  darRed: "#800000",
  aquaSpring: "#EAFAF1",
  seaGreen: "#219653",
  seaGreen_30: "rgba(33, 150, 83, 0.3)",
  aliceBlue: "#F0F8FF",
  green: "#00D649",
  toggle_green: "#35c659",
  transparentGreen: "#EAFAF1",
  yellow: "#A36700",
  transparentYellow: "#FFECCC",
  redFast: "#D80000",
  transparentRedFast: "#FFE5E6",
  mineShaft: "#2B2B2B",
  magenta: "#EC10D6",
  blackBright: "#000000",
  tuna36: "rgba(60, 60, 67, 0.36)",
  azureRadiance: "#007AFF",
  orange: "#fca105",
  chelseaGem3: "rgba(163, 103, 0, 0.3)",
  chelseaGem: "#A36700",
  sandyBeach: "#FFECCC",
};

export const FONTFAMILY = {
  averta_semibold: "Averta-Semibold",
  averta_bold: "Averta-Bold",
  averta_regular: "AvertaDemoPE-Regular",
};

export const FONTS = {
  h1: hp(1),
  h1_1: hp(1.1),
  h1_2: hp(1.2),
  h1_3: hp(1.3),
  h1_4: hp(1.4),
  h1_5: hp(1.5),
  h1_6: hp(1.6),
  h1_7: hp(1.7),
  h1_8: hp(1.8),
  h1_9: hp(1.9),
  h2: hp(2),
  h2_1: hp(2.1),
  h2_2: hp(2.2),
  h2_3: hp(2.3),
  h2_5: hp(2.5),
  h2_6: hp(2.6),
  h2_7: hp(2.7),
  h2_8: hp(2.8),
  h3: hp(3),
  h3_1: hp(3.1),
  h3_2: hp(3.2),
  h3_3: hp(3.3),
  h3_4: hp(3.4),
  h3_5: hp(3.5),
  h3_6: hp(3.6),
  h3_7: hp(3.7),
  h4: hp(4),
  h4_5: hp(4.5),
  h5: hp(5),
  h5_5: hp(5.5),

  heading: {
    fontSize: hp(2.4),
    fontFamily: FONTFAMILY.averta_bold,
    lineHeight: hp(2.4),
  },
  title: {
    fontSize: hp(2),
    fontFamily: FONTFAMILY.averta_semibold,
    lineHeight: hp(2.2),
  },
  title2: {
    fontSize: hp(1.6),
    fontFamily: FONTFAMILY.averta_semibold,
    lineHeight: hp(1.8),
  },
  body: {
    fontSize: hp(1.8),
    fontFamily: FONTFAMILY.averta_regular,
  },
  body2: {
    fontSize: hp(1.5),
    fontFamily: FONTFAMILY.averta_regular,
    lineHeight: hp(1.8),
  },
};

export const SIZES = {
  tip: wp(1),
  base: wp(2),
  radius: wp(3),
  padding: wp(5),
  height,
  width,
};

export const ICONSIZE = {
  h1: hp(1),
  h2: hp(2),
  h2_5: hp(5),
  h3: hp(3),
  h5: hp(5),
};

export const WEIGHT = {
  w_400: { fontWeight: "400" },
  bold: { fontWeight: "bold" },
  w_900: { fontWeight: "900" },
  w_700: { fontWeight: "700" },
};
