import {
  widthPercentageToDP,
  heightPercentageToDP,
} from "react-native-responsive-screen";
import { Alert, PermissionsAndroid, Platform } from "react-native";
import DeviceInfo from "react-native-device-info";
import { SIZES } from "./theme";
import moment from "moment";
import currencyToSymbolMap from "currency-symbol-map";

export const isDeviceTablet = () => {
  const aspectRatio = SIZES.height / SIZES.width;
  let istablet;
  if (Platform.OS === "ios") {
    istablet = aspectRatio < 1.6 ? true : false;
  } else {
    istablet = DeviceInfo.isTablet();
  }

  return istablet;
};

interface ObjectInterface {
  [key: string]: any;
}

export const checkRemainingQtyBool = (productItem: any) => {
  if (productItem?.remainingQuanityStr.includes("X")) {
    let qtyArr = productItem?.remainingQuanityStr
      .replace(/\s+/g, "")
      .split("X");

    if (Number(qtyArr[0]) == 0) {
      return false;
    } else {
      return true;
    }
  } else {
    if (Number(productItem?.remainingQuanityStr) == 0) {
      return false;
    } else {
      return true;
    }
  }
};

export const filterDataByName = (
  blockData: ObjectInterface[],
  property: string,
  key: any
) => {
  let filteredData =
    blockData &&
    blockData?.filter((item) =>
      item?.[property]?.toLowerCase().includes(key?.toLowerCase())
    );
  return filteredData;
};

export const filterByMultipleKeys = (
  blockData: ObjectInterface[],
  firstKey: string,
  secondKey: string,
  searchText: any
) => {
  let filteredData = null;
  if (blockData) {
    filteredData = blockData?.filter((element) => {
      return (
        element?.[firstKey]?.toLowerCase() +
        " " +
        element?.[secondKey]?.toLowerCase()
      ).includes(searchText?.toLowerCase());
    });
  }

  return filteredData;
};
export const filterByMultipleKeysBarcode = (
  blockData: ObjectInterface[],
  firstKey: string,
  secondKey: string,
  searchText: any
) => {
  let filteredData = null;
  if (blockData) {
    filteredData = blockData?.filter((element) => {
      if (
        element?.[firstKey]?.toLowerCase() == searchText?.toLowerCase() ||
        element?.[secondKey]?.toLowerCase() == searchText
      ) {
        return true;
      } else {
        return false;
      }
    });
  }

  return filteredData;
};

export const removeOfflineProduct = (item: any) => {
  if (item != null) {
    const filteredItem = item.filter((obj: any) => obj?.status != "offline");
    return filteredItem;
  }
  return [];
};

export const isProductFreezed = (item: any) => {
  return item?.freeze == true || item?.freezed == true;
};

export const isReceiveProductFreezed = (item: any) => {
  return (
    item?.freeze == true || (item?.status == "offline" && item?.isOneTime != 1)
  );
};

export const isReplenishProductFreezed = (item: any) => {
  if (item?.type == "ONETIME") {
    return false;
  }
  return item?.freeze == true || item?.status == "offline";
};

export const removeEmojis = (string: String) => {
  // emoji regex from the emoji-regex library
  const regex =
    /(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])/g;
  // /\uD83C\uDFF4(?:\uDB40\uDC67\uDB40\uDC62(?:\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73|\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74)\uDB40\uDC7F|\u200D\u2620\uFE0F)|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC68(?:\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83D\uDC68|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDB0-\uDDB3])|(?:\uD83C[\uDFFB-\uDFFF])\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDB0-\uDDB3]))|\uD83D\uDC69\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDB0-\uDDB3])|\uD83D\uDC69\u200D\uD83D\uDC66\u200D\uD83D\uDC66|(?:\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2695\u2696\u2708]|\uD83D\uDC68(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])|(?:(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)\uFE0F|\uD83D\uDC6F|\uD83E[\uDD3C\uDDDE\uDDDF])\u200D[\u2640\u2642]|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDD6-\uDDDD])(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|\u200D[\u2640\u2642])|\uD83D\uDC69\u200D[\u2695\u2696\u2708])\uFE0F|\uD83D\uDC69\u200D\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D[\uDC66\uDC67])|\uD83D\uDC68(?:\u200D(?:(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D[\uDC66\uDC67])|\uD83D[\uDC66\uDC67])|\uD83C[\uDFFB-\uDFFF])|\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08|\uD83D\uDC69\u200D\uD83D\uDC67|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDB0-\uDDB3])|\uD83D\uDC69\u200D\uD83D\uDC66|\uD83C\uDDF6\uD83C\uDDE6|\uD83C\uDDFD\uD83C\uDDF0|\uD83C\uDDF4\uD83C\uDDF2|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDED(?:\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA])|\uD83C\uDDEC(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE])|\uD83C\uDDEA(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA])|\uD83C\uDDE8(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF])|\uD83C\uDDF2(?:\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF])|\uD83C\uDDF3(?:\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF])|\uD83C\uDDFC(?:\uD83C[\uDDEB\uDDF8])|\uD83C\uDDFA(?:\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF])|\uD83C\uDDF0(?:\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF])|\uD83C\uDDEF(?:\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5])|\uD83C\uDDF8(?:\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF])|\uD83C\uDDEE(?:\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9])|\uD83C\uDDFF(?:\uD83C[\uDDE6\uDDF2\uDDFC])|\uD83C\uDDEB(?:\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7])|\uD83C\uDDF5(?:\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE])|\uD83C\uDDE9(?:\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF])|\uD83C\uDDF9(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF])|\uD83C\uDDE7(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF])|[#\*0-9]\uFE0F\u20E3|\uD83C\uDDF1(?:\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE])|\uD83C\uDDE6(?:\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF])|\uD83C\uDDF7(?:\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC])|\uD83C\uDDFB(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA])|\uD83C\uDDFE(?:\uD83C[\uDDEA\uDDF9])|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u270A-\u270D]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC70\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDCAA\uDD74\uDD7A\uDD90\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD36\uDDB5\uDDB6\uDDD1-\uDDD5])(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDEEB\uDEEC\uDEF4-\uDEF9]|\uD83E[\uDD10-\uDD3A\uDD3C-\uDD3E\uDD40-\uDD45\uDD47-\uDD70\uDD73-\uDD76\uDD7A\uDD7C-\uDDA2\uDDB0-\uDDB9\uDDC0-\uDDC2\uDDD0-\uDDFF])|(?:[#*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEF9]|\uD83E[\uDD10-\uDD3A\uDD3C-\uDD3E\uDD40-\uDD45\uDD47-\uDD70\uDD73-\uDD76\uDD7A\uDD7C-\uDDA2\uDDB0-\uDDB9\uDDC0-\uDDC2\uDDD0-\uDDFF])\uFE0F|(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC69\uDC6E\uDC70-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD18-\uDD1C\uDD1E\uDD1F\uDD26\uDD30-\uDD39\uDD3D\uDD3E\uDDB5\uDDB6\uDDB8\uDDB9\uDDD1-\uDDDD])/g;

  if (string != null) return string.replace(regex, "");
  else return "";
};

const hasUserPrivilegeName = (userPrivilege: any, name: string) => {
  const data = userPrivilege?.filter(
    (item: { name: string }) => item?.name === name
  );
  return data?.length ? true : false;
};

const checkStockCorrectionTransferPrivilege = (
  userPrivilege: any,
  type: string
) => {
  if (type == "stock.transfer.scanner") {
    return hasUserPrivilegeName(userPrivilege, type);
  } else if (
    (type == "show.scanner.PI.Count" || type == "stock.correction(scanner)") &&
    hasUserPrivilegeName(userPrivilege, "stock.correction.scanner")
  ) {
    return hasUserPrivilegeName(userPrivilege, type);
  } else {
    return false;
  }
};

const hasUserPrivilage = (userPrivilege: any, name: string) => {
  const data = userPrivilege?.filter(
    (item: { name: string }) => item?.name === name
  );

  if (data?.length != 0) {
    const typeData = userPrivilege?.filter(
      (item: { parentType: any }) => item?.parentType == data[0].type
    );
    return typeData?.length ? true : false;
  } else {
    return false;
  }
};

export const checkUserPrivileges = (userPrivilege: any, type: string) => {
  if (checkStockCorrectionTransferPrivilege(userPrivilege, type)) {
    return true;
  } else {
    return hasUserPrivilage(userPrivilege, type);
  }
};

export const checkUserPrevilageForApprovals = (
  userPrivilege: any,
  type: string
) => {
  if (type == "consume.request") {
    return checkUserPrevilageForApproval(
      userPrivilege,
      "approval.consume.requests.scanner"
    );
  } else if (type == "order.request") {
    return checkUserPrevilageForApproval(
      userPrivilege,
      "approval.orders.scanner"
    );
  } else if (type == "pou.order") {
    return checkUserPrevilageForApproval(
      userPrivilege,
      "approval.requests.scanner"
    );
  }

  return false;
};

const checkUserPrevilageForApproval = (userPrivilege: any, type: string) => {
  const data = userPrivilege?.filter(
    (item: { name: string }) => item?.name === "approval.scanner"
  );
  if (data?.length != 0) {
    const requestData = userPrivilege?.filter(
      (item: { name: string }) => item?.name === type
    );
    if (requestData?.length != 0) {
      if (requestData[0].parentType == data[0].type) {
        return true;
      }
    }
  }
  return false;
};

export const filterByThreeKeys = (
  blockData: ObjectInterface[],
  firstKey: string,
  secondKey: string,
  thirdKey: string,
  searchText: any
) => {
  let filteredData = null;
  if (blockData) {
    filteredData = blockData?.filter((element) => {
      return (
        element?.[firstKey]?.toLowerCase() +
        " " +
        element?.[secondKey]?.toLowerCase() +
        " " +
        element?.[thirdKey]?.toLowerCase()
      ).includes(searchText?.toLowerCase());
    });
  }

  return filteredData;
};

export const filterByFiveKeys = (
  blockData: ObjectInterface[],
  firstKey: string,
  secondKey: string,
  thirdKey: string,
  fourthKey: string,
  fifthKey: string,
  searchText: any
) => {
  let filteredData = null;
  if (blockData) {
    filteredData = blockData?.filter((element) => {
      return (
        element?.[firstKey]?.toLowerCase() +
        " " +
        element?.[secondKey]?.toLowerCase() +
        " " +
        element?.[thirdKey]?.toLowerCase() +
        " " +
        element?.[fourthKey]?.toLowerCase() +
        " " +
        element?.[fifthKey]?.toLowerCase()
      )
        .replace(/\s/g, "")
        .includes(searchText?.toLowerCase().replace(/\s/g, ""));
    });
  }

  return filteredData;
};

export const wp = (val: number) => widthPercentageToDP(val);
export const hp = (val: number) => heightPercentageToDP(val);

export const getConsumeReceipt = (
  data: any,
  organizationName: string,
  stockroomName: string,
  showPrice=false
) => {
  const {
    consumedProducts,
    costCenterName,
    departmentName,
    customerShipNo,
    soldTo,
    dateFormat,
    timeFormatString,
  } = data || {};
  const { transactionId, createdDate, locationName } = data.res[0] || {};

  const htmlContent = `<html>
<head>
  <meta 
    name="viewport" 
    content="width=device-width, initial-scale=0.7 maximum-scale=0.7, user-scalable=0"
  >
  <title>Receipt</title>
</head>
<body>
  <style>
    table {
      border-collapse: collapse;
      border: 1px solid #222222;
    }
    tr {
      border-bottom: 1px solid #222222;
    }
    th {
      background: #53555a;
      color: #fff;
      border-right: 1px solid #222222;
    }
    td {
      border-right: 1px solid #222222;
    }
    span {
      font-size: 10px;
    }
    table1 {
      border-collapse: collapse;
    }
    th1 {
      background: #53555a;
      color: #fff;
    }
    tr1 {
    }
  </style>
  <table style="table-layout: fixed; width: 160%; border:0px ">
    <tr style="border:0px ">
      <td style="width:50%; border:0px ">
        <p><strong><span style="font-family:Verdana,Geneva,sans-serif">${organizationName}</strong></p>
      </td>
      <td>
        <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Receipt</strong></p>
      </td>
    </tr>
    <tr style="border:0px ">
      <td style="width:50%; border:0px ">
        <p><strong><span style="font-family:Verdana,Geneva,sans-serif">${stockroomName}</strong></p>
      </td>
      <td>
        <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Transaction Id : ${
          transactionId || ""
        }</strong></p>
      </td>
    </tr>
    <tr style="border-bottom: 0px ">
      <td style="width:50%; border:0px ">
        <p><span style="font-family:Verdana,Geneva,sans-serif">Ship-To Number : ${
          customerShipNo || ""
        }</p>
      </td>
      <td>
        <p><span style="font-family:Verdana,Geneva,sans-serif">Date : ${
          moment(createdDate).format(
            `${dateFormat?.date} ${timeFormatString}`
          ) || ""
        }</p>
      </td>
    </tr>
    <tr style="border-bottom: 0px ">
      <td style="width:50%; border:0px ">
        <p><span style="font-family:Verdana,Geneva,sans-serif">Sold-To Number : ${soldTo}</p>
      </td>
    </tr>
  </table>
  <table
    border="1"
    cellpadding="1"
    cellspacing="1"
    class="fixed"
    style="table-layout: fixed; width: 100%; word-break: break-all;"
  >
    <thead>
      <tr>
        <th
          class="block"
          style="width: 35%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Product Catalog Number</span
              ></strong
            >
          </p>
        </th>
        <th
          class="block"
          style="width: 35%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Vendor Catalog Number</span
              ></strong
            >
          </p>
        </th>
         <th
          class="block"
          style="width: 35%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Customer Catalog Number</span
              ></strong
            >
          </p>
        </th>
        <th
          class="block"
          style="width: 40%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Description</span
              ></strong
            >
          </p>
        </th>
        <th
          class="block"
          style="width: 23%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Vendor</span
              ></strong
            >
          </p>
        </th>
        <th
          class="block"
          style="width: 23%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Cost Center</span
              ></strong
            >
          </p>
        </th>
        <th
          class="block"
          style="width: 23%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Department</span
              ></strong
            >
          </p>
        </th>
        <th
          class="block"
          style="width: 27%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Location</span
              ></strong
            >
          </p>
        </th>
        <th
          class="block"
          style="width: 40%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Available Quantity</span
              ></strong
            >
          </p>
        </th>
        <th
          class="block"
          style="width: 40%; vertical-align: top; text-align: left;"
        >
          <p>
            <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Consumed Quantity</span
              ></strong
            >
          </p>
        </th>
        ${
          showPrice ?
          `
            <th
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Price</span
                ></strong
              >
            </p>
          </th>
            
          </tr>
          `
          :""
        }
       
    </thead>
    <tbody>
      ${data?.res
        ?.map?.((element: any, index: number) => {
          return `
          <tr>
            <td
              class="block"
              style="width: 35%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${element?.productCatalogNo || ""}</span
              >
            </td>
            <td
              class="block"
              style="width: 35%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${element?.vendorCatalogNo || ""}</span
            >
            </td>
             <td
              class="block"
              style="width: 35%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${element?.customerCatalogNo || ""}</span
            >
            </td>
            <td
              class="block"
              style="width: 40%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${element?.productDescription || ""}</span
            >
            </td>
            <td
              class="block"
              style="width: 23%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${element?.vendor?.vendorName || ""}</span
            >
            </td>
            <td
              class="block"
              style="width: 23%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${costCenterName || ""}</span
            >
            </td>
            <td
              class="block"
              style="width: 23%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${departmentName || ""}</span
            >
            </td>
            <td
              class="block"
              style="width: 27%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${locationName || ""}</span
            </td>
            <td
              class="block"
              style="width: 40%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${element?.availableProductQty}</span
            </td>
            <td
              class="block"
              style="width: 40%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${element?.requestQuantity}</span
            </td>
            ${
              showPrice ?`
              <td
              class="block"
              style="width: 40%; vertical-align: top; text-align: left;"
            >
              <span style="font-family: Verdana, Geneva, sans-serif;"
                >${element?.product?.purchasePrice}</span
            </td>
              `:""
            }
         
          </tr>
         ${
           element?.requestBatch?.length
             ? ` <tr>
            <td colspan="11">
              <table
                border="1"
                cellpadding="1"
                cellspacing="1"
                class="fixed"
                style="
                  table-layout: fixed;
                  width: 75%;
                  word-break: break-all;
                  margin: auto 0 auto auto;
                "
              >
                <thead>
                  <tr style="">
                    <th class="block" style="width: 14%;">
                      <p>
                        <strong
                          ><span style="font-family: Verdana, Geneva, sans-serif;"
                            >Batch Number</span
                          ></strong
                        >
                      </p>
                    </th>
                    <th class="block" style="width: 13%;">
                      <p>
                        <strong
                          ><span style="font-family: Verdana, Geneva, sans-serif;"
                            >Expiry Date</span
                          ></strong
                        >
                      </p>
                    </th>
                    <th class="block" style="width: 13%;">
                      <p>
                        <strong
                          ><span style="font-family: Verdana, Geneva, sans-serif;"
                            >Available Qty</span
                          ></strong
                        >
                      </p>
                    </th>
                    <th class="block" style="width: 16%;">
                      <p>
                        <strong
                          ><span style="font-family: Verdana, Geneva, sans-serif;"
                            >Qty</span
                          ></strong
                        >
                      </p>
                    </th>
                  </tr>
                </thead>
                <tbody>
                ${element?.requestBatch
                  ?.map((b: any, i: any) => {
                    let batch = b.batchProduct;
                    return `
                            <tr>
                              <td style="width: 14%;">
                                <span style="font-family: Verdana, Geneva, sans-serif;"
                                  >${batch?.batchNo || ""}</span
                                >
                              </td>
                              <td style="width: 13%;">
                                <span style="font-family: Verdana, Geneva, sans-serif;"
                                  >${consumeExpDate(
                                    batch?.expiryDate,
                                    dateFormat
                                  )}</span
                              </td>
                              <td style="width: 13%;">
                                <span style="font-family: Verdana, Geneva, sans-serif;"
                                  >${batch?.availableQty || 0}</span
                              </td>
                              <td style="width: 16%;">
                                <span style="font-family: Verdana, Geneva, sans-serif;"
                                  >${b.requestedQty || 0}</span
                              </td>
                            </tr>
                          `;
                  })
                  .join("")}
              </tbody>
               </table>
            </td>
          </tr>`
             : ""
         }
        `;
        })
        .join("")}
    </tbody>
  </table>
</body>
</html>
`;

  return htmlContent;
};

export const getReplenishReceipt = (
  data: any,
  organizationName: string,
  stockroomName: string,
  timeString: string,
  dateFormat: string,
  soldToNumber: string,
  shipToNumber: string,
  currency:string
) => {
  const {
    transactionId,
    shipToAttn,
    createdDateValue,
    replenishProducts,
    costCenterName,
  } = data || {};
  const htmlContent = `
  <html>
   <head>
   <meta 
                name="viewport" 
                content="width=device-width, initial-scale=0.7 maximum-scale=0.7, user-scalable=0"
            >
            <title>Receipt</title>
   </head>
    <body>
    <style>
          table {
              border-collapse: collapse;
          }
  
          tr {
              border-bottom: 1px solid #222222;
          }
  
          th {
              background: #53555a;
              color: #fff;
          }
  
         
      </style>
    <table style="width:100%">
        <tr>
            <td style="width:50%,">
                <p><strong><span style="font-family:Verdana,Geneva,sans-serif">${organizationName}</strong></p>
            </td>
            <td>
                <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Receipt</strong></p>
            </td>
        </tr>
        <tr>
            <td style="width:50%">
                <p><strong><span style="font-family:Verdana,Geneva,sans-serif">${stockroomName}</strong></p>
            </td>
            <td>
                <p><span style="font-family:Verdana,Geneva,sans-serif">Date : ${
                  moment(createdDateValue).format(
                    `${dateFormat}, ${timeString}`
                  ) || ""
                }</p>
            </td>
        </tr>
        <tr>
            <td style="width:50%">
                <p><span style="font-family:Verdana,Geneva,sans-serif">Ship-To Number : ${
                  shipToNumber || ""
                }</p>
            </td>
            <td>
                <p><span style="font-family:Verdana,Geneva,sans-serif">Transaction Id : ${
                  transactionId || ""
                }</p>
            </td>
        </tr>
        <tr>
            <td style="width:50%">
                <p><span style="font-family:Verdana,Geneva,sans-serif">Sold-To Number : ${
                  soldToNumber || ""
                }</p>
            </td>
        </tr>
    </table>
    <table border="1" cellpadding="1" cellspacing="1" style="margin-top:${hp(
      2
    )}">
    <tr>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Catalog Number</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Customer Catalog Number</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Description</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Vendor</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Cost Center</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Required Quantity</span></strong></p>
        </th>
        <th>
        <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Price</span></strong></p>
    </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Ordered Quantity</span></strong></p>
        </th>
        <th>
        <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Extended Price</span></strong></p>
    </th>
    </tr>
        ${replenishProducts?.map?.(
          (
            element: {
              stockroomUOMDisplay: string;
              orderedQtyUOMDisplay: string;
              catalogNo: any;
              custCatalogNo: any;
              description: any;
              vendorName: any;
              availableQtyForDisplay: string;
              prefilledOrderedQty: any;
              purchasePrice:string,
              currency:string
            },
            index: any,
          ) => {
            return `
            <tr>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.catalogNo || ""
            }</span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.custCatalogNo || ""
            }</span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.description || ""
            }</span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.vendorName || ""
            }</span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              costCenterName || ""
            }</span></td>
            <td style="width:150px"><span style="font-family:Verdana,Geneva,sans-serif">
           ${element?.availableQtyForDisplay.replace("null", "").trim() || ""}
            </span></td>
            <td style="width:150px"><span style="font-family:Verdana,Geneva,sans-serif">
            ${element?.vendorName &&element?.currency?element?.currency: currency} ${element?.purchasePrice}
             </span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.prefilledOrderedQty +
              " " +
              element?.orderedQtyUOMDisplay +
              " " +
              element.stockroomUOMDisplay
            }</span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${currency} ${(
              element?.purchasePrice * element?.prefilledOrderedQty
            )?.toFixed(2)}</span></td>
        </tr>
            `;
          }
        )}
    </table>
    </body>
  </html>
  `;
  return htmlContent;
};

export const getReplenishReceiptRequest = (
  data: any,
  organizationName: string,
  stockroomName: string,
  timeString: string,
  dateFormat: string,
  soldToNumber: string,
  shipToNumber: string,
  currency:string
) => {
  const {
    transactionId,
    shipToAttn,
    createdDateValue,
    replenishProducts,
    costCenterName,
  } = data || {};

  const htmlContent = `
  <html>
   <head>
   <meta 
                name="viewport" 
                content="width=device-width, initial-scale=0.7 maximum-scale=0.7, user-scalable=0"
            >
            <title>Receipt</title>
   </head>
    <body>
    <style>
          table {
              border-collapse: collapse;
          }
  
          tr {
              border-bottom: 1px solid #222222;
          }
  
          th {
              background: #53555a;
              color: #fff;
          }
  
         
      </style>
    <table style="width:100%">
        <tr>
            <td style="width:50%,">
                <p><strong><span style="font-family:Verdana,Geneva,sans-serif">${organizationName}</strong></p>
            </td>
            <td>
                <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Receipt</strong></p>
            </td>
        </tr>
        <tr>
            <td style="width:50%">
                <p><strong><span style="font-family:Verdana,Geneva,sans-serif">${stockroomName}</strong></p>
            </td>
            <td>
                <p><span style="font-family:Verdana,Geneva,sans-serif">Date : ${
                  moment(createdDateValue).format(
                    `${dateFormat}, ${timeString}`
                  ) || ""
                }</p>
            </td>
        </tr>
        <tr>
            <td style="width:50%">
                <p><span style="font-family:Verdana,Geneva,sans-serif">Ship-To Number : ${
                  shipToNumber || ""
                }</p>
            </td>
            <td>
                <p><span style="font-family:Verdana,Geneva,sans-serif">Transaction Id : ${
                  transactionId || ""
                }</p>
            </td>
        </tr>
        <tr>
            <td style="width:50%">
                <p><span style="font-family:Verdana,Geneva,sans-serif">Sold-To Number : ${
                  soldToNumber || ""
                }</p>
            </td>
        </tr>
    </table>
    <table border="1" cellpadding="1" cellspacing="1" style="margin-top:${hp(
      2
    )}">
    <tr>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Catalog Number</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Customer Catalog Number</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Description</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Vendor</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Cost Center</span></strong></p>
        </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Required Quantity</span></strong></p>
        </th>
        <th>
        <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Price</span></strong></p>
    </th>
        <th>
            <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Ordered Quantity</span></strong></p>
        </th>
        <th>
        <p><strong><span style="font-family:Verdana,Geneva,sans-serif">Extended Price</span></strong></p>
    </th>
    </tr>
        ${replenishProducts?.map?.(
          (
            element: {
              catalogNo: any;
              custCatalogNo: any;
              description: any;
              vendorName: any;
              availableQtyForDisplay: string;
              purchasePrice: number;
              prefilledOrderedQty: string | number;
              orderedQtyUOMDisplay: string;
              stockroomUOMDisplay: string;
            },
            index: any
          ) => {
            console.log("element", element);
            return `
            <tr>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.catalogNo || ""
            }</span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.custCatalogNo || ""
            }</span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.description || ""
            }</span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.vendorName || ""
            }</span></td>

            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              costCenterName || ""
            }</span></td>
            <td style="width:150px"><span style="font-family:Verdana,Geneva,sans-serif">
           ${element?.availableQtyForDisplay.replace("null", "").trim() || ""}
            </span></td>
            <td style="width:150px"><span style="font-family:Verdana,Geneva,sans-serif">
            ${currency} ${element?.purchasePrice}
             </span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${
              element?.prefilledOrderedQty +
              " " +
              element?.orderedQtyUOMDisplay +
              " " +
              element.stockroomUOMDisplay
            }</span></td>
            <td style="width:106px"><span style="font-family:Verdana,Geneva,sans-serif">${currency} ${(
              element?.purchasePrice * element?.prefilledOrderedQty
            )?.toFixed(2)}</span></td>
        </tr>
            `;
          }
        )}
    </table>
    </body>
  </html>
  `;
  return htmlContent;
};

const getPutAwayBatchContent = (element: any, dateFormat: any) => {
  let value: any;
  element?.receiveBatchDetails?.forEach((batchData: any) => {
    value += `
    <tr>
      <td class="block" style="width: 14%;">
        <span style="font-family: Verdana, Geneva, sans-serif;"
          >${batchData?.batchNo || ""}</span
        >
      </td>
      <td class="block" style="width: 14%;">
        <span style="font-family: Verdana, Geneva, sans-serif;"
          >
          ${receiveExpDate(
            batchData?.expiryDtFormat,
            batchData?.expiryDate,
            dateFormat
          )}
          </span
        >
      </td>
      <td class="block" style="width: 15%;">
        <span style="font-family: Verdana, Geneva, sans-serif;"
          >${(batchData?.receivedQty ?? batchData?.actualQty) || ""}</span
        >
      </td>
    </tr>
    `;
  });

  return value.replace("undefined", "");
};

const checkBatchContent = (element: any, dateFormat: any) => {
  if (element?.receiveBatchDetails?.length > 0) {
    return `
    <table
      align="right
      class="fixed"
      style="table-layout: fixed; width: 50%; word-break: break-all;  margin-left: 20px; float:right"
    >
      <tr>
        <td class="block" style="width: 10%;">
          <table
            border="3"
            class="block"
            style="width:80%,margin-left:20px"
          >
            <tr>
              <th class="block" style="width: 10%;">
              <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Batch #</span
              ></strong
            >
                
              </th>
              <th class="block" style="width: 12%;">
              <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Expiry Date</span
              ></strong
            >
                
              </th>
              <th class="block" style="width: 15%;">
              <strong
              ><span style="font-family: Verdana, Geneva, sans-serif;"
                >Received Qty</span
              ></strong
            >
               
              </th>
            </tr>
            ${getPutAwayBatchContent(element, dateFormat)}
          </table>
        </td>
      </tr>
    </table>
    `;
  } else {
    return `<tr></tr>`;
  }
};

export const getPutAwayTicket = (
  receiveStatus: string,
  data: any,
  itemData: any,
  createdDate: any,
  receivedDate: any,
  filteredOrderData: any,
  dateFormat: any
) => {
  const htmlContent = `<html>

  <head>
      <meta name="viewport" content="width=device-width, initial-scale=0.7 maximum-scale=0.7, user-scalable=0" />
      <title>Receipt</title>
  </head>
  
  <body>
      <style>
          table {
              border-collapse: collapse;
              border: 1px solid #222222;
          }
  
          tr {
              border-bottom: 1px solid #222222;
          }
  
          th {
              background: #53555a;
              color: #fff;
              border-right: 1px solid #222222;
          }
  
          td {
              border-right: 1px solid #222222;
          }
  
          span {
              font-size: 10px;
          }
      </style>
  
  
  
      <table border="1" cellpadding="1" cellspacing="1" class="fixed" style="table-layout: fixed; width: 100%; word-break: break-all;">
          <tr style="">
              <th class="block" style="width: 24%;">
                  <p>
                      <strong><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Order #</span
                  ></strong
                >
              </p>
            </th>
            <th class="block" style="width: 15%;">
              <p>
                <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Vendor</span
                  ></strong
                >
              </p>
            </th>
            <th class="block" style="width: 15%;">
              <p>
                <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Cost Center</span
                  ></strong
                >
              </p>
            </th>
            <th class="block" style="width: 15%;">
              <p>
                <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Project #</span
                  ></strong
                >
              </p>
            </th>
            <th class="block" style="width: 17%;">
              <p>
                <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Purchase Order #</span
                  ></strong
                >
              </p>
            </th>
            <th class="block" style="width: 16%;">
              <p>
                <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Contract #</span
                  ></strong
                >
              </p>
            </th>
            <th class="block" style="width: 17%;">
              <p>
                <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Creation Date</span
                  ></strong
                >
              </p>
            </th>
            <th class="block" style="width: 17%;">
              <p>
                <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Received Date</span
                  ></strong
                >
              </p>
            </th>
            <th class="block" style="width: 16%;">
              <p>
                <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Status</span
                  ></strong
                >
              </p>
            </th>
          </tr>
          ${filteredOrderData?.map?.((element: any, index: number) => {
            return `
          <table
            border="1"
            class="fixed"
            style="table-layout: fixed; width: 100%; word-break: break-all;"
          >
            <tr>
              <td style="width: 24%;">
                <span style="font-family: Verdana, Geneva, sans-serif;"
                  >${data?.internalPurOrderNo || ""}</span
                >
              </td>
              <td style="width: 15%;">
                <span style="font-family: Verdana, Geneva, sans-serif;"
                  >${itemData?.vendor?.vendorName || ""}</span
                >
              </td>
              <td style="width: 15%;">
                <span style="font-family: Verdana, Geneva, sans-serif;"
                  >${itemData?.costCenterName || ""}</span
                >
              </td>
              <td style="width: 15%;">
                <span style="font-family: Verdana, Geneva, sans-serif;"
                  >${itemData?.projectNo || ""}</span
                >
              </td>
              <td style="width: 17%;">
                <span style="font-family: Verdana, Geneva, sans-serif;"
                  >${itemData?.purchaseOrderNo || ""}</span
                >
              </td>
              <td style="width: 16%;">
                <span style="font-family: Verdana, Geneva, sans-serif;"
                  >${itemData?.contractNo || ""}</span
                >
              </td>
              <td style="width: 17%;">
                <span style="font-family: Verdana, Geneva, sans-serif;"
                  >${createdDate || ""}</span
                >
              </td>
              <td style="width: 17%;">
                <span style="font-family: Verdana, Geneva, sans-serif;"
                  >${receivedDate || ""}</span
                >
              </td>
              <td style="width: 16%;">
                <span style="width:10%,font-family:Verdana,Geneva,sans-serif"
                  >${(receiveStatus ?? "") || ""}</span
                >
              </td>
              <table
              class="fixed"
              style="table-layout: fixed; width: 80%; word-break: break-all; float: right"
            >
              <tr>
                <td class="block" style="width: 10%;">
                  <table
                    border="3"
                    class="block"
                    style="width:90%,margin-left:20px"
                  >
                    <tr>
                      <th class="block" style="width: 14%;">
                      <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Product Catalog #</span
                  ></strong
                >
                       
                      </th>
                      <th class="block" style="width: 14%;">
                      <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Customer Catalog #</span
                  ></strong
                >
                       
                      </th>
                      <th class="block" style="width: 15%;">
                      <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Description</span
                  ></strong
                >
                       
                      </th>
                      <th class="block" style="width: 10%;">
                      <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Vendor</span
                  ></strong
                >
                       
                      </th>
                      <th class="block" style="width: 10%;">
                      <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Order<br/>Qty</span
                  ></strong
                >
                       
                      </th>
                      <th class="block" style="width: 10%;">
                      <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Received<br/>Qty</span
                  ></strong
                >
                       
                      </th>
                      <th class="block" style="width: 10%;">
                      <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Remaining<br/>Qty</span
                  ></strong
                >
                       
                      </th>
                      <th class="block" style="width: 10%;">
                      <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Expected Date of<br/>Delivery</span
                  ></strong
                >
                       
                      </th>
                      <th class="block" style="width: 9%;">
                      <strong
                  ><span style="font-family: Verdana, Geneva, sans-serif;"
                    >Ship<br/>From</span
                  ></strong
                >
                       
                      </th>
                    </tr>
    
                    <tr>
                      <td class="block" style="width: 14%;">
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >${element?.product?.catalogNo || ""}</span
                        >
                      </td>
                      <td class="block" style="width: 14%;">
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >${element?.product?.custCatalogNo || ""}</span
                        >
                      </td>
                      <td class="block" style="width: 15%;">
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >${element?.product?.description || ""}</span
                        >
                      </td>
                      <td class="block" style="width: 10%;">
                        <span
                          style="width:10%,font-family:Verdana,Geneva,sans-serif"
                          >${element?.product?.vendorName || ""}</span
                        >
                      </td>
                      <td class="block" style="width: 10%;">
                        <span
                          style="width:10%,font-family:Verdana,Geneva,sans-serif"
                          >${element?.orderQtyStr || ""}</span
                        >
                      </td>
                      <td class="block" style="width: 10%;">
                        <span
                          style="width:10%,font-family:Verdana,Geneva,sans-serif"
                          >${
                            (element?.receivedQtyStr || "") +
                            getreceivedQtyStr(element)
                          }</span
                        >
                      </td>
                      <td class="block" style="width: 10%;">
                        <span
                          style="width:10%,font-family:Verdana,Geneva,sans-serif"
                          >${
                            (element?.remainingQuanityStr || "") +
                            getreceivedQtyStr(element)
                          }</span
                        >
                      </td>
                      <td class="block" style="width: 9%;">
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >${element?.expectDeliveryDtFormat || ""}</span
                        >
                      </td>
                      <td class="block" style="width: 13%;">
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >${element?.shipFrom || ""}</span
                        >
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            </tr>
            ${checkBatchContent(element, dateFormat)}
          </table>
          
          `;
          })}
        </table>
      </body>
    </html>`;
  return htmlContent;
};
const consumeExpDate = (expiryDate: null, dateFormat: { date: any }) => {
  // moment(expiryDate).format(`${dateFormat?.date}`);
  let date =
    expiryDate &&
    moment(expiryDate, findDateFormat(expiryDate)).format(dateFormat.date);
  //expiryDate;

  if (expiryDate !== null) {
    if (moment(expiryDate).format(`${dateFormat?.date}`) != "Invalid date") {
      //return date;
      return moment(expiryDate).format(`${dateFormat?.date}`);
    } else {
      return "";
    }
  } else {
    return "";
  }
};

const receiveExpDate = (
  expiryDtFormat: any,
  expiryDate: null,
  dateFormat: any
) => {
  if (expiryDtFormat !== null && expiryDtFormat !== undefined) {
    if (
      moment(expiryDtFormat).format(`${dateFormat?.date}`) != "Invalid date"
    ) {
      let date =
        expiryDtFormat &&
        moment(expiryDtFormat, findDateFormat(expiryDtFormat)).format(
          dateFormat?.date
        );
      return date;
    } else {
      return "";
    }
  } else {
    console.log(
      String(expiryDtFormat),
      String(expiryDate),
      String(dateFormat?.date),
      moment(expiryDate, "YYYY-MM-DD"),
      ".....----------------......>>>>>>"
    );
    if (moment(expiryDate).format(`${dateFormat?.date}`) != "Invalid date") {
      let newDate = moment(expiryDate, "YYYY-MM-DD").format(dateFormat?.date);
      console.log(newDate, "...........////////////////////");

      return newDate;
    } else {
      return "";
    }
  }
};

const expdate = (expiryDate: null, dateFormat: { date: any }) => {
  //Used only for Consume Approval
  if (expiryDate !== null) {
    if (moment(expiryDate).format(`${dateFormat?.date}`) != "Invalid date") {
      return moment(expiryDate).format(`${dateFormat?.date}`);
    } else {
      return "";
    }
  } else {
    return "";
  }
};

export const getConsumePickTicket = (productData: any, dateFormat?: any) => {
  const htmlContent = `
  <html>
  <head>
    <meta
      name="viewport"
      content="width=device-width, initial-scale=0.7 maximum-scale=0.7, user-scalable=0"
    />
    <title>Receipt</title>
  </head>
  <body>
    <style>
      table {
              border-collapse: collapse;
              border: 1px solid #222222;
          }
  
          tr {
              border-bottom: 1px solid #222222;
          }
  
          th {
              background: #53555a;
              color: #fff;
              border-right: 1px solid #222222;
          }

      td {
        border-right: 1px solid #222222;
      }

      span {
        font-size: 10px;
      }
    </style>

    <table
      border="1"
      cellpadding="1"
      cellspacing="1"
      class="fixed"
      style="table-layout: fixed; width: 100%; word-break: break-all;"
    >
      <thead>
        <tr>
          <th
            class="block"
            style="width: 35%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Product Catalog Number</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 35%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Customer Catalog Number</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Description</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Vendor</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Cost Center</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Department</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 27%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Location</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Available Quantity</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Current Approval Quantity</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Picked Required Quantity</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Remaining Quantity</span
                ></strong
              >
            </p>
          </th>
        </tr>
      </thead>
      <tbody>
        ${productData?.map?.((element: any, index: number) => {
          return `
        <tr>
          <td
            class="block"
            style="width: 35%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element["product"]?.catalogNo || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 35%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element["product"]?.custCatalogNo || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element["product"]?.description || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element["product"]?.vendorName || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.costCenterName || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.departmentName || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 27%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element["product"]?.locationName || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element["product"]?.availableQty}</span
            >
          </td>
          <td
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.currentApprovalQty}</span
            >
          </td>
          <td
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.pickedRequiredQty}</span
            >
          </td>
          <td
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.remainingQty}</span
            >
          </td>
        </tr>
        ${
          element?.requestBatch?.length > 0
            ? [
                `
        <tr>
          <td colspan="11">
            <table
              border="1"
              cellpadding="1"
              cellspacing="1"
              class="fixed"
              style="
                table-layout: fixed;
                width: 75%;
                word-break: break-all;
                margin: auto 0 auto auto;
              "
            >
              <thead>
                <tr style="">
                  <th class="block" style="width: 14%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Batch Number</span
                        ></strong
                      >
                    </p>
                  </th>
                  <th class="block" style="width: 13%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Expiry Date</span
                        ></strong
                      >
                    </p>
                  </th>
                  <th class="block" style="width: 13%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Available Qty</span
                        ></strong
                      >
                    </p>
                  </th>
                  <th class="block" style="width: 16%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Current Approval Quantity</span
                        ></strong
                      >
                    </p>
                  </th>
                  <th class="block" style="width: 16%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Picked Required Quantity</span
                        ></strong
                      >
                    </p>
                  </th>
                  <th class="block" style="width: 16%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Remaining Quantity</span
                        ></strong
                      >
                    </p>
                  </th>
                </tr>
              </thead>
              <tbody>
                `,
                ...element?.requestBatch?.map((batchItem: any, i: any) => {
                  return `
                <tr>
                  <td style="width: 14%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${batchItem?.batchProduct?.batchNo || ""}</span
                    >
                  </td>
                  <td style="width: 13%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${expdate(
                        batchItem?.batchProduct?.expiryDate,
                        dateFormat
                      )}</span
                    >
                  </td>
                  <td style="width: 13%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${batchItem?.batchProduct?.availableQty}</span
                    >
                  </td>
                  <td style="width: 16%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${
                        batchItem?.currentApprovalQty !== null &&
                        batchItem?.currentApprovalQty
                      }</span
                    >
                  </td>
                  <td style="width: 16%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${
                        batchItem?.pickedQty !== null && batchItem?.pickedQty
                      }</span
                    >
                  </td>
                  <td style="width: 16%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${
                        batchItem?.remainingQty !== null &&
                        batchItem?.remainingQty
                      }</span
                    >
                  </td>
                </tr>
                `;
                }),
                `
              </tbody>
            </table>
          </td>
        </tr>
        `,
              ].join("")
            : `
        <p></p>
        `
        } `;
        })}
      </tbody>
    </table>
  </body>
</html>
  `;
  return htmlContent;
};

export const getPouPickTicket = (productData: any, dateFormat?: any) => {
  const htmlContent = `
  <html>
  <head>
    <meta
      name="viewport"
      content="width=device-width, initial-scale=0.7 maximum-scale=0.7, user-scalable=0"
    />
    <title>Receipt</title>
  </head>
  <body>
    <style>
    table {
      border-collapse: collapse;
      border: 1px solid #222222;
  }

  tr {
      border-bottom: 1px solid #222222;
  }

  th {
      background: #53555a;
      color: #fff;
      border-right: 1px solid #222222;
  }

      td {
        border-right: 1px solid #222222;
      }

      span {
        font-size: 10px;
      }
    </style>

    <table
      border="1"
      cellpadding="1"
      cellspacing="1"
      class="fixed"
      style="table-layout: fixed; width: 100%; word-break: break-all;"
    >
      <thead>
        <tr>
          <th
            class="block"
            style="width: 35%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Product Catalog Number</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 35%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Customer Catalog No</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Description</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >PoU</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Vendor</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 27%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Location</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Cost Center</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Department</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Available Quantity</span
                ></strong
              >
            </p>
          </th>
          <th
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <p>
              <strong
                ><span style="font-family: Verdana, Geneva, sans-serif;"
                  >Consumed Quantity</span
                ></strong
              >
            </p>
          </th>
        </tr>
      </thead>
      <tbody>
        ${productData?.map?.((element: any, index: number) => {
          return `
        <tr>
          <td
            class="block"
            style="width: 35%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.productCatalogNo || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 35%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.customerCatalogNo || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.productDescription || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.pouStockRoomName || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element["product"]?.vendorName || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 27%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.locationName || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.costCenterName || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 23%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.departmentName || ""}</span
            >
          </td>
          <td
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.availableProductQty}</span
            >
          </td>
          <td
            class="block"
            style="width: 40%; vertical-align: top; text-align: left;"
          >
            <span style="font-family: Verdana, Geneva, sans-serif;"
              >${element?.requestQuantity}</span
            >
          </td>
        </tr>
        ${
          element?.requestBatch?.length > 0
            ? [
                `
        <tr>
          <td colspan="11">
            <table
              border="1"
              cellpadding="1"
              cellspacing="1"
              class="fixed"
              style="
                table-layout: fixed;
                width: 75%;
                word-break: break-all;
                margin: auto 0 auto auto;
              "
            >
              <thead>
                <tr style="">
                  <th class="block" style="width: 14%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Batch Number</span
                        ></strong
                      >
                    </p>
                  </th>
                  <th class="block" style="width: 13%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Expiry Date</span
                        ></strong
                      >
                    </p>
                  </th>
                  <th class="block" style="width: 13%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Available Qty</span
                        ></strong
                      >
                    </p>
                  </th>
                  <th class="block" style="width: 16%;">
                    <p>
                      <strong
                        ><span style="font-family: Verdana, Geneva, sans-serif;"
                          >Picked Required Quantity</span
                        ></strong
                      >
                    </p>
                  </th>
                </tr>
              </thead>
              <tbody>
                `,
                ...element?.requestBatch?.map((batchItem: any, i: any) => {
                  return `
                <tr>
                  <td style="width: 14%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${batchItem?.batchProduct?.batchNo || ""}</span
                    >
                  </td>
                  <td style="width: 13%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${
                        (batchItem?.batchProduct?.expiryDate !== null &&
                          moment(batchItem?.batchProduct?.expiryDate).format(
                            `${dateFormat?.date}`
                          )) ||
                        ""
                      }</span
                    >
                  </td>
                  <td style="width: 13%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${batchItem?.batchProduct?.availableQty}</span
                    >
                  </td>
                  <td style="width: 16%;">
                    <span style="font-family: Verdana, Geneva, sans-serif;"
                      >${
                        batchItem?.requestedQty !== null &&
                        batchItem?.requestedQty
                      }</span
                    >
                  </td>
                </tr>
                `;
                }),
                `
              </tbody>
            </table>
          </td>
        </tr>
        `,
              ].join("")
            : `
        <p></p>
        `
        } `;
        })}
      </tbody>
    </table>
  </body>
</html>

  `;
  return htmlContent;
};

const checkStockBatchContent = (element: any, batchData: any) => {
  if (
    element.batches &&
    element?.batches?.length > 0 &&
    (element?.batchManagementEnabled || element?.expiryDateManagementenabled)
  ) {
    return `
    <tr>
          <td colspan="11">
            <table
              border="1"
              cellpadding="1"
              cellspacing="1"
              class="fixed"
              style="
                table-layout: fixed;
                word-break: break-all;
                margin: auto 0 auto auto;
                width: 75%
              "
            >
              <thead>
                <tr>
                  <th
                    class="block"
                    style="width: 130px; vertical-align: top; text-align: left;"
                  >
                      <strong>
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >Batch Number</span
                        >
                      </strong>
                  </th>
                  <th
                    class="block"
                    style="width: 130px; vertical-align: top; text-align: left;"
                  >
                      <strong>
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >Expiry Date</span
                        >
                      </strong>
                  </th>
                  <th
                    class="block"
                    style="width: 130px; vertical-align: top; text-align: left;"
                  >
                      <strong>
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >Dynamic Expiry Date</span
                        >
                      </strong>
                  </th>
                  <th
                    class="block"
                    style="width: 130px; vertical-align: top; text-align: left;"
                  >
                      <strong>
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >Available Qty</span
                        >
                      </strong>
                  </th>
                  <th
                    class="block"
                    style="width: 100px; vertical-align: top; text-align: left;"
                  >
                      <strong>
                        <span style="font-family: Verdana, Geneva, sans-serif;"
                          >Transfer Qty</span
                        >
                      </strong>
                  </th>
                </tr>
              </thead>
              <tbody>
              ${getBatchContent(batchData, element)}
              </tbody>
            </table>
          </td>
        </tr>
    `;
  } else {
    return `<tr></tr>`;
  }
};

const getBatchContent = (batchData: any, element: any) => {
  let blockData: any = [];
  batchData?.map((batch: any, i: any) => {
    element.batches.map((item: any, i: number) => {
      if (item.id == batch.batchId) {
        let dataset = {
          ...item,
          required_batchQty: batch.requiredQty,
        };
        blockData.push(dataset);
      }
    });
  });
  let value: any;
  blockData.forEach((matchingBatch: any) => {
    value += `
 <thead>
     <tr>
       <td >
         <span
           style="
             font-family: Verdana, Geneva, sans-serif;
           "
           >${matchingBatch?.batchNo || ""}</span
         >
       </td>
       <td >
         <span
           style="
             font-family: Verdana, Geneva, sans-serif;
           "
           >${matchingBatch?.expiryDateFormat || ""}</span
         >
       </td>
       <td>
         <span
           style="
             font-family: Verdana, Geneva, sans-serif;
           "
           >${matchingBatch?.dynamicExpiryDateFormat || ""}</span
         >
       </td>
       <td >
         <span
           style="
             font-family: Verdana, Geneva, sans-serif;
           "
           >
           ${matchingBatch?.availableQty-matchingBatch?.required_batchQty || 0}</span
         >
       </td>
       <td>
         <span
           style="
             font-family: Verdana, Geneva, sans-serif;
           "
           >${matchingBatch?.required_batchQty || 0}</span
         >
       </td>
     </tr>
   </thead>
 `;
  });

  return value.replace("undefined", "");
  // return blockData.map((matchingBatch: any, i: number) => {
  //   return `
  //   <thead>
  //       <tr>
  //         <td >
  //           <span
  //             style="
  //               font-family: Verdana, Geneva, sans-serif;
  //             "
  //             >${matchingBatch?.batchNo || ""}</span
  //           >
  //         </td>
  //         <td >
  //           <span
  //             style="
  //               font-family: Verdana, Geneva, sans-serif;
  //             "
  //             >${matchingBatch?.expiryDateFormat || ""}</span
  //           >
  //         </td>
  //         <td>
  //           <span
  //             style="
  //               font-family: Verdana, Geneva, sans-serif;
  //             "
  //             >${matchingBatch?.dynamicExpiryDateFormat || ""}</span
  //           >
  //         </td>
  //         <td >
  //           <span
  //             style="
  //               font-family: Verdana, Geneva, sans-serif;
  //             "
  //             >${matchingBatch?.availableQty || 0}</span
  //           >
  //         </td>
  //         <td>
  //           <span
  //             style="
  //               font-family: Verdana, Geneva, sans-serif;
  //             "
  //             >${matchingBatch?.required_batchQty || 0}</span
  //           >
  //         </td>
  //       </tr>
  //     </thead>
  //   `;
  // });
};

const getTotalTransferQty = (batchData: any, element: any) => {
  let sumOfRequiredQty = 0;

  for (const item2 of batchData) {
    const matchedItem = element?.batches.find((item1: { id: any }) => {
      return item1.id === item2.batchId;
    });
    if (matchedItem) {
      sumOfRequiredQty += Number(item2.requiredQty);
    }
  }
  return sumOfRequiredQty ?? 0;
};

const getTransferQty = (elementId: string, passedData: any) => {
  let matchedData: any;

  matchedData = passedData.find((e: any) => e.id == elementId);
  return matchedData.requiredQty;
};

export const getStockTransferTicket = (
  productData: any,
  sourceStockRoom: string,
  destinationStockRoom: string,
  batchData: any,
  passedProducts: any
) => {
  const htmlContent = `
  <!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.7 maximum-scale=0.7, user-scalable=0" />
    <title>Receipt</title>
</head>

<body>
    <style>
    table {
      border-collapse: collapse;
      border: 1px solid #222222;
  }

  tr {
      border-bottom: 1px solid #222222;
  }

  th {
      background: #53555a;
      color: #fff;
      border-right: 1px solid #222222;
  }

        td {
            border-right: 2px solid #222222;
        }

        span {
            font-size: 10px;
        }
    </style>

    <table border="1" cellpadding="1" cellspacing="1" class="fixed" style="table-layout: fixed; width: 100%; word-break: break-all;">
        <thead>
            <tr>
                <th class="block" style="width: 120px; vertical-align: top; text-align: left;">
                        <strong>
                            <span style="font-family: Verdana, Geneva, sans-serif;">Product Catalog Number</span>
                        </strong>
                </th>
                <th class="block" style="width: 120px; vertical-align: top; text-align: left;">
                        <strong>
                            <span style="font-family: Verdana, Geneva, sans-serif;">Customer Catalog No</span>
                        </strong>
                </th>
                <th class="block" style="width: 120px; vertical-align: top; text-align: left;">
                        <strong>
                            <span style="font-family: Verdana, Geneva, sans-serif;">Description</span>
                        </strong>
                </th>
                <th class="block" style="width:120px; vertical-align: top; text-align: left;">
                        <strong>
                            <span style="font-family: Verdana, Geneva, sans-serif;">Vendor</span>
                        </strong>
                </th>
                <th class="block" style="width: 120px; vertical-align: top; text-align: left;">
                        <strong>
                            <span style="font-family: Verdana, Geneva, sans-serif;">Source Stockroom</span>
                        </strong>
                </th>
                <th class="block" style="width: 120px; vertical-align: top; text-align: left;">
                        <strong>
                            <span style="font-family: Verdana, Geneva, sans-serif;">Destination Stockroom</span>
                        </strong>
                </th>
                <th class="block" style="width: 120px; vertical-align: top; text-align: left;">
                        <strong>
                            <span style="font-family: Verdana, Geneva, sans-serif;">Available Quantity</span>
                        </strong>
                </th>
                <th class="block" style="width: 120px; vertical-align: top; text-align: left;">
                        <strong>
                            <span style="font-family: Verdana, Geneva, sans-serif;">Transfer Quantity</span>
                        </strong>
                </th>
            </tr>
        </thead>
        <tbody>
            ${productData?.map?.((element: any, index: number) => {
              return `
            <tr>
                <td class="block" style="vertical-align: top; text-align: left;">
                    <span style="font-family: Verdana, Geneva, sans-serif;">${
                      element?.catalogNo || ""
                    }</span>
                </td>
                <td class="block" style="vertical-align: top; text-align: left;">
                    <span style="font-family: Verdana, Geneva, sans-serif;">${
                      element?.custCatalogNo || ""
                    }</span>
                </td>
                <td class="block" style="vertical-align: top; text-align: left;">
                    <span style="font-family: Verdana, Geneva, sans-serif;">${
                      element?.description || ""
                    }</span>
                </td>
                <td class="block" style="vertical-align: top; text-align: left;">
                    <span style="font-family: Verdana, Geneva, sans-serif;">${
                      element?.vendorName || ""
                    }</span>
                </td>
                <td class="block" style="vertical-align: top; text-align: left;">
                    <span style="font-family: Verdana, Geneva, sans-serif;">${
                      sourceStockRoom || ""
                    }</span>
                </td>
                <td class="block" style="vertical-align: top; text-align: left;">
                    <span style="font-family: Verdana, Geneva, sans-serif;">${
                      destinationStockRoom || ""
                    }</span>
                </td>
                <td class="block" style="vertical-align: top; text-align: left;">
                    <span style="font-family: Verdana, Geneva, sans-serif;">${
                      Number(element?.availableQty) - Number(getTransferQty(element.id, passedProducts))
                    }</span>
                </td>
                <td class="block" style="vertical-align: top; text-align: left;">
                    <span style="font-family: Verdana, Geneva, sans-serif;">${
                      element?.batches?.length > 0
                        ? getTotalTransferQty(batchData, element)
                        : getTransferQty(element.id, passedProducts)
                    }</span>
                </td>
            </tr>
            ${checkStockBatchContent(element, batchData)}
            `;
            })} 
        </tbody>
    </table>
</body>

</html>
  `;

  return htmlContent;
};

export const checkUomCondition = (item: any) => {
  if (item?.uomManagementEnabled == 1 && item.stockRoomUOMUnit != null) {
    return true;
  } else if (item?.uomManagementEnabled == 0 && item.uomId !== null) {
    return true;
  } else return false;
};

export const filterReasonCodeData = (
  reasonCodeData: any[],
  stockroomType: string
) => {
  return reasonCodeData.filter((item) => {
    if (stockroomType == "Regular") {
      return item.reasonCode !== "Overwrite logic";
    } else return item;
  });
};

export const getReceiveRemainingQty = (item: any) => {
  let qtyArr1: string = "";
  let qtyArr2: string = "";
  if (item?.remainingQuanityStr.includes("X")) {
    qtyArr1 = item?.remainingQuanityStr.replace(/\s+/g, "").split("X");
    if (
      item?.product?.maxStockQtyForDisplay &&
      item?.product?.maxStockQtyForDisplay.includes("X")
    ) {
      qtyArr2 = item?.product?.maxStockQtyForDisplay
        .replace(/\s+/g, "")
        .split("X");
    }
  } else {
    qtyArr1 = item?.remainingQuanityStr;
  }

  return Number(item?.remainingQuanityStr.includes("X") ? qtyArr1[0] : qtyArr1);
};

export const getMultiplier = (item: any) => {
  if (item?.maxStockQtyForDisplay && item?.maxStockQtyForDisplay.includes("X"))
    if (item?.uomManagementEnabled == 1) {
      return (
        (item?.stockRoomUOMUnit != null ? item?.stockRoomUOMUnit + " " : "") +
        "X " +
        item?.maxStockQtyForDisplay.replace(/\s+/g, "").split("X")[1]
      );
    } else {
      return (
        (item?.vendorUOMUnit != null ? item?.vendorUOMUnit + " " : "") +
        "X " +
        item?.maxStockQtyForDisplay.replace(/\s+/g, "").split("X")[1]
      );
    }
  else return null;
};

export const getreceivedQtyStr = (item: any) => {
  if (item?.maxStockQtyForDisplay && item?.maxStockQtyForDisplay.includes("X"))
    return "X " + item?.maxStockQtyForDisplay.replace(/\s+/g, "").split("X")[1];
  else return "";
};

export const checkifBatchEnabled = (item: any, stockRoomDetail: any) => {
  if (
    stockRoomDetail?.isBatchManagementEnabled &&
    (item?.product?.batchManagementEnabled || item?.batchManagementEnabled)
  ) {
    return true;
  } else return false;
};

export const checkifExpiryEnabled = (item: any, stockRoomDetail: any) => {
  if (
    stockRoomDetail?.isExpiryManagementEnabled &&
    (item?.product?.expiryDateManagementenabled ||
      item?.expiryDateManagementenabled)
  ) {
    return true;
  } else {
    return false;
  }
};

const check = (userPrivilege: any, type: string) => {
  const requestData = userPrivilege?.filter(
    (item: { name: string }) => item?.name === type
  );
  return requestData?.length ? true : false;
};

export const handleApprovals = (
  userPrivilege: any,
  pouCount: { count: number }
) => {
  const POU =
    checkUserPrevilageForApprovals(userPrivilege, "pou.order") &&
    check(userPrivilege, "approval.requests.scanner") 
    // &&
    // pouCount?.count > 0;
  return POU;
};
export const handleApprovalsPOU = (userPrivilege: any) => {
  const POU = checkUserPrevilageForApprovals(userPrivilege, "pou.order");
  return POU;
};

export const checkStoragePermission = async () => {
  try {
    if (Platform.OS === "ios") {
      return true;
    } else {
      let deviceVersion = DeviceInfo.getSystemVersion();
      let granted = PermissionsAndroid.RESULTS.DENIED;
      if (Number(deviceVersion) >= 13) {
        granted = PermissionsAndroid.RESULTS.GRANTED;
      } else {
        granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE
        );
      }

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return true;
      } else {
        return false;
      }
    }
  } catch (error) {
    console.log(error);
    return false;
  }
};

export const findDateFormat = (dateString: string) => {
  const formats = ["DD-MM-YYYY", "MM-DD-YYYY", "YYYY-MM-DD", "YYYY-DD-MM"];

  for (const format of formats) {
    const parts = format.split("-");
    const values = dateString.split(/\D/).map(Number); // Split by non-digit characters

    if (parts.length === values.length) {
      let isValid = true;

      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        const value = values[i];

        switch (part) {
          case "YYYY":
            if (value < 1000 || value > 9999) {
              isValid = false;
            }
            break;
          case "MM":
            if (value < 1 || value > 12) {
              isValid = false;
            }
            break;
          case "DD":
            if (value < 1 || value > 31) {
              isValid = false;
            }
            break;
          default:
            isValid = false;
        }

        if (!isValid) {
          break;
        }
      }

      if (isValid) {
        return format;
      }
    }
  }

  return "DD-MM-YYYY";
};


export function sortArray(a: { firstName: string }, b: { firstName: string }) {
  if (a.firstName < b.firstName) {
    return -1;
  }
  if (a.firstName > b.firstName) {
    return 1;
  }
  return 0;
}

export const getCurrencySymbol = (currency: string) => {
  return currencyToSymbolMap(currency);
};
