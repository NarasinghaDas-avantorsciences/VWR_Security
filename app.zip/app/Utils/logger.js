const isDevelopment = process.env.NODE_ENV !== 'production';

export const log = (...args) => {
  if (isDevelopment) {
    console.log(...args);
  }
};

export const warn = (...args) => {
  if (isDevelopment) {
    console.warn(...args);
  }
};

export const error = (...args) => {
  if (isDevelopment) {
    console.error(...args);
  }
};
