export default {
  READY_TO_BE_APPROVED: "1",
  PARTIALLY_AVAILABLE: "2",
  OUT_OF_STOCK: "3"
};
