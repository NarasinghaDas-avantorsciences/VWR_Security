export const htmlContent = `
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
  <head>
    <!--[if gte mso 9]>
		<xml>
			<o:OfficeDocumentSettings>
				<o:AllowPNG/>
				<o:PixelsPerInch>96</o:PixelsPerInch>
			</o:OfficeDocumentSettings>
		</xml>
		<![endif]-->
    <title>vwr part of avantor</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0 " />
    <meta name="format-detection" content="telephone=no" />
    <meta class="mktoColor" id="bgcolorwhite" mktoname="Background Color White" default="#ffffff" mktomodulescope="true" />
    <meta class="mktoColor" id="bgcolorgrey" mktoname="Background Color Grey" default="#f5f5f5" mktomodulescope="true" />
    <meta class="mktoColor" id="bgcolorgreen" mktoname="Background Color Green" default="#00d649" />
    <meta class="mktoString" id="utm" mktoname="UTM" default="?utm_source=mkto&amp;utm_medium=email&amp;utm_campaign={{program.Name}}" mktomodulescope="true" />
    <meta class="mktoString" id="putm" mktoname="UTM" default="&amp;utm_source=mkto&amp;utm_medium=email&amp;utm_campaign={{program.Name}}" mktomodulescope="true" />
    <style type="text/css">
      body {
        margin: 0 !important;
        padding: 0 !important;
        -webkit-text-size-adjust: 100% !important;
        -ms-text-size-adjust: 100% !important;
        -webkit-font-smoothing: antialiased !important;
      }

      img {
        border: 0 !important;
        outline: none !important;
      }

      p {
        Margin: 0px !important;
        Padding: 0px !important;
      }

      table {
        border-collapse: collapse;
        mso-table-lspace: 0px;
        mso-table-rspace: 0px;
      }

      td,
      a,
      span {
        border-collapse: collapse;
        mso-line-height-rule: exactly;
      }

      .ExternalClass * {
        line-height: 100%;
      }

      .em_defaultlink a {
        color: inherit !important;
        text-decoration: none !important;
      }

      span.MsoHyperlink {
        mso-style-priority: 99;
        color: inherit;
      }

      span.MsoHyperlinkFollowed {
        mso-style-priority: 99;
        color: inherit;
      }

      .em_green a {
        text-decoration: none;
        color: #28E946;
      }

      .em_green1 a {
        text-decoration: none;
        color: #00D649;
      }

      .em_blue a {
        text-decoration: none;
        color: #0064C8;
      }

      .em_white a {
        text-decoration: none;
        color: #ffffff;
      }

      @media only screen and (min-width:481px) and (max-width:667px) {
        .em_main_table {
          width: 100% !important;
        }

        .em_wrapper {
          width: 100% !important;
        }

        .em_hide {
          display: none !important;
        }

        .em_img {
          width: 100% !important;
          height: auto !important;
        }

        .em_height {
          height: 20px !important;
        }

        .em_top {
          padding-top: 20px !important;
        }

        .em_pad {
          padding: 0 10px !important;
        }

        .em_img1 {
          width: 100% !important;
          height: auto !important;
          max-width: none !important;
        }

        .em_padnone {
          padding: 0px !important;
        }

        .em_bordernone {
          border: none !important;
        }

        .em_padnone {
          padding: 0 !important;
        }

        .em_padtop {
          padding: 10px 0 10px 0 !important;
        }
      }

      @media screen and (max-width: 480px) {
        .em_main_table {
          width: 100% !important;
        }

        .em_wrapper {
          width: 100% !important;
        }

        .em_hide {
          display: none !important;
        }

        .em_img {
          width: 100% !important;
          height: auto !important;
        }

        .em_img1 {
          width: 100% !important;
          height: auto !important;
        }

        .em_height {
          height: 20px !important;
        }

        .em_top {
          padding-top: 20px !important;
        }

        .em_pad {
          padding: 0 10px !important;
        }

        .em_img1 {
          width: 100% !important;
          height: auto !important;
          max-width: none !important;
        }

        u+.em_body .em_full_wrap {
          width: 100% !important;
          width: 100vw !important;
        }

        .em_padnone {
          padding: 0px !important;
        }

        .em_bordernone {
          border: none !important;
        }

        .em_padnone {
          padding: 0 !important;
        }

        .em_padtop {
          padding: 10px 0 10px 0 !important;
        }
      }
    </style>
  </head>
  <body class="em_body" style="margin:0px; padding:0px;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="em_full_wrap">
      <!--Header Section -->
      <tbody>
        <tr>
          <td align="center" valign="top">
            <table align="center" width="750" border="0" cellspacing="0" cellpadding="0" class="em_main_table" style="width:750px; background-color:#236192;" bgcolor="#236192">
              <tbody>
                <tr>
                  <td align="center" valign="top">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tbody>
                        <tr>
                          <td width="30" style="width:30px;" class="em_4ide">&nbsp;</td>
                          <td align="left" valign="top">
                            <table width="254" border="0" cellspacing="0" cellpadding="0" align="left" class="em_wrapper" style="width:254px;">
                              <tbody>
                                <tr>
                                  <td height="25" style="font-size:1px; line-height:1px; height:25px;" class="em_height">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td align="center" valign="top">
                                    <div id="headerlogo" class="mktoImg" mktoname="headerlogo">
                                      <img src="http://go.vwr.com/rs/251-TTP-665/images/avantor_logo_cmyk-symbol_rev185x44anew.png" width="185" height="44" border="0" alt="vwr part of avantor" style="display:block; max-width:185px; font-family:Arial, sans-serif; font-size:14px; line-height:18px; color:#ffffff;" />
                                    </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td height="10" style="font-size:1px; line-height:1px; height:10px;">&nbsp;</td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                          <td align="center" valign="top" class="em_hide">
                            <div id="image1" class="mktoImg" mktoname="image1">
                              <img src="http://go.vwr.com/rs/251-TTP-665/images/1527080663412_right_img.jpg" width="466" height="79" border="0" style="display:block; max-width:600px;" class="em_img" />
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <!--//Header Section -->
        <!--Body Section -->
        <tr>
          <td align="center" valign="top">
            <table align="center" width="750" border="0" cellspacing="0" cellpadding="0" class="em_main_table" style="width:750px;" bgcolor="#ffffff">
              <tbody>
                <tr>
                  <td align="center" valign="top" class="mktoContainer" id="Template">
                    <table width="750" border="0" cellspacing="0" cellpadding="0" align="center" style="width:750px; background-color:#FFFFFF;" class="mktoModule em_wrapper" mktoname="Content_Section" id="Content_Section" bgcolor="$#FFFFFF">
                      <tbody>
                        <tr>
                          <td align="center" valign="top" style="padding:0px 30px;" class="em_pad">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
                              <tbody>
                                <tr>
                                  <td height="28" style="height:28px; font-size:1px; line-height:1px;" class="em_height">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td align="left" class="em_blue" style="font-family:'Averta', Calibri, Arial, sans-serif; font-size:13px; line-height:16px; color:#0064C8;">
                                    <div id="Text5" class="mktoText" mktoname="Content text"></div>
                                  </td>
                                </tr>
                                <tr>
                                  <td height="62" style="height:62px; font-size:1px; line-height:1px;" class="em_height">&nbsp;</td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <!--//Body Section -->
      </tbody>
    </table>
    <div class="em_hide" style="white-space: nowrap; display: none; font-size:0px; line-height:0px;"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </div>
    <!-- Prevent injection of Marketo Unsubscribe HTML since we're using a custom link -->
    <p>
      <a href="{{system.unsubscribeLink}}" style="display: none; font-size: 0; color: transparent;"></a>
      <br />
    </p>
  </body>
</html>
`;
