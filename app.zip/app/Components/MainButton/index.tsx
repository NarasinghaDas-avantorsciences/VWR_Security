import React from "react";
import {
  TouchableOpacity,
  StyleProp,
  ViewStyle,
  TextStyle,
} from "react-native";
import styles from "./styles";
import CustomText from "../CustomText";
import { COLORS } from "../../Utils/theme";

interface MainButtonProps {
  onChangeBtnPress: () => void;
  title: String;
  buttonTextStyle?: StyleProp<TextStyle>;
  buttonStyle?: StyleProp<ViewStyle>;
  disabled?: boolean;
  accessibilityLabel?: any;
}

const MainButton: React.FC<MainButtonProps> = ({
  title,
  buttonTextStyle,
  buttonStyle,
  onChangeBtnPress,
  accessibilityLabel,
  disabled = false,
  ...props
}) => {
  return (
    <TouchableOpacity
      accessible={true}
      accessibilityLabel={accessibilityLabel}
      style={[
        styles.pressableContainer,
        { backgroundColor: disabled ? COLORS.gray2 : COLORS.scienceBlue },
        buttonStyle,
      ]}
      onPress={onChangeBtnPress}
      disabled={disabled}
      {...props}
    >
      <CustomText
        accessibilityLabel={`${accessibilityLabel}-main_button_label`}
        allowFontScaling={false}
        style={[styles.pressableText, buttonTextStyle]}
      >
        {title}
      </CustomText>
    </TouchableOpacity>
  );
};

export default MainButton;
