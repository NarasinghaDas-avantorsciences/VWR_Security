import { StyleSheet } from "react-native";

import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  pressableContainer: {
    justifyContent: "center",
    alignItems: "center",
    height: hp(6),
    width: wp(45),
  },

  pressableText: {
    color: COLORS.white,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_4,
  },
});

export default Styles;
