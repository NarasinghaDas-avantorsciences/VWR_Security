import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  viewContainer: {
    backgroundColor: COLORS.white,
    width: wp(95),
    alignSelf: "center",
  },

  header: {
    marginVertical: hp(1), //27
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
  },

  rowContainer: { flexDirection: "row", alignItems: "center" },

  monthYear: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
  },

  buttonContainer: { padding: wp(2) },

  btnWrapper: { alignItems: "flex-end" },

  btnContainer: { padding: hp(1) },
});

export default Styles;
