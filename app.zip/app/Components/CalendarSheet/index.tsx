import React from "react";
import { Pressable, View } from "react-native";
import { COLORS } from "../../Utils/theme";
import { Cross, LeftArrow, RightArrow } from "../../Utils/images";
import { hp, wp } from "../../Utils/globalFunction";
import styles from "./styles";
import CalendarPicker from "react-native-calendar-picker";

type CalendarSheetProps = {
  todayDate: string;
  focusedDate: string;
  decrement: () => void;
  increment: () => void;
  changeDate: any;
  onClose?: any;
  addExpiryDate?: (date: Date) => void;
};

const CalendarSheet: React.FC<CalendarSheetProps> = ({
  todayDate,
  focusedDate,
  decrement,
  increment,
  changeDate,
  onClose,
  addExpiryDate,
}) => {
  const LeftIcon = () => {
    return <LeftArrow height={hp(2)} width={hp(2)} />;
  };
  const RightIcon = () => {
    return (
      <RightArrow
        // onPress={incrementYear}
        style={{ marginLeft: wp(2) }}
        height={hp(2)}
        width={hp(2)}
      />
    );
  };
  const onChange = (date: any) => {
    changeDate(date);
    onClose();
  };

  return (
    <View style={styles.viewContainer}>
      <View style={styles.btnWrapper}>
        <Pressable onPress={onClose} style={styles.btnContainer}>
          <Cross />
        </Pressable>
      </View>
      <CalendarPicker
        startFromMonday={false}
        allowRangeSelection={false}
        // minDate={moment(new Date())}
        previousTitle={LeftIcon()}
        nextTitle={RightIcon()}
        // selectMonthTitle={
        //   moment(selectedDate, "MM-DD-YYYY").format("MMMM") + " "
        // }
        select
        todayBackgroundColor={COLORS.aliceBlue}
        selectedDayTextColor="#fff"
        todayTextStyle={{ color: COLORS.abbey }}
        selectedDayColor={COLORS.scienceBlue}
        scaleFactor={375}
        textStyle={{
          color: "#000000",
        }}
        // onDateChange={onChange}
        onDateChange={(date: any) => onChange(date)}
        selectedStartDate={focusedDate}
        initialDate={focusedDate}
        monthTitleStyle={{
          color: COLORS.abbey,
          paddingVertical: hp(1),
        }}
        yearTitleStyle={{
          color: COLORS.abbey,
          paddingVertical: hp(1),
        }}
        disabledDates={(date: Date) => addExpiryDate && addExpiryDate(date)}
      />
    </View>
  );
};

export default CalendarSheet;
