import React from "react";
import {
  TouchableOpacity,
  TextInput,
  View,
  StyleProp,
  ViewStyle,
} from "react-native";
import { useSelector } from "react-redux";
import { COLORS } from "../../Utils/theme";
import { CloseBlack } from "../../Utils/images";
import styles from "./styles";
import CustomText from "../CustomText";

type SearchProps = {
  placeholder?: string;
  search: string;
  onSearch: (text: string) => void;
  cancel?: Boolean;
  onPressCancel: any;
  containerStyle?: StyleProp<ViewStyle>;
  onBarcodeDetected?: (barcode: string) => void;
};

const InnerSearchBar: React.FC<SearchProps> = ({
  placeholder,
  search,
  onPressCancel,
  onSearch,
  cancel = false,
  containerStyle,
  onBarcodeDetected,
}) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);

  return (
    <View style={[styles.mainContainer, containerStyle]}>
      <View
        style={[
          styles.container,
          {
            // borderWidth: cancel ?0.6: 0,
            backgroundColor: COLORS.gray3,
          },
        ]}
      >
        <TextInput
          allowFontScaling={false}
          style={styles.textInput}
          placeholder={placeholder}
          placeholderTextColor={COLORS.gray2}
          value={search}
          onChangeText={onSearch}
        />

        {search.length > 0 && (
          <TouchableOpacity
            style={styles.closeBtnContainer}
            onPress={() => onSearch("")}
          >
            <CloseBlack style={styles.iconStyle} fill={COLORS.black} />
          </TouchableOpacity>
        )}
      </View>

      {cancel && (
        <CustomText style={styles.cancelText} onPress={onPressCancel}>
          {Strings["cancel"]}
        </CustomText>
      )}
    </View>
  );
};

export default InnerSearchBar;
