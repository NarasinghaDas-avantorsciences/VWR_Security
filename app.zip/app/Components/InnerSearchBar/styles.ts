import { StyleSheet } from "react-native";
import { COLORS, FONTS, ICONSIZE, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  mainContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginVertical: hp(1),
  },

  container: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: 38,
    paddingHorizontal: SIZES.base,
  },

  iconStyle: { height: ICONSIZE.h3, width: ICONSIZE.h3 },

  textInput: {
    flex: 1,
    ...FONTS.body2,
    paddingHorizontal: SIZES.base,
    color: COLORS.abbey,
  },

  closeBtnContainer: { paddingHorizontal: SIZES.base },

  cancelText: {
    ...FONTS.title2,
    color: COLORS.scienceBlue,
    marginLeft: SIZES.base,
  },
});

export default Styles;
