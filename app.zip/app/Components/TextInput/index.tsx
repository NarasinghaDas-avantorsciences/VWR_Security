import React from "react";
import {
  View,
  TextInput,
  StyleProp,
  ViewStyle,
  TouchableOpacity,
  TextStyle,
  ReturnKeyTypeOptions,
  NativeSyntheticEvent,
  TextInputSubmitEditingEventData,
} from "react-native";
import { hp, wp } from "../../Utils/globalFunction";
import { COLORS } from "../../Utils/theme";
import styles from "./styles";
import CustomText from "../CustomText";
import { useSelector } from "react-redux";

interface TextInputComponentProps {
  idLabel?: string;
  refs?: any;
  inputStyle?: StyleProp<TextStyle>;
  placeholder?: string;
  value?: string;
  onChangeText?: (val: any) => void;
  main?: StyleProp<ViewStyle>;
  title?: string;
  titleStyle?: StyleProp<TextStyle>;
  LeftIcon?: any;
  RightIcon?: any;
  inputMain?: StyleProp<ViewStyle>;
  onPressLeftIcon?: any;
  disableLeftIcon?: any;
  leftIconHeight?: number;
  leftIconWidth?: number;
  rightIconHeight?: number;
  rightIconWidth?: number;
  onPressRightIcon?: any;
  disableRightIcon?: boolean;
  editable?: boolean;
  placeholderTextColor?: string;
  onFocus?: (event: FocusEvent) => void;
  onBlur?: (event: FocusEvent) => void;
  required?: Boolean;
  requiredStyle?: StyleProp<ViewStyle>;
  returnKeyType?: ReturnKeyTypeOptions;
  returnKeyLabel?: string;
  onSubmitEditing?:
    | ((e: NativeSyntheticEvent<TextInputSubmitEditingEventData>) => void)
    | undefined;
  disabled?: boolean;
  pointerEvents?: "box-none" | "none" | "box-only" | "auto" | undefined;
  charLimit?: number;
}

const TextInputComponent: React.FC<TextInputComponentProps> = ({
  idLabel = "",
  refs,
  LeftIcon,
  RightIcon,
  disabled = false,
  pointerEvents = "auto",
  charLimit = 50,
  onChangeText,
  ...props
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);

  return (
    <TouchableOpacity
      disabled={disabled}
      onPress={() => props?.onPressRightIcon?.()}
      style={[styles.main, props?.main]}
      accessible={true}
      accessibilityLabel={`text-input-main-btn-${idLabel}`}
    >
      <View
        style={{ flexDirection: "row", justifyContent: "space-between" }}
        accessible={true}
        accessibilityLabel={`text-input-main-container-${idLabel}`}
      >
        {props?.title && (
          <CustomText
            allowFontScaling={false}
            style={[styles.title, props?.titleStyle]}
            accessible={true}
            accessibilityLabel={`text-input-title-text-${idLabel}`}
          >
            {props?.title}
          </CustomText>
        )}
        {props?.required && !props?.value && (
          <CustomText
            allowFontScaling={false}
            style={[styles.required, props?.requiredStyle]}
            accessible={true}
            accessibilityLabel={`text-input-required-text-${idLabel}`}
          >
            {strings["required"]}
          </CustomText>
        )}
      </View>

      <View
        style={[
          styles.inputMain,
          props?.inputMain,
          { borderColor: disabled ? COLORS.gray4 : COLORS.abbey },
        ]}
        accessible={true}
        accessibilityLabel={`main-input-view-container-${idLabel}`}
        pointerEvents={pointerEvents}
      >
        <TextInput
          onPressIn={() => props?.onPressRightIcon?.()}
          editable={disabled}
          ref={refs}
          allowFontScaling={false}
          style={[
            styles.input,
            props?.inputStyle,
            {
              color: disabled ? COLORS.gray4 : COLORS.abbey,
            },
          ]}
          placeholderTextColor={COLORS.gray4}
          onChangeText={(value) =>
            value?.length <= charLimit && onChangeText?.(value)
          }
          {...props}
          accessible={true}
          accessibilityLabel={`main-text-input-component-${idLabel}`}
        />
        {RightIcon && (
          <TouchableOpacity
            onPress={() => props?.onPressRightIcon(true)}
            disabled={props?.disableRightIcon}
            accessible={true}
            accessibilityLabel={`main-text-input-right-btn-${idLabel}`}
          >
            <RightIcon
              height={props?.rightIconHeight || hp(2)}
              width={props?.rightIconWidth || hp(2)}
              style={{ paddingRight: wp(3) }}
            />
          </TouchableOpacity>
        )}
      </View>
    </TouchableOpacity>
  );
};

export default TextInputComponent;
