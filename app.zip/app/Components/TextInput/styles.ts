import { StyleSheet } from "react-native";

import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  main: {
    width: wp(85),
    alignSelf: "center",
    backgroundColor: COLORS.white,
  },
  inputMain: {
    borderWidth: 1,
    height: hp(5),
    width: "100%",
    alignSelf: "center",
    backgroundColor: COLORS.white,
    borderColor: COLORS.lightGray,
    flexDirection: "row",
    alignItems: "center",
    paddingRight:wp(2),
    paddingLeft:wp(2),
    paddingHorizontal: wp(2),
  },
  input: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_8,
    fontFamily: FONTFAMILY.averta_semibold,
    flex:1,
    paddingHorizontal: wp(1),
  },
  title: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_semibold,
    marginBottom: hp(1),
  },
  required: {
    color: COLORS.redFast,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_semibold,
    marginBottom: hp(1),
  },
  icon: {
    height: hp(2.6),
    width: hp(2.6),
  },
});

export default Styles;
