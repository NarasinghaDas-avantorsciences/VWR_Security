import React from "react";
import {
  View,
  TouchableOpacity,
  StyleProp,
  ViewStyle,
} from "react-native";
import { Tick } from "../../Utils/images";
import { COLORS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";
import styles from "./styles";
import CustomText from "../CustomText";

interface IconStyleProps {
  height: number;
  width: number;
}
interface ListItemCheckButton {
  onChangeBtnPress?: () => void;
  isSelected: Boolean;
  iconStyle?: IconStyleProps;
  maincontainerStyle?: StyleProp<ViewStyle>;
  title: String;
}

const ListItemCheckButton: React.FC<ListItemCheckButton> = ({
  isSelected,
  title,
  iconStyle,
  maincontainerStyle,
  onChangeBtnPress,
}) => {
  return (
    <View style={[styles.contaier, maincontainerStyle]}>
      {!!title && <CustomText style={styles.pressableText}>{title}</CustomText>}

      <TouchableOpacity
        style={{
          ...styles.pressableContainer,
          borderColor: isSelected ? COLORS.blueLight : COLORS.lightGray,
          backgroundColor: isSelected ? COLORS.scienceBlue : COLORS.white,
        }}
        onPress={onChangeBtnPress}
      >
        {!!isSelected && (
          <Tick
            height={iconStyle?.height ? iconStyle?.height : hp(1.3)}
            width={iconStyle?.width ? iconStyle?.width : wp(5)}
          />
        )}
      </TouchableOpacity>
    </View>
  );
};

export default ListItemCheckButton;
