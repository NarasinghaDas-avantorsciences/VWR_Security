import { StyleSheet } from "react-native";

import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  pressableContainer: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    borderWidth: 1,
    borderColor: COLORS.blueLight,
    backgroundColor: COLORS.scienceBlue,
    height: wp(7),
    width: wp(7),
    borderRadius: wp(7) / 2,
  },

  contaier: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },

  pressableText: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_5,
    marginRight: wp(2),
  },

  buttonContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
});

export default Styles;
