import React, { useCallback, useEffect } from "react";
import {
  ActivityIndicator,
  View,
  Image,
  Modal,
  TouchableOpacity,
} from "react-native";
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from "react-native-responsive-screen";
import { Cross, Loading1 } from "../../Utils/images";
import { isDeviceTablet } from "../../Utils/globalFunction";
import styles from "./styles";
import buttonToastStyles from "../../Components/Toast/styles";
import { useSelector } from "react-redux";
import CustomText from "../CustomText";
import { useFocusEffect } from "@react-navigation/native";
import OutlinedButton from "../OutlinedButton";
import MainButton from "../MainButton";

export const ModalToast = (props: any) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const isTablet = isDeviceTablet();

  // if (props?.isShow) {
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={props?.isShow}
      onRequestClose={() => {
        props?.onClose();
      }}
    >
      <View
        style={{
          position: "absolute",
          bottom: hp(10),
          width: wp(90),
          // paddingHorizontal: wp(2),
          marginHorizontal: wp(5),
          // height: hp(10),
        }}
      >
        <View style={styles.main}>
          <View style={styles.inner}>
            <View style={{ flex: 1 }}>
              <CustomText style={styles.tite}>{props?.title}</CustomText>
              <CustomText style={styles.des}>{props?.discription}</CustomText>
              {props?.isSaveReceipt && (
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <TouchableOpacity
                    style={styles.buttonMain}
                    onPress={() => props?.onPress?.()}
                  >
                    <CustomText style={styles.buttonTitle}>
                      Save Receipt
                    </CustomText>
                  </TouchableOpacity>
                  <View style={{ flex: 1 }} />
                </View>
              )}
            </View>
            <TouchableOpacity onPress={() => props?.onClose()}>
              <Cross height={hp(1.7)} width={hp(1.7)} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
  // }
};
export const ModalToastWithTwoButtons = (props: any) => {
  let styles = buttonToastStyles;
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={props?.isShow}
      onRequestClose={() => {
        props?.onClose();
      }}
    >
      <View
        style={{
          position: "absolute",
          bottom: hp(10),
          width: wp(100),
          // paddingHorizontal: wp(2),
          marginHorizontal: wp(5),
          // height: hp(10),
        }}
      >
        <View style={styles.main}>
          <View style={styles.inner}>
            <View>
              <CustomText style={styles.bottomTitle}>{props?.title}</CustomText>
              <CustomText style={styles.des}>{props?.description}</CustomText>
              <View style={styles.buttonContainers}>
                <OutlinedButton
                  title={"Put-Away Ticket"}
                  onChangeBtnPress={() => props?.onPressLeft()}
                  mainContainerStyle={[styles.outlineBtnContainer]}
                  mainTextStyle={[styles.buttonTitle, { padding: 0 }]}
                />
                <MainButton
                  title={Strings["im.print.barcodes"]}
                  onChangeBtnPress={() => props?.onPressRight()}
                  buttonStyle={styles.outlineBtnContainer}
                  buttonTextStyle={styles.barcodeText}
                />
              </View>
            </View>
            <TouchableOpacity
              onPress={() => {
                props?.onClose();
                // props?.goback();
              }}
            >
              <Cross height={hp(1.7)} width={hp(1.7)} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
  // }
};
