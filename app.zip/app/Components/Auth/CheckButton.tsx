import React from "react";
import { View, StyleSheet, TouchableOpacity } from "react-native";
import { COLORS, FONTS } from "../../Utils/theme";
import { Tick } from "../../Utils/images";
import { hp, wp } from "../../Utils/globalFunction";
import CustomText from "../CustomText";

interface CheckButton {
  label?: string;
  value?: boolean | undefined;
  onChange?: (val: boolean) => void;
  accessibilityLabel?: string;
}

const CheckButton = (props: CheckButton) => {
  const { label, value, onChange, accessibilityLabel } = props;
  return (
    <TouchableOpacity
      accessibilityLabel={accessibilityLabel}
      accessible={true}
      style={styles.container}
      activeOpacity={0.5}
      onPress={() => onChange?.(!value)}
    >
      <View
        style={value ? styles.activeTick : styles.deactiveTick}
        accessible={true}
        accessibilityLabel={`${accessibilityLabel}-tickContainer`}
      >
        <Tick />
      </View>
      <CustomText
        style={styles.labelStyle}
        accessibilityLabel={`${accessibilityLabel}-${label}`}
      >
        {label}
      </CustomText>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    marginVertical: hp(0.8),
  },
  labelStyle: {
    fontWeight: "400",
    marginLeft: wp(1.5),
    fontSize: FONTS.h1_5,
    color: COLORS.abbey,
  },
  activeTick: {
    width: wp(4.5),
    height: wp(4.5),
    backgroundColor: "#0064C8",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: wp(1.3),
  },
  deactiveTick: {
    width: wp(4.5),
    height: wp(4.5),
    borderColor: COLORS.black,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: wp(1.3),
  },
  tickStyle: {
    resizeMode: "contain",
    width: wp(4),
    height: wp(4),
  },
});

export default CheckButton;
