import React from "react";
import {
  AccessibilityProps,
  StyleProp,
  Text,
  TextInputProps,
  TextStyle,
} from "react-native";

interface CustomTextProps extends AccessibilityProps, TextInputProps {
  style?: StyleProp<TextStyle>;
  children?: React.ReactNode;
  accessibilityLabel?: string;
}

const CustomText: React.FC<CustomTextProps> = ({
  style,
  children,
  accessibilityLabel,
  ...props
}) => {
  return (
    <Text
      style={style}
      allowFontScaling={false}
      {...props}
      accessible={true}
      accessibilityLabel={accessibilityLabel}
    >
      {children}
    </Text>
  );
};

export default CustomText;
