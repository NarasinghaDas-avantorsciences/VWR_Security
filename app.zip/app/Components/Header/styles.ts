import { StyleSheet } from "react-native";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

import { FONTS, COLORS } from "../../Utils/theme";
export default StyleSheet.create({
  main: {
    width: "100%",
  },
  container: {
    backgroundColor: COLORS.scienceBlue,
    flexDirection: "row",
    paddingVertical: hp(2),
    alignItems: "center",
  },

  iconRight: { position: "absolute", right: wp(2.5), zIndex: 999 },
  iconLeft: {
    position: "absolute",
    justifyContent: "center",
    alignItems: "center",
    // left: wp(2.5),
    zIndex: 999,
    height: hp(5),
    width: hp(6),
    left: 0,
  },
  icon: {
    height: hp(2.6),
    width: hp(2.6),
  },
  title: {
    flex: 1,
    fontSize: FONTS.h2,
    fontWeight: "700",
    position: "relative",
    textAlign: "center",
  },
  notificationIndicator: {
    position: "absolute",
    backgroundColor: COLORS.green,
    borderWidth: 2,
    borderColor: COLORS.scienceBlue,
    right: 0,
    top: 0,
  },
  subTitleStyle: {
    fontSize: FONTS.h2,
    position: "absolute",
    textAlign: "center",
    right: wp(13),
    color: COLORS.orange,
  },
});
