import React, { useEffect } from "react";
import {
  TouchableOpacity,
  View,
  StyleProp,
  ViewStyle,
  TextStyle,
  Keyboard,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import MyStatusBar from "../StatusBar";
import { Bell, Menu } from "../../Utils/images";
import { COLORS } from "../../Utils/theme";
import { hp, isDeviceTablet, wp } from "../../Utils/globalFunction";
import {
  getMessagesCount,
  getNewsCount,
  getNotificationCount,
} from "../../Redux/Action/communicationActions";
import styles from "./styles";
import CustomText from "../CustomText";

interface Header {
  idLabel?: string;
  statusBar: Boolean;
  statusBarColor: any;
  container?: StyleProp<ViewStyle>;
  onLeftIconPress?: () => void;
  onRightIconPress?: () => void;
  iconLeft?: Boolean;
  iconRight?: Boolean;
  LeftIcon?: any;
  RightIcon?: any;
  title: string;
  subTitle?: string;
  titleStyle?: StyleProp<TextStyle>;
  leftIconHeight?: number;
  leftIconWidth?: number;
  rightIconHeight?: number;
  rightIconWidth?: number;
  statusBarContainerStyle?: StyleProp<ViewStyle>;
}

const Header = ({
  idLabel = "",
  LeftIcon,
  RightIcon,
  onLeftIconPress,
  onRightIconPress,
  ...props
}: Header) => {
  const { notificationCount, messagesCount, newsCount, loader } = useSelector(
    (state: any) => state.communicationReducer
  );
  const dispatch = useDispatch<any>();
  const navigation = useNavigation<any>();
  const isTablet = isDeviceTablet();

  useEffect(() => {
    isNotificationAvailable();
  }, []);

  const isNotificationAvailable = async () => {
    await Promise.all([
      dispatch(getNotificationCount()),
      dispatch(getMessagesCount()),
      dispatch(getNewsCount()),
    ]);
  };

  return (
    <View
      style={styles.main}
      accessible={true}
      accessibilityLabel={`${idLabel}-header-main-container`}
    >
      {props?.statusBar && (
        <MyStatusBar
          backgroundColor={
            props.statusBarColor == "blue" ? COLORS.scienceBlue : COLORS.white
          }
          containerStyle={props.statusBarContainerStyle}
        />
      )}
      <View
        style={[styles.container, props?.container]}
        accessible={true}
        accessibilityLabel={`${idLabel}-header-sub-container`}
      >
        {props.iconLeft && (
          <TouchableOpacity
            style={[styles.iconLeft]}
            onPress={onLeftIconPress}
            accessible={true}
            accessibilityLabel={`${idLabel}-header-left-icon-btn`}
          >
            {LeftIcon ? (
              <LeftIcon
                height={props?.leftIconHeight || hp(2.7)}
                width={props?.leftIconWidth || hp(2.7)}
              />
            ) : (
              <Menu
                height={props?.leftIconHeight || isTablet ? hp(4) : hp(2.7)}
                width={props?.leftIconWidth || isTablet ? hp(4) : hp(2.7)}
              />
            )}
          </TouchableOpacity>
        )}
        <CustomText
          style={[
            styles.title,
            {
              color:
                props.statusBarColor == "blue"
                  ? COLORS.white
                  : COLORS.scienceBlue,
            },
            props?.titleStyle,
          ]}
          accessibilityLabel={`${idLabel}-header-title-label`}
          numberOfLines={1}
        >
          {props?.title}
        </CustomText>
        <CustomText
          style={[styles.subTitleStyle]}
          accessibilityLabel={`${idLabel}-header-subtitle-container`}
        >
          <CustomText accessibilityLabel={`${idLabel}-header-subtitle-label`}>
            {props?.subTitle}
          </CustomText>
        </CustomText>

        {props.iconRight && (
          <TouchableOpacity
            style={[styles.iconRight]}
            onPress={
              onRightIconPress
                ? () => onRightIconPress()
                : () => navigation.navigate("CommunicationCenter")
            }
            accessible={true}
            accessibilityLabel={`${idLabel}-header-right-icon-btn`}
          >
            {RightIcon ? (
              <RightIcon
                height={props?.rightIconHeight || hp(2.7)}
                width={props?.rightIconWidth || hp(2.7)}
              />
            ) : (
              <View>
                <Bell
                  height={props?.rightIconHeight || isTablet ? hp(4) : hp(3)}
                  width={props?.rightIconWidth || isTablet ? hp(4) : hp(3)}
                />
                {notificationCount + messagesCount + newsCount > 0 && (
                  <View
                    style={[
                      styles.notificationIndicator,
                      {
                        height: isTablet ? wp(2.5) : wp(2.5),
                        width: isTablet ? wp(2.5) : wp(2.5),
                        borderRadius: isTablet ? wp(2) : wp(2),
                      },
                    ]}
                  />
                )}
              </View>
            )}
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

export default Header;
