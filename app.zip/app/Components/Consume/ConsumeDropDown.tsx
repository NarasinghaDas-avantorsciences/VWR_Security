import React, { useEffect, useRef, useState } from "react";
import {
  View,
  StyleSheet,
  TouchableOpacity,
  StyleProp,
  ViewStyle,
  Keyboard,
  Pressable,
} from "react-native";
import {
  filterByFiveKeys,
  filterByMultipleKeys,
  hp,
  wp,
} from "../../Utils/globalFunction";
import toaststyles from "../Toast/styles";

import { useDispatch, useSelector } from "react-redux";
import { ArrowDown, Cross } from "../../Utils/images";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import BottomSheetComponent from "../BottomSheet";
import ConsumeBottomSheet from "./ConsumeBottomSheet";
import MainButton from "../MainButton";
import { addOneTimeCostCenter } from "../../Redux/Action/replenishAction";
import { addOneTimeDepartment } from "../../Redux/Action/consumeAction";
import Text from "../CustomText";
import TextInputComponent from "../TextInput";
import ScannerButton from "../ScannerButton";
import {
  onChangeCostSearchLogic,
  onChangeDepartmentLogic,
} from "../../Screens/AppFlow/Consume/logic";
import CustomToast from "../../Screens/AppFlow/Consume/Toast";

interface ConsumeDropdownProps {
  showTitle?: boolean;
  disabled?: boolean;
  title?: string;
  value?: string;
  items?: any;
  userId?: any;
  required?: any;
  buttonEnabled?: any;
  type?: any;
  buttonTitle?: any;
  showToast?: any;
  callBack?: any;
  dropDownContainer?: StyleProp<ViewStyle>;
  onPressItem?: (index: number) => void;
  onSerachTextChanged?: ((text: string) => void) | undefined;
  onBarcodeDetected?: any;
  showScanner?: boolean;
  showInputScanner?: boolean;
  allData?: any;
  baseSelectedValue?: any;
  maxLength?: any;
}

const ConsumeDropdown: React.FC<ConsumeDropdownProps> = ({
  showTitle = true,
  disabled = false,
  title = "",
  value,
  items,
  userId,
  required,
  buttonEnabled,
  type,
  buttonTitle,
  showToast,
  callBack,
  dropDownContainer,
  onPressItem,
  onSerachTextChanged,
  onBarcodeDetected,
  showScanner = true,
  showInputScanner = true,
  allData = [],
  baseSelectedValue,
  maxLength,
}) => {
  const dispatch = useDispatch<any>();
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const [searchText, setSearchText] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [costCenterName, setCostCenterName] = useState("");
  const [departmentName, setDepartmentName] = useState("");
  const [toastData, setToastData] = useState(null);
  const [isShowToast, setIsShowToast] = useState(false);
  const sheetRef = useRef<any>();
  const ref_add_sheet = useRef<any>();
  const toastBottomSheetRef = useRef<any>(null);

  const filterListData = (barcode: any) => {
    let array = [];
    if (type == "cost_center") {
      let costcenters = onChangeCostSearchLogic(barcode, allData);
      costcenters?.map((item, index) => {
        array.push({
          id: item.id,
          title: item.costCenterName,
          selected: items.find((i) => i.id == item.id)?.selected,
        });
      });
    } else if (type == "department") {
      let depts = onChangeDepartmentLogic(barcode, allData);
      depts?.map((item, index) => {
        array.push({
          id: item.id,
          title: item.departmentName,
          selected: items.find((i) => i.id == item.id)?.selected,
        });
      });
    } else if (type == "uom") {
      let uomList = filterByMultipleKeys(allData, "title", "uomCode", barcode);
      uomList?.map((item, index) => {
        array.push({
          id: item.id,
          title: item.title,
          selected: items.find((i) => i.id == item.id)?.selected,
        });
      });
    } else {
      let userDataList = filterByFiveKeys(
        allData,
        "firstName",
        "lastName",
        "loginId",
        "id",
        "vwrUserId",
        barcode
      );
      userDataList?.map((item, index) => {
        array.push({
          id: item.id,
          title: item.firstName + " " + item.lastName,
          selected: items.find((i) => i.id == item.id)?.selected,
        });
      });
    }
    return array;
  };
  useEffect(() => {
    setTimeout(() => {
      setIsShowToast(false);
      setToastData(null);
    }, 2000);
  }, [isShowToast]);

  const setScannedValue = (barcode: any) => {
    let b = barcode;
    if (items?.length) {
      let scannedData: any = filterListData(b);

      if (!scannedData?.length) {
        let errorMessage =
          type == "department"
            ? strings["ime.scanner.Scanner.scanned.department.not.found"] ??
              "Scanner scanned department not found"
            : type == "cost_center"
            ? strings["ime.scanner.Scanner.scanned.costcenter.is.not.found"] ??
              "Scanner scanned costcenter is not found"
            : strings["ime.scanner.invalid.scanned.user"] ??
              "Invalid Scanned User";
        showToast(strings["ime.scanner.Not.Found"], errorMessage);
      } else {
        if (
          scannedData &&
          (scannedData?.[0]?.id == b || scannedData?.[0]?.title == b)
        ) {
          setSearchText(scannedData?.[0]?.title);
        } else {
          setSearchText(b);
        }
        const index = items.findIndex(
          (obj: any) => obj.id === scannedData?.[0]?.id
        );
        setSearchText("");
        onPressItem?.(index);
      }
    }
  };
  const onSubmitEditing = () => {
    /**/

    switch (type) {
      case "cost_center":
        if (costCenterName) {
          const obj = {
            data: {
              costCenterName: costCenterName,
              userId: userId,
              isOneTime: true,
            },
            onSuccess: (res: any) => {
              //showToast("", res?.status || "", "");
              setErrorMessage("");
              Keyboard.dismiss();
              setCostCenterName("");
              setToastData(res?.status ?? "");
              setIsShowToast(true);
              ref_add_sheet.current.close();
              callBack(res);
            },
            onFail: (errorMsg: string) => {
              setErrorMessage(errorMsg);
            },
          };
          dispatch(addOneTimeCostCenter(obj));
        } else {
          setToastData("Cost Center field should not be empty");
          Keyboard.dismiss();
          ref_add_sheet.current.close();
          setIsShowToast(true);
        }
        break;

      case "department":
        if (departmentName) {
          const obj = {
            data: {
              departmentName: departmentName,
              userId: userId,
              isOneTimeDept: true,
            },
            onSuccess: (res: any) => {
              //showToast("", res?.status || "", "");
              setErrorMessage("");
              Keyboard.dismiss();
              setDepartmentName("");
              setToastData(res?.status ?? "");
              setIsShowToast(true);
              ref_add_sheet.current.close();
              callBack(res);
            },
            onFail: (errorMsg: string) => {
              setErrorMessage(errorMsg);
            },
          };
          dispatch(addOneTimeDepartment(obj));
        } else {
          setToastData("Department field should not be empty");
          Keyboard.dismiss();
          ref_add_sheet.current.close();
          setIsShowToast(true);
        }
        break;

      default:
        break;
    }
  };
  const onPressDropDown = () => {
    if (type == "cost_center") {
      if (!!baseSelectedValue) sheetRef?.current?.open();
      else
        showToast(
          strings["cost.center"],
          strings["ime.scanner.select.user.msg"] ?? "Please select user first."
        );
    } else if (type == "department") {
      if (!!baseSelectedValue) sheetRef?.current?.open();
      else
        showToast(
          strings["department"],
          strings["ime.scanner.select.user.msg"] ?? "Please select user first."
        );
    } else {
      sheetRef?.current?.open();
    }
  };
  return (
    <View
      accessible={true}
      accessibilityLabel={"cointainer"}
      style={styles.container}
    >
      {showTitle && (
        <Text accessibilityLabel={"title"} style={styles.dropdownLabel}>
          {title}
          {!!required && (
            <Text
              accessibilityLabel={"label"}
              style={[styles.dropdownLabel, { color: COLORS.red }]}
            >
              {" "}
              *{" "}
            </Text>
          )}
        </Text>
      )}

      <TouchableOpacity
        disabled={disabled}
        accessible={true}
        accessibilityLabel={"dropdown_selected_value_button"}
        style={[
          styles.dropdown,
          dropDownContainer,
          { opacity: disabled ? 0.5 : 1 },
        ]}
        onPress={onPressDropDown}
      >
        <Text
          accessibilityLabel={"dropdown_selected_value"}
          style={[
            styles.dropdownTitle,
            { color: !!value ? COLORS.abbey : COLORS.gray2 },
          ]}
        >
          {value ||
            (!required && (type == "cost_center" || type == "department")
              ? ""
              : strings["select"])}
        </Text>
        <ArrowDown width={wp(3)} height={wp(3)} />
      </TouchableOpacity>
      {showScanner && (
        <TouchableOpacity onPress={() => console.log("")}>
          <ScannerButton
            from="auth"
            onBarcodeDetected={(barcode) => {
              setScannedValue(barcode);
            }}
            disabled={disabled}
          />
        </TouchableOpacity>
      )}

      <BottomSheetComponent
        didCloseModal={() => {
          setSearchText("");
        }}
        bottomSheetRef={sheetRef}
        height={hp(70)}
      >
        <ConsumeBottomSheet
          title={title}
          filterListData={filterListData}
          consumeSheetRef={sheetRef}
          items={items}
          required={required}
          onPressItem={(id) => {
            const index = items.findIndex((item) => item.id == id);
            onPressItem?.(index);
            sheetRef?.current?.close();
            setSearchText("");
          }}
          searchText={searchText}
          onSerachTextChanged={(val) => {
            setSearchText(val);
          }}
          onBarcodeDetected={(barcode) => {
            setSearchText(barcode);
          }}
          showInputScannerBtn={showInputScanner}
          type={type}
          onPressSelect={() => {
            onPressItem?.(-1);
            sheetRef?.current?.close();
          }}
        />
        {!!buttonEnabled && (
          <View style={styles.buttonsContainer}>
            <MainButton
              title={buttonTitle}
              buttonTextStyle={styles.mainText}
              onChangeBtnPress={() => ref_add_sheet.current.open()}
              buttonStyle={styles.addBtnStyle}
            />
          </View>
        )}
        {isShowToast && (
          <View
            style={[
              toaststyles.main,
              { position: "absolute", bottom: hp(10), alignSelf: "center" },
            ]}
          >
            <View style={toaststyles.inner}>
              <View style={{ flex: 1 }}>
                <Text style={toaststyles.tite}>{toastData}</Text>
              </View>
            </View>
          </View>
        )}

        <BottomSheetComponent
          customStyles={{ container: styles.bottomSheetContainer }}
          height={!!errorMessage ? hp(35) : hp(25)}
          bottomSheetRef={ref_add_sheet}
          onOpen={() => {
            setErrorMessage("");
            if (type == "department") {
              setDepartmentName("");
            } else setCostCenterName("");
          }}
        >
          <View style={[styles.headerContainer, {}]}>
            <View style={{ flex: 1 }} />
            <Text style={[styles.headerText, { fontSize: FONTS.h1_9 }]}>
              {buttonTitle}
            </Text>

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.secondaryPressableContainer}
                onPress={() => {
                  setErrorMessage("");
                  ref_add_sheet.current.close();
                }}
              >
                <Text style={styles.closeBtn}>{strings["close"]}</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View>
            <TextInputComponent
              idLabel="consumeDropDown-costcenter-name"
              title={
                type == "department"
                  ? strings["department.name"]
                  : strings["cost.center.name"]
              }
              onPressRightIcon={(isClear?: boolean) => {
                setErrorMessage("");
                if (type == "department") {
                  isClear && setDepartmentName("");
                } else isClear && setCostCenterName("");
              }}
              RightIcon={Cross}
              value={type == "department" ? departmentName : costCenterName}
              editable={true}
              onChangeText={(value) => {
                setErrorMessage("");
                if (type == "department") {
                  setDepartmentName(value);
                } else setCostCenterName(value);
              }}
              main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
              inputStyle={styles.inputStyle}
              inputMain={styles.inputMainStyle}
              returnKeyType="go"
              onSubmitEditing={() => onSubmitEditing()}
              maxLength={50}
            />
            {!!errorMessage ? (
              <Text style={styles.errorMessage}>{errorMessage}</Text>
            ) : null}
          </View>
        </BottomSheetComponent>
      </BottomSheetComponent>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: hp(1),
  },
  stockTxtContainerStyle: {
    width: wp(92),
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginTop: hp(2),
  },

  inputStyle: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h1_5,
    color: COLORS.abbey,
    left: -wp(2),
  },

  inputMainStyle: {
    height: hp(5),
    top: 0,
    borderColor: COLORS.gray2,
    borderWidth: 0.8,
  },
  errorMessage: {
    color: "red",
    fontFamily: FONTFAMILY.averta_regular,
    alignSelf: "center",
    marginTop: hp(1.5),
    marginHorizontal: wp(4),
    marginBottom: hp(5),
  },
  bottomsheetContainer: { width: "100%", height: 120 },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    marginBottom: wp(8),
  },
  headerText: {
    fontSize: FONTS.h2_3,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.doveGray,
    textAlign: "center",
    // flex: 1,
  },
  buttonsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: SIZES.base,
    marginHorizontal: wp(4),
    position: "absolute",
    bottom: 0,
  },
  buttonContainer: {
    flex: 1,
    alignItems: "flex-end",
    marginEnd: wp(5),
  },
  secondaryPressableContainer: {
    justifyContent: "center",
    alignItems: "center",
  },
  bottomSheetContainer: {
    borderTopLeftRadius: hp(1),
    borderTopRightRadius: hp(1),
  },
  closeBtn: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.blue,
    // paddingLeft: wp(6),
    fontFamily: FONTFAMILY.averta_regular,
  },
  mainText: { ...FONTS.title, color: COLORS.white },
  addBtnStyle: { width: "100%", marginVertical: hp(2) },

  dropdownLabel: {
    fontSize: FONTS.h1_9,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    width: "30%",
  },
  dropdownTitle: {
    fontSize: FONTS.h1_7,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
  },
  dropdown: {
    alignItems: "center",
    flexDirection: "row",
    borderColor: COLORS.lightGray,
    borderWidth: 1,
    marginRight: wp(2),
    paddingHorizontal: wp(2),
    paddingVertical: hp(1),
    width: "55%",
    justifyContent: "space-between",
  },
});

export default ConsumeDropdown;
