import React from "react";
import { View, StyleSheet, TouchableOpacity } from "react-native";
import Text from "../../Components/CustomText";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import ConsumeBottomView from "./ConsumeBottomView";
import { Locked } from "../../Utils/images";
import { useSelector } from "react-redux";
import MainButton from "../MainButton";
import { COLORS } from "../../Utils/theme";

interface ConsumeParentView {
  styles: any;
  isConsume: any;
  selectedItem: any;
  selectedItemId: any;
  innerProductDetailsRef: any;
  dispatch: any;
  getProductDetails: any;
  setProductLoader: any;
  checkifBatchEnabled: any;
  checkifExpiryEnabled: any;
  setSelectedItem: any;
  bottomSheetRefDetails: any;
  isProductFreezed: any;
  onChildStateUpdate: any;
  setIsShowWarn: any;
  setIsShowAlert: any;
  isShowWarn: any;
  setIsVisibleMaxconsumptionPopup: any;
  onPressConfirm: any;
  isDisabled: any;
  bottomSheetRef: any;
  offlineCollection: any;
  removeBatchItem?: any;
}

const ConsumeParentView: React.FC<ConsumeParentView> = ({
  styles,
  isConsume,
  selectedItem,
  selectedItemId,
  innerProductDetailsRef,
  dispatch,
  getProductDetails,
  setProductLoader,
  checkifBatchEnabled,
  checkifExpiryEnabled,
  setSelectedItem,
  bottomSheetRefDetails,
  isProductFreezed,
  onChildStateUpdate,
  setIsShowWarn,
  setIsVisibleMaxconsumptionPopup,
  onPressConfirm,
  isDisabled,
  setIsShowAlert,
  isShowWarn,
  bottomSheetRef,
  offlineCollection,
  removeBatchItem,
}) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { stockRoomDetail } = useSelector((state: any) => state.userReducer);
  return (
    <>
      <View
        accessible={true}
        accessibilityLabel={"consume_bottom_sheet_container"}
        style={styles.bottomSheetContainer}
      >
        <Text
          accessibilityLabel={"consume_ottom_sheet_description"}
          style={styles.stockTitle}
          numberOfLines={1}
        >
          {selectedItem?.description}
        </Text>
      </View>
      <KeyboardAwareScrollView
        accessible={true}
        accessibilityLabel={"consume_bottom_sheet_content_container"}
        keyboardDismissMode="none"
        showsVerticalScrollIndicator={false}
        alwaysBounceVertical={false}
        contentContainerStyle={styles.contentContainerStyle}
      >
        <ConsumeBottomView
          isConsume={isConsume}
          removeBatchItem={removeBatchItem}
          offlineCollection={offlineCollection}
          item={selectedItem}
          key={`${selectedItemId}`}
          handleOnSelect={async () => {
            innerProductDetailsRef?.current?.open();
            await dispatch(getProductDetails(selectedItem?.id));
            await dispatch(setProductLoader(false));
          }}
          comment={false} //{!!stockRoomDetail?.isCommentsEnabled}
          showBatch={
            isConsume &&
            (checkifBatchEnabled(selectedItem) ||
              checkifExpiryEnabled(selectedItem))
          }
          onNamePressed={async (item: any) => {
            setSelectedItem(item);
            setTimeout(() => {
              bottomSheetRefDetails?.current?.open();
            }, 500);
            await dispatch(getProductDetails(item?.id));
            await dispatch(setProductLoader(false));
          }}
          freeze={isProductFreezed(selectedItem)}
          bottomBorder={false}
          rightIcon={isProductFreezed(selectedItem) ? <Locked /> : null}
          checkifBatchEnabled={checkifBatchEnabled(selectedItem)}
          checkifExpiryEnabled={checkifExpiryEnabled(selectedItem)}
          bottomSheetRef={bottomSheetRef}
          onChildStateUpdate={onChildStateUpdate}
          showWarn={(val: boolean) => setIsShowWarn(val)}
          showAlert={(val: boolean) => setIsShowAlert(val)}
        />
      </KeyboardAwareScrollView>
      {isShowWarn && (
        <Text style={styles.warningText}>
          {stockRoomDetail.maxConsumptionText}
        </Text>
      )}
      <View
        accessible={true}
        accessibilityLabel={"button_container"}
        style={styles.buttonsContainer}
      >
        <TouchableOpacity
          accessible={true}
          accessibilityLabel={"cancel_button"}
          style={styles.cancelButtonContainer}
          onPress={() => {
            bottomSheetRef?.current?.close?.();
            setIsShowWarn(false);
            setIsShowAlert(false);
            setIsVisibleMaxconsumptionPopup(false);
          }}
        >
          <Text
            accessibilityLabel={"cancel_button_title"}
            style={styles.cancelText}
          >
            {Strings["cancel"]}
          </Text>
        </TouchableOpacity>
        <MainButton
          title={Strings["confirm"]}
          buttonTextStyle={styles.mainText}
          onChangeBtnPress={() => {
            bottomSheetRef?.current?.close();
            onPressConfirm?.();
          }}
          disabled={isDisabled}
          buttonStyle={isDisabled && { backgroundColor: COLORS.gray4 }}
        />
      </View>
    </>
  );
};

const styles = StyleSheet.create({});

export default ConsumeParentView;
