import React from "react";
import { StyleSheet, View } from "react-native";
import { AlertModal, MainButton, OutlinedButton } from "../../Components";
import CustomText from "../CustomText";
import { hp, isDeviceTablet, wp } from "../../Utils/globalFunction";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";

type ConsumeMaxConsumptionQtyPopupProps = {
  didCloseModal?: () => void;
  isShow: boolean;
  orderTitle: String;
  orderDesc: String;
  outlinedButtonTitle: String;
  mainButtonTitle: String;
  didOutlinedButtonClicked: () => void;
  didMainButtonTitleClicked: () => void;
};

const ConsumeMaxConsumptionQtyPopup: React.FC<ConsumeMaxConsumptionQtyPopupProps> = (props) => {
  return (
    <AlertModal
      isShow={props.isShow}
      didCloseModal={props.didCloseModal}
      customStyles={styles.clearModalContainer}
    >
      <View style={styles.clearContainer}>
        <CustomText style={styles.clearOrderTitle}>
          {props.orderTitle}
        </CustomText>
        <CustomText style={styles.clearOrderDesc}>{props.orderDesc}</CustomText>
        <View style={styles.flexRowContainer}>
          <OutlinedButton
            title={props.outlinedButtonTitle}
            onChangeBtnPress={props.didOutlinedButtonClicked}
            mainContainerStyle={styles.cancelContainer}
            mainTextStyle={styles.cancelText}
          />
          <MainButton
            title={props.mainButtonTitle}
            onChangeBtnPress={props.didMainButtonTitleClicked}
            buttonStyle={styles.clearOrderContainer}
            buttonTextStyle={styles.clearOrderText}
          />
        </View>
      </View>
    </AlertModal>
  );
};

const styles = StyleSheet.create({
  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: 'space-between',
    marginTop: hp(1.2)
  },
  clearModalContainer: { borderRadius: 6, width: isDeviceTablet() ? wp(70) : wp(95), padding: isDeviceTablet() ? 20 : 10 },
  clearContainer: {
    alignItems: "center",

  },
  clearOrderTitle: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h2,
    color: COLORS.black,
  },
  clearOrderDesc: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h2,
    color: COLORS.abbey,
    padding: 0,
    marginVertical: hp(1),
  },
  cancelContainer: {
    flex: 1,
    marginTop: hp(1),
    marginLeft: 0,
    borderWidth: 0,
  },
  cancelText: {
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h2,
    color: COLORS.abbey,
    fontWeight: "600",
  },
  clearOrderContainer: {
    flex: 1,
    marginTop: hp(1),
    backgroundColor: COLORS.scienceBlue
  },
  clearOrderText: {
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.white,
    fontSize: FONTS.h2,
    fontWeight: "700",
  },
})


export default ConsumeMaxConsumptionQtyPopup;
