import React from "react";
import { Image, Pressable, TouchableOpacity, View } from "react-native";
import { ConsumeTag, ListItem } from "../../Components";
import { useDispatch, useSelector } from "react-redux";
import styles from "../../Screens/AppFlow/Consume/styles";
import { DefaultProductImage, Locked, TickGreen } from "../../Utils/images";
import Text from "../../Components/CustomText";
import {
  getProductBatchDetails,
  setProductBatchLoader,
} from "../../Redux/Action/searchAction";
import { wp } from "../../Utils/globalFunction";
import { COLORS } from "../../Utils/theme";

interface ConsumeBatchListItem {
  checkifTheItemExistInOrder: any;
  index: any;
  disabled: any;
  productsData: any;
  itemFooter: any;
  setSelectedItem: any;
  checkifBatchEnabled: any;
  checkifExpiryEnabled: any;
  bottomSheetRef: any;
  errorCallBack: any;
  showToast: any;
  item: any;
  batchSaved: any;
  setChildState?: any;
  isOnline: any;
}

const ConsumeBatchListItem = (props: ConsumeBatchListItem) => {
  const {
    checkifTheItemExistInOrder,
    index,
    disabled,
    productsData,
    itemFooter,
    setSelectedItem,
    checkifBatchEnabled,
    checkifExpiryEnabled,
    bottomSheetRef,
    errorCallBack,
    showToast,
    item,
    batchSaved,
    setChildState,
    isOnline,
  } = props;
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const getBatches = async () => {
    dispatch(setProductBatchLoader(true));
    await dispatch(
      getProductBatchDetails(
        item?.id ?? "",
        (data: any) => {
          dispatch(setProductBatchLoader(false));
          item["batches"] = data;
          setChildState?.(null);
          setSelectedItem(item);
          bottomSheetRef?.current?.open();
        },
        () => {
          dispatch(setProductBatchLoader(false));
          errorCallBack();
        }
      )
    );
  };
  const onPressItem = async (item) => {
    if (isOnline) {
      if (!checkifTheItemExistInOrder(item.id)) {
        await getBatches();
      } else {
        showToast(
          Strings["ime.scanner.error.occured.msg"],
          Strings["ime.scanner.Item.already.exists.in.the.order"]
        );
      }
    } else {
      /**offline */
      if (!item.batches?.length) await getBatches();
      else {
        setChildState?.(null);
        setSelectedItem(item);
        bottomSheetRef?.current?.open();
      }
    }
  };
  const renderItemHeader = (item: any) => {
    const uomId =
      item?.uomManagementEnabled == 1 ? item.stockRoomUOMUnit : item.uomId;
    return (
      <>
        <Text
          accessibilityLabel="catalog_no_value"
          style={styles.catalogNumber}
        >
          {item?.catalogNo}
        </Text>
        <TouchableOpacity
        accessible={true}
        disabled={disabled}
        accessibilityLabel="item_header_button"
        onPress={() => (disabled ? null : onPressItem(item))}
      >
        <Text
          accessibilityLabel="description_value"
          style={styles.itemHeaderContent}
        >
          {item?.description}
        </Text>
        </TouchableOpacity>
        {(!!checkifBatchEnabled(item) || !!checkifExpiryEnabled(item)) && (
          <View
            accessible={true}
            accessibilityLabel="tag_container"
            style={styles.tagContainer}
          >
            {!!checkifBatchEnabled(item) && (
              <ConsumeTag tag="Batch Controlled" />
            )}
            {!!checkifExpiryEnabled(item) && (
              <ConsumeTag tag="Expiry Date Controlled" />
            )}
          </View>
        )}
        {!!uomId && (
          <View
            accessible={true}
            accessibilityLabel="item_uomid_container"
            style={styles.qtyInfoContainer}
          >
            <Text
              accessibilityLabel="item_uomid_value"
              style={styles.itemSubHeaderStyle}
            >{`(${uomId})`}</Text>
          </View>
        )}
      </>
    );
  };
  const DetailItem = ({ value, title }) => {
    return (
      <View
        accessible={true}
        accessibilityLabel={"detail_item_container"}
        style={[styles.itemChildContainer]}
      >
        <Text
          accessibilityLabel={"item_title "}
          style={styles.itemChildTitleText}
        >
          {title}
        </Text>
        <Text
          accessibilityLabel={"item_value"}
          style={styles.itemChildValueText}
        >
          {value}
        </Text>
      </View>
    );
  };

  return (
    <ListItem
      disabled={disabled}
      leftIcon={
        <View
          accessible={true}
          accessibilityLabel={"left_icon_cointainer"}
          style={styles.leftIconContainer}
        >
          {!!item.imagePath || !!item?.imageURL ? (
            <Image
              accessible={true}
              accessibilityLabel={"item_image"}
              source={{
                uri: item.imagePath
                  ? `https://vsr-stage4.vwr.com/${item?.imagePath}`
                  : item?.imageURL.replace("http://", "https://"),
              }}
              style={styles.leftIcon}
              resizeMode={"contain"}
            />
          ) : (
            <DefaultProductImage
              accessible={true}
              accessibilityLabel={"default_image"}
              width={wp(18)}
              height={wp(18)}
            />
          )}
        </View>
      }
      headerContent={renderItemHeader(item)}
      rightIcon={
        item?.freeze == true ? (
          <Locked
            accessible={true}
            accessibilityLabel="consume-item-locked-image"
          />
        ) : batchSaved ? (
          <View
            style={{
              borderWidth: 2,
              height: wp(6),
              width: wp(6),
              borderRadius: 20,
              borderColor: COLORS.blueLight,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <TickGreen
              height={wp(5.5)}
              width={wp(5.5)}
              accessible={true}
              accessibilityLabel="consume-item-checked-image"
            />
          </View>
        ) : null
      }
      customStyles={{ container: styles.itemContainerStyle }}
      onPress={() => onPressItem(item)}
    >
      {!!isOnline && (
        <View
          accessible={true}
          accessibilityLabel={"row_flex_container"}
          style={styles.flexRowContainer}
        >
          <DetailItem
            value={item?.availableQty}
            title={Strings["ime.availqty"] ?? "Avail Qty"}
          />
          <DetailItem value={item?.vendorName} title={Strings["vendor"]} />
        </View>
      )}
      {!!(index == productsData?.data?.length - 1) && itemFooter()}
    </ListItem>
  );
};
export default ConsumeBatchListItem;
