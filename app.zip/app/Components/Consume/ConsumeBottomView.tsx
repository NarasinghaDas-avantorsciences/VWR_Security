import React, { useEffect, useState } from "react";
import {
  Image,
  View,
  StyleProp,
  ViewStyle,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { setProductLoader } from "../../Redux/Action/searchAction";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { getMultiplier, hp, wp } from "../../Utils/globalFunction";
import { DefaultProductImage } from "../../Utils/images";
import QtyController from "../QtyController";
import TextInputComponent from "../TextInput";
import ListItem from "../ListItem";
import AddBatch from "../ConsumeAddBatch";
import CustomText from "../CustomText";
import ConsumeTag from "./ConsumeTag";
import MainButton from "../MainButton";

type Props = {
  item: any;
  id?: string;
  handleOnSelect?: any;
  onNamePressed?: any;
  freeze?: boolean;
  comment?: Boolean;
  bottomBorder?: Boolean;
  rightIcon?: any;
  containerStyle?: StyleProp<ViewStyle>;
  showBatch?: boolean;
  checkifBatchEnabled: any;
  checkifExpiryEnabled: any;
  bottomSheetRef: any;
  onChildStateUpdate: any;
  isConsume: any;
  showWarn?: any;
  showAlert?: any;
  offlineCollection?: any;
  removeBatchItem?: any;
};

const ConsumeBottomView: React.FC<Props> = ({
  item,
  id,
  handleOnSelect,
  onNamePressed,
  freeze = false,
  comment = false,
  bottomBorder = true,
  rightIcon = null,
  containerStyle,
  showBatch,
  checkifBatchEnabled,
  checkifExpiryEnabled,
  bottomSheetRef,
  onChildStateUpdate,
  isConsume,
  showWarn,
  showAlert,
  offlineCollection,
  removeBatchItem,
}) => {
  const dispatch = useDispatch<any>();
  const [qty, setQty] = useState(
    // item?.availableQty ? `${item?.availableQty}` :
    "0"
  );
  const [comments, setComments] = useState("");
  const [batchArray, setBatchArray] = useState([]);
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const [isBatchEmpty, setIsBatchEmpty] = useState(false);
  const { stockRoomDetail, consumeCustomPrivilage } = useSelector(
    (state: any) => state.userReducer
  );
  const { data } = useSelector((state: any) => state.accountReducer);
  useEffect(() => {
    setQty(
      // item?.availableQty ? item?.availableQty :
      item?.actualQty ?? 0
    );
    let batches = [];
    item?.batches?.map((i: any) => {
      const { batchNo, actualQty, availableQty, id, expiryDate } = i;
      if (parseInt(availableQty) > 0) {
        batches.push({
          batchNo,
          actualQty,
          availableQty,
          id,
          expiryDate,
        });
      }
    });
    setIsBatchEmpty(!batches.length);
    setBatchArray(batches);
    updatechild(batches.length ? item.actualQty : 0, "", batches, item.id);
  }, []);
  const updatechild = (
    actualQty: any,
    comments: any,
    batches?: any,
    itemId?: any
  ) => {
    //IF condition for warning msg
    // console.error("IETMMM: ", item, "======", stockRoomDetail);
    if (
      stockRoomDetail?.isMaximumConsumptionEnabled &&
      item?.maxConsumptionQuantity != null
    ) {
      if (Number(actualQty) > item?.maxConsumptionQuantity) {
        if (stockRoomDetail?.isOverConsume) {
          showWarn(false);
          showAlert(true);
        } else {
          showWarn(true);
        }
      } else {
        showWarn(false);
      }
    }
    if (isConsume && batches?.length > 0) {
      actualQty = batches?.reduce((aQty, item) => {
        return aQty + (!!item?.actualQty ? parseInt(item?.actualQty) : 0);
      }, 0);
    }
    let child = {
      batches: batches,
      actualQty: actualQty ?? 0,
      comments: comments,
      id: itemId,
    };
    onChildStateUpdate(child);
  };
  const handleBatch = (batches: any, batchId: string, itemId: string) => {
    setBatchArray(batches);
    updatechild(qty, comments, batches, itemId);
  };
  const handleBatchDelete = async (index: any) => {
    let batches = batchArray;
    batches.splice(index, 1);
    setBatchArray(batches);
  };
  const setFormatedData = async (value) => {
    setBatchArray(value);
  };
  const uomId =
    item?.uomManagementEnabled == 1 ? item?.stockRoomUOMUnit : item?.uomId;
  return (
    <View
      accessible={true}
      accessibilityLabel={"consume_bottom_view_container"}
      style={[
        styles.container,
        bottomBorder && { borderBottomWidth: bottomBorder ? 1 : 0 },
        containerStyle,
      ]}
    >
      <ListItem
        key={id}
        leftIcon={
          <View
            accessible={true}
            accessibilityLabel={"left_iconr"}
            style={styles.leftIconContainer}
          >
            {!!item?.imagePath || !!item?.imageURL ? (
              <Image
                accessible={true}
                accessibilityLabel={"consume_bottom_view_image"}
                source={{
                  uri: item?.imagePath
                    ? `https://vsr-stage4.vwr.com/${item?.imagePath}`
                    : item?.imageURL.replace("http://", "https://"),
                }}
                style={styles.leftIcon}
                resizeMode={"contain"}
              />
            ) : (
              <DefaultProductImage
                accessible={true}
                accessibilityLabel={"consume_bottom_view_default_image"}
                width={wp(20)}
                height={wp(20)}
              />
            )}
          </View>
        }
        headerContent={
          <View
            accessible={true}
            accessibilityLabel={"consume_bottom_sheet_container"}
            style={styles.headerContainerStyle}
          >
            <CustomText
              accessibilityLabel={"catalog_number_value"}
              style={styles.catalogNumber}
            >
              {item?.catalogNo}
            </CustomText>
            <TouchableOpacity onPress={() => handleOnSelect?.()}>
              <CustomText
                accessibilityLabel={"description_value"}
                style={styles.itemHeaderContent}
              >
                {item?.description}
              </CustomText>
            </TouchableOpacity>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              {
                <View
                  accessible={true}
                  accessibilityLabel={"uomid_container"}
                  style={styles.qtyInfoContainer}
                >
                  {uomId && (
                    <CustomText
                      accessibilityLabel={"uomid_value"}
                      style={styles.itemSubHeaderStyle}
                    >
                      ({uomId})
                    </CustomText>
                  )}
                </View>
              }
              {offlineCollection && (
                <View style={styles.offlineQtyContainer}>
                  <CustomText
                    allowFontScaling={false}
                    accessibilityLabel="consume_offline_list_title"
                    style={styles.offlineQty}
                  >
                    {strings["ime.scanner.Offline.Qty"] + " "}
                  </CustomText>

                  <CustomText
                    allowFontScaling={false}
                    accessibilityLabel="consume_offline_list_title"
                    style={styles.offlineQty}
                  >
                    {batchArray?.reduce((aQty, item) => {
                      return (
                        aQty +
                        (!!item?.actualQty ? parseInt(item?.actualQty) : 0)
                      );
                    }, 0)}
                  </CustomText>
                </View>
              )}
            </View>
            {showBatch && (
              <View
                accessible={true}
                accessibilityLabel="product_batch_expiry_label_container"
                style={styles.tagContainer}
              >
                {!!checkifBatchEnabled && <ConsumeTag tag="Batch Controlled" />}
                {!!checkifExpiryEnabled && (
                  <ConsumeTag tag="Expiry Date Controlled" />
                )}
              </View>
            )}
          </View>
        }
        onPress={() => {}}
        rightIcon={rightIcon}
      >
        {!showBatch && (
          <View
            accessible={true}
            accessibilityLabel={"flexrow_container"}
            style={styles.flexRowContainer}
          >
            <View
              accessible={true}
              accessibilityLabel={"item_child_container"}
              style={[styles.itemChildContainer]}
            >
              <CustomText
                accessibilityLabel={"item_child_title"}
                style={styles.itemChildTitleText}
              >
                {strings["ime.avail.qty"]}
              </CustomText>
              <CustomText
                accessibilityLabel={"item_child_value"}
                style={styles.itemChildValueText}
              >
                {/* {!!item?.availableQty ? item?.availableQty : 0} */}
                {`${item?.availableQty + " "}${
                  getMultiplier(item) == null ? " " : getMultiplier(item)
                }`}
              </CustomText>
            </View>
            <View
              accessible={true}
              accessibilityLabel={"item_child_container"}
              style={[styles.itemChildContainer]}
            >
              <CustomText
                accessibilityLabel={"item_child_title"}
                style={styles.itemChildTitleText}
              >
                {strings["vendor"]}
              </CustomText>
              <CustomText
                accessibilityLabel={"item_child_value"}
                style={styles.itemChildValueText}
              >
                {item?.vendorName}
              </CustomText>
            </View>
          </View>
        )}
      </ListItem>
      {!showBatch && (
        <View
          accessible={true}
          accessibilityLabel={"container"}
          style={{ flexDirection: "row" }}
        >
          {!!comment && (
            <View
              accessible={true}
              accessibilityLabel={"comment_container"}
              style={styles.commentContainer}
            >
              <CustomText
                accessibilityLabel={"comment"}
                style={styles.itemText}
              >
                {strings["ime.comment"]}
              </CustomText>
              <TextInputComponent
                idLabel="consumeBottomView-comment-input"
                value={""}
                onChangeText={(text) => {
                  setComments(text);
                  updatechild(qty, text, batchArray, item.id);
                }}
                title={""}
                editable={true}
                main={styles.commentMain}
                inputStyle={styles.inputStyle}
                required={false}
                placeholder={
                  strings["ime.scanner.enter.comment"] ?? "Enter comment"
                }
              />
            </View>
          )}
          <View
            accessible={true}
            accessibilityLabel={"qty_container"}
            style={[
              styles.center,
              { paddingTop: SIZES.padding, marginStart: !!comment ? wp(9) : 0 },
            ]}
          >
            <CustomText
              accessibilityLabel={"qty"}
              style={[
                styles.itemText,
                { fontSize: FONTS.h1_9, marginTop: wp(1) },
              ]}
            >
              {strings["ime.qty"]}
            </CustomText>

            <QtyController
              onChange={(val: React.SetStateAction<string>) => {
                setQty(val);
                updatechild(val, comments, batchArray, item.id);
              }}
              showLabel={false}
              inputStyle={styles.controllerInputStyle}
              inputValue={qty}
              disable={
                freeze ||
                (isConsume &&
                  (item?.expiryDateManagementenabled != 0 ||
                    item?.batchManagementEnabled != 0))
              }
            />
          </View>
        </View>
      )}
      <>
        {showBatch &&
        !isBatchEmpty &&
        !(
          consumeCustomPrivilage == "request" && data?.userType != "SUPER_USER"
        ) ? (
          <AddBatch
            item={item}
            onChange={handleBatch}
            onDelete={handleBatchDelete}
            updateActualQty={(val: any) => {
              setQty(val);
            }}
            setLoader={(val: boolean) => dispatch(setProductLoader(val))}
            data={batchArray}
            formatedData={batchArray}
            setFormatedData={setFormatedData}
            uomId={uomId}
            availableQty={item.availableQty}
            showWarn={(val: boolean) => showWarn(val)}
            showAlert={(val: boolean) => showAlert(val)}
            freeze={freeze}
            from="item_confirm"
          />
        ) : (
          isBatchEmpty &&
          offlineCollection && (
            <View
              accessible={true}
              accessibilityLabel={"empty_container"}
              style={styles.emptyContainer}
            >
              <CustomText
                accessibilityLabel={"empoty_container_label"}
                style={[styles.itemText, { fontSize: FONTS.h1_9 }]}
              >
                No Batch No. or Expiry Date information available. Product
                cannot be consumed. Remove product from List to proceed.
              </CustomText>
              <MainButton
                accessibilityLabel={"empty_container_button"}
                title={strings["remove"]}
                onChangeBtnPress={() => removeBatchItem?.(item)}
                buttonStyle={styles.emptyButtonStyle}
                buttonTextStyle={{ color: COLORS.white }}
              />
            </View>
          )
        )}
      </>
      {!showBatch && (
        <View
          accessible={true}
          accessibilityLabel={"spacer"}
          style={{
            width: "100%",
            height: 1,
            backgroundColor: COLORS.grayLight,
            marginVertical: wp(2),
          }}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainerStyle: { flex: 1, marginTop: -wp(2) },
  tagContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: hp(0.4),
  },
  offlineQtyContainer: {
    // marginTop: wp(-4),
    paddingVertical: hp(0.8),
    alignSelf: "flex-end",
    flexDirection: "row",
    marginHorizontal: wp(2),
    alignItems: "center",
  },
  offlineQty: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_6,
  },

  contentContainerStyle: {
    flexGrow: 1,
    paddingBottom: hp(6),
  },
  buttonsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: SIZES.base,
    position: "absolute",
    bottom: wp(6),
    zIndex: 1000,
  },
  emptyButtonStyle: { width: wp(40), marginTop: wp(2) },
  emptyContainer: {
    flex: 1,
    marginTop: wp(10),
    alignItems: "center",
    justifyContent: "center",
  },
  cancelText: { ...FONTS.body, color: COLORS.gray },

  cancelButtonContainer: {
    width: "50%",
    alignItems: "center",
    padding: SIZES.padding,
  },
  container: {
    paddingTop: SIZES.padding,
    borderBottomColor: COLORS.whiteSmoke,
    marginHorizontal: SIZES.padding,
    marginBottom: wp(8),
  },
  rowContainer: { flexDirection: "row", alignItems: "flex-start" },
  image: {
    height: SIZES.width * 0.2,
    width: SIZES.width * 0.2,
    borderWidth: 1,
    borderColor: COLORS.gray2,
  },
  idText: {
    ...FONTS.body2,
    color: COLORS.gray,
    marginBottom: SIZES.base,
  },
  titleText: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
    marginBottom: SIZES.base,
  },
  caseText: {
    ...FONTS.title2,
    color: COLORS.gray,
    marginBottom: SIZES.base,
    backgroundColor: COLORS.whiteSmoke,
    alignSelf: "flex-start",
  },
  itemText: {
    ...FONTS.title2,
    color: COLORS.gray,
    marginBottom: SIZES.tip,
    marginEnd: wp(2),
  },
  valueText: { ...FONTS.body, color: COLORS.gray },
  reasonContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    marginTop: SIZES.base,
  },
  center: {
    alignItems: "center",
    flex: 1,
    flexDirection: "row",
    marginStart: wp(9),
  },
  controllerInputStyle: {
    ...FONTS.body,
    paddingVertical: SIZES.base,
    paddingHorizontal: SIZES.tip,
  },
  commentMain: {
    width: "100%",
  },
  inputStyle: {
    width: "100%",
    paddingLeft: 0,
  },
  commentContainer: {
    marginTop: hp(2),
    flex: 1,
    marginEnd: wp(2),
  },
  locationMain: {
    width: "50%",
    marginTop: hp(2),
  },
  // ListItem
  leftIconContainer: { marginRight: wp(4) },
  leftIcon: { width: wp(20), height: wp(20) },
  productDetailsImageStyle: { height: wp(20), width: wp(20) },
  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },
  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },
  qtyInfoContainer: { paddingVertical: hp(0.8) },
  itemSubHeaderStyle: {
    alignSelf: "flex-start",
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
  },

  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  itemChildContainer: {
    width: SIZES.width * 0.4,
    marginVertical: wp(0.5),
    paddingVertical: 8,
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },
});
export default ConsumeBottomView;
