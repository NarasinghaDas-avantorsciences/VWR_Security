import React from "react";
import { View, StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";
import CustomText from "../CustomText";

interface ConsumeTag {
  tag: string;
}

const ConsumeTag = (props: ConsumeTag) => {
  const { tag, } = props;
  return (
    <View accessible={true} accessibilityLabel={"tag_cointainer"} style={styles.container}>
      <CustomText accessibilityLabel={"tag_label"} allowFontScaling={false} style={styles.tag}>{tag}</CustomText>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.abbey,
    paddingHorizontal: wp(1.5),
    borderRadius: wp(6),
    paddingVertical: hp(0.8),
    marginRight: wp(1)

  },
  tag: {
    color: COLORS.white,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_1
  },
});

export default ConsumeTag;
