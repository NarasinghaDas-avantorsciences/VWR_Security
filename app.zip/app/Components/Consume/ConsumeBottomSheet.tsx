import React from "react";
import {
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Platform,
  Keyboard,
} from "react-native";
import { useSelector } from "react-redux";
import { filterByMultipleKeys, hp, wp } from "../../Utils/globalFunction";
import { COLORS, FONTFAMILY } from "../../Utils/theme";
import { Check, SearchIcon } from "../../Utils/images";
import Text from "../CustomText";
import ScannerButton from "../ScannerButton";
import Header from "../Header";
import AnimatedSearch from "../AnimatedSearch";

interface ConsumeBottomSheet {
  title: string;
  items: any;
  onPressItem: (index: number) => void;
  searchText?: string;
  type?: string;
  onPressSelect?: any;

  onSerachTextChanged?: ((text: string) => void) | null;
  onBarcodeDetected?: (barcode: string) => void;
  showInputScannerBtn?: boolean;
  consumeSheetRef?: any;
  filterListData?: any;
  required?: any;
}

const ConsumeBottomSheet = (props: ConsumeBottomSheet) => {
  const {
    title,
    items,
    onPressItem,
    searchText,
    type,
    onPressSelect,
    onSerachTextChanged,
    onBarcodeDetected,
    showInputScannerBtn,
    consumeSheetRef,
    filterListData,
    required,
  } = props;
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const flatListData = !!searchText ? filterListData(searchText) : items;
  const noDataFound = () => {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>{strings["no.records.found"]}</Text>
      </View>
    );
  };
  return (
    <ScrollView
      accessible={true}
      accessibilityLabel={"cointainer"}
      style={styles.container}
      contentContainerStyle={styles.outerContainerStyle}
      overScrollMode="never"
      keyboardShouldPersistTaps={"handled"}
    >
      <Header
        title={title}
        titleStyle={styles.headerText}
        container={styles.header}
        onRightIconPress={() => {
          onSerachTextChanged?.("");
          consumeSheetRef?.current?.close();
        }}
        statusBar={true}
        statusBarColor={COLORS.white}
        statusBarContainerStyle={Platform.OS === "android" && { height: 0 }}
        iconLeft={false}
        iconRight={true}
        RightIcon={() => (
          <View style={styles.closeContainer}>
            <Text style={styles.closeText}>{strings["close"]}</Text>
          </View>
        )}
      />

      {/* <View
        accessible={true}
        accessibilityLabel={"consume_bottomsheet_input_container"}
        style={styles.inputContainer}
      >
        <SearchIcon
          accessible={true}
          accessibilityLabel={"consume_bottomsheet_search_icon"}
          width={wp(4.5)}
          height={wp(4.5)}
        />
        <TextInput
          accessible={true}
          accessibilityLabel={"consume_bottomsheet_search_input"}
          allowFontScaling={false}
          placeholder={strings["search"]}
          placeholderTextColor={COLORS.abbey}
          style={styles.inputStyle}
          value={searchText}
          onChangeText={onSerachTextChanged}
        />
        {showInputScannerBtn && (
          <TouchableOpacity
            accessible={true}
            accessibilityLabel={"consume_bottomsheet_scan_icon"}
            onPress={() => console.log("")}
          >
            <ScannerButton
              from="consume"
              mainButtonStyle={styles.mainButtonStyle}
              onBarcodeDetected={onBarcodeDetected}
            />
          </TouchableOpacity>
        )}
      </View> */}
      <AnimatedSearch
        search={searchText ?? ""}
        onSearch={onSerachTextChanged}
        containerStyle={{}}
        placeholder={strings["search"]}
        clearText={() => {
          onSerachTextChanged?.("");
        }}
        onBarcodeDetected={(barcode) => {
          let Arr =
            flatListData &&
            flatListData.filter(
              (item: any) => String(item?.id) == String(barcode)
            );
          if (Arr && Arr?.length > 0) onBarcodeDetected(Arr[0]?.title);
          else {
            onBarcodeDetected(barcode);
          }
        }}
        from={"Replenish"}
        onCancel={() => {
          onSerachTextChanged?.("");
          Keyboard.dismiss();
        }}
      />

      <ScrollView
        accessible={true}
        accessibilityLabel={"consume_bottomsheet_scrollview"}
      >
        {!!flatListData?.length &&
          // !required &&
          (type == "cost_center" || type == "department") &&
          !searchText && (
            <TouchableOpacity
              accessible={true}
              accessibilityLabel={"consume_bottomsheet_element_button"}
              style={styles.itemContainer}
              onPress={() => onPressSelect()}
              activeOpacity={0.8}
            >
              <Text
                accessibilityLabel={"consume_bottomsheet_element_title"}
                style={styles.itemText}
              >
                {strings["select"]}
              </Text>
            </TouchableOpacity>
          )}
        {flatListData?.map((element, index) => {
          return (
            <TouchableOpacity
              accessible={true}
              accessibilityLabel={"consume_bottomsheet_element_button"}
              key={index.toString()}
              style={styles.itemContainer}
              onPress={() => onPressItem(element.id)}
              activeOpacity={0.8}
            >
              <Text
                accessibilityLabel={"consume_bottomsheet_element_title"}
                style={
                  element?.selected ? styles.selectedItemText : styles.itemText
                }
              >
                {element.title}
              </Text>
              {element?.selected ? (
                <Check
                  accessible={true}
                  accessibilityLabel={"consume_bottomsheet_check_icon"}
                />
              ) : null}
            </TouchableOpacity>
          );
        })}
      </ScrollView>
      {flatListData?.length === 0 && !!searchText ? noDataFound() : null}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: wp(3),
  },
  outerContainerStyle: { paddingBottom: hp(10) },
  mainButtonStyle: {
    width: wp(6.5),
    height: wp(6.5),
    backgroundColor: COLORS.white,
  },
  emptyContainer: { alignItems: "center", justifyContent: "center" },
  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: COLORS.white,
  },
  headerText: {
    color: COLORS.abbey,
    fontSize: wp(5),
    fontFamily: FONTFAMILY.averta_semibold,
  },
  closeContainer: { padding: hp(2), paddingRight: 0 },
  closeText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: wp(4.2),
  },
  inputContainer: {
    flexDirection: "row",
    backgroundColor: COLORS.whiteSmoke,
    alignItems: "center",
    paddingHorizontal: wp(3),
    marginVertical: hp(3),
  },
  inputStyle: {
    flex: 1,
    paddingHorizontal: wp(3),
    paddingVertical: hp(1),
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: wp(3.6),
    color: COLORS.abbey,
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: COLORS.alto,
    paddingVertical: hp(1),
    paddingRight: wp(3),
  },
  itemText: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: wp(4),
  },
  initialselectText: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: wp(3.3),
    fontStyle: "italic",
  },
  selectedItemText: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: wp(4),
  },
  noFoundText: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: wp(4),
    alignSelf: "center",
    marginTop: hp(5),
    color: COLORS.abbey,
  },
});

export default ConsumeBottomSheet;
