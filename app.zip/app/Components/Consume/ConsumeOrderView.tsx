import React, { useEffect, useState } from "react";
import { View, StyleSheet, Image, TouchableOpacity } from "react-native";
import {
  getCurrencySymbol,
  getMultiplier,
  hp,
  wp,
} from "../../Utils/globalFunction";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { DefaultProductImage, TickIcon } from "../../Utils/images";
import QtyController from "../QtyController";
import { useDispatch, useSelector } from "react-redux";
import {
  ConsumeTag,
  InnerSearchBar,
  ListItem,
  TextInputComponent,
} from "../../Components";
import AddBatch from "../ConsumeAddBatch";
import Text from "../CustomText";
import { setProductLoader } from "../../Redux/Action/searchAction";

interface ConsumeOrderView {
  data: any;
  onPressItemCheck?: (index: number) => void;
  onPressSelectAll?: (state: boolean) => void;
  checkifExpiryEnabled: any;
  isConsume: any;
  checkifBatchEnabled: any;
  totalPrice: any;
  itemPrice:any,
  handleBatch: any;
  handleAvailQty: any;
  onNamePressed: any;
  item: any;
  id?: string;
  handleOnSelect?: any;
  freeze?: boolean;
  comment?: Boolean;
  bottomBorder?: Boolean;
  rightIcon?: any;
  containerStyle?: StyleProp<ViewStyle>;
  onChangeCommentText: any;
  setFormatedData: any;
  showWarn?: any;
  showAlert?: any;
}

const ConsumeOrderView = (props: ConsumeOrderView) => {
  const { stockRoomDetail, org_details, organizationName, stockroomName } =
    useSelector((state: any) => state.userReducer);
  const [qty, setQty] = useState(
    item?.availableQty ? `${item?.availableQty}` : "0"
  );
  const {
    data,
    onPressItemCheck,
    onPressSelectAll,
    onNamePressed,
    checkifBatchEnabled,
    checkifExpiryEnabled,
    isConsume,
    handleBatch,
    totalPrice,
    itemPrice,
    handleAvailQty,
    onChangeCommentText,
    item,
    id,
    handleOnSelect,
    freeze = false,
    comment = false,
    bottomBorder = true,
    rightIcon = null,
    containerStyle,
    setFormatedData,
    showWarn,
    showAlert,
  } = props;
  const dispatch = useDispatch<any>();
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const [isSelectAll, setIsSelectAll] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [productSearchKey, setProductSearchKey] = useState("");
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { currency } = useSelector((state: any) => state.userReducer);

  const filterProductsbyKey = (array) =>
    array.filter((item, index) => {
      return productSearchKey !== ""
        ? (item?.description)
            .toLowerCase()
            .includes(productSearchKey.toLocaleLowerCase())
        : data;
    });

  useEffect(() => {
    if (item?.actualQty) {
      setQty(item?.actualQty);
    }
  }, []);
  const itemFooter = () => {
    return <View style={styles.itemFooter} />;
  };

  const checkIfAllSelected = () => data?.every((dat) => dat.selected);
  const filteredProducts = filterProductsbyKey(data);
  const isAllSelcted = checkIfAllSelected();

  const getProductPrice = (data: any,) => {
    return getProductPriceMapdata(data, itemPrice);
  };
  const getProductPriceMapdata = (data: any, itemPrice: any) => {
    if(itemPrice?.data?.length > 0){
    const matchingItem = itemPrice?.data?.find(item => item.id == data.id);
    const purchasePrice = matchingItem?.purchasePrice && !isNaN(parseFloat(matchingItem.purchasePrice))
  ? matchingItem.purchasePrice:0;
    return (
        parseFloat(purchasePrice) * parseFloat(data.actualQty)
      ).toFixed(2);
    }else{
      return (
        parseFloat(data?.purchasePrice) * parseFloat(data.actualQty)
      ).toFixed(2);
    }
  };
  return (
    <View
      accessible={true}
      accessibilityLabel={"consume_order_view_container"}
      style={styles.container}
    >
      {!!data?.length && (
        <View
          accessible={true}
          accessibilityLabel={"consume_order_view_header"}
          style={styles.header}
        >
          <View style={styles.priceContainer}>
            <Text
              accessibilityLabel={"consume_order_view_order_count"}
              style={styles.orderLabel}
            >
              {`${filteredProducts?.length}`}{" "}
              <Text
                style={[
                  styles.orderLabel,
                  { fontFamily: FONTFAMILY.averta_regular },
                ]}
              >{`${Strings["ime.scanner.Items"] ?? "Items"}`}</Text>
            </Text>
            {!!org_details.showPrice &&
              !!stockRoomDetail?.isConsumeShowPrice && (
                <Text
                  accessibilityLabel={"consume_order_view_total_price"}
                  style={styles.priceText}
                >
                  {getCurrencySymbol(
                    data[0]?.vendorName ? data[0]?.currency : currency
                  ) + `${totalPrice == 0 ? 0 : totalPrice}`}
                </Text>
              )}
          </View>
          <View style={styles.rightContainer}>
            <View
              accessible={true}
              accessibilityLabel={"consume_order_view_header_right"}
              style={styles.headerRight}
            >
              <Text
                accessibilityLabel={"consume_order_view_selection_label"}
                style={styles.selectAll}
              >
                {isAllSelcted
                  ? Strings["ime.scanner.deselect.all"] ?? "Deselect All"
                  : Strings["ime.select.all"] ?? "Select All"}
              </Text>
              <TouchableOpacity
                accessible={true}
                accessibilityLabel={"consume_order_view_selection_button"}
                style={isAllSelcted ? styles.activeTick : styles.deactiveTick}
                onPress={() => {
                  setIsSelectAll(!isAllSelcted);
                  onPressSelectAll(!isAllSelcted);
                }}
              >
                {isAllSelcted && (
                  <TickIcon
                    accessible={true}
                    accessibilityLabel={"consume_order_view_tick_iconr"}
                    fill={COLORS.white}
                  />
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
      {!!showSearch && (
        <InnerSearchBar
          search={productSearchKey}
          onSearch={(text: string) => setProductSearchKey(text)}
          placeholder={Strings["ime.scanner.Search.list"] ?? "Search list"}
          onPressCancel={() => setShowSearch(false)}
          cancel={true}
        />
      )}
      <View
        accessible={true}
        accessibilityLabel={"consume_order_view_product_container"}
      >
        {filteredProducts?.map((item, index) => {
          const showBatch =
            isConsume &&
            (checkifBatchEnabled(item) || checkifExpiryEnabled(item));
          const uomId =
            item?.uomManagementEnabled == 1
              ? item?.stockRoomUOMUnit
              : item?.uomId;
          const batches = item?.batches?.map((i: any) => {
            const { batchNo, actualQty, availableQty, id, expiryDate } = i;
            if (parseInt(availableQty) > 0)
              return {
                batchNo,
                actualQty,
                availableQty,
                id,
                expiryDate,
              };
          });
          return (
            <View
              accessible={true}
              accessibilityLabel={"consume_order_view_item_container"}
              style={[
                styles.container,
                bottomBorder && {
                  borderBottomWidth: 0.6,
                  borderBottomColor: COLORS.alto,
                  // paddingBottom: wp(-8),
                  paddingTop: wp(2),
                },
                containerStyle,
              ]}
            >
              <ListItem
                key={id}
                leftIcon={
                  <View
                    accessible={true}
                    accessibilityLabel={"consume_order_view_left_icon_ontainer"}
                    style={styles.leftIconContainer}
                  >
                    {!!item?.imagePath || !!item?.imageURL ? (
                      <Image
                        accessible={true}
                        accessibilityLabel={"consume_order_view_product_image"}
                        source={{
                          uri: item?.imagePath
                            ? `https://vsr-stage4.vwr.com/${item?.imagePath}`
                            : item?.imageURL.replace("http://", "https://"),
                        }}
                        style={styles.leftIcon}
                        resizeMode={"contain"}
                      />
                    ) : (
                      <DefaultProductImage
                        accessible={true}
                        accessibilityLabel={
                          "consume_order_view_product_default_image"
                        }
                        width={wp(20)}
                        height={wp(20)}
                      />
                    )}
                  </View>
                }
                headerContent={
                  <View
                    accessible={true}
                    accessibilityLabel={
                      "consume_order_view_product_item_container"
                    }
                    style={styles.headerContainerStyle}
                  >
                    <Text
                      accessibilityLabel={"consume_order_view_catalog_number"}
                      style={styles.catalogNumber}
                    >
                      {item?.catalogNo}
                    </Text>
                    <Text
                      accessibilityLabel={"consume_order_view_description"}
                      onPress={() => {
                        onNamePressed(item);
                      }}
                      style={styles.itemHeaderContent}
                    >
                      {item?.description}
                    </Text>
                    {!!uomId && (
                      <View
                        accessible={true}
                        accessibilityLabel={
                          "consume_order_view_uomid_container"
                        }
                        style={styles.qtyInfoContainer}
                      >
                        <Text
                          accessibilityLabel={"consume_order_view_uomid"}
                          style={styles.itemSubHeaderStyle}
                        >
                          ({uomId})
                        </Text>
                      </View>
                    )}
                    {!!showBatch && (
                      <View
                        accessible={true}
                        accessibilityLabel="product_batch_expiry_label_container"
                        style={styles.tagContainer}
                      >
                        {!!checkifBatchEnabled(item) && (
                          <ConsumeTag tag="Batch Controlled" />
                        )}
                        {!!checkifExpiryEnabled(item) && (
                          <ConsumeTag tag="Expiry Date Controlled" />
                        )}
                      </View>
                    )}
                  </View>
                }
                onPress={handleOnSelect}
                rightIcon={
                  <TouchableOpacity
                    accessible={true}
                    accessibilityLabel={"consume_order_view_right_icon"}
                    style={
                      item?.selected ? styles.activeTick : styles.deactiveTick
                    }
                    onPress={() => onPressItemCheck(index)}
                  >
                    {item?.selected && (
                      <TickIcon
                        accessible={true}
                        accessibilityLabel={"consume_order_view_tick_icon"}
                        fill={COLORS.white}
                      />
                    )}
                  </TouchableOpacity>
                }
              >
                {!showBatch && (
                  <View
                    accessible={true}
                    accessibilityLabel={"consume_order_view_flexrow_container"}
                    style={styles.flexRowContainer}
                  >
                    <View
                      accessible={true}
                      accessibilityLabel={
                        "consume_order_view_item_child_container"
                      }
                      style={[
                        styles.itemChildContainer,
                        {
                          width:
                            !!org_details.showPrice &&
                            !!stockRoomDetail?.isConsumeIndividual
                              ? SIZES.width * 0.24
                              : SIZES.width * 0.4,
                        },
                      ]}
                    >
                      <Text
                        accessibilityLabel={
                          "consume_order_view_item_child_text"
                        }
                        style={styles.itemChildTitleText}
                      >
                        {strings["ime.avail.qty"]}
                      </Text>
                      <Text
                        accessibilityLabel={
                          "consume_order_view_item_child_value"
                        }
                        style={styles.itemChildValueText}
                      >
                        {`${item?.availableQty + " "}${
                          getMultiplier(item) == null
                            ? " "
                            : getMultiplier(item)
                        }`}
                        {/* {!!item?.availableQty ? item?.availableQty : 0} */}
                      </Text>
                    </View>
                    <View
                      accessible={true}
                      accessibilityLabel={
                        "consume_order_view_iterm_child_container"
                      }
                      style={[
                        styles.itemChildContainer,
                        {
                          width:
                            !!org_details.showPrice &&
                            !!stockRoomDetail?.isConsumeIndividual
                              ? SIZES.width * 0.24
                              : SIZES.width * 0.4,
                        },
                      ]}
                    >
                      <Text
                        accessibilityLabel={
                          "consume_order_view_item_child_text"
                        }
                        style={styles.itemChildTitleText}
                      >
                        {strings["vendor"]}
                      </Text>
                      <Text
                        accessibilityLabel={
                          "consume_order_view_item_child_value"
                        }
                        style={styles.itemChildValueText}
                      >
                        {item?.vendorName}
                      </Text>
                    </View>
                    {!!org_details.showPrice &&
                      !!stockRoomDetail?.isConsumeIndividual && (
                        <View
                          accessible={true}
                          accessibilityLabel={
                            "consume_order_view_iterm_child_container"
                          }
                          style={[styles.itemChildContainer]}
                        >
                          <Text
                            accessibilityLabel={
                              "consume_order_view_item_child_text"
                            }
                            style={styles.itemChildTitleText}
                          >
                            {strings["price"]}
                          </Text>
                          <Text
                            accessibilityLabel={
                              "consume_order_view_item_child_value"
                            }
                            style={styles.itemChildValueText}
                          >
                            {/* {getCurrencySymbol(
                              item?.vendorName ? item?.currency : currency
                            ) +
                              `${(
                                item?.purchasePrice * Number(item?.actualQty)
                              ).toFixed(2)}`} */}
                        {getCurrencySymbol(
                              data.slice(-1)?.vendorName ? data.slice(-1)?.currency : currency
                            ) + getProductPrice(item)}
                          </Text>
                        </View>
                      )}
                  </View>
                )}
              </ListItem>
              {!showBatch ? (
                <View style={styles.commentMainContainer}>
                  {!!comment && (
                    <View
                      accessible={true}
                      accessibilityLabel={
                        "consume_order_view_comment_container"
                      }
                      style={styles.commentContainer}
                    >
                      <Text
                        accessibilityLabel={"consume_order_view_comment_title"}
                        style={styles.itemText}
                      >
                        {strings["ime.comment"]}
                      </Text>

                      <TextInputComponent
                        idLabel="consumeOrderView-comment-input"
                        title={""}
                        editable={true}
                        main={styles.commentMain}
                        inputStyle={styles.inputStyle}
                        required={false}
                        placeholder={
                          strings["ime.scanner.enter.comment"] ??
                          "Enter comment"
                        }
                        value={item?.comments}
                        onChangeText={(value) => {
                          onChangeCommentText(value, item?.id);
                        }}
                      />
                    </View>
                  )}
                  <View
                    accessible={true}
                    accessibilityLabel={"consume_order_view_qty_container"}
                    style={[styles.center, { paddingTop: SIZES.padding }]}
                  >
                    <Text
                      accessibilityLabel={"consume_order_view_qty_title"}
                      style={[
                        styles.itemText,
                        { fontSize: FONTS.h1_8, marginTop: wp(1) },
                      ]}
                    >
                      {strings["ime.qty"]}
                    </Text>

                    <QtyController
                      onChange={(val: React.SetStateAction<string>) => {
                        setQty(val);
                        item["actualQty"] = val;
                        handleAvailQty(val, item?.id, item);
                      }}
                      showLabel={false}
                      inputStyle={styles.controllerInputStyle}
                      inputValue={item["actualQty"]}
                      disable={
                        freeze ||
                        (isConsume &&
                          (item?.expiryDateManagementenabled != 0 ||
                            item?.batchManagementEnabled != 0))
                      }
                    />
                    {/* <Text
                      style={styles.multipierText}
                      accessibilityLabel="consumerOrder-list-item-multiplier"
                    >
                      {item?.orderedQtyUOMDisplay ?? 
                      getMultiplier(item)}
                    </Text> */}
                  </View>
                </View>
              ) : (
                <AddBatch
                  symbol={
                    // getCurrencySymbol(
                    //   data[0]?.vendorName ? data[0]?.currency : currency
                    // ) + `${totalPrice == 0 ? 0 : totalPrice}`
                    getCurrencySymbol(
                      data.slice(-1)?.vendorName ?   data.slice(-1)?.currency : currency
                    ) + `${totalPrice == 0 ? 0 : totalPrice}`
                  }
                  item={item}
                  onChange={handleBatch}
                  updateActualQty={(val: any) => {
                    setQty(val);
                    item["actualQty"] = val;
                    handleAvailQty(val, item?.id);
                  }}
                  setLoader={(val: boolean) => dispatch(setProductLoader(val))}
                  data={batches}
                  formatedData={batches}
                  setFormatedData={setFormatedData}
                  uomId={uomId}
                  availableQty={item.availableQty}
                  freeze={freeze}
                  showWarn={showWarn}
                  showAlert={showAlert}
                  price={getProductPrice(item)}
                  showPrice={
                    !!org_details.showPrice &&
                    !!stockRoomDetail?.isConsumeIndividual
                  }
                />
              )}
            </View>
          );
        })}
        {itemFooter()}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  leftIconContainer: { marginRight: wp(4) },
  commentMainContainer: { flexDirection: "row", marginBottom: hp(1.5) },
  headerContainerStyle: { flex: 1, marginTop: -wp(2) },
  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  priceContainer: { alignItems: "flex-end" },
  itemChildContainer: {
    width: SIZES.width * 0.24,
    marginVertical: wp(0.5),
    paddingVertical: 8,
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },
  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },
  commentContainer: {
    marginTop: hp(2),
    flex: 1,
    marginEnd: wp(2),
  },
  itemText: {
    ...FONTS.title2,
    color: COLORS.abbey,
    marginBottom: SIZES.tip,
    marginEnd: wp(2),
  },
  commentMain: {
    width: "100%",
  },
  center: {
    alignItems: "center",
    flex: 1,
    flexDirection: "row",
    // marginStart: wp(2),
  },
  inputStyle: {
    width: "100%",
    paddingLeft: 0,
  },

  container: {
    marginTop: hp(2),
  },
  itemFooter: {
    height: hp(10),
    width: wp(100),
  },
  tagContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: hp(0.4),
  },
  subHeaderTextContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 6,
    marginTop: hp(3),
  },
  recomentedText: { ...FONTS.title2, fontSize: FONTS.h2, lineHeight: 20 },

  priceText: {
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    alignSelf: "flex-end",
    marginTop: wp(1),
  },

  itemChildHeaderText: {
    fontSize: FONTS.h1_7,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    alignItems: "center",
  },

  itemContainer: {
    marginVertical: hp(2),
  },

  itemHeader: {
    flexDirection: "row",
    alignItems: "center",
  },
  itemHeaderLeft: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  leftIcon: {
    width: wp(20),
    height: wp(20),
    marginRight: wp(3),
  },
  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },
  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },
  qtyInfoContainer: {
    paddingVertical: hp(0.8),
    marginVertical: hp(1.2),
  },
  itemSubHeaderStyle: {
    textAlign: "center",
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    minWidth: wp(10),
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
    position: "absolute",
    paddingVertical: hp(0.1),
  },
  activeTick: {
    width: wp(6),
    height: wp(6),
    backgroundColor: COLORS.scienceBlue,
    borderRadius: wp(6),
    alignItems: "center",
    justifyContent: "center",
  },
  deactiveTick: {
    width: wp(6),
    height: wp(6),
    backgroundColor: COLORS.white,
    borderRadius: wp(6),
    alignItems: "center",
    justifyContent: "center",
    borderColor: COLORS.lightGray,
    borderWidth: 1,
  },
  subItemContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderBottomColor: COLORS.alto,
    borderBottomWidth: 1,
    paddingVertical: hp(1.2),
    marginHorizontal: wp(4),
  },
  subItemLeft: {
    alignSelf: "flex-start",
  },
  subItemRight: {
    alignSelf: "flex-start",
  },
  qtyContainer: {
    alignSelf: "flex-start",
  },
  lableStyle: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_5,
  },
  valueStyle: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_9,
    marginTop: hp(0.6),
  },
  controllerInputStyle: {
    ...FONTS.body,
    paddingVertical: SIZES.base,
    paddingHorizontal: SIZES.tip,
    maxWidth: wp(10),
  },
  multipierText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_regular,
  },
  header: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  orderLabel: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: wp(3),
  },
  selectAll: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: wp(3.5),
    marginRight: wp(2),
    marginLeft: wp(3),
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
  },
  rightContainer: {
    alignItems: "flex-end",
  },
});

export default ConsumeOrderView;
