import React,{ useState, useRef, useEffect } from "react";
import { View, TouchableOpacity, Platform, Linking } from "react-native";
import RNExitApp from "react-native-exit-app";

import styles from "./styles";
import CustomText from "../CustomText";
import AlertModal from "../AlertModal";
import { FONTS, SIZES } from "../../Utils/theme";
import MainButton from "../MainButton";
import { useSelector } from "react-redux";
import { NavigationState, useNavigation, useRoute } from "@react-navigation/native";

const UpdateAlertBox: React.FC = () => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  function goToStore() {
    const link =
      Platform.OS === "ios"
        ? "https://apps.apple.com/us/app/vsr-scanner/id1014009276"
        : "https://play.google.com/store/apps/details?id=com.vwr.vsrms";

    Linking.canOpenURL(link).then(
      (supported) => {
        Linking.openURL(link);
      },
      (err) => console.log(err)
    );
  }

  
  const { showUpdateAlert } = useSelector((state: any) => state.loginReducer);


  const getActiveRouteState = () => {
    const route = useNavigation().getState()
    return route?.routes[route?.index]?.name  ?? "" 
  };

function couldShowAlert(){
  const routeName = getActiveRouteState()
  return (routeName == 'Dashboard' || routeName == 'Login')
}
  return (
    <AlertModal
      isShow={showUpdateAlert && couldShowAlert()}
      customStyles={{ width: SIZES.width * 0.9 }}
    >
      <CustomText
        style={styles.modalHeaderText}
        accessibilityLabel="dashboard-modal-header-text"
      >
        {"Update Required"}
      </CustomText>
      <CustomText
        style={styles.modalBodyText}
        accessibilityLabel="dashboard-modal-bodytext"
      >
        {
          "There is a newer version of Inventory Manager available. Please update by visiting the App Store."
        }
      </CustomText>
      <View style={styles.btnContainer}>
        <TouchableOpacity
          style={styles.modalSecondaryButton}
          onPress={async () => {
            RNExitApp.exitApp();
          }}
          accessible={true}
          accessibilityLabel="updateApp-secondary-btn"
        >
          <CustomText
            style={styles.modalSecondaryButtonText}
            accessibilityLabel="updateApp-secondary-text"
          >
            {"Close App"}
          </CustomText>
        </TouchableOpacity>

        <MainButton
          title={Strings["update"]}
          buttonTextStyle={{ ...FONTS.title }}
          onChangeBtnPress={async () => {
            goToStore();
          }}
          buttonStyle={styles.modalMainButton}
          accessibilityLabel={"updateApp-update-btn"}
        />
      </View>
    </AlertModal>
  );
};

export default UpdateAlertBox;
