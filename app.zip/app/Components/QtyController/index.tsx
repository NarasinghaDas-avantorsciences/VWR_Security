import React, { useEffect, useState } from "react";
import {
  Alert,
  Pressable,
  StyleProp,
  TextInput,
  TextStyle,
  View,
  ViewStyle,
  TouchableOpacity,
  Keyboard,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { BlueMinus, BluePlus, GreyMinus } from "../../Utils/images";
import { COLORS } from "../../Utils/theme";
import styles from "./styles";
import CustomText from "../CustomText";
import { setReceiveLimtiFlag } from "../../Redux/Action/receiveAction";

type QtyControllerProps = {
  title?: string;
  inputValue?: any;
  initialValue?: number;
  topLimit?: boolean;
  onChange?: any;
  titleStyle?: StyleProp<TextStyle>;
  showLabel?: boolean;
  inputStyle?: StyleProp<TextStyle>;
  containerStyle?: StyleProp<ViewStyle>;
  disable?: boolean;
  limit?: number;
  approval?: boolean;
  isOffline?: boolean;
  from?: string;
  availableQty?: any;
  showToast?: any;
  topLimitValue?: any;
  resetValue?: any;
  stockTransfer?: any;
  isReceiveBatch?: boolean;
  remainingVal?: any;
  screen?: number;
};

const QtyController: React.FC<QtyControllerProps> = ({
  title,
  onChange,
  titleStyle,
  inputValue,
  initialValue,
  showLabel = true,
  inputStyle = {},
  containerStyle,
  disable,
  topLimit = false,
  limit,
  approval,
  isOffline,
  from,
  availableQty = null,
  showToast,
  topLimitValue,
  resetValue,
  stockTransfer,
  isReceiveBatch = null,
  remainingVal,
  screen,
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const dispatch = useDispatch<any>();
  const { receiveLimitFlag } = useSelector(
    (state: any) => state.receiveReducer
  );
  const name = title ?? strings["ime.qty"];
  const [inputVal, setInputVal] = useState("");
  const [avllimit, setAvllimit] = useState<any>();
  // const [selection, setSelection] = useState({ start: 0, end: 0 });

  // useEffect(() => {
  //   console.log('remainingVal',remainingVal)
  // }, []);

  useEffect(() => {
    if (from && from == "stock.correction") {
      setInputVal(inputValue ?? "");
    } else if (from && from == "picount") {
      setInputVal(inputValue == null ? "" : inputValue.toString());
    } else {
      setInputVal(inputValue ? `${inputValue}` : "0");
    }

    // setSelection({
    //   start: String(inputValue).length,
    //   end: String(inputValue).length,
    // });
  }, [inputValue]);

  useEffect(() => {
    setAvllimit(limit);
  }, [limit]);
  const onChangeValue = (val: String, key: String) => {
    var regex = /^0+$/;
    // const value = val?.replace(/[^0-9]/g, "");
    const value = val?.match(regex) ? "0" : val?.replace(/[^0-9]/g, "");

    try {
      if (approval) {
        if (
          key == "new" &&
          limit &&
          limit > 0 &&
          Number(value) <= Number(limit)
        ) {
          setInputVal(String(value));
          onChange(value);
        } else if (
          key == "new" &&
          limit == 0 &&
          Number(value) <= Number(inputVal)
        ) {
          setInputVal(String(value));
          onChange(value);
        } else if (key == "minus") {
          let newVal = Number(value) - 1;
          setInputVal(String(newVal < 0 ? 0 : newVal));
          onChange(String(newVal < 0 ? 0 : newVal));
        } else if (key == "plus" && limit && limit > 0) {
          let newVal = Number(value) + 1;
          let avblQty = Number(availableQty);

          setInputVal(String(newVal <= avblQty ? newVal : avblQty));
          onChange(String(newVal <= avblQty ? newVal : avblQty));
        } else if (
          key == "new" &&
          Number(value) <= Number(limit) + Number(inputVal)
        ) {
          setInputVal(String(value));
          onChange(value);
        } else if (Number(value) <= Number(availableQty) && key == "plus") {
          let newVal = Number(value) + 1;
          let avblQty = Number(availableQty);
          setInputVal(String(newVal <= avblQty ? newVal : avblQty));
          onChange(String(newVal <= avblQty ? newVal : avblQty));
        } else if (Number(value) <= availableQty) {
          setInputVal(String(value));
          onChange(value);
        } else {
          onChangeValue(resetValue?.toString(), "new");
          showToast &&
            showToast(
              strings["ime.scanner.error.occured.msg"],
              stockTransfer
                ? "Stock cannot be transferred more than available"
                : strings["ime.alert.less.than.req.ordered.quantity"],
              true
            );
        }
      } else {
        if (key == "new") {
          // let str = String(value).replace(/^0+/, "");

          let str = String(value).replace(/^0+/, "");
          if (String(value)?.length <= 1) {
            str = String(value);
          }
          //Initial 0 removed using above regex  (variable value change to str)

          setInputVal(String(str));
          if (isReceiveBatch ?? false) {
            if (topLimitValue) {
              let newval = String(str > remainingVal ? "0" : val);
              onChange(newval, setInputVal);
            } else {
              onChange(val, setInputVal);
            }
          } else {
            onChange(str);
          }
        } else if (key == "minus") {
          let newVal = Number(value) - 1;
          setInputVal(String(newVal < 0 ? 0 : newVal));
          if (isReceiveBatch ?? false) {
            onChange(String(newVal < 0 ? 0 : newVal), setInputVal);
          } else {
            onChange(String(newVal < 0 ? 0 : newVal));
          }
        } else if (key == "plus") {
          let newVal = Number(value) + 1;
          let val = String(newVal > topLimitValue ? topLimitValue : newVal);
          setInputVal(String(Number(val)));
          if (isReceiveBatch ?? false) {
            onChange(val, setInputVal);
          } else {
            onChange(val);
          }
        }
      }
    } catch (e: any) {
      console.log(e.message);
    }
  };

  const availableQtyCheck = () => {
    if (availableQty || availableQty == 0) {
      if (approval) {
        return Number(inputVal) >= Number(availableQty);
      } else {
        return !(Number(inputVal) <= Number(availableQty));
      }

      //return !(Number(inputVal) <= Number(availableQty));
    } else {
      return false;
    }
  };

  const input_val = (from?: String) => {
    if (from == "receive") {
      return Number(inputValue).toString();
    } else if (from == "picount") {
      return inputVal.toString();
    } else if (from == "stock.correction") {
      var regex = /^0+$/;
      const value =
        inputVal && inputVal?.match(regex)
          ? "0"
          : inputVal && inputVal?.replace(/[^0-9]/g, "");
      let str = String(value).replace(/^0+/, "0");
      console.log("inputVal", str);
      return str;
    } else {
      //IF Added for clearing begginig zero
      if (
        inputVal?.length > 1 &&
        String(inputValue) != "0" &&
        Number(inputVal) >= 0
      ) {
        var regex = /^0+$/;
        const value =
          inputVal && inputVal?.match(regex)
            ? "0"
            : inputVal && inputVal?.replace(/[^0-9]/g, "");
        let str = String(value).replace(/^0+/, "");
        return str; //inputVal?.replace(/[^0-9]/g, "");
      } else {
        return inputVal;
      }
      // return Number(inputVal).toString();
    }
  };

  return (
    <View
      style={[styles.container, containerStyle]}
      accessible={true}
      accessibilityLabel="qty-controller"
    >
      {showLabel && (
        <CustomText style={[styles.titleStyle, titleStyle]}>{name}</CustomText>
      )}
      <TouchableOpacity
        disabled={disable}
        onPress={() => {
          if (inputVal != "1" || !isOffline) {
            Keyboard.dismiss();
            inputVal != "0" && onChangeValue(inputVal, "minus");
          }
        }}
        style={styles.iconContainer}
        accessible={true}
        accessibilityLabel="qty-controller-minus"
      >
        {isOffline || inputVal == "0" ? (
          <GreyMinus opacity={disable ? 0.5 : 1} />
        ) : (
          <BlueMinus opacity={disable ? 0.5 : 1} />
        )}
      </TouchableOpacity>
      <TextInput
        maxLength={25}
        accessible={true}
        accessibilityLabel="qty-controller-text-input"
        placeholder=""
        style={[
          styles.textInputStyle,
          inputStyle,
          {
            borderColor: disable ? COLORS.gray4 : COLORS.black,
            color: disable ? COLORS.gray4 : COLORS.abbey,
          },
        ]}
        value={
          input_val(from)
          // from == "receive"
          //   ? inputValue.replace(/^0+/, "")
          //   : inputVal.replace(/^0+/, "")
        }
        onBlur={() =>
          inputVal == "" &&
          onChangeValue(from == "stock.correction" ? "" : "0", "new")
        }
        keyboardType={"number-pad"}
        onChangeText={(value) => {
          if (availableQty) {
            if (Number(value) <= Number(availableQty)) {
              // value = Number(value).toString();
              if (initialValue && Number(value) > initialValue) {
                dispatch(setReceiveLimtiFlag(receiveLimitFlag + 1));

                // setSelection({
                //   start: String(initialValue).length,
                //   end: String(initialValue).length,
                // });

                onChangeValue(`${initialValue}`, "new");
                return;
              }
              // setSelection({
              //   start: String(value).length,
              //   end: String(value).length,
              // });
              onChangeValue(value, "new");
            } else {
              showToast &&
                showToast(
                  strings["ime.scanner.error.occured.msg"],
                  stockTransfer
                    ? "Please enter a valid transfer quantity for selected products!"
                    : screen == 3
                    ? "Please enter less than or equal to Available Quantity!"
                    : strings["ime.alert.less.than.req.ordered.quantity"],
                  true
                );
              // setSelection({
              //   start: String(resetValue).length,
              //   end: String(resetValue).length,
              // });

              onChangeValue(resetValue?.toString(), "new");
            }
          } else {
            // value = Number(value).toString();

            if (initialValue && Number(value) > initialValue) {
              dispatch(setReceiveLimtiFlag(receiveLimitFlag + 1));
              // setSelection({
              //   start: String(initialValue).length,
              //   end: String(initialValue).length,
              // });

              onChangeValue(`${initialValue}`, "new");
              return;
            }
            // setSelection({
            //   start: String(value).length,
            //   end: String(value).length,
            // });

            onChangeValue(value, "new");
          }
        }}
        editable={!disable}
        // selection={selection}
      />
      <TouchableOpacity
        accessible={true}
        accessibilityLabel="qty-controller-plus"
        disabled={disable || availableQtyCheck() || remainingVal == 0}
        onPress={() => {
          if (disable || topLimit) return;
          if (approval) {
            onChangeValue(inputVal, "plus");
          } else {
            onChangeValue(inputVal, "plus");
            let val = String(inputVal > topLimitValue ? 0 : inputVal);
            onChangeValue(val, "plus");
          }
          Keyboard.dismiss();
        }}
        style={styles.iconContainer}
      >
        <BluePlus
          opacity={
            remainingVal == 0
              ? 0.5
              : disable || topLimit || availableQtyCheck()
              ? 0.5
              : 1
          }
        />
      </TouchableOpacity>
    </View>
  );
};

export default QtyController;
