import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp,isDeviceTablet } from "../../Utils/globalFunction";
//const isTablet = isDeviceTablet();
const Styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  titleStyle: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_6,
  },
  textInputStyle: {
    borderWidth: 1,
    marginHorizontal: wp(2.4),
    minWidth: isDeviceTablet() ? 60 :40,
    maxWidth: isDeviceTablet() ? 80  : 60,
    marginVertical: 10,
    height: isDeviceTablet() ? 55 : 40,
    textAlign: "center",
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_5,
  },

  iconContainer: {
    justifyContent: "center",
    height: hp(6.5),
    width: wp(6.5),
    alignItems: "center",
  },
});

export default Styles;
