import React, { useState } from "react";
import {
  TouchableOpacity,
  View,
  Platform,
  UIManager,
  LayoutAnimation,
} from "react-native";
import CustomText from "../CustomText";

import styles from "./styles";
import {
  BlueArrowDown,
  BlueArrowUp,
  Checkbox,
  Unselected,
} from "../../Utils/images";
import { useSelector } from "react-redux";

type AccordionProps = {
  title?: string;
  children: React.ReactNode;
  accordionItemTitle?: string;
  onPressCheckbox: () => void;
  isSelectedAll: boolean;
  isShowCheckbox?: boolean;
};

if (Platform.OS === "android") {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const Accordion: React.FC<AccordionProps> = ({
  title,
  children,
  onPressCheckbox,
  isSelectedAll,
  isShowCheckbox,
}) => {
  const [expanded, setExpanded] = useState(true);
  const Strings = useSelector((state: any) => state.languageReducer?.data);

  const toggleItem = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpanded(!expanded);
  };

  return (
    <View>
      <View
        accessible={true}
        accessibilityLabel="accordion_container"
        style={[styles.accordHeader]}
      >
        <TouchableOpacity
          accessible={true}
          accessibilityLabel="accordion_button"
          style={styles.flexRowContainer}
          onPress={toggleItem}
        >
          {expanded ? <BlueArrowUp /> : <BlueArrowDown />}
          <CustomText
            accessibilityLabel="accordion_button_title"
            style={styles.accordTitle}
          >
            {title}
          </CustomText>
        </TouchableOpacity>

        {isShowCheckbox && (
          <TouchableOpacity
            accessible={true}
            accessibilityLabel="accordion_select_button"
            style={styles.flexRowContainer}
            onPress={onPressCheckbox}
          >
            <CustomText
              accessible={true}
              accessibilityLabel="accordion_select_button_title"
              style={styles.selectAll}
            >
              {isSelectedAll
                ? Strings["ime.scanner.deselect.all"] ?? "Deselect All"
                : Strings["ime.select.all"] ?? "Select All"}
            </CustomText>
            {isSelectedAll ? <Checkbox /> : <Unselected />}
          </TouchableOpacity>
        )}
      </View>
      {isSelectedAll ? children : expanded && children}
    </View>
  );
};

export default Accordion;
