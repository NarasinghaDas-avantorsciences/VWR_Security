import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  accordHeader: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: hp(4),
  },

  justifyEnd: {
    justifyContent: "flex-end",
  },

  flexRowContainer: { flexDirection: "row", alignItems: "center" },

  accordTitle: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingHorizontal: wp(3),
  },

  selectAll: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_semibold,
    paddingHorizontal: wp(2),
  },
});

export default Styles;
