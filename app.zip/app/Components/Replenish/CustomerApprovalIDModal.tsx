import React, { useEffect, useState } from "react";
import {
  View,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  Keyboard,
} from "react-native";
import { Check } from "../../Utils/images";
import { filterDataByName, hp, wp } from "../../Utils/globalFunction";
import { useSelector } from "react-redux";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import AnimatedSearch from "../AnimatedSearch";
import CustomText from "../CustomText";

interface CustomerApprovalIDModal {
  ids: any;
  onClose: () => void;
  selectedItem?: any;
  onPress: (item: any) => void;
}

const CustomerApprovalIDModal = (props: CustomerApprovalIDModal) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const { ids, onClose, selectedItem, onPress } = props;

  const [searckKey, setSearchKey] = useState("");
  const [idsList, setIdsList] = useState();
  const [keysList, setKeysList] = useState();

  useEffect(() => {
    if (ids) {
      const keys = Object.keys(ids || {});
      const values = Object.values(ids || {});
      const newArray = [];
      keys?.map((item, index) => {
        const obj = {
          keyElement: item,
          value: values?.[index],
        };
        newArray.push(obj);
      });
      setIdsList(newArray);
      setKeysList(newArray);
    }
  }, [ids]);

  const onChangeText = (text: string) => {
    setSearchKey(text);
    const filterData = filterDataByName(keysList, "keyElement", text);
    setIdsList(filterData);
  };

  const onPressItem = (item: any) => {
    onPress?.(item);
    onClose?.();
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerContainer}>
        <View style={{ flex: 1 }} />
        <CustomText style={styles.headerText}>
          {strings["customer.approver.id"]}
        </CustomText>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.secondaryPressableContainer}
            onPress={onClose}
          >
            <CustomText style={styles.closeBtn}>{strings["close"]}</CustomText>
          </TouchableOpacity>
        </View>
      </View>

      {/* <AnimatedSearch
        search={searckKey ?? ""}
        onSearch={onChangeText}
        containerStyle={styles.searchMain}
        placeholder={strings["search"]}
        clearText={() => onChangeText("")}
      /> */}
      <AnimatedSearch
        search={searckKey ?? ""}
        onSearch={(res) => onChangeText(res)}
        containerStyle={styles.searchMain}
        placeholder={strings["search"]}
        clearText={() => onChangeText("")}
        cancelBtnStyle={{ marginHorizontal: 8 }}
        onBarcodeDetected={(barcode) => onChangeText(barcode)}
        from={"Replenish"}
        isShowScan={false}
        onCancel={() => {
          onChangeText("");
          Keyboard.dismiss();
        }}
      />
      <ScrollView style={styles.listMain} showsVerticalScrollIndicator={false}>
        {idsList && idsList?.length > 0 ? (
          idsList?.map((item, index) => {
            return (
              <TouchableOpacity
                onPress={() => onPressItem(item)}
                key={index.toString()}
                style={[styles.itemMain]}
              >
                <CustomText style={[styles.itemTitle]}>
                  {item.keyElement}
                </CustomText>
                {selectedItem?.keyElement === item?.keyElement ? (
                  <Check
                    height={hp(2)}
                    width={hp(2)}
                    style={{
                      marginRight: wp(2),
                    }}
                  />
                ) : null}
              </TouchableOpacity>
            );
          })
        ) : (
          <View>
            <CustomText style={styles.notFoundText}>
              {strings["ime.scanner.customer.approver.msg"] ??
                "No customer approver ids are available"}
            </CustomText>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listMain: {
    width: "90%",
    alignSelf: "center",
    paddingBottom: hp(15),
    flex: 1,
  },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
  },
  headerText: {
    fontSize: FONTS.h2_3,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.doveGray,
    textAlign: "center",
  },
  buttonContainer: {
    flex: 1,
    alignItems: "flex-end",
    marginEnd: wp(5),
  },
  secondaryPressableContainer: {
    justifyContent: "center",
    alignItems: "center",
  },
  closeBtn: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.blue,
    fontFamily: FONTFAMILY.averta_regular,
  },
  searchMain: {
    width: "90%",
    alignSelf: "center",
  },
  bottomSheetContainer: {
    borderTopLeftRadius: hp(1),
    borderTopRightRadius: hp(1),
  },
  itemMain: {
    borderBottomWidth: 0.4,
    borderBottomColor: COLORS.alto,
    paddingVertical: hp(1.3),
    flexDirection: "row",
    justifyContent: "space-between",
  },
  itemTitle: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_8,
    color: COLORS.abbey,
  },
  notFoundText: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    alignSelf: "center",
    marginTop: hp(20),
    fontSize: FONTS.h1_7,
  },
});

export default CustomerApprovalIDModal;
