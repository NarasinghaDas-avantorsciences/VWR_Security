import React, { useRef, useState } from "react";
import { View, TouchableOpacity, Image } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import BottomSheetComponent from "../BottomSheet";
import VWRProductModal from "../VWRProductModal";
import { addVwrToStockRoom } from "../../Redux/Action/replenishAction";
import { hp } from "../../Utils/globalFunction";
import { DefaultProductImage } from "../../Utils/images";
import styles from "./styles";
import CustomText from "../CustomText";

type VWRProductListProps = {
  keyword: string;
  productDetailsSheetRef: any;
  clearInput: Function;
  showToast?: any;
};

export type UnitsOfMeasureType = {
  availabilityStatus?: string;
  availableQuantity?: string;
  code?: string;
  contractPrice?: string;
  description: string;
  listPrice?: string;
  selected?: boolean;
};

type ElementType = {
  description: string;
  unitOfMeasure: string;
  availableQuantity: number;
  supplierName: string;
  productThumbnailURL: string | null;
  productId: string;
  unitsOfMeasure: UnitsOfMeasureType[];
  catalogNumber: string;
};

const VWRProductList: React.FC<VWRProductListProps> = ({
  keyword,
  clearInput,
  showToast,
}) => {
  const dispatch = useDispatch<any>();
  const productSheetRef = useRef<any>();
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const searchData = useSelector(
    (state: any) => state.replenishReducer?.vwrProductSearchData
  );
  const currency = useSelector((state: any) => state.userReducer.currency);

  const [selectedItem, setSelectedItem] = useState<ElementType>();
  const [unitsOfMeasureArr, setUnitsOfMeasureArr] = useState<{}[]>([]);

  const onPressItem = (item: ElementType) => {
    let newArray = item.unitsOfMeasure;
    let unitsOfMeasure = newArray.map((item) => ({
      id: Math.floor(Math.random() * 100),
      title: item.description,
      selected: false,
      uomCode: item.code,
    }));
    setUnitsOfMeasureArr(unitsOfMeasure);
    setSelectedItem(item);

    productSheetRef?.current?.open();
  };

  const onPressAdd = async (
    quantity: number,
    unitMeasureValue: string,
    uomCode: string,
    comment: string
  ) => {
    productSheetRef?.current?.close();
    clearInput();
    await dispatch(
      addVwrToStockRoom(
        selectedItem,
        quantity,
        unitMeasureValue,
        uomCode,
        currency,
        comment,
        async (res: any) => {},
        async (res: any) => {
          showToast(true, {
            title: strings["ime.scanner.error.occured.msg"],
            description: res,
          });
        }
      )
    );
  };

  return (
    <>
      {keyword && searchData?.length > 0 ? (
        searchData?.map((element: ElementType, index: string) => {
          return (
            <TouchableOpacity
              key={index.toString()}
              style={styles.itemContainer}
              onPress={() => onPressItem(element)}
              accessible={true}
              accessibilityLabel="addVwr-search-list-btn-container"
            >
              <View
                style={styles.itemTop}
                accessible={true}
                accessibilityLabel="addVwr-search-list-itemTop"
              >
                {element?.productThumbnailURL ? (
                  <Image
                    source={{
                      uri: element.productThumbnailURL.replace(
                        "http://",
                        "https://"
                      ),
                    }}
                    style={styles.itemImage}
                    accessible={true}
                    accessibilityLabel="addVwr-search-list-itemImage"
                  />
                ) : (
                  <DefaultProductImage
                    width={hp(9)}
                    height={hp(9)}
                    accessible={true}
                    accessibilityLabel="addVwr-search-list-defaultImage"
                  />
                )}
                <View
                  style={styles.itemTopRight}
                  accessible={true}
                  accessibilityLabel="addVwr-search-list-itemTopRight"
                >
                  <CustomText
                    style={styles.catalogNumber}
                    accessibilityLabel="addVwr-search-list-catalogNo"
                  >
                    {element?.catalogNumber}
                  </CustomText>
                  <CustomText
                    style={styles.itemTitle}
                    accessibilityLabel="addVwr-search-list-itemTitle"
                  >
                    {element?.description}
                  </CustomText>
                  {element?.unitOfMeasure && (
                    <CustomText
                      style={styles.itemLabel}
                      accessibilityLabel="addVwr-search-list-itemLabel"
                    >
                      {element?.unitOfMeasure !== null
                        ? element?.unitOfMeasure
                        : ""}
                    </CustomText>
                  )}
                </View>
              </View>
              <View
                style={styles.itemBottom}
                accessible={true}
                accessibilityLabel="addVwr-search-list-itemBottom"
              >
                <View style={styles.itemBottomLeft}>
                  <CustomText
                    style={styles.labelStyle}
                    accessibilityLabel="addVwr-search-list-availQty-label"
                  >
                    {strings["ime.avail.qty"]}
                  </CustomText>
                  <CustomText
                    style={styles.valueStyle}
                    accessibilityLabel="addVwr-search-list-availQty-value"
                  >
                    {element?.availableQuantity}
                  </CustomText>
                </View>
                <View style={styles.itemBottomRight}>
                  <CustomText
                    style={styles.labelStyle}
                    accessibilityLabel="addVwr-search-list-vendor-label"
                  >
                    {strings["vendor"]}
                  </CustomText>
                  <CustomText
                    style={styles.valueStyle}
                    accessibilityLabel="addVwr-search-list-vendor-name"
                    numberOfLines={2}
                    multiline={true}
                  >
                    {element?.supplierName}
                  </CustomText>
                </View>
              </View>
            </TouchableOpacity>
          );
        })
      ) : (
        <>
          <View style={styles.emptyContainer}>
            <CustomText style={styles.emptyText}>
              {strings["no.records.found"]}
            </CustomText>
          </View>
        </>
      )}

      <BottomSheetComponent bottomSheetRef={productSheetRef} height={hp(92)}>
        <VWRProductModal
          item={selectedItem}
          onPressAdd={onPressAdd}
          productSheetRef={productSheetRef}
          unitsOfMeasureArr={unitsOfMeasureArr}
          setUnitsOfMeasureArr={setUnitsOfMeasureArr}
        />
      </BottomSheetComponent>
    </>
  );
};

export default VWRProductList;
