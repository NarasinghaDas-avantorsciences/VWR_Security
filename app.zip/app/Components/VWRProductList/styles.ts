import { StyleSheet } from "react-native";

import { hp, wp } from "../../Utils/globalFunction";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";

const Styles = StyleSheet.create({
  itemContainer: {
    borderBottomColor: COLORS.alto,
    borderBottomWidth: 1,
    paddingBottom: hp(2),
    paddingTop: hp(3),
    marginHorizontal: wp(5),
  },
  itemTop: {
    flexDirection: "row",
    alignItems: "center",
  },
  itemImage: {
    width: hp(9),
    height: hp(9),
    resizeMode: "contain",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: COLORS.abbey,
  },
  itemTopRight: {
    marginLeft: wp(3),
    flex: 1,
  },
  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },
  itemTitle: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: hp(2.3),
  },
  itemLabel: {
    backgroundColor: COLORS.whiteSmoke,
    alignSelf: "flex-start",
    paddingHorizontal: wp(2),
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: hp(1.8),
    marginTop: hp(0.6),
  },
  itemBottom: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: hp(3),
  },
  itemBottomLeft: {
    width: "40%",
  },
  itemBottomRight: {
    width: "50%",
  },
  labelStyle: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: hp(1.9),
  },
  valueStyle: {
    fontFamily: FONTFAMILY.averta_regular,
    color: COLORS.abbey,
    fontSize: hp(1.9),
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
  },

  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },
});

export default Styles;
