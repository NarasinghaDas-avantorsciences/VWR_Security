import React from "react";
import { View, TouchableOpacity, StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";
import CustomText from "../CustomText";
import { useDispatch, useSelector } from "react-redux";

interface DashboardItemCard {
  Icon: any;
  title: string;
  onPress?: () => void;
  count?: number;
  disabled?: boolean;
  totalItems?: number;
}

const DashboardItemCard = (props: DashboardItemCard) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { Icon, title, onPress, count, disabled, totalItems } = props;
  const iconSize = () => {
    if (totalItems == 2) {
      return hp(7);
    } else if (totalItems == 3) {
      return hp(6.5);
    } else if (totalItems == 4) {
      return hp(6);
    } else if (totalItems == 5) {
      return hp(5.5);
    } else if (totalItems == 6) {
      return hp(4.5);
    } else if (totalItems == 7) {
      return hp(4.5);
    } else {
      return hp(4);
    }
  };
  const fontSize = () => {
    if (totalItems == 2) {
      return hp(3.5);
    } else if (totalItems == 3) {
      return hp(3);
    } else if (totalItems == 4) {
      return hp(2.6);
    } else if (totalItems == 5) {
      return hp(2.4);
    } else if (totalItems == 6) {
      return hp(2.3);
    } else if (totalItems == 7) {
      return hp(2.3);
    } else {
      return hp(2.1);
    }
  };
  return (
    <TouchableOpacity
      accessible={true}
      disabled={disabled}
      accessibilityLabel={`${title}-item_container`}
      style={[
        styles.container,
        disabled && {
          backgroundColor: "#f7f7f9",
        },
        {
          justifyContent: "center",
        },
      ]}
      onPress={onPress}
    >
      <View
        style={{
          paddingHorizontal: wp(3),
          paddingVertical: hp(1.5),
          flexDirection: "row",
          flexWrap: "wrap",
          justifyContent: "space-between",
        }}
      >
        <View
          style={{
            marginRight: wp(1),
          }}
        >
          <Icon
            accessible={true}
            accessibilityLabel={`${title}-item_icon`}
            width={title == "Approvals" ? iconSize() - hp(0.8) : iconSize()}
            height={title == "Approvals" ? iconSize() - hp(0.8) : iconSize()}
          />
          <CustomText
            accessibilityLabel={`${title}-item_title`}
            style={[
              styles.titleStyle,
              disabled && {
                color: "#53565A",
              },
              {
                fontSize: fontSize(),
              },
            ]}
          >
            {title}
          </CustomText>
        </View>
        {/* {title == "Approvals" ? ( */}
        {title == Strings["approval"] ? (
          <View
            accessible={true}
            accessibilityLabel={`${title}-item_count_container`}
            style={[
              styles.countContainer,
              count >= 10 && {
                height: hp(4.5),
                width: hp(4.5),
              },
              count >= 100 && {
                height: hp(5),
                width: hp(5),
              },
              count >= 1000 && {
                height: hp(5.5),
                width: hp(5.5),
              },
              disabled && {
                borderColor: "#53565A",
              },
              {
                marginLeft: 0,
                alignSelf: "flex-end",
              },
              totalItems == 3 && {
                marginTop: hp(1),
              },
            ]}
          >
            <CustomText
              accessibilityLabel={`${title}-item_count_value`}
              style={[
                styles.countText,
                disabled && {
                  color: "#53565A",
                },
              ]}
            >
              {`${count}`}
            </CustomText>
          </View>
        ) : null}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    borderWidth: 1,
    borderColor: COLORS.alto,
    width: wp(45),
    marginHorizontal: wp(1.5),
    marginVertical: hp(1),
  },
  subContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "flex-end",
    flexWrap: "wrap",
  },
  titleStyle: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.scienceBlue,
    fontSize: wp(3.8),
  },
  countContainer: {
    borderColor: COLORS.scienceBlue,
    borderWidth: 1.5,
    borderRadius: wp(3.5),
    alignItems: "center",
    justifyContent: "center",
    height: hp(2.75),
    width: hp(3.5),
  },
  countText: {
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_8,
    color: COLORS.scienceBlue,
  },
});

export default DashboardItemCard;
