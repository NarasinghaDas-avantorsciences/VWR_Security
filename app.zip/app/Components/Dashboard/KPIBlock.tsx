import React from "react";
import { View, StyleSheet, TouchableOpacity, Dimensions } from "react-native";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp, isDeviceTablet } from "../../Utils/globalFunction";
import CustomText from "../CustomText";

interface KPIBlock {
  LeftIcon?: any;
  title: string;
  value?: number;
  onClick?: () => void;
}

const KPIBlock = (props: KPIBlock) => {
  const { title, value = 0, LeftIcon, onClick } = props;
  return (
    <TouchableOpacity
      onPress={onClick}
      style={styles.container}
      accessible={true}
      accessibilityLabel="kpiblock-btn-container"
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          width: "70%",
        }}
      >
        {LeftIcon && <LeftIcon height={wp(4)} width={wp(4)} />}
        <CustomText
          style={styles.titleStyle}
          accessibilityLabel="kpiblock-title"
        >
          {title}
        </CustomText>
      </View>
      <View
        accessible={true}
        accessibilityLabel="kpiblock-value-container"
        style={styles.valueContainer}
      >
        <CustomText
          style={[styles.valueText]}
          accessibilityLabel="kpiblock-value-label"
        >
          {value > 99 ? "99+" : value}
        </CustomText>
      </View>
    </TouchableOpacity>
  );
};
const isTablet = isDeviceTablet();
const styles = StyleSheet.create({
  container: {
    borderColor: COLORS.alto,
    borderWidth: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: wp(2.5),
    paddingVertical: hp(0.9),
    width: wp(45),
    flexWrap: "wrap",
  },
  titleStyle: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: isDeviceTablet() ? FONTS.h2_5 : FONTS.h1_7,
    marginLeft: wp(1.6),
  },
  valueContainer: {
    borderColor: COLORS.scienceBlue,
    borderWidth: 1.5,
    borderRadius: wp(3.5),
    alignItems: "center",
    justifyContent: "center",
    height: hp(3),
    width: Dimensions.get("window").width * 0.09,//hp(4.5),
    paddingHorizontal: hp(0.4),
  },
  valueText: {
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_8,
    color: COLORS.scienceBlue,
  },
});

export default KPIBlock;
