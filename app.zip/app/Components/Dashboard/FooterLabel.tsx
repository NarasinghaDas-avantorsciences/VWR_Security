import React from "react";
import {StyleSheet, TouchableOpacity } from "react-native";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";
import CustomText from "../CustomText";

interface FooterLabel {
  label?: string;
  handleClick?: () => void;
}

const FooterLabel = (props: FooterLabel) => {
  const { label, handleClick } = props;
  return (
    <TouchableOpacity onPress={handleClick} style={styles.container}>
      <CustomText style={styles.labelStyle}>{label}</CustomText>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.magenta,
    marginRight: wp(3),
    paddingHorizontal: wp(2),
    paddingVertical: hp(1),
    borderRadius: wp(2),
  },
  labelStyle: {
    color: COLORS.white,
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_7,
  },
});

export default FooterLabel;
