import React from "react";
import { View, StyleSheet } from "react-native";
import DashboardItemCard from "./DashboardItemCard";
import { hp } from "../../Utils/globalFunction";
import { setNavigationData } from "../../Redux/Action/navigationRouteAction";
import { useDispatch } from "react-redux";

interface DashboardCardList {
  list: any;
  onPressItem: (route: string) => void;
}

const DashboardCardList = (props: DashboardCardList) => {
  const { list, onPressItem } = props;
  const dispatch = useDispatch<any>();
  let component = [];
  for (let i = 0; i <= list?.length; i++) {
    i++;
    component.push(
      <View style={styles.rowContainer} key={i.toString()}>
        {list?.slice(i - 1, i + 1)?.map((element, index) => {
          return (
            <DashboardItemCard
              key={index.toString()}
              Icon={element.icon}
              title={element.title}
              onPress={() => {
                dispatch(setNavigationData(element.route));
                onPressItem(element.route);
              }}
              count={element.count}
              disabled={element?.disabled}
              totalItems={list?.length}
            />
          );
        })}
      </View>
    );
  }
  return <View style={styles.container}>{component}</View>;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginBottom: hp(2),
  },
  rowContainer: {
    flexDirection: "row",
    flex: 1,
  },
});

export default DashboardCardList;
