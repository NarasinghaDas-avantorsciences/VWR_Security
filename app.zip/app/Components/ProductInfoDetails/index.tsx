import React from "react";
import { View } from "react-native";
import styles from "./styles";
import { useSelector } from "react-redux";
import CustomText from "../CustomText";

type ProductInfoDetailsProps = {
  vendorName: string;
  locationName: string;
  requiredQty: string;
  transitQty: string;
  isFromStockTransfer?: boolean;
};

const ProductInfoDetails: React.FC<ProductInfoDetailsProps> = ({
  vendorName,
  locationName,
  requiredQty,
  transitQty,
  isFromStockTransfer,
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);

  return (
    <View
      style={styles.flexRowContainer}
      accessible={true}
      accessibilityLabel="productInfo-container"
    >
      <View
        style={[styles.itemChildContainer]}
        accessible={true}
        accessibilityLabel="product-vendor"
      >
        <CustomText
          style={styles.itemChildTitleText}
          accessibilityLabel="product-vendor-label"
        >
          {strings["vendor"]}
        </CustomText>
        <CustomText
          style={styles.itemChildValueText}
          accessibilityLabel="product-vendor-value"
        >
          {vendorName}
        </CustomText>
      </View>

      <View
        style={[styles.itemChildContainer]}
        accessible={true}
        accessibilityLabel="product-location"
      >
        <CustomText
          style={styles.itemChildTitleText}
          accessibilityLabel="product-location-label"
        >
          {strings["location"]}
        </CustomText>
        <CustomText
          style={styles.itemChildValueText}
          accessibilityLabel="product-location-value"
        >
          {locationName}
        </CustomText>
      </View>
      {!(isFromStockTransfer ?? false) && (
        <View
          style={[styles.itemChildContainer]}
          accessible={true}
          accessibilityLabel="product-required-quantity"
        >
          <CustomText
            style={styles.itemChildTitleText}
            accessibilityLabel="product-required-quantity-label"
          >
            {/* {strings["required.quantity"]} */}
            {strings["maximum.quantity"]}
          </CustomText>
          <CustomText
            style={styles.itemChildValueText}
            accessibilityLabel="product-required-quantity-value"
          >
            {requiredQty}
          </CustomText>
        </View>
      )}

      {!(isFromStockTransfer ?? false) && (
        <View
          style={[styles.itemChildContainer]}
          accessible={true}
          accessibilityLabel="product-transit-quantity"
        >
          <CustomText
            style={styles.itemChildTitleText}
            accessibilityLabel="product-transit-quantity-value"
          >
            {strings["ime.scanner.qty.in.transit"] ?? "Qty in Transit"}
          </CustomText>
          <CustomText
            style={styles.itemChildValueText}
            accessibilityLabel="product-transit-quantity-value"
          >
            {transitQty}
          </CustomText>
        </View>
      )}
    </View>
  );
};

export default ProductInfoDetails;
