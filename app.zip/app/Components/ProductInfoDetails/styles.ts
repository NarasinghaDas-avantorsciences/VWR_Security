import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  itemChildContainer: {
    width: SIZES.width * 0.4,
    marginVertical: wp(0.5),
    paddingVertical: 8,
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },
});

export default Styles;
