import { StyleSheet } from "react-native";
import { hp, wp } from "../../Utils/globalFunction";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";

export default StyleSheet.create({
  leftIconContainer: { marginRight: wp(4) },

  leftIcon: {
    width: wp(18),
    height: wp(18),
  },

  flexRowCenter: { flexDirection: "row", alignItems: "center" },

  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },

  tagContainer: { marginHorizontal: wp(2) },

  openOrderContainer: {
    borderWidth: 1,
    borderRadius: wp(10),
    borderColor: COLORS.chelseaGem3,
    backgroundColor: COLORS.sandyBeach,
    paddingHorizontal: wp(2),
  },

  kpiDivider: {
    marginHorizontal: wp(2),
  },

  openOrder: {
    color: COLORS.chelseaGem,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },

  qtyInfoContainer: { paddingVertical: hp(0.8), alignSelf: "flex-start" },

  itemSubHeaderStyle: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
  },

  itemContainerStyle: {
    borderBottomWidth: 1,
    paddingVertical: hp(3),
    borderColor: COLORS.whiteSmoke,
    backgroundColor: COLORS.white,
  },

  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  itemChildContainer: {
    width: SIZES.width * 0.4,
    marginTop: wp(0.5),
  },

  commentInputStyle: {
    width: wp(42),
    alignSelf: "flex-start",
    backgroundColor: COLORS.white,
    marginRight: wp(4),
    paddingTop: hp(1),
  },

  inputStyle: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h1_5,
    color: COLORS.abbey,
    left: -wp(2),
  },

  inputMainStyle: {
    height: hp(4),
    top: 0,
    borderColor: COLORS.gray2,
    borderWidth: 0.8,
  },

  qtyWrapper: {
    paddingTop: hp(1),
    flexDirection: "row",
    alignItems: "center",
  },

  qtyTitleStyle: {
    marginRight: wp(3),
    paddingHorizontal: 3,
  },

  itemSeparator: { height: hp(1.8) },

  multipierText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_regular,
  },
});
