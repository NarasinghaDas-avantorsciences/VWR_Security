import React from "react";
import { View, Image, Pressable, TouchableOpacity } from "react-native";
import { useSelector } from "react-redux";

import ListItem from "../ListItem";
import TextInputComponent from "../TextInput";
import QtyController from "../QtyController";
import {
  Checkbox,
  DefaultProductImage,
  Locked,
  OneTag,
  RTag,
  STag,
  Unselected,
} from "../../Utils/images";
import {
  checkUomCondition,
  wp,
  isReplenishProductFreezed,
  getMultiplier,
  isDeviceTablet,
} from "../../Utils/globalFunction";
import { Item } from "../../Screens/AppFlow/Replenish";
import ProductInfoDetails from "../ProductInfoDetails";
import CustomText from "../CustomText";
import styles from "./styles";

type ReplenishListItemProps = {
  disabled: boolean;
  item: Item;
  inputQtyValue: string;
  onPressItemDescription: () => void;
  onPressItemCheckbox: () => void;
  onChangeComment: (text: string) => void;
  onChangeQty: (v: string) => void;
  index: number;
};

const ReplenishListItem: React.FC<ReplenishListItemProps> = ({
  disabled,
  item,
  inputQtyValue,
  onPressItemDescription,
  onPressItemCheckbox,
  onChangeComment,
  onChangeQty,
  index,
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const { stockRoomDetail, isOnHand } = useSelector(
    (state: any) => state.userReducer
  );

  return (
    <ListItem
      disabled={disabled}
      leftIcon={
        <View
          style={styles.leftIconContainer}
          accessible={true}
          accessibilityLabel="list-item-left-icon-container"
        >
          {item?.imageURL ? (
            <Image
              source={{ uri: item.imageURL.replace("http://", "https://") }}
              style={styles.leftIcon}
              resizeMode={"contain"}
              accessible={true}
              accessibilityLabel="list-item-left-icon-image"
            />
          ) : (
            <DefaultProductImage
              width={wp(18)}
              height={wp(18)}
              accessible={true}
              accessibilityLabel="list-item-left-default-image"
            />
          )}
        </View>
      }
      headerContent={
        <View>
          <View
            style={styles.flexRowCenter}
            accessible={true}
            accessibilityLabel="list-item-header-content"
          >
            <CustomText
              style={styles.catalogNumber}
              accessible={true}
              accessibilityLabel="list-item-header-content-catalogNo"
            >
              {item?.catalogNo}
            </CustomText>
            {item.type === "RECOMMENDED" && (
              <RTag
                style={styles.tagContainer}
                accessible={true}
                accessibilityLabel="list-item-header-r-tag"
              />
            )}
            {item.type === "STOCKED" && (
              <STag
                style={styles.tagContainer}
                accessible={true}
                accessibilityLabel="list-item-header-s-tag"
              />
            )}
            {item.type === "ONETIME" && (
              <OneTag
                style={styles.tagContainer}
                accessible={true}
                accessibilityLabel="list-item-header-one-tag"
              />
            )}
            {parseInt(item.backlogQty) > 0 && (
              <View
                style={[
                  styles.openOrderContainer,
                  item.kpiEnabled && styles.kpiDivider,
                ]}
                accessible={true}
                accessibilityLabel="list-item-header-oepn-order-container"
              >
                <CustomText
                  style={styles.openOrder}
                  accessibilityLabel="list-item-open-order-label"
                >
                  {strings["ime.open.orders"]}
                </CustomText>
              </View>
            )}
          </View>

          <TouchableOpacity onPress={onPressItemDescription}>
            <CustomText
              style={styles.itemHeaderContent}
              accessibilityLabel="list-item-description"
            >
              {item?.description}
            </CustomText>
          </TouchableOpacity>

          {checkUomCondition(item) && (
            <View style={styles.qtyInfoContainer}>
              <CustomText
                style={styles.itemSubHeaderStyle}
                accessibilityLabel="list-item-uom-label"
              >
                {item?.uomManagementEnabled == 1
                  ? item.stockRoomUOMUnit !== null
                    ? `(${item.stockRoomUOMUnit})`
                    : ""
                  : item.uomId !== null
                  ? `(${item.uomId})`
                  : ""}
              </CustomText>
            </View>
          )}
        </View>
      }
      rightIcon={
        isReplenishProductFreezed(item) ? (
          <Locked
            accessible={true}
            accessibilityLabel="list-item-locked-image"
          />
        ) : (
          <Pressable
            onPress={onPressItemCheckbox}
            accessible={true}
            accessibilityLabel="list-item-checkbox"
          >
            {item?.selected ? <Checkbox /> : <Unselected />}
          </Pressable>
        )
      }
      customStyles={{ container: styles.itemContainerStyle }}
    >
      <View
        style={styles.flexRowContainer}
        accessible={true}
        accessibilityLabel="list-item-flex-container"
      >
        <ProductInfoDetails
          vendorName={item?.vendorName}
          locationName={item?.locationName ?? "-"}
          requiredQty={item?.maxStockQty ?? "-"}
          transitQty={item?.backlogQty ?? "-"}
        />

        <View
          style={[
            styles.itemChildContainer,
            styles.flexRowCenter,
            isDeviceTablet() ? { flexWrap: "nowrap" } : { flexWrap: "wrap" },
          ]}
          accessible={true}
          accessibilityLabel="list-item-child-container"
        >
          {stockRoomDetail?.isCommentsEnabled ? (
            <TextInputComponent
              idLabel={`replenishListItem-comment-${index}`}
              title={strings["comment"]}
              disableRightIcon={true}
              disableLeftIcon={true}
              placeholder={
                item?.enteredComment ??
                strings["ime.scanner.enter.comment"] ??
                "Enter comment"
              }
              value={item?.enteredComment ?? ""}
              editable={true}
              onChangeText={onChangeComment}
              main={styles.commentInputStyle}
              inputStyle={styles.inputStyle}
              inputMain={styles.inputMainStyle}
            />
          ) : null}

          <View style={styles.qtyWrapper}>
            <QtyController
              title={
                isOnHand ? "Current \non hand\nquantity" : strings["ime.qty"]
              }
              onChange={onChangeQty}
              titleStyle={styles.qtyTitleStyle}
              inputValue={inputQtyValue}
              disable={isReplenishProductFreezed(item)}
            />
            <CustomText
              style={styles.multipierText}
              accessibilityLabel="list-item-multiplier"
            >
              {item?.orderedQtyUOMDisplay ?? getMultiplier(item)}
            </CustomText>
          </View>
        </View>
      </View>
    </ListItem>
  );
};

export default ReplenishListItem;
