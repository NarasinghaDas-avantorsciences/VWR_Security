import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  addButton: {
    borderWidth: 1,
    paddingVertical: hp(1),
    justifyContent: "center",
    alignItems: "center",
    marginTop: hp(2),
    width: wp(37),
  },

  buttonTitle: {
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_5,
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: COLORS.alto,
    alignItems: "center",
    paddingTop: SIZES.tip,
  },
  qty: {
    width: wp(10),
    height: hp(4),
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_regular,
    textAlign: "center",
    padding: 0,
  },
  qtyTitle: {
    color: COLORS.abbey,
    textAlign: "center",
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_semibold,
  },
  inputMain: {
    width: "30%",
    alignSelf: "flex-start",
  },
  header: {
    marginTop: 27,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    marginBottom: 10,
  },
  headerText: {
    ...FONTS.body,
    color: COLORS.abbey,
  },
  input: {
    height: hp(4),
    fontSize: FONTS.h1_5,
    padding: 0,
    color: COLORS.abbey,
  },
  arrowMain: {
    flexDirection: "row",
    alignItems: "center",
  },
  crossBtn: {
    marginTop: SIZES.radius,
    paddingHorizontal: 3,
    paddingVertical: 6,
  },
});

export default Styles;
