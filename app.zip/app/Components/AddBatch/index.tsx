import React, { useCallback, useEffect, useState } from "react";
import {
  View,
  TouchableOpacity,
  Keyboard,
  ViewStyle,
  Platform,
} from "react-native";
import { useSelector, useDispatch } from "react-redux";
import Calender from "../../Components/Calender";
import moment from "moment";
import styles from "./styles";
import {
  QtyController,
  TextInputComponent,
  AlertModal,
} from "../../Components/index";
import {
  findDateFormat,
  hp,
  removeEmojis,
  wp,
} from "../../Utils/globalFunction";
import { setReceiveLimtiFlag } from "../../Redux/Action/receiveAction";
import { Cross } from "../../Utils/images";
import { COLORS } from "../../Utils/theme";
import CustomText from "../CustomText";
import { useFocusEffect } from "@react-navigation/native";
import { setCorrectStockList } from "../../Redux/Action/stockCorrection";

type AddBatchProps = {
  item?: any;
  from?: any;
  onChange?: any;
  data?: any;
  onDelete?: any;
  updateActualQty?: any;
  setLoader?: any;
  disabled?: boolean;
  freeze?: boolean;
  topLimitValue?: any;
  formatedData: any;
  setFormatedData: any;
  setVariationQty?: any;
  addBatchContainerStyle?: ViewStyle;
  receiveTabActive?: boolean;
  setMainQtyDisabledState?: any;
};

let flag = 0;
const PICOUNT = "picount";

const AddBatch: React.FC<AddBatchProps> = ({
  item,
  from = "stock.correction",
  onChange,
  data,
  onDelete,
  updateActualQty,
  setLoader,
  disabled = false,
  formatedData,
  setFormatedData,
  topLimitValue,
  freeze = false,
  setVariationQty,
  addBatchContainerStyle = {},
  receiveTabActive = false,
  setMainQtyDisabledState,
}) => {
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { stockRoomDetail, dateFormat } = useSelector(
    (state: any) => state.userReducer
  );
  const { receiveLimitFlag } = useSelector(
    (state: any) => state.receiveReducer
  );
  const [batchValue, setBatchValue] = useState<any>("0");
  const [todayDate, setToday] = useState(moment().format("YYYY-MM-DD"));
  const [focusedDate, setFocusedDate] = useState(moment().format("MM-DD-YYYY"));
  const [visable, setVisable] = useState(false);
  const [selectedDate, setSelectedDate] = useState<any>(null);
  const [keyboardStatus, setKeyboardStatus] = useState(false);
  const [batchFormattedData, setBatchFormattedData] = useState(formatedData);
  const { correctStockList } = useSelector(
    (state: any) => state.stockCorrectionReducer
  );

  useFocusEffect(
    useCallback(() => {
      const showSubscription = Keyboard.addListener("keyboardDidShow", () => {
        setKeyboardStatus(true);
      });
      const hideSubscription = Keyboard.addListener("keyboardDidHide", () => {
        setKeyboardStatus(false);
      });

      return () => {
        showSubscription.remove();
        hideSubscription.remove();
      };
    }, [])
  );

  useEffect(() => {
    addPreData();
  }, []);

  const onChangeData = async (
    inputVal: string,
    index: number,
    key: string,
    batchId: string
  ) => {
    let text = removeEmojis(inputVal);
    let data =
      key == "actualQty" || key == "expiryDate"
        ? from == PICOUNT
          ? batchFormattedData
          : formatedData
        : from == PICOUNT
        ? [...batchFormattedData]
        : [...formatedData];

    data[index] = {
      ...data[index],
      [key]: text,
    };
    setFormatedData(data);
    setBatchFormattedData(data);
    onChange && onChange(data, batchId, item?.id, key == "actualQty");

    if (key == "actualQty") {
      if (from == "stock.correction" || from == PICOUNT) {
        // const val =
        //   from == PICOUNT
        //     ? batchFormattedData.reduce(
        //         (n: any, { actualQty }: any) => Number(n) + Number(actualQty),
        //         0
        //       )
        //     :
        //     formatedData.reduce(
        //         (n: any, { actualQty }: any) => Number(n) + Number(actualQty),
        //         0
        //       );
        let val = 0;
        let val_stockCorrection = "";

        if (from == PICOUNT) {
          val = batchFormattedData.reduce(
            (n: any, { actualQty }: any) => Number(n) + Number(actualQty),
            0
          );
        } else if (from == "stock.correction") {
          let newArr = formatedData?.filter((item) => item?.actualQty != "");

          if (newArr?.length > 0) {
            val_stockCorrection = String(
              formatedData.reduce(
                (n: any, { actualQty }: any) => Number(n) + Number(actualQty),
                0
              )
            );
          }
        } else {
          val = formatedData.reduce(
            (n: any, { actualQty }: any) => Number(n) + Number(actualQty),
            0
          );
        }

        await updateActualQty(
          from == "stock.correction" ? val_stockCorrection : val
        );
      } else {
        let dummyArr =
          from == PICOUNT
            ? batchFormattedData.filter((item: any) => item.added == true)
            : formatedData.filter((item: any) => item.added == true);
        const val = dummyArr.reduce(
          (n: any, { actualQty }: any) => Number(n) + Number(actualQty),
          0
        );
        await updateActualQty(val);
      }
    }
  };

  const checkifBatchEnabled = () => {
    if (
      stockRoomDetail?.isBatchManagementEnabled &&
      (item?.batchManagementEnabled || item?.product?.batchManagementEnabled)
    ) {
      return true;
    } else {
      return false;
    }
  };

  const checkifExpiryEnabled = () => {
    if (
      stockRoomDetail?.isExpiryManagementEnabled &&
      (item?.expiryDateManagementenabled ||
        item?.product?.expiryDateManagementenabled)
    ) {
      return true;
    } else {
      return false;
    }
  };

  const addPreData = async () => {
    let preData = [];
    setLoader?.(true);
    for (let i = 0; i < data?.length; i++) {
      let d = {
        batchNo: data[i]?.batchNo,
        expiryDate: data[i]?.expiryDate,
        actualQty:
          from == "stock.correction"
            ? data[i]?.actualQty ?? ""
            : data[i]?.actualQty ?? data[i]?.availableQty,
        id: data[i]?.id,
        added: data[i]?.id.includes("addedBatch") ? true : false,
      };
      preData.push(d);
    }
    await setBatchFormattedData([...preData]);
    await setFormatedData([...preData]);

    const val =
      preData &&
      preData.reduce(
        (n: any, { actualQty }: any) => Number(n) + Number(actualQty),
        0
      );

    setVariationQty(val);
    setLoader?.(false);
  };

  const add = async () => {
    flag += 1;

    let d = {
      batchNo: "",
      expiryDate: "",
      // actualQty: from == "picount" ? "" : 0,
      actualQty: from == "picount" ? "" : from == "stock.correction" ? "" : 0,
      id: `addedBatch-${flag}`,
      added: true,
    };

    let findIndex = correctStockList?.findIndex(
      (data: any) => data.id == item.id
    );
    let newBlockData = correctStockList;
    if (findIndex != -1) {
      newBlockData[findIndex].batches = [
        ...newBlockData[findIndex]?.batches,
        d,
      ];
    }
    await dispatch(setCorrectStockList(newBlockData));

    setBatchFormattedData([...batchFormattedData, d]);
    from == PICOUNT
      ? setFormatedData([...batchFormattedData, d], item.id)
      : setFormatedData([...formatedData, d], item.id);
  };

  const preDate = () => {
    let date;
    if (
      from == PICOUNT
        ? batchFormattedData[selectedDate?.index]?.date
        : formatedData[selectedDate?.index]?.date
    ) {
      date = moment(
        from == PICOUNT
          ? batchFormattedData[selectedDate?.index]?.date
          : formatedData[selectedDate?.index]?.date
      ).format("YYYY-MM-DD");
    } else {
      date = moment().format("YYYY-MM-DD");
    }
    return date;
  };

  const markedDate = () => {
    return {
      [preDate()]: { selected: true, selectedColor: COLORS.scienceBlue },
    };
  };

  const changeDate = (date: string) => {
    date = moment(date).format("YYYY-MM-DD");
    onChangeData(date, selectedDate?.index, "expiryDate", selectedDate?.id);
    setVisable(false);
    setSelectedDate(null);
    //setToday(date);
  };

  const __renderCalander = () => (
    <Calender
      changeDate={(date: any) => changeDate(date)}
      selectedDate={focusedDate}
      // selectedDate={moment(focusedDate).format("MM-DD-YYYY")}
      onClose={() => setVisable(!visable)}
    />
  );

  const checkPICount = (formattedItem: any) => {
    if (from == PICOUNT && formattedItem?.id?.includes("addedBatch")) {
      return true;
    } else {
      return false;
    }
  };

  const getExpiryFormattedDate = (dateValue: string, isAdded: boolean) => {
    //Added formate is always YYYY-MM-DD, we will formate it to "MM/DD/YYYY" in
    // mainData?.map((formattedItem: any, index: any) during rendering the ADD batch
    if (isAdded) {
      return (
        dateValue && moment(dateValue, "MM-DD-YYYY").format(dateFormat.date)
      );
    } else {
      return (
        dateValue && moment(dateValue, "MM-DD-YYYY").format(dateFormat.date)
        // dateValue &&
        // moment(dateValue, findDateFormat(dateValue)).format(dateFormat.date)
      );
    }
  };

  let mainData = from == PICOUNT ? batchFormattedData : formatedData;
  return (
    <View
      style={[
        from !== PICOUNT && {
          flex: 1,
          paddingBottom: 0, //keyboardStatus && Platform.OS == "ios" ? hp(10) : 0,
        },
        addBatchContainerStyle,
      ]}
    >
      {mainData?.map((formattedItem: any, index: any) => {
        let date =
          from == "receive"
            ? String(
                formattedItem?.expiryDate != ""
                  ? formattedItem?.added
                    ? moment(formattedItem?.expiryDate, "YYYY-MM-DD").format(
                        "MM-DD-YYYY"
                      )
                    : moment(formattedItem?.expiryDate, "YYYY-MM-DD").format(
                        "MM-DD-YYYY"
                      )
                  : focusedDate
              )
            : moment(formattedItem?.expiryDate, "YYYY-MM-DD").format(
                "MM-DD-YYYY"
              );
        /* 
            let date = (formattedItem?.added)
          ? moment(formattedItem?.expiryDate, "DD-MM-YYYY")
          : (formattedItem?.expiryDate != "")
          ? moment(formattedItem?.expiryDate, "DD-MM-YYYY").format("MM-DD-YYYY")
          : focusedDate; 
          */

        date = formattedItem?.expiryDate
          ? date.substring(0, 6) + "2" + date.substring(6 + 1)
          : "";
        let batch = item?.batches ?? item?.new_batches;
        return (
          <View style={styles.item} key={index}>
            <TextInputComponent
              charLimit={25}
              idLabel={`${from}-batch-number`}
              title={Strings["batch.no"]}
              editable={
                from == PICOUNT ||
                formattedItem?.added ||
                from == "stock.correction"
                  ? checkifBatchEnabled()
                  : false
              }
              disabled={
                receiveTabActive
                  ? false
                  : freeze
                  ? true
                  : from == "receive"
                  ? formattedItem?.added
                    ? !checkifBatchEnabled()
                    : true
                  : !checkifBatchEnabled()
              }
              main={styles.inputMain}
              inputStyle={[
                styles.input,
                {
                  color: formattedItem?.added ? COLORS.abbey : COLORS.gray4,
                },
              ]}
              inputMain={{
                height: hp(4),
              }}
              placeholder={Strings["batch.no"]}
              value={removeEmojis(formattedItem?.batchNo)}
              onChangeText={
                from == "receive"
                  ? formattedItem?.added
                    ? (val) =>
                        onChangeData(val, index, "batchNo", formattedItem?.id)
                    : () => null
                  : checkifBatchEnabled()
                  ? (val) =>
                      onChangeData(val, index, "batchNo", formattedItem?.id)
                  : () => null
              }
            />
            <TextInputComponent
              idLabel={`${from}-expiry-date`}
              title={Strings["ime.scanner.Exp.Date"]}
              pointerEvents="none"
              editable={false}
              disabled={
                receiveTabActive
                  ? false
                  : freeze
                  ? true
                  : from == "receive"
                  ? formattedItem?.added
                    ? !checkifExpiryEnabled()
                    : true
                  : !checkifExpiryEnabled()
              }
              value={getExpiryFormattedDate(date, formattedItem?.added)}
              main={styles.inputMain}
              inputStyle={styles.input}
              inputMain={{
                height: hp(4),
                alignItems: "center",
              }}
              placeholder={Strings["date"]}
              onChangeText={
                checkifExpiryEnabled() ||
                (from == "receive" && !formattedItem?.added)
                  ? (val) =>
                      onChangeData(val, index, "expiryDate", formattedItem?.id)
                  : () => null
              }
              onPressRightIcon={
                checkifExpiryEnabled() ||
                (from == "receive" && !formattedItem?.added)
                  ? () => {
                      setSelectedDate({ index, id: formattedItem?.id });
                      setVisable(!visable);
                      date && setFocusedDate(date);
                    }
                  : () => null
              }
            />
            <View>
              <CustomText
                allowFontScaling={false}
                style={styles.qtyTitle}
                accessibilityLabel={`${from}-qty-text`}
              >
                {Strings["ime.qty"]}
              </CustomText>
              <QtyController
                showLabel={false}
                onChange={async (val: string, setInputVal: any = null) => {
                  val = val != "" ? Number(val).toString() : val;

                  if (from == "receive" && val != "") {
                    const qty =
                      mainData.reduce(
                        (n: any, { actualQty }: any) =>
                          Number(n) + Number(actualQty),
                        0
                      ) -
                      Number(mainData[index]?.actualQty) +
                      Number(val);
                    if (qty > topLimitValue) {
                      if (setInputVal) {
                        setInputVal("0");
                      }
                      setBatchValue("0"); //reset to zero
                      val = "0";
                      await dispatch(setReceiveLimtiFlag(receiveLimitFlag + 1));
                    } else {
                      setBatchValue(qty);
                    }
                  }

                  // val != "" &&
                  onChangeData(val, index, "actualQty", formattedItem?.id);
                }}
                inputStyle={styles.qty}
                // inputValue={
                //   from == "stock.correction"
                //     ? formattedItem?.added
                //       ? String(mainData[index]?.actualQty ?? "")
                //       : String(batch[index]?.actualQty ?? "")
                //     : String(formattedItem?.actualQty)
                // }
                inputValue={
                  from == "stock.correction"
                    ? formattedItem?.added
                      ? String(mainData[index]?.actualQty ?? "")
                      : String(
                          formattedItem?.actualQty ??
                            batch[index]?.actualQty ??
                            ""
                        )
                    : String(formattedItem?.actualQty)
                }
                topLimit={Number(batchValue) >= topLimitValue}
                topLimitValue={topLimitValue}
                disable={
                  receiveTabActive
                    ? true
                    : freeze
                    ? true
                    : from == "receive"
                    ? !formattedItem?.added
                    : false
                }
                from={from}
                isReceiveBatch={from == "receive"}
              />
            </View>

            {(formattedItem?.added || checkPICount(formattedItem)) && (
              <TouchableOpacity
                testID="addBatch-cross"
                accessible={true}
                accessibilityLabel={
                  from ? `${from}-addBatch-cross` : `addBatch-cross`
                }
                style={styles.crossBtn}
                onPress={async () => {
                  flag -= 1;
                  if (flag <= 0)
                    from == "receive" && setMainQtyDisabledState(false);
                  await onDelete(formattedItem, formattedItem, item);
                  let newData = mainData?.filter(
                    (item: any, i: any) => i != index
                  );
                  setBatchFormattedData(newData);
                  setFormatedData(newData);

                  //UPDATE RECEIVED QTY ISSUE IN RECEIVE SCREEN
                  //===========================================

                  if (from == "receive") {
                    let dummyArr = newData.filter(
                      (item: any) => item.added == true
                    );

                    const val = dummyArr.reduce(
                      (n: any, { actualQty }: any) =>
                        Number(n) + Number(actualQty),
                      0
                    );
                    setBatchValue(val);
                    await updateActualQty(val);
                  } else {
                    const val = newData.reduce(
                      (n: any, { actualQty }: any) =>
                        Number(n) + Number(actualQty),
                      0
                    );
                    await updateActualQty(val);
                  }
                  //===============================================
                  // const val = newData.reduce(
                  //   (n: any, { actualQty }: any) =>
                  //     Number(n) + Number(actualQty),
                  //   0
                  // );

                  // if (from == "receive") setBatchValue(val);

                  // await updateActualQty(val);
                  //======================================
                }}
              >
                <Cross />
              </TouchableOpacity>
            )}
          </View>
        );
      })}
      {!freeze && (
        <TouchableOpacity
          testID="addBatch-button"
          accessible={true}
          accessibilityLabel={
            from ? `${from}-addBatch-button` : "addBatch-button"
          }
          disabled={!!disabled || !!(Number(batchValue) >= topLimitValue)}
          style={[
            styles.addButton,
            {
              borderColor:
                disabled || !!(Number(batchValue) >= topLimitValue)
                  ? COLORS.gray2
                  : COLORS.scienceBlue,
            },
          ]}
          onPress={() => {
            from == "receive" && setMainQtyDisabledState(true);
            add();
          }}
        >
          <CustomText
            allowFontScaling={false}
            style={[
              styles.buttonTitle,
              {
                color:
                  disabled || Number(batchValue) >= topLimitValue
                    ? COLORS.gray2
                    : COLORS.scienceBlue,
              },
            ]}
            accessibilityLabel={
              from ? `${from}-addBatch-button-text` : "addBatch-button-text"
            }
          >
            {Strings["ime.scanner.add.batch.expiry"] ?? "Add Batch / Expiry"}
          </CustomText>
        </TouchableOpacity>
      )}
      <AlertModal
        isShow={visable}
        customStyles={{
          width: wp(95),
          borderRadius: 4,
          alignSelf: "center",
          paddingVertical: hp(1),
        }}
      >
        {__renderCalander()}
      </AlertModal>
    </View>
  );
};

export default AddBatch;
