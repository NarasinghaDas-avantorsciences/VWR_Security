import React from "react";
import { View, StatusBar, SafeAreaView } from "react-native";

const STATUSBAR_HEIGHT = StatusBar.currentHeight;

const MyStatusBar = ({ backgroundColor, containerStyle, ...props }: any) => (
  <View
    accessible={true}
    accessibilityLabel="statusbar_container"
    style={[{ height: STATUSBAR_HEIGHT }, { backgroundColor }, containerStyle]}
  >
    <SafeAreaView>
      <StatusBar accessible={true}
        accessibilityLabel="status_bar" translucent backgroundColor={backgroundColor} {...props} />
    </SafeAreaView>
  </View>
);

export default MyStatusBar;
