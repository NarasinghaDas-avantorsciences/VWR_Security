import React, { useState } from "react";
import { Switch, SwitchProps } from "react-native";
import styles from "./styles";
import { COLORS } from "../../Utils/theme";

interface ToggleSwitchProps extends SwitchProps {
  onValueChange: (value: boolean) => void;
  isEnabled: boolean;
}

const ToggleSwitch: React.FC<ToggleSwitchProps> = ({
  onValueChange,
  isEnabled,
  ...props
}) => {
  // const [isEnabled, setIsEnabled] = useState(false);

  const handleToggle = (value: boolean) => {
    // setIsEnabled(value);
    onValueChange(value);
  };

  return (
    <Switch
      style={styles.switch}
      onValueChange={handleToggle}
      trackColor={{ false: COLORS.gray2, true: COLORS.toggle_green }}
      thumbColor={COLORS.white}
      value={isEnabled ? isEnabled : false}
      {...props}
    />
  );
};

export default ToggleSwitch;
