import { StyleSheet } from "react-native";

const Styles = StyleSheet.create({
  switch: { marginLeft: 12 },
});

export default Styles;
