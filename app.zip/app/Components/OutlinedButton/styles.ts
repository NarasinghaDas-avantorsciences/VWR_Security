import { StyleSheet } from "react-native";

import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  pressableContainer: {
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: hp(1.5),
    marginHorizontal: wp(4),
  },

  pressableText: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_6,
  },
});

export default Styles;
