import React from "react";
import {
  Text,
  TouchableOpacity,
  StyleProp,
  ViewStyle,
  TextStyle,
} from "react-native";

import styles from "./styles";
import CustomText from "../CustomText";
import { COLORS } from "../../Utils/theme";

interface OutlinedButtonProps {
  onChangeBtnPress?: () => void;
  title: String;
  mainContainerStyle?: StyleProp<ViewStyle>;
  mainTextStyle?: StyleProp<TextStyle>;
  accessibilityLabel?: any;
  disabled?: boolean;
}

const OutlinedButton: React.FC<OutlinedButtonProps> = ({
  mainContainerStyle,
  mainTextStyle,
  title,
  accessibilityLabel,
  onChangeBtnPress,
  disabled = false,
}) => {
  return (
    <TouchableOpacity
      accessible={true}
      accessibilityLabel={accessibilityLabel}
      style={[
        styles.pressableContainer,
        mainContainerStyle,
        {
          borderColor: disabled ? COLORS.gray2 : COLORS.scienceBlue,
          opacity: disabled ? 0.4 : 1,
        },
      ]}
      onPress={onChangeBtnPress}
      disabled={disabled}
    >
      <CustomText
        accessibilityLabel={`${accessibilityLabel}-outlined_button_label`}
        allowFontScaling={false}
        style={[
          styles.pressableText,
          { color: disabled ? COLORS.gray2 : COLORS.scienceBlue },
          mainTextStyle,
        ]}
      >
        {title}
      </CustomText>
    </TouchableOpacity>
  );
};

export default OutlinedButton;
