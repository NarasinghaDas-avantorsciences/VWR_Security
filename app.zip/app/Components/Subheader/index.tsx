import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Pressable,
  StyleProp,
  ViewStyle,
  ScrollView,
  TouchableOpacity,
  Keyboard,
} from "react-native";
import { Shadow } from "react-native-shadow-2";
import { useSelector, useDispatch } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import {
  filterByMultipleKeys,
  filterByMultipleKeysBarcode,
  hp,
  wp,
} from "../../Utils/globalFunction";
import { ArrowDown, TickIcon } from "../../Utils/images";
import { COLORS, FONTFAMILY, SIZES, FONTS } from "../../Utils/theme";
import {
  BottomSheetComponent,
  AlertModal,
  AnimatedSearch,
} from "../../Components";
import MainButton from "../MainButton";
import OutlinedButton from "../OutlinedButton";
import SearchBar from "../SearchBar";
import TextInputComponent from "../TextInput";
import styles from "./styles";
import { ApiConfig } from "../../Service/Api";
import {
  getStockroomDetail,
  getStockroomsnew,
  setSelectedOrgandStockRoom,
  setSelectedOrgId,
  setSelectedRoomId,
  setStockroomDetail,
  clearOrgStockData,
  getUserPrivilege,
  getOrg as restStore,
} from "../../Redux/Action/userAction";
interface SubheaderProps {
  idLabel?: string;
  mainContainer?: StyleProp<ViewStyle>;
  buttonContainerStyle?: StyleProp<ViewStyle>;
  distance?: number;
  offset?: [x: string | number, y: string | number] | undefined;
  rowContainer?: StyleProp<ViewStyle>;
  onChangePress?: () => void;
  clearReplenishState?: any;
}
import * as storage from "../../Service/AsyncStoreConfig";
import {
  clearStockLevelData,
  getOutOfStock,
  getRunningLowStock,
} from "../../Redux/Action/dashboardAction";
import {
  saveDataToStorage,
  dispatchActions,
  _selectedStoreRoom,
  _selectedStoreOrg,
  stockRoomValue,
  orgRoomValue,
} from "./logic";
import CustomText from "../CustomText";
import NavigationService from "../../Navigation/NavigationService";
import { resetReplenishState } from "../../Redux/Action/replenishAction";
import { emptyProductData } from "../../Redux/Action/searchAction";

const Subheader: React.FC<SubheaderProps> = ({
  idLabel = "",
  mainContainer = {},
  buttonContainerStyle = {},
  distance = 25,
  offset = [3, 4],
  onChangePress,
  clearReplenishState,
}) => {
  const navigation = useNavigation();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const refRBSheet: any = useRef();
  const refRBSheet_list: any = useRef();
  const [sel_str, setSel_str] = useState("");
  const [searckKey, setSearchKey] = useState("");
  const { org, selectedTitle, selectedSubTitle, selectedOrgId, selectedRoom } =
    useSelector((state: any) => state.userReducer);
  const stockRoomsData = useSelector(
    (state: any) => state.userReducer?.stockRooms
  );
  const dispatch = useDispatch<any>();
  const userToken = useSelector((state: any) => state.loginReducer?.userToken);
  const [selectedRoomChild, setSelectedChildRoom] = useState<any>(null);
  const [stockRooms, setStockRooms] = useState<any>(stockRoomsData);
  const [active, setActive] = useState<any>(false);
  const { internet } = useSelector((state: any) => state.loginReducer);
  const [showModal, setShowModal] = useState(false);
  const [preData, setPreData] = useState<any>({});
  const [barcodeData, setBarcodeData] = useState<any>(false);

  useEffect(() => {
    !active && getOrg();
  }, [stockRoomsData, org]);

  useEffect(() => {
    setStockRooms(stockRoomsData);
  }, [stockRoomsData]);

  const getRooms = (id: any) => {
    dispatch(
      getStockroomsnew(id, (res: any) => {
        setStockRooms(res);
        setSelectedRoom(res?.stockroomHierarchy[0]["id"]);
      })
    );
  };
  const updateStoreDetailsToServer = async (data: any) => {
    await storage.getItem("dataStoreSave").then((res: any) => {
      let prevData = JSON.parse(res);
      if (prevData) {
        console.log("save store db");
        dispatch(
          setStockroomDetail({
            rememberOrgId: data?.orgId ?? "",
            rememberStockRoomId: data?.stockroomId ?? "",
          })
        );
      } else {
        return false;
      }
    });
  };
  const onSearchBarCode = (res) => {
    let blockData: any =
      sel_str == "stockroom"
        ? stockRooms?.stockroomHierarchy
        : sel_str == "org"
        ? org?.imeorganizationBaseDTO
        : null;

    let sampleArr: any = [];
    if (sel_str == "stockroom") {
      blockData?.map((item: any, index: number) => {
        blockData?.map((item, index) => {
          if (item.childStockroom?.length > 0) {
            item.childStockroom?.map((childData) => {
              let childDataSet = {
                ...childData,
                isChild: true,
                parentId: item.id,
              };
              let selectedIndex = sampleArr.findIndex(
                (sampleItem: any) => sampleItem.id == childData.id
              );
              selectedIndex == -1 && sampleArr.push(childDataSet);
            });
          }
          let selectedIndex = sampleArr.findIndex(
            (sampleItem: any) => sampleItem.id == item.id
          );
          selectedIndex == -1 && sampleArr.push(item);
        });
      });
    }
    // console.log("sampleArr",sampleArr)

    const filteredData = filterByMultipleKeysBarcode(
      sel_str == "stockroom" ? sampleArr.reverse() : blockData,
      sel_str == "org" ? "orgName" : "stockroomName",
      "id",
      res
    );
    if (filteredData?.length) {
      setBarcodeData(true);

      const item = filteredData[0];
      if (sel_str == "org") {
        setSearchKey(item?.orgName);
      } else {
        if (item.id == res || item.stockroomName == res) {
          setSearchKey(item?.stockroomName);
        } else if (
          item?.childStockroom?.length &&
          item?.childStockroom?.filter((item: { id: any }) => item?.id == res)
        ) {
          const name = item?.childStockroom?.filter((cItem: any) => {
            if (cItem?.id == res) {
              return cItem?.stockroomName;
            }
          });
          setSearchKey(name);
        } else {
          setSearchKey(res);
        }
      }
    } else {
      setBarcodeData(false);
      setSearchKey(res);
    }
  };

  const getOrg = () => {
    let dat = {};
    storage.getItem("org").then((res: any) => {
      const orgData = JSON.parse(res);
      const currentstockRooms = stockRoomsData || stockRooms;
      for (let i = 0; i < currentstockRooms?.stockroomHierarchy?.length; i++) {
        if (
          currentstockRooms?.stockroomHierarchy[i]?.id == orgData?.stockroomId
        ) {
          dispatch({
            type: "SUBTITLE",
            value: currentstockRooms?.stockroomHierarchy[i]?.stockroomName,
          });
          dat = {
            ...dat,
            selectedRoom: currentstockRooms?.stockroomHierarchy[i]?.id,
          };
          setSelectedRoom(currentstockRooms?.stockroomHierarchy[i]?.id);
        } else {
          for (
            let k = 0;
            k <
            currentstockRooms?.stockroomHierarchy[i]?.childStockroom?.length;
            k++
          ) {
            if (
              currentstockRooms?.stockroomHierarchy[i]?.childStockroom[k]?.id ==
              orgData?.stockroomId
            ) {
              dispatch({
                type: "SUBTITLE",
                value:
                  currentstockRooms?.stockroomHierarchy[i]?.childStockroom[k]
                    ?.stockroomName,
              });
              setSelectedRoom(currentstockRooms?.stockroomHierarchy[i]?.id);
              setSelectedChildRoom(k);
              dat = {
                ...dat,
                selectedRoom: currentstockRooms?.stockroomHierarchy[i]?.id,
                selectedRoomChild: k,
              };
            }
          }
        }
        setActive(true);
      }
      for (let i = 0; i < org?.imeorganizationBaseDTO?.length; i++) {
        if (org?.imeorganizationBaseDTO[i]?.id == orgData?.orgId) {
          dispatch({
            type: "TITLE",
            value: org?.imeorganizationBaseDTO[i]?.orgName,
          });
          setSelectedOrg(org?.imeorganizationBaseDTO[i]?.id);
          dat = {
            ...dat,
            selectedOrgId: org?.imeorganizationBaseDTO[i]?.id,
          };
        }
      }
      setPreData({
        currentstockRooms,
        ...dat,
      });
    });
  };
  const onReset = () => {
    refRBSheet.current.close();
  };

  const onClose = () => {
    setSelectedOrg(preData?.selectedOrgId);
    setSelectedRoom(preData?.selectedRoom);
    setSelectedChildRoom(preData?.selectedRoomChild);
    setStockRooms(preData.currentstockRooms);
    dispatch(restStore(true));
  };

  function setSelectedOrg(id: number) {
    dispatch(setSelectedOrgId(id));
  }

  function setSelectedRoom(id: number) {
    dispatch(setSelectedRoomId(id));
  }

  const onSelectCat = (str: string) => {
    setSel_str(str);
    refRBSheet_list.current.open();
  };

  const disableButton = () => {
    if (
      selectedTitle == orgRoomValue(org, selectedOrgId) &&
      selectedSubTitle ==
        stockRoomValue(selectedRoomChild, stockRooms, selectedRoom)
    ) {
      return true;
    } else {
      return false;
    }
  };

  const getTitle = () => {
    if (sel_str == "org") {
      return Strings["organization"];
    } else if (sel_str == "stockroom") {
      return Strings["stockroom"];
    }
  };

  const setApiToken = (token: any, data: { stockroomId: any; orgId: any }) => {
    new ApiConfig().setToken(token, JSON.stringify(data));
  };
  const saveStore = async () => {
    const routes = navigation.getState().routes;

    const data = {
      stockroomId:
        selectedRoomChild != null
          ? _selectedStoreRoom(stockRooms, selectedRoom)?.childStockroom[
              selectedRoomChild
            ]?.id
          : selectedRoom,
      orgId: selectedOrgId,
    };
    const details = {
      selectedStockRoom:
        selectedRoomChild != null
          ? _selectedStoreRoom(stockRooms, selectedRoom)?.childStockroom[
              selectedRoomChild
            ]
          : _selectedStoreRoom(stockRooms, selectedRoom),
      selectedOrg: _selectedStoreOrg(org, selectedOrgId),
    };
    //remove the offline consume/replenish data

    await storage.removeData("consume_offline_data");
    await storage.removeData("replenish_offline_data");

    setApiToken(userToken, data);
    saveDataToStorage("org", data);
    updateStoreDetailsToServer(data);
    const titleValue = _selectedStoreOrg(org, selectedOrgId)?.orgName;
    const subTitle =
      selectedRoomChild != null
        ? _selectedStoreRoom(stockRooms, selectedRoom)?.childStockroom[
            selectedRoomChild
          ]?.stockroomName
        : _selectedStoreRoom(stockRooms, selectedRoom)?.stockroomName;
    dispatchActions(
      details,
      dispatch,
      setSelectedOrgandStockRoom,
      getOutOfStock,
      getRunningLowStock,
      getStockroomDetail,
      titleValue,
      subTitle,
      clearStockLevelData
    );
    refRBSheet.current.close();
    setSearchKey("");
    clearReplenishState && clearReplenishState();
    await dispatch(resetReplenishState());
    await dispatch(emptyProductData());
    if (
      routes[1]?.name == "ReceiveDetails" ||
      routes[1]?.name == "ApprovalDetails"
    ) {
      navigation.goBack();
      NavigationService.reset("Dashboard");
    } else {
      NavigationService.reset("Dashboard");
    }
    dispatch(getUserPrivilege());
  };

  const _renderList = () => {
    let blockData: any =
      sel_str == "stockroom"
        ? stockRooms?.stockroomHierarchy
        : sel_str == "org"
        ? org?.imeorganizationBaseDTO
        : null;
    const filteredData = filterByMultipleKeys(
      blockData,
      sel_str == "org" ? "orgName" : "stockroomName",
      "id",
      searckKey
    );
    let sampleArr: any = [];
    if (sel_str == "stockroom") {
      blockData?.map((item: any, index: number) => {
        blockData?.map((item, index) => {
          if (item.childStockroom?.length > 0) {
            item.childStockroom?.map((childData) => {
              let childDataSet = {
                ...childData,
                isChild: true,
                parentId: item.id,
              };
              let selectedIndex = sampleArr.findIndex(
                (sampleItem: any) => sampleItem.id == childData.id
              );
              selectedIndex == -1 && sampleArr.push(childDataSet);
            });
          }
          let selectedIndex = sampleArr.findIndex(
            (sampleItem: any) => sampleItem.id == item.id
          );
          selectedIndex == -1 && sampleArr.push(item);
        });
      });

      const filteredData_new = barcodeData
        ? filterByMultipleKeysBarcode(
            sampleArr.reverse(),
            "stockroomName",
            "id",
            searckKey
          )
        : filterByMultipleKeys(
            sampleArr.reverse(),
            "stockroomName",
            "id",
            searckKey
          );

      if (searckKey.length > 0) {
        if (filteredData_new?.length) {
          return (
            <>
              {filteredData_new?.map((i, key) => {
                let filterSet = blockData?.filter(
                  (item) => item.id == (i.isChild ? i.parentId : i.id)
                );
                return <>{__renderItem(i, key, filterSet)}</>;
              })}
            </>
          );
        } else {
          return noDataFound();
        }
      } else {
        return filteredData?.map((item: any, index: number) => (
          <>
            {__renderItem(item, index)}
            {sel_str == "stockroom" &&
              filteredData[index]?.childStockroom?.map((i: any, key: number) =>
                __renderChildItem(i, item?.id, key)
              )}
          </>
        ));
      }
    } else {
      if (filteredData?.length) {
        {
          return filteredData?.map((item: any, index: number) => (
            <>{__renderItem(item, index)}</>
          ));
        }
      } else {
        return noDataFound();
      }
    }
  };

  const __renderItem = (item: any, index: number, filterDataSet?: any) => (
    <TouchableOpacity
      accessible={true}
      accessibilityLabel={`${idLabel}-subheaderItem-${index}`}
      onPress={() => {
        if (sel_str == "org") {
          setSelectedOrg(item?.id);
          getRooms(item?.id);
          setSelectedChildRoom(null);
        } else if (sel_str == "stockroom") {
          let firstIndex =
            filterDataSet &&
            filterDataSet?.findIndex((element) =>
              element.id == item.isChild ? item.parentId : item?.id
            );
          let secondIndex =
            filterDataSet &&
            filterDataSet[firstIndex]?.childStockroom?.findIndex(
              (element) => element.id == item.id
            );
          setSelectedRoom(item.isChild ? item.parentId : item?.id);
          setSelectedChildRoom(secondIndex == -1 ? null : secondIndex);
        }
        setSearchKey("");
        refRBSheet_list.current.close();
      }}
      key={index}
      style={[
        styles.itemMain,
        sel_str == "org" &&
          selectedOrgId === item?.id && {
            justifyContent: "space-between",
            alignItems: "center",
          },
        sel_str == "stockroom" &&
          selectedRoom === item?.id &&
          selectedRoomChild == null && {
            justifyContent: "space-between",
            alignItems: "center",
          },
      ]}
    >
      <CustomText
        style={[
          styles.itemTitle,
          { width: "85%", marginLeft: item?.isChild ? 20 : 0 },
          sel_str == "org" &&
            selectedOrgId === item?.id && {
              color: "#53565A",
              fontFamily: FONTFAMILY.averta_semibold,
            },
          sel_str == "stockroom" &&
            selectedRoom === item?.id &&
            selectedRoomChild == null && {
              color: "#53565A",
              fontFamily: FONTFAMILY.averta_semibold,
            },
        ]}
        accessibilityLabel={`${idLabel}-subheaderItem-${index}-${sel_str}`}
      >
        {sel_str == "org" ? item?.orgName : item?.stockroomName}
      </CustomText>
      {sel_str == "org" && selectedOrgId === item?.id && __renderCheck(index)}
      {sel_str == "stockroom" &&
        selectedRoom === item?.id &&
        selectedRoomChild == null &&
        __renderCheck(index)}
    </TouchableOpacity>
  );
  const __renderChildItem = (item: any, id: number, i: number) => (
    <TouchableOpacity
      onPress={() => {
        setSelectedRoom(id);
        setSelectedChildRoom(i);
        setSearchKey("");
        refRBSheet_list.current.close();
      }}
      key={i}
      style={[
        styles.itemMain,
        selectedRoomChild === i &&
          selectedRoom == id && {
            justifyContent: "space-between",
            alignItems: "center",
          },
      ]}
      accessible={true}
      accessibilityLabel={`${idLabel}-subheader-childItem-${id}`}
    >
      <CustomText
        style={[
          styles.itemTitle,
          { width: "85%", marginLeft: 20 },

          selectedRoomChild === i &&
            selectedRoom == id && {
              color: "#53565A",
              fontFamily: FONTFAMILY.averta_semibold,
            },
        ]}
        accessibilityLabel={`${idLabel}-subheader-childItem-title-${id}`}
      >
        {item?.stockroomName}
      </CustomText>
      {selectedRoomChild === i && selectedRoom == id && __renderCheck(i)}
    </TouchableOpacity>
  );
  const __renderCheck = (index: number) => (
    <TickIcon
      height={hp(2)}
      width={hp(2)}
      fill={COLORS.scienceBlue}
      style={{
        marginRight: wp(2),
      }}
      accessible={true}
      accessibilityLabel={`${idLabel}-subheader-tick-${index}`}
    />
  );

  const __renderList = () => (
    <BottomSheetComponent
      customStyles={{ container: styles.bottomSheetContainer }}
      bottomSheetRef={refRBSheet_list}
      height={hp(80)}
      didCloseModal={() => {
        setSearchKey("");
      }}
    >
      <View style={styles.headerContainer}>
        <CustomText
          style={styles.headerText}
          accessibilityLabel={`${idLabel}-${getTitle()}-subheaderTitle`}
        >
          {getTitle()}
        </CustomText>
        <CustomText
          style={styles.closeBtn}
          onPress={() => {
            setSearchKey("");
            refRBSheet_list.current.close();
          }}
          accessibilityLabel={`${idLabel}-subheader-close`}
        >
          {Strings["close"]||"close"}
        </CustomText>
      </View>
      {/* <SearchBar
        idLabel={`${idLabel}-subheader`}
        search={searckKey ?? ""}
        onSearch={(text: string) => {
          setBarcodeData(false);
          setSearchKey(text);
        }}
        containerStyle={styles.searchMain}
        placeholder={Strings["search"]}
        onBarcodeDetected={(barcode) => onSearchBarCode(barcode)}
        from="org"
      /> */}
      <View style={styles.animatedSearchContainer}>
        <AnimatedSearch
          idLabel={`${idLabel}-subheader`}
          search={searckKey ?? ""}
          onSearch={(text: string) => {
            setBarcodeData(false);
            setSearchKey(text);
          }}
          containerStyle={[styles.searchMain]}
          cancelBtnStyle={{ paddingRight: wp(7) }}
          placeholder={Strings["search"] ?? "Search"}
          clearText={() => {
            setSearchKey("");
            // Keyboard.dismiss();
          }}
          onBarcodeDetected={(barcode) => onSearchBarCode(barcode)}
          onCancel={() => {
            setSearchKey("");
            Keyboard.dismiss();
          }}
          from="org"
        />
      </View>

      <ScrollView
        style={styles.listMain}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        keyboardDismissMode="on-drag"
      >
        {_renderList()}
      </ScrollView>
    </BottomSheetComponent>
  );

  const noDataFound = () => {
    return (
      <View style={styles.emptyContainer}>
        <CustomText style={styles.emptyText}>
          {Strings["no.records.found"]}
        </CustomText>
      </View>
    );
  };

  return (
    <View style={mainContainer}>
      <View
        style={styles.rowContainer}
        accessible={true}
        accessibilityLabel={`${idLabel}-subheader-rowContainer`}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.contentContainer}
        >
          <View
            style={styles.titleContainer}
            accessible={true}
            accessibilityLabel={`${idLabel}-subheader-titleContainer`}
          >
            <CustomText
              style={styles.titleText}
              accessibilityLabel={`${idLabel}-subheader-organisation-txt`}
            >
              {Strings["organization"]||"organization"}
            </CustomText>
            <CustomText
              style={styles.titleText}
              accessibilityLabel={`${idLabel}-subheader-stockroom-txt`}
            >
              {Strings["stockroom"]||"stockroom"}
            </CustomText>
          </View>
          <View
            style={styles.valueContainer}
            accessible={true}
            accessibilityLabel={`${idLabel}-subheader-valueContainer`}
          >
            <CustomText
              style={styles.valueText}
              numberOfLines={1}
              accessibilityLabel={`${idLabel}-subheader-titleValue`}
            >
              {selectedTitle}
            </CustomText>
            <CustomText
              numberOfLines={1}
              style={styles.valueText}
              accessibilityLabel={`${idLabel}-subheader-subtitleValue`}
            >
              {selectedSubTitle}
            </CustomText>
          </View>
          <View style={styles.spacer} />
        </ScrollView>
        <View style={[styles.buttonContainer, buttonContainerStyle]}>
          <Shadow
            distance={distance}
            startColor={"#ffffffd8"}
            endColor={"#ffffff10"}
            offset={offset}
          >
            <Pressable
              style={styles.pressableContainer}
              onPress={() => {
                refRBSheet.current.open();
              }}
              disabled={!internet}
              accessible={true}
              accessibilityLabel={`${idLabel}-subheader-changeBtn`}
            >
              <CustomText
                style={styles.pressableText}
                accessibilityLabel={`${idLabel}-subheader-changeTxt`}
              >
                {Strings["ime.scanner.change"] ?? "Change"}
              </CustomText>
            </Pressable>
          </Shadow>
        </View>
      </View>
      <BottomSheetComponent
        customStyles={{ container: styles.bottomSheetContainer }}
        height={hp(42)}
        bottomSheetRef={refRBSheet}
        didCloseModal={() => onClose()}
      >
        <CustomText
          style={styles.headerText}
          accessibilityLabel={`${idLabel}-subheader-changeOrgStock`}
        >
          {Strings["ime.change.org.stockroom"]}
        </CustomText>
        <TextInputComponent
          idLabel={`${idLabel}-subheader-${Strings["vcm.report.pi.organization"]}`}
          title={Strings["vcm.report.pi.organization"]||"Organization"}
          onPressRightIcon={() => onSelectCat("org")}
          onPressLeftIcon={() => console.log("left icon pressed")}
          RightIcon={ArrowDown}
          value={orgRoomValue(org, selectedOrgId)}
          editable={false}
          main={styles.orgTxtContainerStyle}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
          pointerEvents="none"
        />
        <TextInputComponent
          idLabel={`${idLabel}-subheader-${Strings["stockroom"]}`}
          title={Strings["stockroom"]||"stockroom"}
          onPressRightIcon={() => onSelectCat("stockroom")}
          onPressLeftIcon={() => console.log("left icon pressed")}
          RightIcon={ArrowDown}
          value={stockRoomValue(selectedRoomChild, stockRooms, selectedRoom)}
          editable={false}
          main={[styles.stockTxtContainerStyle, { marginVertical: 0 }]}
          inputStyle={styles.inputStyle}
          inputMain={styles.inputMainStyle}
          pointerEvents="none"
        />
        <View style={styles.btnContainer}>
          <OutlinedButton
            accessibilityLabel={`${idLabel}-subheader-cancelBtn`}
            title={Strings["cancel"]||"cancel"}
            onChangeBtnPress={() => {
              onReset();
            }}
            mainContainerStyle={styles.outlinedBtnContainerStyle}
          />
          <MainButton
            accessibilityLabel={`${idLabel}-subheader-continueBtn`}
            disabled={
              disableButton() || !stockRooms?.stockroomHierarchy?.length
            }
            title={Strings["ime.continue"]||"ime.continue"}
            buttonTextStyle={[styles.mainBtnText]}
            buttonStyle={[
              styles.btnWidth,
              (disableButton() || !stockRooms?.stockroomHierarchy?.length) && {
                backgroundColor: COLORS.gray,
              },
            ]}
            onChangeBtnPress={() => {
              if (selectedTitle != orgRoomValue(org, selectedOrgId)) {
                setShowModal(!showModal);
              } else {
                saveStore();
              }
            }}
          />
        </View>
        {__renderList()}

        <AlertModal
          isShow={showModal}
          customStyles={{ width: SIZES.width * 0.9 }}
        >
          <CustomText
            style={styles.modalHeaderText}
            accessibilityLabel={`${idLabel}-subheader-${Strings["ime.scanner.change.Organization"]}`}
          >
            {Strings["ime.scanner.change.Organization"] ??
              "Are you sure you want to change the Organization?"}
          </CustomText>
          <CustomText
            style={styles.modalBodyText}
            accessibilityLabel={`${idLabel}-subheader-${Strings["ime.scanner.unsaved.msg"]}`}
          >
            {Strings["ime.scanner.unsaved.msg"] ??
              "There may be unsaved changes that will be lost."}
          </CustomText>
          <MainButton
            accessibilityLabel={`${idLabel}-subheader-changeBtn`}
            title={Strings["ime.scanner.change"] ?? "Change"}
            buttonTextStyle={{ ...FONTS.title }}
            onChangeBtnPress={() => {
              saveStore();
              setShowModal(!showModal);
            }}
            buttonStyle={styles.modalMainButton}
          />
          <TouchableOpacity
            style={styles.modalSecondaryButton}
            onPress={() => {
              refRBSheet.current.close();
              setShowModal(!showModal);
            }}
            accessible={true}
            accessibilityLabel={`${idLabel}-subheader-login-close-biometrics-modal`}
          >
            <CustomText
              style={styles.modalSecondaryButtonText}
              accessibilityLabel={`${idLabel}-subheader-dontChange`}
            >
              {Strings["ime.dont.change.label"] ?? "Do Not Change"}
            </CustomText>
          </TouchableOpacity>
        </AlertModal>
      </BottomSheetComponent>
    </View>
  );
};

export default Subheader;
