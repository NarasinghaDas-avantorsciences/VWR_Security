import * as storage from "../../Service/AsyncStoreConfig";

const saveDataToStorage = async (key: string, data: any) => {
  await storage.setItem(key, JSON.stringify(data));
};

const dispatchActions = (
  details: { selectedStockRoom: any; selectedOrg: any },
  dispatch: (arg0: any) => void,
  setSelectedOrgandStockRoom: {
    (payload: any): (dispatch: any) => Promise<void>;
    (arg0: any): any;
  },
  getOutOfStock: { (): (dispatch: any) => Promise<void>; (): any },
  getRunningLowStock: { (): (dispatch: any) => Promise<void>; (): any },
  getStockroomDetail: { (): (dispatch: any) => Promise<void>; (): any },
  titleValue: any,
  subTitle: any,
  clearStockLevelData: any
) => {
  dispatch(setSelectedOrgandStockRoom(details));
  dispatch(getOutOfStock());
  dispatch(getRunningLowStock());
  dispatch(getStockroomDetail());
  dispatch(clearStockLevelData());
  dispatch({
    type: "TITLE",
    value: titleValue,
  });
  dispatch({
    type: "SUBTITLE",
    value: subTitle,
  });
};

const _selectedStoreRoom = (
  stockRooms: { stockroomHierarchy: any[] },
  selectedRoom: any
) => {
  const data = stockRooms?.stockroomHierarchy?.filter(
    (item) => item?.id === selectedRoom
  );
  return data?.length ? data[0] : null;
};

const _selectedStoreOrg = (
  org: { imeorganizationBaseDTO: any[] },
  selectedOrgId: any
) => {
  const data = org?.imeorganizationBaseDTO?.filter(
    (item) => item?.id === selectedOrgId
  );
  return data?.length ? data[0] : null;
};

const stockRoomValue = (
  selectedRoomChild: string | number | null,
  stockRooms: { stockroomHierarchy: any[] },
  selectedRoom: any
) => {
  if (selectedRoomChild != null) {
    const childStockroom = _selectedStoreRoom(
      stockRooms,
      selectedRoom
    )?.childStockroom;
    return childStockroom
      ? childStockroom[selectedRoomChild]?.stockroomName
      : null;
  } else {
    return _selectedStoreRoom(stockRooms, selectedRoom)?.stockroomName;
  }
};

const orgRoomValue = (
  org: { imeorganizationBaseDTO: any[] },
  selectedOrgId: any
) => {
  const selectedOrg = _selectedStoreOrg(org, selectedOrgId);
  return selectedOrg?.orgName || "";
};

export {
  saveDataToStorage,
  dispatchActions,
  _selectedStoreRoom,
  _selectedStoreOrg,
  stockRoomValue,
  orgRoomValue,
};
