import { StyleSheet } from "react-native";

import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  rowContainer: {
    flexDirection: "row",
    backgroundColor: COLORS.white,
    height: hp(7),
    justifyContent: "center",
    paddingHorizontal: wp(2),
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray2,
    overflow: "hidden",
  },
  emptyContainer: { alignItems: "center", justifyContent: "center" },
  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },

  contentContainer: { flexGrow: 1 },

  titleContainer: {
    width: wp(30),
    flexDirection: "column",
    justifyContent: "center",
  },

  titleText: {
    fontSize: FONTS.h1_3,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.doveGray,
    textTransform: "uppercase",
  },

  valueContainer: {
    width: wp(40),
    flexDirection: "column",
    justifyContent: "center",
  },

  valueText: {
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.abbey,
  },
  spacer: { width: wp(22) },
  buttonContainer: {
    position: "absolute",
    justifyContent: "center",
    alignItems: "center",
    right: 10,
    backgroundColor: "white",
    alignSelf: "center",
  },
  pressableContainer: {
    borderWidth: 1,
    borderColor: COLORS.scienceBlue,
    backgroundColor: COLORS.white,
    height: hp(3),
    width: wp(16),
    justifyContent: "center",
    alignItems: "center",
  },

  pressableText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_2,
  },

  bottomSheetContainer: {
    borderTopLeftRadius: hp(1),
    borderTopRightRadius: hp(1),
  },

  orgTxtContainerStyle: {
    width: wp(90),
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginVertical: wp(5),
  },

  stockTxtContainerStyle: {
    width: wp(90),
    alignSelf: "center",
    backgroundColor: COLORS.white,
  },

  btnContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: wp(90),
    alignSelf: "center",
    alignItems: "center",
    flex: 1,
  },
  headerText: {
    fontSize: FONTS.h2_3,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.doveGray,
    textAlign: "center",
  },
  inputStyle: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h1_9,
    color: COLORS.gray,
    left: -wp(2),
    marginRight: wp(4),
    fontFamily: FONTFAMILY.averta_regular,
  },
  inputMainStyle: {
    height: hp(5),
    top: 0,
    borderColor: COLORS.gray,
  },
  outlinedBtnContainerStyle: {
    borderWidth: 0,
    width: wp(35),
  },
  outlinedBtnTextStyle: {
    color: COLORS.gray,
    fontSize: FONTS.h1_9,
  },
  mainBtnText: {
    fontSize: FONTS.h1_9,
  },
  btnWidth: {
    backgroundColor: COLORS.scienceBlue,
    width: wp(45),
  },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginLeft: wp(30),
    alignItems: "center",
    paddingTop: hp(1.8),
  },
  closeBtn: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.blue,
    paddingLeft: wp(6),
    fontFamily: FONTFAMILY.averta_regular,
  },
  itemMain: {
    borderBottomWidth: 0.4,
    borderBottomColor: COLORS.alto,
    paddingVertical: hp(1.3),
    flexDirection: "row",
  },
  itemTitle: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_8,
    color: COLORS.abbey,
  },
  listMain: {
    width: "90%",
    alignSelf: "center",
  },
  searchMain: {
    // width: "90%",
    // alignSelf: "center",
    paddingHorizontal: wp(3),
  },
  animatedSearchContainer: {
    width: "100%",
    marginLeft: wp(1),
  },
  modalHeaderText: {
    fontSize: hp(2),
    fontFamily: FONTFAMILY.averta_bold,
    lineHeight: hp(2),
    textAlign: "center",
    color: COLORS.scienceBlue,
    marginBottom: SIZES.tip,
  },
  modalBodyText: {
    ...FONTS.body,
    textAlign: "center",
    color: COLORS.black,
    marginVertical: SIZES.radius,
  },
  modalMainButton: {
    width: SIZES.width * 0.9 - SIZES.padding * 2,
    marginTop: SIZES.base,
  },
  modalSecondaryButton: {
    padding: SIZES.padding,
    width: SIZES.width * 0.9 - SIZES.padding * 2,
    alignItems: "center",
  },
  modalSecondaryButtonText: { ...FONTS.title, color: COLORS.gray },
  modalFooterText: {
    ...FONTS.body2,
    color: COLORS.gray,
    textAlign: "center",
    marginTop: SIZES.tip,
  },
});

export default Styles;
