import React, { useEffect, useState } from "react";
import { TouchableOpacity, View } from "react-native";
import { useSelector } from "react-redux";
import moment from "moment";

import { COLORS } from "../../Utils/theme";
import { Ready, Partial, Pending, ChevronRight } from "../../Utils/images";
import styles from "./styles";
import CustomText from "../CustomText";

type OrderListItemProps = {
  item: any;
  color: string;
  onPressListItem?: () => void;
};

const OrderListItem: React.FC<OrderListItemProps> = ({
  item,
  color,
  onPressListItem,
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const { dateFormat, timeFormat } = useSelector(
    (state: any) => state.userReducer
  );

  const [timeString, setTimeString] = useState("h:mm:ss A");

  useEffect(() => {
    if (timeFormat?.toUpperCase() == "24Hours".toUpperCase()) setTimeString("H:mm:ss");
    else setTimeString("h:mm:ss A");
  }, []);

  return (
    <TouchableOpacity
      accessible={true}
      accessibilityLabel={`${item.id}-order-list-item`}
      style={styles.mainBtnContainer}
      onPress={onPressListItem}
    >
      <View
        style={styles.mainWrapperContainer}
        accessible={true}
        accessibilityLabel={`${item.id}-order-list-item-wrapper`}
      >
        {color == "green" ? (
          <Ready />
        ) : color == "yellow" ? (
          <Partial />
        ) : (
          <Pending />
        )}

        <View style={styles.subWrapperContainer}>
          <View>
            <CustomText
              style={styles.idStyle}
              accessibilityLabel={`${item.id}-order-list-order-no`}
            >
              {(item?.editedVwrOrderNo ?? '').trim().length > 0
                ? `${item?.editedVwrOrderNo} - ${item?.internalOrderNo}`
                : item?.internalOrderNo}
            </CustomText>
            <CustomText
              style={styles.stockRoomText}
              accessibilityLabel={`${item.id}-order-list-cost-center`}
            >
              {item?.costCenterName ? item.costCenterName : "-"}
            </CustomText>
            <CustomText
              style={styles.stockRoomText}
              accessibilityLabel={`${item.id}-order-list-date`}
            >
              {moment(item?.createdDate).format(
                `${dateFormat?.date}, ${timeString}`
              )}
            </CustomText>
            <View
              accessible={true}
              accessibilityLabel={`${item.id}-order-list-status`}
              style={[
                styles.bodyContainer,
                {
                  borderColor:
                    color == "green"
                      ? COLORS.seaGreen
                      : color == "yellow"
                      ? COLORS.yellow
                      : COLORS.redFast,
                  backgroundColor:
                    color == "green"
                      ? COLORS.transparentGreen
                      : color == "yellow"
                      ? COLORS.transparentYellow
                      : COLORS.transparentRedFast,
                },
              ]}
            >
              <CustomText
                accessibilityLabel={`${item.id}-oreder-list-status-text`}
                style={[
                  styles.status,
                  {
                    color:
                      color == "green"
                        ? COLORS.green
                        : color == "yellow"
                        ? COLORS.yellow
                        : COLORS.redFast,
                  },
                ]}
              >
                {color == "red"
                  ? strings["ime.pending.delivery"]
                  : color == "yellow"
                  ? strings["partially.received"]
                  : strings["ime.ready.to.be.received"]}
              </CustomText>
            </View>
          </View>

          <ChevronRight />
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default OrderListItem;
