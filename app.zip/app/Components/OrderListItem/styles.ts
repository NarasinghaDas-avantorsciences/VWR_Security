import { StyleSheet } from "react-native";
import { COLORS, FONTS, SIZES } from "../../Utils/theme";

const Styles = StyleSheet.create({
  mainBtnContainer: {
    paddingVertical: SIZES.radius,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray2,
  },

  mainWrapperContainer: {
    flexDirection: "row",
    justifyContent: "flex-start",
    paddingHorizontal: SIZES.padding,
  },

  subWrapperContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginLeft: SIZES.base,
  },

  idStyle: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
    marginBottom: SIZES.base,
  },

  stockRoomText: {
    ...FONTS.body,
    color: COLORS.abbey,
    marginBottom: SIZES.base,
  },

  bodyContainer: {
    alignSelf: "flex-start",
    paddingHorizontal: SIZES.tip,
    paddingVertical: SIZES.tip / 2,
    borderWidth: 1,
    borderRadius: SIZES.padding,
    alignItems: "center",
    justifyContent: "center",
  },

  status: {
    ...FONTS.body2,
  },
});

export default Styles;
