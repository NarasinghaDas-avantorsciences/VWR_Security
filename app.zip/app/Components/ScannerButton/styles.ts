import { StyleSheet } from "react-native";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";

const Styles = StyleSheet.create({
  pressableContainer: {
    backgroundColor: COLORS.scienceBlue,
    justifyContent: "center",
    alignItems: "center",
    height: hp(6),
    width: hp(6),
    alignSelf: "flex-end",
    position: "absolute",
    right: wp(5),
    bottom: hp(4),
    zIndex: 100,
  },

  pressableText: {
    color: COLORS.white,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_2,
  },

  scanIcon: {
    color: COLORS.scienceBlue,
  },

  btmSheetContainer: {
    borderTopLeftRadius: wp(3),
    borderTopRightRadius: wp(3),
    backgroundColor: COLORS.mineShaft,
  },

  container: {
    flex: 1,
  },

  scan: {
    color: COLORS.white,
    fontSize: FONTS.h2_2,
    fontFamily: FONTFAMILY.averta_semibold,
    textAlign: "center",
    marginVertical: hp(1.5),
  },

  cameraContainer: {
    flex: 1,
  },

  optionsContainer: {
    flex: 0.3,
    flexDirection: "row",
    justifyContent: "space-between",
    padding: hp(1),
  },

  optionBtnContainer: {
    height: hp(6),
    width: wp(20),
    justifyContent: "center",
    alignItems: "center",
  },

  cancel: {
    color: COLORS.white,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_regular,
  },
});

export default Styles;
