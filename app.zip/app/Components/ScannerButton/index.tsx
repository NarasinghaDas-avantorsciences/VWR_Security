import React, { useRef, useState, useEffect } from "react";
import { PermissionsAndroid } from "react-native";
import {
  StyleProp,
  ViewStyle,
  TouchableOpacity,
  View,
  StyleSheet,
  Platform,
  Alert,
} from "react-native";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Camera, useCameraDevices } from "react-native-vision-camera";
import { useScanBarcodes, BarcodeFormat } from "vision-camera-code-scanner";
import { trigger } from "react-native-haptic-feedback";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useSelector } from "react-redux";
import BottomSheetComponent from "../BottomSheet";
import { FlashLight, QR, ScanIcon, ScanIconBlue } from "../../Utils/images";
import styles from "./styles";
import { COLORS, ICONSIZE } from "../../Utils/theme";
import CustomText from "../CustomText";
import { wp } from "../../Utils/globalFunction";
interface ScannerButtonProps {
  idLabel?: string;
  mainButtonStyle?: StyleProp<ViewStyle>;
  onBarcodeDetected?: (barcode: string | {}) => void;
  barcodeFormats?: Array<BarcodeFormat>;
  from?: string;
  onButtonPressed?: any;
  disabled?: any;
  onSearch?: (text: string) => void;
  isProductCodeOnly?: boolean;
  scanBatch?: boolean;
}

const ScannerButton: React.FC<ScannerButtonProps> = ({
  idLabel = "",
  mainButtonStyle,
  onBarcodeDetected,
  barcodeFormats = [
    BarcodeFormat.CODE_128,
    BarcodeFormat.CODE_39,
    BarcodeFormat.CODE_93,
    BarcodeFormat.AZTEC,
    BarcodeFormat.CODABAR,
    BarcodeFormat.DATA_MATRIX,
    BarcodeFormat.EAN_13,
    BarcodeFormat.EAN_8,
    BarcodeFormat.ITF,
    BarcodeFormat.PDF417,
    BarcodeFormat.UPC_A,
    BarcodeFormat.UPC_E,
  ],
  from,
  onButtonPressed,
  disabled = false,
  onSearch,
  isProductCodeOnly = true,
  scanBatch = false,
}) => {
  const devices = useCameraDevices();
  const device = devices.back;

  const [hasPermission, setHasPermission] = useState(false);
  const [isScanned, setIsScanned] = useState(false);
  const [barcode, setBarcode] = useState("");
  const [flashEnabled, setFlash] = useState<boolean>(true);

  const btmSheetRef = useRef<any>();
  const { top } = useSafeAreaInsets();

  const strings = useSelector((state: any) => state.languageReducer?.data);

  const [frameProcessor, barcodes] = useScanBarcodes(barcodeFormats, {
    checkInverted: true,
  });
  useEffect(() => {
    !isScanned && toggleActiveState();
    return () => {
      barcodes;
    };
  }, [barcodes]);

  /*=================================

//check scan item is batch product
var batchesArray = barcodeValue.split("*UI#");
if(batchesArray!=null && batchesArray.length==2)

{ barcodeValue = batchesArray[0]; this.batchCode = batchesArray[1]; }
In the above code barcodeValue is the Product catalog number, 
based on this filter the product in the existing list. Then take the batchCode, 
its a batch id. Add this batch into the selection with the quantity 1. 

================================*/

  // const toggleActiveState = async () => {
  //   if (barcodes && barcodes.length > 0 && isScanned === false) {
  //     setIsScanned(true);
  //     trigger("impactLight", {
  //       enableVibrateFallback: true,
  //       ignoreAndroidSystemSettings: false,
  //     });
  //     btmSheetRef?.current?.close();
  //     setFlash(false);
  //     // setTimeout(() => {
  //     // }, 500);
  //     onBarcodeDetected?.(barcodes[0]?.rawValue);

  //     // setBarcode('');
  //     // barcodes.forEach(async (scannedBarcode: any) => {
  //     //   if (scannedBarcode.rawValue !== "") {
  //     //     setBarcode(scannedBarcode.rawValue);
  //     //     trigger("impactLight", {
  //     //       enableVibrateFallback: true,
  //     //       ignoreAndroidSystemSettings: false,
  //     //     });
  //     //     setFlash(false);
  //     //     setTimeout(() => {
  //     //       btmSheetRef?.current?.close();
  //     //     }, 500);
  //     //     console.log("scannedBarcode", scannedBarcode);
  //     //     let readedString = scannedBarcode.rawValue.replace(
  //     //       /[\x00-\x1F\x7F]/g,
  //     //       ""
  //     //     );
  //     //     // let readedString = scannedBarcode.rawValue.replace(
  //     //     //   /[^a-zA-Z0-9. ]/g,
  //     //     //   ""
  //     //     // );
  //     //     var batchesArray = scanBatch
  //     //       ? readedString
  //     //       : readedString.split("*UI#");
  //     //     if (batchesArray != null && batchesArray.length == 2) {
  //     //       readedString = batchesArray[0];
  //     //       if (isProductCodeOnly) {
  //     //         onBarcodeDetected?.(readedString);
  //     //       } else {
  //     //         onBarcodeDetected?.({
  //     //           productCode: readedString,
  //     //           batchCode: batchesArray[1],
  //     //         });
  //     //       }
  //     //     } else {
  //     //       onBarcodeDetected?.(readedString);
  //     //     }
  //     //   }
  //     // });
  //   } else {
  //     setIsScanned(false);
  //   }
  // };

  const toggleActiveState = async () => {
    if (barcodes && barcodes.length > 0 && isScanned === false) {
      setIsScanned(true);
      trigger("impactLight", {
        enableVibrateFallback: true,
        ignoreAndroidSystemSettings: false,
      });
      btmSheetRef?.current?.close();
      setFlash(false);
      let readedString = barcodes[0]?.rawValue.replace(/[\x00-\x1F\x7F]/g, "");
      var batchesArray = scanBatch ? readedString : readedString.split("*UI#");
      if (batchesArray != null && batchesArray.length == 2) {
        readedString = batchesArray[0];
        if (isProductCodeOnly) {
          onBarcodeDetected?.(readedString);
        } else {
          onBarcodeDetected?.({
            productCode: readedString,
            batchCode: batchesArray[1],
          });
        }
      } else {
        onBarcodeDetected?.(readedString);
      }
    } else {
      setIsScanned(false);
    }
  };
  const requestCameraPermission = async () => {
    if (Platform.OS === "android") {
      let permission = requestAndroidCameraPermission();
      if (!permission) showCameraPermision(true);
      else {
        setTimeout(() => {
          btmSheetRef?.current?.open();
        }, 300);
      }
    } else {
      const status = await Camera.requestCameraPermission();
      const cameraPermission = await Camera.getCameraPermissionStatus();
      setHasPermission(cameraPermission == "authorized");
      showCameraPermision(cameraPermission != "authorized");
    }
  };

  function showCameraPermision(noPermission: boolean) {
    if (noPermission) {
      Alert.alert(
        strings["ime.scanner.Permission.Denied"] ?? "Permission Denied!.",
        strings["ime.scanner.enable.camera.permissions.msg"] ??
          "To enable camera, please go to the device settings and change permissions and try again.",
        [{ text: strings["ok"], style: strings["cancel"] }]
      );
    }
  }
  const requestAndroidCameraPermission = async () => {
    try {
      var isPermission = true;
      const permissionAndroid = await PermissionsAndroid.check(
        PermissionsAndroid.PERMISSIONS.CAMERA
      );
      if (!permissionAndroid) {
        const reqPer = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.CAMERA
        );
        if (reqPer != PermissionsAndroid.RESULTS.GRANTED) {
          isPermission = false;
        }
      }
      setHasPermission(isPermission);
      return isPermission;
    } catch (err) {
      // console.warn(err);
    }
  };

  return (
    <>
      {from == "consume" ? (
        <TouchableOpacity
          style={[mainButtonStyle]}
          onPress={async () => {
            onSearch && onSearch("");
            setIsScanned(false);
            setFlash(true);
            await requestCameraPermission();
            if (Platform.OS == "ios") await btmSheetRef?.current?.open();
          }}
          accessible={true}
          accessibilityLabel={`${idLabel}-scanner-btn-qr`}
        >
          <ScanIconBlue width={wp(6.5)} height={wp(6.5)} />
        </TouchableOpacity>
      ) : from !== "auth" ? (
        <TouchableOpacity
          style={[styles.pressableContainer, mainButtonStyle]}
          onPress={async () => {
            onSearch && onSearch("");
            onButtonPressed?.();
            setIsScanned(false);
            setFlash(true);

            await requestCameraPermission();
            if (Platform.OS == "ios") await btmSheetRef?.current?.open();
          }}
          accessible={true}
          accessibilityLabel={`${idLabel}-scanner-btn-qr`}
          disabled={disabled}
        >
          <QR />
        </TouchableOpacity>
      ) : (
        <TouchableOpacity
          onPress={async () => {
            onSearch && onSearch("");
            setIsScanned(false);
            setFlash(true);

            await requestCameraPermission();
            if (Platform.OS == "ios") await btmSheetRef?.current?.open();
          }}
          accessible={true}
          accessibilityLabel={`${idLabel}-scanner-btn-scan-icon`}
          disabled={disabled}
          style={{ opacity: disabled ? 0.5 : 1 }}
        >
          <ScanIcon height={ICONSIZE.h3} width={ICONSIZE.h3} />
        </TouchableOpacity>
      )}

      {!device || !hasPermission ? null : (
        <View>
          <BottomSheetComponent
            customStyles={{
              container: [
                styles.btmSheetContainer,
                { marginTop: Platform.OS === "ios" ? top + 20 : -top },
              ],
            }}
            height={hp(100)}
            bottomSheetRef={btmSheetRef}
          >
            <View
              style={styles.container}
              accessible={true}
              accessibilityLabel={`${idLabel}-scanner-btn-container`}
            >
              <CustomText
                style={styles.scan}
                accessibilityLabel={`${idLabel}-scanner-btn-scan`}
              >
                Scan
              </CustomText>
              <View
                style={styles.cameraContainer}
                accessible={true}
                accessibilityLabel={`${idLabel}-scanner-btn-camera-container`}
              >
                <Camera
                  style={StyleSheet.absoluteFill}
                  device={device}
                  isActive={!isScanned}
                  frameProcessor={frameProcessor}
                  frameProcessorFps={5}
                  torch={flashEnabled ? "on" : "off"}
                  accessible={true}
                  accessibilityLabel={`${idLabel}-scanner-btn-camera`}
                />
              </View>

              <View
                style={styles.optionsContainer}
                accessible={true}
                accessibilityLabel={`${idLabel}-scanner-btn-options-container`}
              >
                <TouchableOpacity
                  style={styles.optionBtnContainer}
                  onPress={() => setFlash(!flashEnabled)}
                  accessible={true}
                  accessibilityLabel={`${idLabel}-scanner-btn-options-btn`}
                >
                  <FlashLight
                    height={hp(3.5)}
                    width={hp(3.5)}
                    color={COLORS.white}
                  />
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.optionBtnContainer}
                  onPress={() => {
                    setFlash(false);
                    btmSheetRef?.current?.close();
                  }}
                  accessible={true}
                  accessibilityLabel={`${idLabel}-scanner-btn-cancel-btn`}
                >
                  <CustomText
                    style={styles.cancel}
                    accessible={true}
                    accessibilityLabel={`${idLabel}-scanner-cancel`}
                  >
                    {strings["cancel"]}
                  </CustomText>
                </TouchableOpacity>
              </View>
            </View>
          </BottomSheetComponent>
        </View>
      )}
    </>
  );
};

export default ScannerButton;
