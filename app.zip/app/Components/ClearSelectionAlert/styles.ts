import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../Utils/theme";
import { hp, wp, isDeviceTablet } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: 'space-between',
    marginTop: hp(1.2)
  },
  clearModalContainer: { borderRadius: 6, width: isDeviceTablet() ? wp(70) : wp(95), padding: isDeviceTablet() ? 20 : 10 },
  clearContainer: {
    alignItems: "center",

  },
  clearOrderTitle: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h2,
    color: COLORS.black,
  },
  clearOrderDesc: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h2,
    color: COLORS.abbey,
    padding: 0,
    marginVertical: hp(1),
    textAlign: 'center'
  },
  cancelContainer: {
    flex: 1,
    marginTop: hp(1),
    marginLeft: 0,
    borderWidth: 0,
  },
  cancelText: {
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h2,
    color: COLORS.abbey,
    fontWeight: "600",
  },
  clearOrderContainer: {
    flex: 1,
    marginTop: hp(1),
    backgroundColor: COLORS.scienceBlue
  },
  clearOrderText: {
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.white,
    fontSize: FONTS.h2,
    fontWeight: "700",
  },
})


export default Styles;