import React from "react";
import { View } from "react-native";
import styles from "./styles";
import { AlertModal, MainButton, OutlinedButton } from "../../Components";
import CustomText from "../CustomText";

type ClearSelectionAlertProps = {
  didCloseModal?: () => void;
  isShow: boolean;
  orderTitle: String;
  orderDesc: String;
  outlinedButtonTitle: String;
  mainButtonTitle: String;
  didOutlinedButtonClicked: () => void;
  didMainButtonTitleClicked: () => void;
};

const ClearSelectionAlert: React.FC<ClearSelectionAlertProps> = (props) => {
  return (
    <AlertModal
      isShow={props.isShow}
      didCloseModal={props.didCloseModal}
      customStyles={styles.clearModalContainer}
    >
      <View style={styles.clearContainer}>
        <CustomText style={styles.clearOrderTitle}>
          {props.orderTitle}
        </CustomText>
        <CustomText style={styles.clearOrderDesc}>{props.orderDesc}</CustomText>
        <View style={styles.flexRowContainer}>
          <OutlinedButton
            title={props.outlinedButtonTitle}
            onChangeBtnPress={props.didOutlinedButtonClicked}
            mainContainerStyle={styles.cancelContainer}
            mainTextStyle={styles.cancelText}
          />
          <MainButton
            title={props.mainButtonTitle}
            onChangeBtnPress={props.didMainButtonTitleClicked}
            buttonStyle={styles.clearOrderContainer}
            buttonTextStyle={styles.clearOrderText}
          />
        </View>
      </View>
    </AlertModal>
  );
};

export default ClearSelectionAlert;
