import React, { FC, ReactNode } from "react";
import {
  View,
  TouchableOpacity,
  ViewStyle,
  StyleProp,
  Text,
} from "react-native";
import Tooltip from "react-native-walkthrough-tooltip";
import {
  BluePointerLeft,
  CloseBlack,
  WhitePointerRight,
} from "../../Utils/images";
import styles from "./styles";
import CustomText from "../CustomText";
import { useSelector } from "react-redux";

interface InfoTooltipProps {
  children?: ReactNode;
  mainTitle?: string;
  tooltipContent?: string;
  isVisible?: boolean;
  stepNo?: number;
  onClose?: () => void;
  onPressNext?: () => void;
  onPressBack?: () => void;
  onFinish?: () => void;
  placement?: any;
  contentStlye?: StyleProp<ViewStyle>;
  accessibilityLabel?: any;
}

const InfoTooltip: FC<InfoTooltipProps> = ({
  children,
  mainTitle,
  tooltipContent,
  isVisible,
  stepNo,
  onClose,
  onPressNext,
  onPressBack,
  onFinish,
  placement = "right",
  contentStlye = {},
  accessibilityLabel,
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);

  return (
    <Tooltip

      isVisible={isVisible}
      content={
        <View accessible={true}
          accessibilityLabel={accessibilityLabel + "tooltip_main_container"} style={styles.mainContainer}>
          <View accessible={true}
            accessibilityLabel="title_container" style={[styles.tooltipTitleContainer]}>
            <Text
              accessibilityLabel="tooltip_title"
              style={[styles.tooltipTitle, stepNo == 3 && styles.fontsizeSet]}
            >
              {mainTitle}
            </Text>
            <TouchableOpacity accessible={true} style={styles.infoToolCrossBtn}
              accessibilityLabel="tooltip_close_button" onPress={onFinish}>
              <CloseBlack accessible={true}
                accessibilityLabel="close_button_icon" />
            </TouchableOpacity>
          </View>
          <View accessible={true}
            accessibilityLabel="content_container" style={styles.tooltipContentContainer}>
            <CustomText
              accessibilityLabel="tooltip_container"
              style={styles.tooltipContent}>{tooltipContent}</CustomText>
          </View>

          <View accessible={true}
            accessibilityLabel="footer_container" style={styles.tooltipFooterContainer}>
            <View accessible={true}
              accessibilityLabel="button_container" style={styles.btnContainer}>
              {stepNo !== 1 && (
                <TouchableOpacity
                  accessible={true}
                  accessibilityLabel="back_button"
                  style={styles.backBtnContainer}
                  onPress={onPressBack}
                >
                  <BluePointerLeft accessible={true}
                    accessibilityLabel="back_button_icon" />
                  <CustomText
                    accessibilityLabel="back_button_title" style={styles.backBtn}>Back</CustomText>
                </TouchableOpacity>
              )}
            </View>

            <View accessible={true}
              accessibilityLabel="step_container" style={styles.stepContainer}>
              <CustomText
                accessibilityLabel="step_number"
                style={[styles.stepCount, stepNo === 1 && styles.alignRight]}
              >{`${stepNo}/5`}</CustomText>
            </View>

            <View accessible={true}
              accessibilityLabel="next_button_container" style={styles.btnContainer}>
              <TouchableOpacity
                accessible={true}
                accessibilityLabel="next_button"
                style={styles.nextBtnContainer}
                onPress={onPressNext}
              >
                <CustomText
                  accessible={true}
                  accessibilityLabel="next_button_title"
                  style={styles.nextBtn}>
                  {stepNo === 5 ? "Done" : strings['im.next']}
                </CustomText>
                {stepNo !== 5 && <WhitePointerRight accessible={true}
                  accessibilityLabel="next_button_icon" />}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      }
      placement={placement}
      onClose={onClose}
      contentStyle={contentStlye}
      disableShadow={false}
      closeOnChildInteraction={false}
      closeOnContentInteraction={false}
      closeOnBackgroundInteraction={false}
    >
      {children}
    </Tooltip>
  );
};

export default InfoTooltip;
