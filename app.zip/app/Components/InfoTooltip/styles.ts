import { StyleSheet,Dimensions } from "react-native";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  mainContainer: { flex: 1 },

  tooltipTitleContainer: {
    flex: 1.5,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  fontsizeSet: {
    fontSize: FONTS.h2,
  },

  tooltipTitle: {
    flex: 1,
    minWidth:'90%',
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h2_2,
    color: COLORS.scienceBlue,
  },

  tooltipContentContainer: {
    flex: 3,
    justifyContent: "center",
  },

  tooltipContent: {
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_6,
    color: COLORS.abbey,
    //paddingVertical: hp(1),
    marginBottom:10,
  },

  tooltipFooterContainer: {
    flex: 1,
    //paddingTop:15,
    marginBottom:10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  btnContainer: {
    flex: 0.5,
  },

  backBtnContainer: {
    flexDirection: "row",
    backgroundColor: COLORS.white,
    alignItems: "center",
    // width: wp(16),
    height: hp(4),
    justifyContent: "space-evenly",
    borderWidth: 1,
    borderColor: COLORS.scienceBlue,
  },

  backBtn: {
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.scienceBlue,
  },

  stepContainer: {
    flex: 1,
    alignItems: "center",
  },

  stepCount: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
  },

  alignRight: {
    alignSelf: "center",
  },

  nextBtnContainer: {
    flexDirection: "row",
    backgroundColor: COLORS.scienceBlue,
    alignItems: "center",
    // width: wp(16),
    height: hp(4),
    justifyContent: "space-evenly",
  },

  nextBtn: {
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.white,
  },
  infoToolCrossBtn:{
    height: hp(3),
    alignItems: "center",
    justifyContent:'center',
    width: hp(3),
    //backgroundColor:'red'
  }
});

export default Styles;
