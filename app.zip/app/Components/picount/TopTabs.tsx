import { TouchableOpacity, View, } from "react-native";
import CustomText from "../CustomText";
import { COLORS } from "../../Utils/theme";
import React from "react";

interface TopTabProps {
    Tabs: any,
    setSelectedIndex: any,
    selectedIndex: any,
    style: any,
};
const TopTabs: React.FC<TopTabProps> = ({
    Tabs,
    setSelectedIndex,
    selectedIndex,
    style,
    ...props
}) => {
    return (
        <View
            accessible={true}
            accessibilityLabel="top_tab_container"
            style={style.tabContainer}>
            {Tabs.map((v, i) => {
                return (
                    <TouchableOpacity
                        accessible={true}
                        accessibilityLabel="top_tab_button"
                        activeOpacity={0.4}
                        onPress={() => setSelectedIndex(v.id)}
                        style={[
                            style.tabContentContainer,
                            {
                                borderBottomColor:
                                    selectedIndex == v.id ? COLORS.scienceBlue : COLORS.white,
                            },
                        ]}>
                        <CustomText
                            accessibilityLabel={v.name + "tab_count"}
                            allowFontScaling={false}
                            style={
                                selectedIndex == v.id
                                    ? style.tabTitleText
                                    : style.unSelectedText
                            }>
                            {v.count}
                        </CustomText>
                        <CustomText
                            accessibilityLabel={v.name + "tab_title"}
                            allowFontScaling={false}
                            style={
                                selectedIndex == v.id
                                    ? style.tabTitleText
                                    : style.unSelectedText
                            }>
                            {v.name}
                        </CustomText>
                    </TouchableOpacity>
                );
            })}
        </View>
    );
};
export default TopTabs