import React from "react";
import { View, Image, TouchableOpacity } from "react-native";
import { useSelector } from "react-redux";

import { wp, hp, isProductFreezed } from "../../Utils/globalFunction";
import { DefaultProductImage, Locked, PICountLocked } from "../../Utils/images";
import CustomText from "../CustomText";
import ListItem from "../ListItem";
import ConsumeTag from "../Consume/ConsumeTag";
import ListItemCheckButton from "../ListItemCheckButton";
import AddBatch from "../AddBatch";
import ReasonCode from "../ReasonCode";
import QtyController from "../QtyController";

interface PICountListItemProps {
  product: any;
  item: any;
  index: any;
  uomId: any;
  batches: any;
  styles: any;
  onProductNameClicked: any;
  isBatchEnabled: any;
  isExpiryEnabled: any;
  selectedIndex: any;
  onPendingItemCheckPressed: any;
  onConfirmedItemCheckPressed: any;
  handleBatch: any;
  handleBatchDelete: any;
  handleAvailQty: any;
  setFormatedData: any;
  variationQty: any;
  updateProductLevelQty: any;
  onProductLevelReasonCodeSelected: any;
  showToast?: any;
}
const PICountListItemtItem: React.FC<PICountListItemProps> = ({
  product,
  uomId,
  item,
  index,
  batches,
  styles,
  onProductNameClicked,
  isBatchEnabled,
  isExpiryEnabled,
  selectedIndex,
  onPendingItemCheckPressed,
  onConfirmedItemCheckPressed,
  handleBatch,
  handleBatchDelete,
  handleAvailQty,
  setFormatedData,
  variationQty,
  updateProductLevelQty,
  onProductLevelReasonCodeSelected,
  showToast,
  ...props
}) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);

  return (
    <View
      accessible={true}
      accessibilityLabel="list_item_main_container"
      style={{
        ...styles.listItemContainer,
        marginTop: index === 0 ? hp(2) : hp(4),
      }}
    >
      <ListItem
        leftIcon={
          product?.imagePath == null && product?.imageURL == null ? (
            <View
              accessible={true}
              accessibilityLabel="product_image_container"
              style={styles.productDetailsImageStyle}
            >
              <DefaultProductImage
                accessible={true}
                accessibilityLabel="product_default_image"
              />
            </View>
          ) : (
            <Image
              accessible={true}
              accessibilityLabel="product_image"
              source={{
                uri: product?.imagePath
                  ? product.imagePath.replace("http://", "https://")
                  : product.imageURL.replace("http://", "https://"),
              }}
              style={[
                styles.productDetailsImageStyle,
                {
                  height: hp(10),
                  width: hp(10),
                },
              ]}
            />
          )
        }
        headerContent={
          <View
            accessible={true}
            accessibilityLabel="header_content_container"
            style={styles.headerContentContainer}
          >
            <View
              accessible={true}
              accessibilityLabel="product_catlog_container"
              style={styles.catalogContainer}
            >
              {!!product?.catalogNo && (
                <CustomText
                  accessibilityLabel="product_catalog_value"
                  allowFontScaling={false}
                  style={styles.product_code}
                >
                  {product?.catalogNo}
                </CustomText>
              )}
              {isProductFreezed(product) && (
                <PICountLocked />
                // <Locked  />
              )}
            </View>
            <TouchableOpacity
              onPress={() => {
                onProductNameClicked(item);
              }}
            >
              <CustomText
                accessibilityLabel="product_description_value"
                allowFontScaling={false}
                style={styles.product_name}
                numberOfLines={2}
              >
                {product?.description}
              </CustomText>
            </TouchableOpacity>
            {!!uomId && (
              <CustomText
                accessibilityLabel="uomid_value"
                allowFontScaling={false}
                style={styles.variant}
              >
                ({uomId})
              </CustomText>
            )}
            {(!!isBatchEnabled || !!isExpiryEnabled) && (
              <View
                accessible={true}
                accessibilityLabel="product_batch_expiry_label_container"
                style={styles.tagContainer}
              >
                {!!isBatchEnabled && <ConsumeTag tag="Batch Controlled" />}
                {!!isExpiryEnabled && (
                  <ConsumeTag tag="Expiry Date Controlled" />
                )}
              </View>
            )}
          </View>
        }
        // rightIcon={
        //     (<ListItemCheckButton
        //         title=""
        //         isSelected={item.isSelected}
        //         onChangeBtnPress={() =>
        //             selectedIndex == 1
        //                 ? onPendingItemCheckPressed(index)
        //                 : onConfirmedItemCheckPressed(index)
        //         }
        //     />)
        // }
        customStyles={{
          contentHeaderStyle: {
            alignItems: "center",
          },
        }}
      >
        {itemDetails(
          item,
          index,
          variationQty,
          styles,
          onProductLevelReasonCodeSelected,
          Strings,
          isBatchEnabled,
          isExpiryEnabled,
          updateProductLevelQty,
          showToast
        )}
        {(!!isBatchEnabled || !!isExpiryEnabled) && (
          <AddBatch
            item={item}
            from="picount"
            onChange={handleBatch}
            onDelete={handleBatchDelete}
            updateActualQty={(val: any) => {
              item["actualQty"] = val;
              handleAvailQty(val, item?.id);
            }}
            formatedData={batches?.length ? batches : []}
            setFormatedData={setFormatedData}
            data={batches?.length ? batches : []}
          />
        )}
      </ListItem>
    </View>
  );
};

export const itemDetails = (
  item: any,
  index: any,
  variationQty: any,
  styles: any,
  onProductLevelReasonCodeSelected: any,
  Strings: any,
  isBatchEnabled: any,
  isExpiryEnabled: any,
  updateProductLevelQty: any,
  showToast: any
) => {
  const product = item.product;
  const reason = item.reasonCode;
  let actualQty = item.actualQty; // getProductActualQty(item, item.batchProducts)
  return (
    <View
      accessible={true}
      accessibilityLabel="product_deails_main_container"
      style={styles.itemDetailsContainer}
    >
      <View
        accessible={true}
        accessibilityLabel="reasoncode_and_details_sub_container"
        style={styles.productDetailsContainer}
      >
        <ReasonCode
          containerStyle={styles.innerDropdownContainer}
          textContainer={styles.textContainerStyle}
          reasonTextStyle={styles.innerInputStyle}
          titleStyle={styles.dropdownproductDetailsItemsTitle}
          reasonCodeType={"stock.correction"}
          from={"masterCode"}
          reason={reason}
          required={true}
          mainContainerstyle={styles.reasonCodeMaincontainerStyle}
          setReason={(value) => onProductLevelReasonCodeSelected(value, index)}
          showToast={(text1: string, text2: string) => showToast(text1, text2)}
        />
        <View style={styles.productDetailsItemsContainer}>
          <CustomText
            accessibilityLabel="vendor_name_title"
            allowFontScaling={false}
            style={styles.dropdownproductDetailsItemsTitle}
          >
            {Strings["copy.move.vendor"]}
          </CustomText>
          <CustomText
            accessibilityLabel="vendor_name_value"
            allowFontScaling={false}
            style={styles.productDetailsItemsValue}
          >
            {product?.vendorName}
          </CustomText>
        </View>
      </View>
      <View
        accessible={true}
        accessibilityLabel="inner_product_details_container"
        style={styles.innerProductDetailsContainer}
      >
        <ProductDetailsItems
          title={Strings["ime.scanner.pre.qty"] ?? "Pre Qty"}
          value={product?.availableQty}
          containerStyle={[styles.leftContainerStyle, { flex: 0.5 }]}
          styles={styles}
        />
        <View
          accessible={true}
          accessibilityLabel="product_qty_control_container"
          style={styles.commonFlex}
        >
          <CustomText
            accessibilityLabel="actual_qty_title"
            allowFontScaling={false}
            style={styles.qtyTitles}
          >
            {Strings["ime.actual.qty"]}
          </CustomText>
          <QtyController
            disable={!!isBatchEnabled || !!isExpiryEnabled}
            showLabel={false}
            onChange={(v: String) => updateProductLevelQty(v, index)}
            inputStyle={styles.qtyInputStyle}
            titleStyle={styles.productDetailsItemsTitle}
            inputValue={actualQty}
            from="picount"
          />
        </View>
        <ProductDetailsItems
          title={Strings["variation"]}
          value={variationQty}
          containerStyle={[styles.rightContainerStyle, {}]}
          styles={styles}
        />
        <View
          accessible={true}
          accessibilityLabel="space"
          style={[{ flex: 0.3 }]}
        />
      </View>
    </View>
  );
};
export const ProductDetailsItems = ({
  title,
  value,
  containerStyle,
  styles,
}) => {
  return (
    <View
      accessible={true}
      accessibilityLabel="product_details_container"
      style={[styles.productDetailsItemsContainer, containerStyle]}
    >
      <CustomText
        accessibilityLabel={title + "_title"}
        allowFontScaling={false}
        style={[
          styles.productDetailsItemsTitle,
          { textTransform: "capitalize" },
        ]}
      >
        {title}
      </CustomText>
      <CustomText
        accessibilityLabel={title + "_value"}
        allowFontScaling={false}
        style={{
          ...styles.productDetailsItemsValue,
          marginTop: wp(5),
        }}
      >
        {value}
      </CustomText>
    </View>
  );
};

export default PICountListItemtItem;
