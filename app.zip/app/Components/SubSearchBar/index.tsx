import React from "react";
import {
  TextInput,
  View,
  StyleProp,
  ViewStyle,
  Pressable,
  TouchableOpacity,
} from "react-native";
import { useSelector } from "react-redux";
import { COLORS } from "../../Utils/theme";
import { Cross } from "../../Utils/images";
import styles from "./styles";
import { hp, wp } from "../../Utils/globalFunction";
import CustomText from "../CustomText";

type SearchProps = {
  placeholder?: string;
  search: string;
  onSearch: (text: string) => void;
  cancel?: Boolean;
  containerStyle?: StyleProp<ViewStyle>;
  onBarcodeDetected?: (barcode: string) => void;
  clearText?: () => void;
  cancelPressed?: () => void;
};

const AnimatedSearch: React.FC<SearchProps> = ({
  placeholder,
  search,
  onSearch,
  cancel = false,
  containerStyle,
  onBarcodeDetected,
  clearText,
  cancelPressed,
}) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);

  return (
    <View style={[styles.mainContainer, containerStyle]}>
      <View style={[styles.container]}>
        <View style={[styles.search]}>
          <TextInput
            allowFontScaling={false}
            style={styles.textInput}
            placeholder={placeholder}
            placeholderTextColor={COLORS.gray2}
            value={search}
            onChangeText={onSearch}
          />
          <TouchableOpacity style={[styles.clearTextStyle]} onPress={clearText}>
            <Cross height={hp(1.5)} width={hp(1.5)} />
          </TouchableOpacity>
        </View>
      </View>

      <Pressable
        style={[styles.cancelSearch, { right: -10 }]}
        onPress={cancelPressed}
      >
        <CustomText style={[styles.cancelSearchText]}>Cancel</CustomText>
      </Pressable>
    </View>
  );
};

export default AnimatedSearch;
