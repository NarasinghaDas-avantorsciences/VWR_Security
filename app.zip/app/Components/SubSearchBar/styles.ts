import { Dimensions, StyleSheet } from "react-native";
import { COLORS, FONTS, ICONSIZE, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  mainContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginVertical: SIZES.base,
  },

  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: 30,
    paddingHorizontal: SIZES.base,
  },

  iconStyle: {
    height: ICONSIZE.h3,
    width: ICONSIZE.h3,
    left: 0,
    alignSelf: "center",
    marginLeft: SIZES.base,
  },
  rightIconStyle: {
    alignSelf: "center",
    paddingHorizontal: SIZES.base,
  },
  textInput: {
    flex: 1,
    ...FONTS.body,
    // paddingHorizontal: wp(7),
    color: COLORS.abbey,
    marginLeft: SIZES.base,
  },

  closeBtnContainer: { paddingHorizontal: SIZES.base },

  cancelText: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
    marginLeft: SIZES.base,
  },
  searchContainer: {
    flexDirection: "row",
    height: 72,
    borderBottomColor: "#00000033",
    paddingTop: 100,
  },
  search: {
    flex: 1,
    flexDirection: "row",
    height: 40,
    width: Dimensions.get("window").width * 0.75,
    position: "absolute",
    // left: 16,
    alignSelf: "center",
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.gray,
    borderRadius: 2,
  },
  cancelSearch: {
    position: "absolute",
    marginHorizontal: 16,
    textAlign: "center",
    justifyContent: "center",
    alignSelf: "center",
    height: hp(4),
  },
  cancelSearchText: {
    color: COLORS.blue,
    marginLeft: wp(10),
  },
  clearTextStyle: {
    alignSelf: "center",
    paddingHorizontal: SIZES.base,
  },
});

export default Styles;
