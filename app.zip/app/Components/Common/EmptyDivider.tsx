import React from 'react';
import { View } from 'react-native';

interface EmptyDivider {
    width?: number,
    height?: number
}

const EmptyDivider = ({ width, height }: EmptyDivider) => {
    return <View accessible={true}
        accessibilityLabel="empty_divider" style={{ width: width, height: height }} />
}


export default EmptyDivider;