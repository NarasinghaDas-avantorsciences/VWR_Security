import React from "react";
import {
  TouchableOpacity,
  StyleSheet,
  StyleProp,
  ViewStyle,
  TextStyle,
  Image,
} from "react-native";
import { COLORS, FONTFAMILY } from "../../Utils/theme";
import { hp } from "../../Utils/globalFunction";
import CustomText from "../CustomText";

interface FlatButton {
  text: string;
  onPress: () => void;
  container?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  disabled?: boolean;
  accessibilityLabel?: string;
  image?: string;
  isImage?: boolean;
}

const FlatButton = (props: FlatButton) => {
  const {
    text,
    onPress,
    container,
    textStyle,
    disabled,
    accessibilityLabel,
    image,
    isImage,
  } = props;
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        disabled ? styles.disabledContainer : styles.container,
        container,
        { flexDirection: "row" },
      ]}
      disabled={disabled}
      accessibilityLabel={`${accessibilityLabel}-btn`}
      accessible={true}
    >
      {(isImage ?? false) && (
        <Image
          style={{
            width: hp(1.8),
            height: hp(1.8),
            marginRight: 5,
            tintColor: "white",
          }}
          resizeMode="contain"
          source={{
            uri: image,
          }}
          accessible={true}
          accessibilityLabel={`${accessibilityLabel}-img`}
        />
      )}

      <CustomText
        style={[styles.textStyle, textStyle]}
        accessibilityLabel={`${accessibilityLabel}-text`}
      >
        {text}
      </CustomText>
    </TouchableOpacity>
  );
};
//
const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.scienceBlue,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: hp(1.3),
  },
  disabledContainer: {
    backgroundColor: COLORS.scienceBlue,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: hp(1.3),
    opacity: 0.5,
  },
  textStyle: {
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.white,
  },
  imageStyle: {
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.white,
  },
});

export default FlatButton;
