import React from "react";
import {
  View,
  Modal,
  StyleProp,
  ViewStyle,
  TouchableWithoutFeedback,
} from "react-native";

import styles from "./styles";

type AlertModalProps = {
  children: React.ReactNode;
  ref?: any;
  height?: number;
  didCloseModal?: () => void;
  customStyles?: StyleProp<ViewStyle>;
  isShow: boolean;
};

const AlertModal: React.FC<AlertModalProps> = (props) => {
  const {
    ref,
    isShow,
    children,
    height = 550,
    customStyles,
    didCloseModal,
  } = props;

  return (
    <Modal
      animationType="fade"
      transparent
      visible={isShow}
      ref={ref}
      onRequestClose={didCloseModal}
    >
      <TouchableWithoutFeedback accessible={true}
        accessibilityLabel="alertmodal_close_button" onPress={didCloseModal}>
        <View accessible={true}
          accessibilityLabel="alertmodal_children_main_container" style={styles.container}>
          <View accessible={true}
            accessibilityLabel="alertmodal_children_sub_container" style={[styles.modal, customStyles]}>{children}</View>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

export default AlertModal;
