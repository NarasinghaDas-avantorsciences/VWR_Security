import { StyleSheet } from "react-native";
import { hp } from "../../Utils/globalFunction";
import { COLORS, SIZES } from "../../Utils/theme";

const Styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },

  modal: {
    backgroundColor: COLORS.white,
    padding: SIZES.padding,
    borderRadius: SIZES.radius,
    alignItems: "center",
    elevation: 5,
    minWidth: SIZES.width * 0.6,
    minHeight: hp(11.6),
  },
});

export default Styles;
