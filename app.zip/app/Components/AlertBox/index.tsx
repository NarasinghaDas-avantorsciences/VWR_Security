import React from "react";
import { View, Modal, TouchableOpacity, ViewStyle } from "react-native";

import styles from "./styles";
import CustomText from "../CustomText";

type AlertBoxProps = {
  children: React.ReactNode;
  isShow: boolean;
  didCloseModal: () => void;
  ref?: any;
  customStyles?: ViewStyle;
  leftButtonText?: string;
  rightButtonText?: string;
};

const AlertBox: React.FC<AlertBoxProps> = (props) => {
  const {
    isShow,
    ref,
    didCloseModal,
    children,
    customStyles,
    leftButtonText,
    rightButtonText,
  } = props;

  return (
    <Modal
      animationType="fade"
      transparent
      visible={isShow}
      ref={ref}
      onRequestClose={didCloseModal}
    >
      <View accessible={true}
        accessibilityLabel="alertbox_main_container" style={styles.container}>
        <View accessible={true}
          accessibilityLabel="alertbox_sub_container" style={styles.modal}>
          <View accessible={true}
            accessibilityLabel="alertbox_child_container" style={styles.childrenContainer}>{children}</View>
          <View accessible={true}
            accessibilityLabel="alertbox_button_wrapper" style={styles.btnWrapperContainer}>
            <TouchableOpacity accessible={true}
              accessibilityLabel="alertbox_left_button" style={styles.button} onPress={didCloseModal}>
              <CustomText
                accessibilityLabel="alertbox_left_button_title" style={styles.buttonText}>{leftButtonText}</CustomText>
            </TouchableOpacity>
            <View style={styles.seperator} />
            <TouchableOpacity accessible={true}
              accessibilityLabel="alertbox_right_button" style={styles.button} onPress={didCloseModal}>
              <CustomText
                accessibilityLabel="alertbox_right_button_title" style={styles.buttonText}>{rightButtonText}</CustomText>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default AlertBox;
