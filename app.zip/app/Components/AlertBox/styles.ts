import { StyleSheet } from "react-native";
import { COLORS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    marginHorizontal: wp(13.6),
  },

  modal: {
    backgroundColor: COLORS.white,
    borderRadius: hp(1.5),
    alignItems: "center",
    elevation: 5,
    width: "100%",
    minHeight: hp(12),
    justifyContent: "space-between",
  },

  childrenContainer: {
    marginVertical: hp(1.2),
    width: "100%",
    paddingHorizontal: wp(1),
    alignItems: "center",
  },

  btnWrapperContainer: {
    borderWidth: 1,
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-evenly",
    borderTopWidth: 0.5,
    height: hp(5),
    borderColor: COLORS.tuna36,
  },

  button: {
    borderRadius: 5,
    justifyContent: "center",
    width: "50%",
    alignItems: "center",
  },

  buttonText: {
    color: COLORS.azureRadiance,
    fontWeight: "bold",
  },

  seperator: {
    width: 1,
    backgroundColor: COLORS.tuna36,
    height: "100%",
  },
});

export default Styles;
