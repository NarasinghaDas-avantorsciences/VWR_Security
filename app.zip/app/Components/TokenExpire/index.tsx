import React, { useState } from "react";
import { View, Text, TouchableOpacity } from "react-native";
import Modal from "react-native-modal";
import FlatButton from "../Common/FlatButton";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

function TokenExpire({ onPress, dismiss,expireTime, visible }: any) {
  return (
    <View>
      <Modal isVisible={visible}>
        <View
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
        >
          <View
            style={{
              backgroundColor: "#FFFFFF",
              width: "100%",
              paddingVertical: !expireTime ? hp(3) : 50,
              justifyContent: "center",
              alignItems: "center",
              paddingHorizontal: 20,
              borderRadius: 5,
            }}
          >
            <Text
              style={{
                color: COLORS.black,
                fontFamily: FONTFAMILY.averta_semibold,
                fontSize: FONTS.h2,
              }}
            >
              {expireTime > 0 && "Keep my session open?"}
            </Text>
            <Text
              style={[
                {
                  color: COLORS.abbey,
                  fontFamily: FONTFAMILY.averta_regular,
                  fontSize: FONTS.h1_6,
                  textAlign: "center",

                  // marginTop: hp(1),
                },
                expireTime && {
                  marginTop: hp(1),
                },
              ]}
            >
              {expireTime > 0?`Your session will be expired in ${expireTime}:00 Please select 'YES' if you want to continue using the application.
              BY SELECTING 'NO' YOU WILL LOSE ALL YOUR DATA AND BE LOGGED OUT OF THE APPLICATION.`:`Session expired.`}
            </Text>
            {expireTime ? (
              <>
                <FlatButton
                  text={"Yes"}
                  onPress={() => onPress()}
                  textStyle={{
                    color: COLORS.scienceBlue,
                  }}
                  accessibilityLabel={"Dismiss-token-update"}
                  container={{
                    backgroundColor: COLORS.white,
                    borderWidth: 1,
                    width: "80%",
                    alignSelf: "center",
                    borderColor: COLORS.scienceBlue,
                    marginTop: hp(3),
                  }}
                />
                <FlatButton
                  accessibilityLabel={"Re Authenticate"}
                  text={"No"}
                  onPress={() => dismiss(true)}
                  container={{
                    width: "80%",
                    alignSelf: "center",
                    marginTop: hp(1),
                  }}
                />
              </>
            ) : (
              <FlatButton
                text={"Ok"}
                onPress={() => dismiss(true)}
                textStyle={{
                  color: COLORS.scienceBlue,
                }}
                accessibilityLabel={"Dismiss-token-update"}
                container={{
                  backgroundColor: COLORS.white,
                  borderWidth: 1,
                  width: expireTime?"80%":"50%",
                  alignSelf: "center",
                  borderColor: COLORS.scienceBlue,
                  marginTop: hp(3),
                }}
              />
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

export default TokenExpire;
