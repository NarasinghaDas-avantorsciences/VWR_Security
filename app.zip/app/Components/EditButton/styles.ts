import { StyleSheet } from "react-native";

import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  pressableContainer: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },

  pressableText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_5,
  },
  editIcon: {
    color: COLORS.scienceBlue,
    marginRight: wp(2),
  },
});

export default Styles;
