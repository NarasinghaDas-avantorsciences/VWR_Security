import React from "react";
import { TouchableOpacity } from "react-native";
import { useSelector } from "react-redux";
import CustomText from "../CustomText";

import { Edit } from "../../Utils/images";
import { hp } from "../../Utils/globalFunction";
import styles from "./styles";

interface IconStyleProps {
  height: number;
  width: number;
}
interface EditButtonProps {
  onChangeBtnPress: () => void;
  title: string;
  iconStyle?: IconStyleProps;
}

const EditButton: React.FC<EditButtonProps> = ({
  iconStyle,
  onChangeBtnPress,
  title,
}) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);

  return (
    <TouchableOpacity
      accessible={true}
      accessibilityLabel="edit_button"
      style={styles.pressableContainer}
      onPress={onChangeBtnPress}
    >
      <Edit
        accessible={true}
        accessibilityLabel="edit_icon"
        height={iconStyle?.height ? iconStyle.height : hp(2)}
        width={iconStyle?.width ? iconStyle.width : hp(2)}
        style={styles.editIcon}
      />
      <CustomText style={styles.pressableText}>{Strings["edit"]}</CustomText>
    </TouchableOpacity>
  );
};

export default EditButton;
