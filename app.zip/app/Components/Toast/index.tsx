import React from "react";
import { View, TouchableOpacity } from "react-native";
import Toast from "react-native-toast-message";
import OutlinedButton from "../OutlinedButton";
import MainButton from "../MainButton";
import { Cross } from "../../Utils/images";
import { hp } from "../../Utils/globalFunction";
import styles from "./styles";
import CustomText from "../CustomText";

const toastConfig = {
  alertToast: ({ text1, text2, props }: any) => {
    return (
      <View style={styles.main}>
        <View style={styles.inner}>
          <View style={{ flex: 1 }}>
            <CustomText style={styles.tite}>{text1}</CustomText>
            <CustomText style={styles.des}>{text2}</CustomText>
          </View>
          <TouchableOpacity onPress={() => Toast.hide()}>
            <Cross height={hp(1.7)} width={hp(1.7)} />
          </TouchableOpacity>
        </View>
      </View>
    );
  },
  alertButton: ({ text1, text2, onPress, props }: any) => {
    return (
      <View style={styles.main}>
        <View style={styles.inner}>
          <View>
            <CustomText style={styles.tite}>{text1}</CustomText>
            <CustomText style={styles.des}>{text2}</CustomText>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <TouchableOpacity
                style={styles.buttonMain}
                onPress={() => onPress?.()}
              >
                <CustomText style={styles.buttonTitle}>Save Receipt</CustomText>
              </TouchableOpacity>
              <View style={{ flex: 1 }} />
            </View>
          </View>
          <TouchableOpacity
            onPress={() => Toast.hide()}
            style={{ padding: 10 }}
          >
            <Cross height={hp(1.7)} width={hp(1.7)} />
          </TouchableOpacity>
        </View>
      </View>
    );
  },
  alertBottomToast: ({ text1, text2, props }: any) => {
    return (
      <View style={styles.main}>
        <View style={styles.inner}>
          <View>
            <CustomText style={styles.bottomTitle}>{text1}</CustomText>
            <CustomText style={styles.des}>{text2}</CustomText>
            <View style={styles.buttonContainers}>
              <OutlinedButton
                title={props.putAwayText}
                onChangeBtnPress={() => props?.onPressLeft()}
                mainContainerStyle={styles.outlineBtnContainer}
                mainTextStyle={styles.buttonTitle}
              />
              <MainButton
                title={props.printBarcodeText}
                onChangeBtnPress={() => props?.onPressRight()}
                buttonStyle={styles.outlineBtnContainer}
                buttonTextStyle={styles.barcodeText}
              />
            </View>
          </View>
          <TouchableOpacity
            onPress={() => {
              Toast.hide();
              props?.goback();
            }}
          >
            <Cross height={hp(1.7)} width={hp(1.7)} />
          </TouchableOpacity>
        </View>
      </View>
    );
  },
  alertApprovalsBottomToast: ({ text1, text2, props }: any) => {
    return (
      <View style={styles.main}>
        <View style={styles.inner}>
          <View>
            <CustomText style={styles.bottomTitle}>{text1}</CustomText>
            <CustomText style={styles.des}>{text2}</CustomText>
            <View style={styles.buttonContainers}>
              <OutlinedButton
                title={props.buttonTitle}
                onChangeBtnPress={() => {
                  props?.onPress();
                }}
                mainContainerStyle={styles.outlineBtnContainer}
                mainTextStyle={styles.buttonTitle}
              />
            </View>
          </View>
          <TouchableOpacity onPress={() => Toast.hide()}>
            <Cross height={hp(1.7)} width={hp(1.7)} />
          </TouchableOpacity>
        </View>
      </View>
    );
  },
  alertOfflineToast: ({ text1, text2, props }: any) => {
    return (
      <View style={[styles.main, { width: "100%" }]}>
        <View style={styles.inner}>
          <View style={{ flex: 1 }}>
            <CustomText style={styles.tite}>{text1}</CustomText>
            <CustomText style={styles.des}>{text2}</CustomText>
            <CustomText style={[styles.text3]}>{props.text3}</CustomText>
          </View>
          <TouchableOpacity onPress={() => Toast.hide()}>
            <Cross height={hp(1.7)} width={hp(1.7)} />
          </TouchableOpacity>
        </View>
      </View>
    );
  },
};

export const ToastComponent: React.FC = () => {
  return <Toast config={toastConfig} bottomOffset={10} visibilityTime={5000} />;
};
