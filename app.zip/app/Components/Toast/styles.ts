import { StyleSheet } from "react-native";

import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const styles = StyleSheet.create({
  main: {
    position: "relative",
    width: "90%",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    borderWidth: 1,
    borderColor: COLORS.alto,
    elevation: 5,
    backgroundColor: COLORS.white,
    borderRadius: 6,
    zIndex: 99,
  },
  inner: {
    width: "90%",
    marginTop: hp(1),
    alignSelf: "center",
    paddingVertical: hp(2),
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  sub: {
    width: "90%",
    alignSelf: "center",
    paddingVertical: hp(2),
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  tite: {
    color: COLORS.blackBright,
    ...FONTS.title,
    marginBottom: SIZES.base,
  },
  text3: {
    color: COLORS.blackBright,
    ...FONTS.title2,
    marginBottom: SIZES.base,
    textAlign: "center",
  },
  des: {
    color: COLORS.blackBright,
    marginRight: wp(2),
    ...FONTS.body,
  },
  buttonMain: {
    borderWidth: 1,
    borderColor: COLORS.scienceBlue,
    justifyContent: "flex-start",
    alignItems: "center",
    marginTop: hp(1),
  },
  buttonTitle: {
    padding: wp(1.5),
    color: COLORS.scienceBlue,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_bold,
  },
  bottomTitle: {
    color: COLORS.blackBright,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: hp(2),
    marginBottom: SIZES.base,
    textTransform: "uppercase",
  },
  buttonContainers: {
    flexDirection: "row",
  },
  outlineBtnContainer: {
    width: wp(30),
    marginTop: hp(1),
    marginLeft: 0,
    marginRight: wp(4),
  },
  barcodeText: {
    color: COLORS.white,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_bold,
  },
});

export default styles;
