import React from "react";
import { View } from "react-native";
import styles from "./styles";
import CustomText from "../CustomText";

type ProductModalDetailsItemsProps = {
  title: string;
  value: string | null | number;
};

const ProductModalDetailsItems: React.FC<ProductModalDetailsItemsProps> = ({
  title,
  value,
}) => {
  return (
    <View style={[styles.productModalDetailsItemsContainer]}>
      <CustomText style={styles.productModalDetailsItemsTitle}>{title}</CustomText>
      <CustomText style={styles.productModalDetailsItemsValue}>
        {value ? value : "-"}
      </CustomText>
    </View>
  );
};

export default ProductModalDetailsItems;
