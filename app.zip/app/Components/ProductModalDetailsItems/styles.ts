import { StyleSheet } from "react-native";

import { wp } from "../../Utils/globalFunction";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";

export default StyleSheet.create({
  productModalDetailsItemsContainer: { marginTop: wp(5) },

  productModalDetailsItemsTitle: {
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
  },

  productModalDetailsItemsValue: {
    fontSize: FONTS.h1_9,
    fontFamily: FONTFAMILY.averta_regular,
    color: COLORS.abbey,
    lineHeight: 19,
    marginTop: wp(0.5),
  },
});
