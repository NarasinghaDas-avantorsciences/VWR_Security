import React from "react";
import { View } from "react-native";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
// Constants
import { SIZES, COLORS, FONTS } from "../../Utils/theme";

const Tab = createMaterialTopTabNavigator();

interface TopTabBarProps {
  tabBarStyle?: object;
  tabBarItemStyle?: object;
  tabBarIndicatorContainerStyle?: object;
  renderContent?: Array<Type>;
  scrollable?: boolean;
  initialRouteName?: string;
}

interface Type {
  name: string;
  count: number;
  component: any;
}

const TopTabBar: React.FC<TopTabBarProps> = ({
  tabBarStyle,
  tabBarItemStyle,
  tabBarIndicatorContainerStyle,
  renderContent = [],
  scrollable = false,
  initialRouteName,
}) => {
  return (
    <Tab.Navigator
    
      initialRouteName={initialRouteName ? initialRouteName : undefined}
      style={{
        flexGrow: 1,
        marginTop: SIZES.base,
      }}
      sceneContainerStyle={{
        backgroundColor: COLORS.white,
      }}
      screenOptions={{
        tabBarAllowFontScaling:false,
        tabBarLabelStyle: [
          {
            textTransform: "capitalize",
            paddingTop: SIZES.width <= 360 ? 5 : 0,
            paddingBottom: -2,
            ...FONTS.title,
            color:COLORS.scienceBlue,
          },
          SIZES.width <= 360 ? { ...FONTS.title } : { ...FONTS.title2 },
        ],
        tabBarIndicatorContainerStyle: {
          flex: 1,
          marginBottom: -2,
          alignItems: "center",
          justifyContent: "center",
          width: scrollable ? SIZES.width * 0.3 : "60%",
          marginLeft: scrollable
            ? 0
            : renderContent.length >= 4
            ? "5%"
            : renderContent.length >= 3
            ? "7.5%"
            : "10%",

          ...tabBarIndicatorContainerStyle,
        },
        tabBarItemStyle: {
          width: scrollable ? "auto" : (SIZES.width * 1) / renderContent.length,

          ...tabBarItemStyle,
        },
        tabBarStyle: { ...tabBarStyle },
        tabBarIndicatorStyle: {
          backgroundColor: COLORS.scienceBlue,
          height: 2.5,
          borderRadius: SIZES.radius,
        },
        tabBarInactiveTintColor: COLORS.gray,
        tabBarActiveTintColor: COLORS.scienceBlue,
        tabBarPressOpacity: 0,
        tabBarPressColor: COLORS.blueLight,
        tabBarScrollEnabled: scrollable,
      }}
      keyboardDismissMode="on-drag"
    >
      {renderContent.map((item, index) => (
        <Tab.Screen
          name={item?.name}
          options={{ title: `${item?.count + " " + item?.name}` }}
          component={item?.component}
          key={`${item?.name}-${index}`}
        />
      ))}
    </Tab.Navigator>
  );
};

export default TopTabBar;
