import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  modalHeaderText: {
    ...FONTS.heading,
    color: COLORS.scienceBlue,
    marginBottom: SIZES.tip,
  },
  modalBodyText: {
    ...FONTS.title,
    fontFamily: FONTFAMILY.averta_regular,
    textAlign: "center",
    color: COLORS.black,
    marginVertical: SIZES.radius,
  },
  modalMainButton: {
    width: SIZES.width * 0.4,
    alignItems: "center",
    marginTop: SIZES.base,
  },
  modalSecondaryButton: {
    width: SIZES.width * 0.4,
    alignItems: "center",
    justifyContent: "center",
    marginTop: SIZES.base,
  },
  modalSecondaryButtonText: { ...FONTS.title, color: COLORS.gray },
  modalFooterText: {
    ...FONTS.body2,
    color: COLORS.gray,
    textAlign: "center",
    marginTop: SIZES.tip,
  },
  btnContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
});

export default Styles;
