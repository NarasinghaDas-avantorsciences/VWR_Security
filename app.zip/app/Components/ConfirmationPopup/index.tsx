import React, { memo, useEffect } from "react";
import {
  View,
  TouchableOpacity,
  Platform,
  Linking,
  BackHandler,
} from "react-native";
import RNExitApp from "react-native-exit-app";

import styles from "./styles";
import CustomText from "../CustomText";
import AlertModal from "../AlertModal";
import { FONTS, SIZES } from "../../Utils/theme";
import MainButton from "../MainButton";
import { useDispatch, useSelector } from "react-redux";
import { setIsShowConfirmationAlert } from "../../Redux/Action/userAction";
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  clearOrderedItemList,
  resetRecommendedProducts,
} from "../../Redux/Action/replenishAction";

type ConfirmationAlertProps = {
  isShow?: boolean;
  onBack?: any;
  onTapNo?: any;
  onTapYes?: any;
  goBack?: boolean;
  from?: String;
};

const ConfirmationAlert: React.FC<ConfirmationAlertProps> = memo(
  function ConfirmationAlert({ ...props }) {
    // const ConfirmationAlert: React.FC<ConfirmationAlertProps> = ({
    //   isShow,
    //   onBack,
    // }) => {
    const Strings = useSelector((state: any) => state.languageReducer?.data);

    const { confirmationAlertInfo } = useSelector(
      (state: any) => state.userReducer
    );

    const dispatch = useDispatch<any>();
    const navigation = useNavigation<any>();

    return (
      <AlertModal
        isShow={confirmationAlertInfo?.isShow == true || props?.isShow == true}
        customStyles={{ width: SIZES.width * 0.9 }}
      >
        <CustomText
          style={styles.modalHeaderText}
          accessibilityLabel="confirmation-popup-header-text"
        >
          {Strings["message"] || "message"}
        </CustomText>
        <CustomText
          style={styles.modalBodyText}
          accessibilityLabel="confirmation-popup-cancel-text"
        >
          {Strings["ime.sure.want.to.cancel"] || "ime.sure.want.to.cancel"}
        </CustomText>
        <View
          style={styles.btnContainer}
          accessible={true}
          accessibilityLabel="confirmation-popup-btn-container"
        >
          <TouchableOpacity
            style={styles.modalSecondaryButton}
            onPress={async () => {
              props?.onTapNo();
              dispatch(
                setIsShowConfirmationAlert({
                  isShow: false,
                  data: [],
                })
              );
              navigation?.getParent("Drawer")?.closeDrawer();
            }}
            accessible={true}
            accessibilityLabel="confirmation-popup-secondary-btn"
          >
            <CustomText
              style={styles.modalSecondaryButtonText}
              accessibilityLabel="confirmation-popup-secondary-text"
            >
              {Strings["no"] || "no"}
            </CustomText>
          </TouchableOpacity>

          <MainButton
            title={Strings["yes"] || "yes"}
            buttonTextStyle={{ ...FONTS.title }}
            onChangeBtnPress={async () => {
              await AsyncStorage.multiRemove([
                "stockTransferCount",
                "stockCorrectionCount",
                "replenishCount",
                "receiveCount",
                "consumeCount",
                "ApprovalsCount",
              ]);
              if (props?.goBack == true) {
                // props.from == "Checkoutscreen" && props?.onBack();
                navigation.goBack();
                dispatch(
                  setIsShowConfirmationAlert({
                    isShow: false,
                    data: [],
                  })
                );
              } else {
                props?.onTapYes();
              }
            }}
            buttonStyle={styles.modalMainButton}
            accessibilityLabel={"confirmation-popup-update-btn"}
          />
        </View>
      </AlertModal>
    );
  }
);

export default ConfirmationAlert;
