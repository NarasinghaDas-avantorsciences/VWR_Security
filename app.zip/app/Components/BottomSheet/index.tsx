import React from "react";
import RBSheet from "react-native-raw-bottom-sheet";
import { StyleProp, ViewStyle } from "react-native";
import { COLORS, SIZES } from "../../Utils/theme";

export type BottomSheetProps = {
  children: React.ReactNode;
  bottomSheetRef: any;
  height?: number;
  didCloseModal?: any;
  customStyles?: {
    wrapper?: StyleProp<ViewStyle>;
    container?: StyleProp<ViewStyle>;
    draggableIcon?: StyleProp<ViewStyle>;
  };
  closeOnDragDown?: boolean;
  closeOnPressMask?: boolean;
  dragFromTopOnly?: boolean;
  onOpen?: () => void;
};

const BottomSheetComponent: React.FC<BottomSheetProps> = (props) => {
  const {
    bottomSheetRef,
    children,
    height = SIZES.height * 0.5,
    customStyles,
    didCloseModal,
    closeOnDragDown,
    closeOnPressMask,
    dragFromTopOnly,
    onOpen,
  } = props;

  return (
    <RBSheet
      accessible={true}
      accessibilityLabel="bottom-sheet"
      ref={bottomSheetRef}
      closeOnDragDown={closeOnDragDown ? closeOnDragDown : true}
      closeOnPressMask={closeOnPressMask ? closeOnPressMask : true}
      height={height}
      onClose={didCloseModal}
      onOpen={onOpen}
      dragFromTopOnly={dragFromTopOnly}
      customStyles={{
        wrapper: {
          backgroundColor: COLORS.transparentBlack,
        },
        draggableIcon: {
          backgroundColor: COLORS.white,
        },
        container: {
          borderTopLeftRadius: SIZES.radius,
          borderTopRightRadius: SIZES.radius,
          overflow: "visible",
        },
        ...customStyles,
      }}
    >
      {children}
    </RBSheet>
  );
};

export default BottomSheetComponent;
