import { StyleSheet } from "react-native";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: SIZES.radius,
    marginTop:SIZES.tip
  },
  emptyContainer: { alignItems: 'center', justifyContent: 'center' },
  emptyText: { color: COLORS.lightGray, fontFamily: FONTFAMILY.averta_semibold, marginTop: wp(8) },

  closeContainer: {
    position: "absolute",
    right: SIZES.base,
    color: COLORS.scienceBlue,
    bottom: SIZES.tip * 0.3,
  },

  closeText: { 
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h1_9,
   },
  flatlistContainer: {
    flexGrow: 1,
    marginHorizontal: SIZES.padding,
  },
  itemContainer: {
    paddingHorizontal: SIZES.base,
    paddingVertical: SIZES.radius * 1.5,
  },
  rowContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
});

export default styles;
