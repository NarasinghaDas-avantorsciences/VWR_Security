import React, { useEffect, useState } from "react";
import { TouchableOpacity, Text, View, FlatList, Keyboard } from "react-native";
import BottomSheetComponent from "../BottomSheet";
import { ToastComponent } from "../Toast";
import SearchBar from "../SearchBar";
import { COLORS, FONTS, SIZES, FONTFAMILY } from "../../Utils/theme";
import { Check } from "../../Utils/images";
import styles from "./styles";
import { useSelector } from "react-redux";
import { filterDataByName, wp } from "../../Utils/globalFunction";
import Toast from "react-native-toast-message";
import AnimatedSearch from "../AnimatedSearch";

interface CategoryProps {
  idLabel?: string;
  title?: string;
  renderBottomComponent?: React.ReactElement;
  value?: any;
  setSelected?: any;
  bottomSheetRef?: any;
  data?: any;
  height?: number;
  searchKeyword?: string;
  didCloseModal?: any;
  reasonCode?: boolean;
  reasonSuffix?: boolean;
  from?: any;
  isAnimatedSearch?: boolean;
}

const SearchBottomSheet: React.FC<CategoryProps> = ({
  idLabel,
  setSelected,
  value,
  title,
  data,
  bottomSheetRef,
  height,
  renderBottomComponent,
  searchKeyword,
  didCloseModal,
  reasonCode = false,
  reasonSuffix = false,
  from = false,
  isAnimatedSearch = false,
}) => {
  const [search, setSearch] = useState("");
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const [blockData, setBlockData] = useState([]);

  useEffect(() => {
    onChangeSearchField("");
  }, [data]);
  const noDataFound = () => {
    return (
      <View
        style={styles.emptyContainer}
        accessible={true}
        accessibilityLabel={`${idLabel}-flatlist-item-not-found-container`}
      >
        <Text
          style={styles.emptyText}
          accessible={true}
          accessibilityLabel={`${idLabel}-flatlist-item-not-found-text`}
        >
          {Strings["no.records.found"]}
        </Text>
      </View>
    );
  };
  const showToast = (text1: string, text2: string) => {
    Toast.show({
      type: "alertToast",
      text1: text1,
      text2: text2,
      position: "bottom",
      bottomOffset: SIZES.padding * 2,
    });
  };

  const onChangeSearchField = async (searckKey: string,barcode=false) => {
    //console.log("barcode",barcode)
    if (reasonCode) {
      let filteredData1 = data.filter(
        (item: any) =>
          item.reasonCode?.toLowerCase().includes(searckKey.toLowerCase()) ||
          item?.id == searckKey
      );
      setBlockData(filteredData1);
      if (filteredData1?.length && barcode) {
        setSearch(filteredData1[0]?.reasonCode);
      } else {
        setSearch(searckKey);
      }
    } else {
      const filteredData: any = filterDataByName(
        data,
        searchKeyword,
        searckKey
      );
      setBlockData(filteredData);
      setSearch(searckKey);
    }
    if(!searckKey){
      setSearch(searckKey);

    }
  };

  const scanReasonCode = (barcode: string) => {
    const code = barcode.split("#")[1];
    let filteredData1 = data.filter((item: any) => {
      if (item?.id == code) return item;
    });

    if (filteredData1?.length == 0) {
      //
      showToast(
        Strings["ime.scanner.error.occured.msg"],
        Strings["please_scan_a_valid_barcode"]
          ? Strings["please_scan_a_valid_barcode"]
          : "Please Scan a valid barcode!"
      );
    } else {
      setBlockData(filteredData1);
    }
  };

  return (
    <BottomSheetComponent
      bottomSheetRef={bottomSheetRef}
      height={height}
      didCloseModal={() => {
        onChangeSearchField("");
        didCloseModal;
      }}
    >
      <View
        style={styles.container}
        accessible={true}
        accessibilityLabel={`${idLabel}-searchBottomSheet-container`}
      >
        <Text
          accessible={true}
          accessibilityLabel={`${idLabel}-search-bottom-sheet-title`}
          style={{
            fontSize: FONTS.h2_1,
            textAlign: "center",
            fontFamily: FONTFAMILY.averta_semibold,
            color: COLORS.abbey,
          }}
        >
          {title}
        </Text>
        <TouchableOpacity
          accessible={true}
          accessibilityLabel={`${idLabel}-search-bottom-sheet-cross`}
          style={[styles.closeContainer]}
          onPress={() => bottomSheetRef.current.close()}
        >
          <Text style={styles.closeText}>{Strings.close}</Text>
        </TouchableOpacity>
      </View>

      {!isAnimatedSearch ? (
        <SearchBar
          idLabel={`${idLabel}-searchBottomSheet-searchBar`}
          search={search}
          onSearch={(text: string) => onChangeSearchField(text)}
          placeholder={Strings["search"]}
          containerStyle={{
            paddingHorizontal: SIZES.padding,
          }}
          onBarcodeDetected={(barcode) =>
            reasonCode ? scanReasonCode(barcode) : onChangeSearchField(barcode,true)
          }
          from={from}
        />
      ) : (
        <AnimatedSearch
          idLabel={`${idLabel}-animatedSearch`}
          search={search}
          onSearch={(text: string) => onChangeSearchField(text)}
          placeholder={Strings["search"]}
          containerStyle={{
            paddingHorizontal: SIZES.padding,
          }}
          cancelBtnStyle={{ paddingRight: wp(5) }}
          clearText={() => {
            onChangeSearchField("");
            // Keyboard.dismiss();
          }}
          onBarcodeDetected={(barcode) => {
            onChangeSearchField(barcode,true);
          }}
          onCancel={() => {
            onChangeSearchField("");
            Keyboard.dismiss();
          }}
          isShowEmptyMsg={false}
        />
      )}

      <FlatList
        accessible={true}
        ListEmptyComponent={noDataFound}
        accessibilityLabel={`${idLabel}-bottom-sheet-list`}
        data={blockData}
        contentContainerStyle={styles.flatlistContainer}
        keyExtractor={(item: any) => `${item.id}`}
        ItemSeparatorComponent={() => (
          <View style={{ backgroundColor: COLORS.gray2, height: 0.5 }} />
        )}
        renderItem={(item: any, index: number) => {
          return (
            <TouchableOpacity
              accessible={true}
              accessibilityLabel={`${idLabel}-flatlist-items-${index}`}
              style={styles.itemContainer}
              onPress={() => {
                bottomSheetRef.current.close();
                setSelected(
                  reasonCode
                    ? {
                        code: item.item?.reasonCode,
                        id: item.item?.id,
                        dontSyncWithSap: item.item?.dontSyncWithSap,
                      }
                    : { code: item?.item?.value, id: index }
                );
              }}
            >
              <View
                style={styles.rowContainer}
                accessible={true}
                accessibilityLabel={`${idLabel}-flatlist-viewRow-container-${index}`}
              >
                <Text
                  accessible={true}
                  accessibilityLabel={`${idLabel}-reasonCode-sync-${index}`}
                  style={{
                    ...FONTS.title,
                    color:
                      value == item.item.id ? COLORS.gray : COLORS.lightGray,
                  }}
                >
                  {reasonCode ? item.item.reasonCode : item.item.value}{" "}
                  {reasonSuffix
                    ? item?.item?.dontSyncWithSap == "N"
                      ? `(${Strings["ime.scanner.Sync.with.SAP"]})`
                      : "(Correct only IM)"
                    : ""}
                </Text>

                {value == item?.item?.id && <Check />}
              </View>
            </TouchableOpacity>
          );
        }}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
      />

      {renderBottomComponent && renderBottomComponent}

      {/* Toast */}
      <ToastComponent />
    </BottomSheetComponent>
  );
};

export default SearchBottomSheet;
