import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS, ICONSIZE, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  mainContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: SIZES.padding,
  },
  emptyContainer: { alignItems: "center", justifyContent: "center" },
  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },
  outerContainer: {},
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: 40,
  },

  iconStyle: {
    height: ICONSIZE.h3,
    width: ICONSIZE.h3,
    left: 0,
    alignSelf: "center",
    marginLeft: SIZES.base,
  },

  rightIconStyle: {
    alignSelf: "center",
    paddingHorizontal: SIZES.base,
  },

  textInput: {
    flex: 1,
    ...FONTS.body,
    color: COLORS.abbey,
    marginLeft: SIZES.base,
  },

  search: {
    // flex: 1,
    flexDirection: "row",
    height: 40,
    borderRadius: 6,
    // position: "absolute",
    alignSelf: "center",
  },

  cancelSearch: {
    position: "absolute",
    marginHorizontal: 16,
    paddingHorizontal: wp(2),
    paddingVertical: wp(1.5),
    textAlign: "center",
    justifyContent: "center",
    alignSelf: "center",
    right: -wp(4.5),
  },

  cancelSearchText: {
    color: COLORS.blue,
    // marginLeft: wp(10),
  },

  clearTextStyle: {
    paddingHorizontal: SIZES.base,
    height: "100%",
    width: "10%",
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Styles;
