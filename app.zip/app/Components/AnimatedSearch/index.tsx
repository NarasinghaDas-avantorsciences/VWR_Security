import React, { useState } from "react";
import {
  TextInput,
  View,
  StyleProp,
  ViewStyle,
  Dimensions,
  Pressable,
  LayoutAnimation,
  Platform,
  UIManager,
  TouchableOpacity,
} from "react-native";
import ScannerButton from "../ScannerButton";
import { COLORS } from "../../Utils/theme";
import { Search, Cross } from "../../Utils/images";
import { hp, removeEmojis, wp } from "../../Utils/globalFunction";
import styles from "./styles";
import CustomText from "../CustomText";
import { useSelector } from "react-redux";

type SearchProps = {
  idLabel?: string;
  placeholder?: string;
  search: string;
  onSearch: (text: string) => void;
  onCancel?: () => void;
  cancel?: Boolean;
  containerStyle?: StyleProp<ViewStyle>;
  cancelBtnStyle?: StyleProp<ViewStyle>;
  onBarcodeDetected?: (barcode: string) => void;
  clearText?: () => void;
  from?: any;
  isShowEmptyMsg?: any;
  isShowScan?: Boolean;
  scanBatch?: boolean;
  returnKeyLabel?: any;
  returnKeyType?: any;
};

const { width } = Dimensions.get("screen");
const PADDING = wp(4);
const SEARCH_FULL_WIDTH = width - PADDING * 1.8; //search_width when unfocused
const SEARCH_SHRINK_WIDTH = width - PADDING - hp(10); //search_width when focused

if (Platform.OS === "android") {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const AnimatedSearch: React.FC<SearchProps> = ({
  idLabel = "",
  placeholder,
  search,
  onSearch,
  onCancel,
  cancel = false,
  containerStyle,
  onBarcodeDetected,
  clearText,
  from,
  isShowEmptyMsg = true,
  cancelBtnStyle,
  isShowScan = true,
  scanBatch = false,
  returnKeyLabel,
  returnKeyType,
}) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const [searchBarFocused, setSearchBarFocused] = useState(false);
  const productDetailsLoading = useSelector(
    (state: any) => state.searchReducer?.productDetailsLoading
  );
  const productsData = useSelector(
    (state: any) => state.searchReducer?.searchList
  );
  const { isLoading, receiveDataList } = useSelector(
    (state: any) => state.receiveReducer
  );
  // const isEmpty =
  //   from != "login" &&
  //   from != "reasoncode" &&
  //   from != "picount" &&
  //   !!search &&
  //   !productsData?.data?.length &&
  //   !productDetailsLoading;
  const isEmpty =
    from != "approvals" &&
    from != "login" &&
    from != "org" &&
    from != "reasoncode" &&
    from != "picount" &&
    !!search &&
    (from == "receive"
      ? !receiveDataList?.length && !isLoading
      : !productsData?.data?.length && !productDetailsLoading);
  const noDataFound = () => {
    return (
      <View
        style={styles.emptyContainer}
        accessible={true}
        accessibilityLabel={`${idLabel}-nodata-container`}
      >
        <CustomText
          style={styles.emptyText}
          accessibilityLabel={`${idLabel}-noRecords-text`}
        >
          {Strings["no.records.found"]}
        </CustomText>
      </View>
    );
  };
  const onFocus = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setSearchBarFocused(true);
  };

  const onBlur = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setSearchBarFocused(false);
  };

  const onSearchText = (text: string) => {
    let newVal = removeEmojis(text);
    onSearch(newVal);
    if (newVal == "") {
      setSearchBarFocused(false);
    } else {
      !searchBarFocused && setSearchBarFocused(true);
    }
  };

  return (
    <View style={styles.outerContainer}>
      <View
        accessible={true}
        accessibilityLabel={`${idLabel}-main_container`}
        style={[styles.mainContainer, containerStyle]}
      >
        <View
          accessible={true}
          accessibilityLabel={`${idLabel}-sub_container`}
          style={[
            styles.container,
            {
              borderWidth: cancel ? 1 : 0,
            },
          ]}
        >
          <View
            accessible={true}
            accessibilityLabel={`${idLabel}-search_container`}
            style={[
              styles.search,
              {
                width: searchBarFocused
                  ? SEARCH_SHRINK_WIDTH
                  : SEARCH_FULL_WIDTH,
                backgroundColor: cancel ? COLORS.white : COLORS.gray3,
              },
              searchBarFocused === true
                ? undefined
                : { justifyContent: "center" },
            ]}
          >
            <Search style={styles.iconStyle} />

            <TextInput
              accessible={true}
              accessibilityLabel={`${idLabel}-search_input`}
              style={[
                styles.textInput,
                { paddingRight: isShowScan ? hp(3) : hp(3) },
              ]}
              placeholder={placeholder}
              placeholderTextColor={COLORS.gray2}
              value={removeEmojis(search)}
              onChangeText={(text: string) => onSearchText(text)}
              onBlur={onBlur}
              onFocus={onFocus}
              autoFocus={false}
              allowFontScaling={false}
              returnKeyLabel={returnKeyLabel}
              returnKeyType={returnKeyType}
            />

            <TouchableOpacity
              accessible={true}
              accessibilityLabel={`${idLabel}-clear_text`}
              style={[
                styles.clearTextStyle,
                { right: isShowScan ? wp(10) : wp(0) },
              ]}
              onPress={() => clearText()}
            >
              {search?.length > 0 && <Cross height={hp(1.5)} width={hp(1.5)} />}
            </TouchableOpacity>
            {isShowScan && (
              <View
                accessible={true}
                accessibilityLabel={`${idLabel}-scanner_button`}
                style={styles.rightIconStyle}
              >
                <ScannerButton
                  from="auth"
                  onBarcodeDetected={onBarcodeDetected}
                  scanBatch={scanBatch}
                />
              </View>
            )}
          </View>
        </View>

        {searchBarFocused && (
          <TouchableOpacity
            accessible={true}
            accessibilityLabel={`${idLabel}-cancel_button`}
            style={[styles.cancelSearch, cancelBtnStyle]}
            onPress={() => onCancel()}
          >
            <CustomText
              accessibilityLabel={`${idLabel}-cancel_button_title`}
              style={[styles.cancelSearchText]}
            >
              {(Strings["ime.cancel"] || "cancel")?.length > 6
                ? (Strings["ime.cancel"] || "cancel").substring(0, 6) + ".."
                : Strings["ime.cancel"] || "cancel"}
            </CustomText>
          </TouchableOpacity>
        )}
      </View>
      {from !== "Replenish" &&
        from !== "stockCorrection" &&
        from !== "stocktransfer" &&
        from !== "consume" &&
        isEmpty &&
        isShowEmptyMsg &&
        noDataFound()}
    </View>
  );
};

export default AnimatedSearch;
