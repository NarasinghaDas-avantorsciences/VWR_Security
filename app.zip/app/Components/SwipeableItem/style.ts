import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  leftAction: {
    minWidth: wp(20),
    backgroundColor: COLORS.red,
    alignItems: "center",
    justifyContent: "center",
  },
  actionText: {
    color: COLORS.white,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
  },
});

export default Styles;
