import React from "react";
import { Animated } from "react-native";
import { RectButton } from "react-native-gesture-handler";
import Swipeable from "react-native-gesture-handler/Swipeable";

import styles from "./style";
import { useSelector } from "react-redux";

type SwipableItemProps = {
  children?: React.ReactNode;
  onPressRight?: () => void;
  id: string;
};

const SwipableItem: React.FC<SwipableItemProps> = ({
  children,
  id,
  onPressRight,
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);

  const renderRightActions = (progress: any, dragX: any) => {
    const trans = dragX.interpolate({
      inputRange: [0, 100],
      outputRange: [0, 1],
      extrapolate: "clamp",
    });

    return (
      <RectButton style={styles.leftAction} onPress={onPressRight}>
        <Animated.Text
          allowFontScaling={false}
          style={[
            styles.actionText,
            {
              transform: [{ translateX: trans }],
            },
          ]}
        >
          {strings["delete.hmisppe"]}
        </Animated.Text>
      </RectButton>
    );
  };

  return (
    <Swipeable key={id} renderRightActions={renderRightActions}>
      {children}
    </Swipeable>
  );
};

export default SwipableItem;
