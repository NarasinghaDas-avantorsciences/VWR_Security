import React from "react";
import { ActivityIndicator, View, Image } from "react-native";
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from "react-native-responsive-screen";
import { Loading1 } from "../../Utils/images";
import { isDeviceTablet } from "../../Utils/globalFunction";
import styles from "./styles";
import { useSelector } from "react-redux";
import CustomText from "../CustomText";

export const Loader = (props: any) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const isTablet = isDeviceTablet();
if(props?.show){

  return (
    <View style={[styles.container]}>
      <View style={[styles.center]}>
        <Image
          style={{
            width: isTablet ? wp("12%") : wp("16%"),
            height: isTablet ? wp("12%") : wp("16%"),
          }}
          source={Loading1}
        />
        <CustomText
          style={[styles.textStyle, { marginTop: isTablet ? hp(2) : hp(1) }]}
        >
          {Strings["ime.loading"] ?? "Loading"}
        </CustomText>
      </View>
    </View>
  );
}

};

export const HalfLoader = () => (
  <ActivityIndicator size="small" color={"#fff"} />
);
