import { StyleSheet } from "react-native";
import { wp, hp } from "../../Utils/globalFunction";
import { COLORS, SIZES, FONTS } from "../../Utils/theme";

export default StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    zIndex: 10,
    backgroundColor:"rgba(1,1,1,0.5)"
  },
  contLarge:{
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 10,
  },

  center: {
    alignItems: "center",
    justifyContent: "center",
    width: wp(34),
    height: hp(18),
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radius,
  },
  textStyle: {
    ...FONTS.heading,
    fontSize: FONTS.h2_5,
    color: COLORS.scienceBlue,
  },
});
