import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  addButton: {
    justifyContent: "center",
    alignItems: "center",
    marginTop: hp(2),
    marginBottom: hp(3),
    width: wp(37),
  },
  qtyContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: SIZES.width * 0.45,
  },
  mainContainer: {
   
    paddingBottom: wp(4),
    paddingTop: wp(2),
    
  },
  crossButton: { alignSelf: "flex-end", marginTop: wp(6) },
  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_semibold,
  },
  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },
  itemChildContainer: {
    width: SIZES.width * 0.4,
    marginTop: wp(2),
  },
  buttonTitle: {
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_5,
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
     alignItems: "flex-start",
    paddingTop: SIZES.tip,
  },
  qty: {
    maxWidth: wp(10),
    paddingVertical: SIZES.base,
    paddingHorizontal: SIZES.tip,
    color: COLORS.abbey,
    textAlign: "center",
    padding: 0,
    ...FONTS.body,
  },
  multipierText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_regular,
  },
  qtyTitle: {
    color: COLORS.abbey,
    textAlign: "center",
    fontSize: FONTS.h1_9,
    fontFamily: FONTFAMILY.averta_bold,
  },
  inputMain: {
    width: "30%",
    alignSelf: "flex-start",
    marginTop: wp(2),
    flex: 1,
    marginRight: wp(8),
  },
  header: {
    marginTop: 27,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    marginBottom: 10,
  },
  headerText: {
    ...FONTS.body,
    color: COLORS.abbey,
  },
  input: {
    height: hp(4),
    fontSize: FONTS.h1_5,
    padding: 0,
    color: COLORS.abbey,
  },
  arrowMain: {
    flexDirection: "row",
    alignItems: "center",
  },
});

export default Styles;
