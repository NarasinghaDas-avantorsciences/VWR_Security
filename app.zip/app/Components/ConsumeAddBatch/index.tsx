import React, { useCallback, useLayoutEffect, useState } from "react";
import { View, TouchableOpacity, Keyboard } from "react-native";
import { useSelector, useDispatch } from "react-redux";
import { Calendar } from "react-native-calendars";
import moment from "moment";
import styles from "./styles";
import {
  QtyController,
  TextInputComponent,
  AlertModal,
} from "../../Components/index";
import {
  findDateFormat,
  getCurrencySymbol,
  hp,
  removeEmojis,
  wp,
} from "../../Utils/globalFunction";
import { RightArrow, LeftArrow } from "../../Utils/images";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import CustomText from "../CustomText";
import { useFocusEffect } from "@react-navigation/native";

type AddBatchProps = {
  item?: any;
  from?: any;
  onChange?: any;
  data?: any;
  updateActualQty?: any;
  setLoader?: any;
  disabled?: boolean;
  topLimitValue?: any;
  formatedData: any;
  setFormatedData: any;
  uomId: any;
  availableQty: any;
  showWarn?: any;
  freeze?: boolean;
  showAlert?: any;
  showPrice?: any;
  price?: any;
  symbol:string
};

let flag = 0;
const PICOUNT = "picount";

const AddBatch: React.FC<AddBatchProps> = ({
  item,
  from = "stock.correction",
  onChange,
  data,
  updateActualQty,
  setLoader,
  disabled = false,
  formatedData,
  setFormatedData,
  uomId,
  availableQty,
  topLimitValue,
  showWarn,
  showAlert,
  showPrice,
  price,
  freeze = false,
  symbol=""
}) => {
  const dispatch = useDispatch<any>();
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { stockRoomDetail, dateFormat } = useSelector(
    (state: any) => state.userReducer
  );
  const { receiveLimitFlag } = useSelector(
    (state: any) => state.receiveReducer
  );
  const [batchValue, setBatchValue] = useState<any>("0");
  const [todayDate, setToday] = useState(moment().format("YYYY-MM-DD"));
  const [focusedDate, setFocusedDate] = useState(todayDate);
  const [visable, setVisable] = useState(false);
  const [selectedDate, setSelectedDate] = useState<any>(null);
  const { currency } = useSelector((state: any) => state.userReducer);

  const onChangeData = async (
    inputVal: string,
    index: number,
    key: string,
    batchId: string
  ) => {
    let text = removeEmojis(inputVal);
    let data =
      key == "actualQty" || key == "expiryDate"
        ? formatedData
        : [...formatedData];

    data[index] = {
      ...data[index],
      [key]: text,
    };
    // setFormatedData(data);

    onChange && onChange(data, batchId, item?.id);

    if (key == "actualQty") {
      const val = formatedData.reduce(
        (n: any, { actualQty }: any) => Number(n) + Number(actualQty),
        0
      );

      //CHECKING MAXSTOCK QUANTITY
      if (
        stockRoomDetail?.isMaximumConsumptionEnabled &&
        item?.maxConsumptionQuantity != null
      ) {
        if (Number(val) > item?.maxConsumptionQuantity) {
          if (stockRoomDetail?.isOverConsume) {
            showWarn(false);
            showAlert(true);
          } else {
            showWarn(true);
          }
        } else {
          showWarn(false);
        }
      }

      await updateActualQty(val);
    }
  };

  const checkifBatchEnabled = () => {
    if (
      !!stockRoomDetail?.isBatchManagementEnabled &&
      (!!item?.batchManagementEnabled ||
        !!item?.product?.batchManagementEnabled)
    ) {
      return true;
    } else {
      return false;
    }
  };

  const checkifExpiryEnabled = () => {
    if (
      !!stockRoomDetail?.isExpiryManagementEnabled &&
      (!!item?.expiryDateManagementenabled ||
        !!item?.product?.expiryDateManagementenabled)
    ) {
      return true;
    } else {
      return false;
    }
  };
  useLayoutEffect(() => {
    addPreData();
  }, []);

  const addPreData = async () => {
    let preData = [];
    setLoader?.(true);
    for (let i = 0; i < data?.length; i++) {
      let d = {
        batchNo: data[i]?.batchNo,
        expiryDate: data[i]?.expiryDate,
        actualQty:
          from == "receive"
            ? data[i]?.receivedQty
            : data[i]?.actualQty ?? data[i]?.availableQty,
        id: data[i]?.id,
        added: false,
      };
      if (parseInt(data[i]?.availableQty) > 0) preData.push(d);
    }
    setFormatedData([...preData]);
    setLoader?.(false);
  };

  const add = () => {
    flag += 1;

    let d = {
      batchNo: "",
      expiryDate: "",
      actualQty: 0,
      id: `addedBatch-${flag}`,
      added: true,
    };
    setFormatedData([...formatedData, d], item.id);
  };

  const decrement = () => {
    const previousMonth = moment(focusedDate, "YYYY-MM-DD")
      .subtract(1, "months")
      .format("YYYY-MM-DD");
    setFocusedDate(previousMonth);
  };

  const increment = () => {
    const nextMonth = moment(focusedDate, "YYYY-MM-DD")
      .add(1, "months")
      .format("YYYY-MM-DD");
    setFocusedDate(nextMonth);
  };

  const incrementYear = () => {
    const nextMonth = moment(focusedDate, "YYYY-MM-DD")
      .add(12, "months")
      .format("YYYY-MM-DD");
    setFocusedDate(nextMonth);
  };

  const preDate = () => {
    let date;
    if (formatedData?.[selectedDate?.index]?.date) {
      date = moment(formatedData?.[selectedDate?.index]?.date).format(
        "YYYY-MM-DD"
      );
    } else {
      date = moment().format("YYYY-MM-DD");
    }
    return date;
  };

  const markedDate = () => {
    return {
      [preDate()]: { selected: true, selectedColor: COLORS.scienceBlue },
    };
  };

  const changeDate = (date: string) => {
    date = moment(date).format("YYYY-MM-DD");
    onChangeData(date, selectedDate?.index, "expiryDate", selectedDate?.id);
    setVisable(false);
    setSelectedDate(null);
    setToday(date);
  };

  const __renderCalander = () => (
    <View
      style={{
        backgroundColor: COLORS.white,
      }}
    >
      <Calendar
        testID="addBatch-calendar"
        accessible={true}
        accessibilityLabel="addBatch-calendar"
        minDate={moment().format("YYYY-MM-DD")}
        initialDate={focusedDate}
        customHeaderTitle={
          <View style={styles.header}>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <CustomText allowFontScaling={false} style={styles.headerText}>
                {moment(focusedDate, "YYYY-MM-DD").format("MMMM YYYY")}
              </CustomText>
              <RightArrow
                // onPress={incrementYear}
                style={{ marginLeft: wp(2) }}
                height={hp(2)}
                width={hp(2)}
              />
            </View>
            <View style={styles.arrowMain}>
              <TouchableOpacity
                onPress={decrement}
                style={{ marginRight: wp(3) }}
              >
                <LeftArrow height={hp(2)} width={hp(2)} />
              </TouchableOpacity>
              <TouchableOpacity onPress={increment}>
                <RightArrow height={hp(2)} width={hp(2)} />
              </TouchableOpacity>
            </View>
          </View>
        }
        onDayPress={(day) => {
          changeDate(day.dateString);
        }}
        style={{}}
        hideArrows={true}
        theme={{
          todayTextColor: COLORS.abbey,
          dayTextColor: COLORS.abbey,
          selectedDayTextColor: COLORS.white,
          textDayFontSize: FONTS.h1_7,
          textDayFontFamily: FONTFAMILY.averta_semibold,
        }}
        markedDates={markedDate()}
        monthFormat={"yyyy MM"}
      />
    </View>
  );

  const [keyboardStatus, setKeyboardStatus] = useState(false);

  useFocusEffect(
    useCallback(() => {
      const showSubscription = Keyboard.addListener("keyboardDidShow", () => {
        setKeyboardStatus(true);
      });
      const hideSubscription = Keyboard.addListener("keyboardDidHide", () => {
        setKeyboardStatus(false);
      });
      return () => {
        showSubscription.remove();
        hideSubscription.remove();
      };
    }, [])
  );

  return (
    <View
      style={
        from !== PICOUNT && {
          flex: 1,
          paddingBottom: keyboardStatus && from == "item_confirm" ? hp(20) : 0,
        }
      }
    >
      {formatedData?.map((item: any, index: any) => {
        let isAddedItem = item?.id?.includes("addedBatch");
        let date =
          from == "receive"
            ? String(
                item?.expiryDate != ""
                  ? isAddedItem
                    ? moment(item?.expiryDate, "YYYY-MM-DD").format(
                        "MM-DD-YYYY"
                      )
                    : moment(item?.expiryDate, "YYYY-MM-DD").format(
                        "MM-DD-YYYY"
                      )
                  : focusedDate
              )
            : moment(item?.expiryDate).format(dateFormat?.date);
        // date = item?.expiryDate
        //   ? date.substring(0, 6) + "2" + date.substring(6 + 1)
        //   : "";

        /*
        let date =
          item?.expiryDate &&
          moment(item?.expiryDate, findDateFormat(item?.expiryDate)).format(
            dateFormat.date
          );*/
        // date = item?.expiryDate
        //   ? date.substring(0, 6) + "2" + date.substring(6 + 1)
        //   : "";

        return (
          <View
            style={[
              styles.mainContainer,
              (from == "item_confirm" || index + 1 != formatedData?.length) && {
                borderBottomWidth: 0.6,
                borderBottomColor: COLORS.alto,
              },
            ]}
            accessible={true}
            accessibilityLabel={`consumeAddBatch-main-container-${index}`}
          >
            <View
              style={[styles.item]}
              key={index}
              accessible={true}
              accessibilityLabel={`consumeAddBatch-item-container-${index}`}
            >
              <TextInputComponent
                charLimit={25}
                idLabel={`consumeAddBatch-batch-no-${index}`}
                title={Strings["batch.no"]}
                editable={
                  freeze ? false : !!isAddedItem && checkifBatchEnabled()
                }
                disabled={
                  freeze ? true : !isAddedItem || !checkifBatchEnabled()
                }
                main={styles.inputMain}
                inputStyle={styles.input}
                inputMain={{
                  height: hp(4),
                }}
                placeholder={Strings["batch.no"]}
                value={removeEmojis(item?.batchNo)}
                onChangeText={
                  checkifBatchEnabled()
                    ? (val) => onChangeData(val, index, "batchNo", item?.id)
                    : () => null
                }
              />
              <TextInputComponent
                idLabel={`consumeAddBatch-expiry-date-${index}`}
                title={Strings["ime.scanner.Exp.Date"]}
                editable={false}
                disabled={
                  freeze ? true : !isAddedItem || !checkifExpiryEnabled()
                }
                value={date == "Invalid date" ? item?.expiryDate : date}
                main={[styles.inputMain]}
                inputStyle={styles.input}
                inputMain={{
                  height: hp(4),
                  alignItems: "center",
                }}
                placeholder={Strings["date"]}
                onChangeText={
                  isAddedItem && checkifExpiryEnabled()
                    ? (val) => onChangeData(val, index, "expiryDate", item?.id)
                    : () => null
                }
                onPressRightIcon={
                  isAddedItem && checkifExpiryEnabled()
                    ? () => {
                        setSelectedDate({ index, id: item?.id });
                        setVisable(!visable);
                      }
                    : () => null
                }
              />
            </View>
            <View
              style={styles.item}
              key={index + 1}
              accessible={true}
              accessibilityLabel={`consumeAddBatch-itemSub-container-${
                index + 1
              }`}
            >
              <View
                style={[styles.itemChildContainer]}
                accessible={true}
                accessibilityLabel={`consumeAddBatch-itemChild-container-${
                  index + 1
                }`}
              >
                <CustomText
                  style={styles.itemChildTitleText}
                  accessibilityLabel={`consumeAddBatch-availQty-text-${
                    index + 1
                  }`}
                >
                  {Strings["ime.avail.qty"]}
                </CustomText>
                {
                  <CustomText
                    style={styles.itemChildValueText}
                    accessibilityLabel={`consumeAddBatch-availQty-value-${
                      index + 1
                    }`}
                  >
                    {!!item?.availableQty ? item.availableQty : 0}
                  </CustomText>
                }
              </View>
              <View
                style={styles.qtyContainer}
                accessible={true}
                accessibilityLabel={`consumeAddBatch-qtyContainer-${index + 1}`}
              >
                <CustomText
                  allowFontScaling={false}
                  style={styles.qtyTitle}
                  accessibilityLabel={`consumeAddBatch-qty-text-${index + 1}`}
                >
                  {Strings["ime.qty"]}
                </CustomText>
                <QtyController
                  showLabel={false}
                  onChange={async (val: string) => {
                    val = val.toString();
                    onChangeData(val, index, "actualQty", item?.id);
                  }}
                  inputStyle={styles.qty}
                  inputValue={item?.actualQty}
                  topLimit={Number(batchValue) >= (item?.availableQty ?? 0)}
                  topLimitValue={item?.availableQty ?? 0}
                  disable={
                    freeze ? true : from == "receive" ? !item?.added : false
                  }
                />

                {/* <CustomText
                  style={styles.multipierText}
                  accessibilityLabel="consume-addBatch-list-item-multiplier"
                >
                  {item?.orderedQtyUOMDisplay ??
                    getMultiplier(item)}
                </CustomText> */}
              </View>
            </View>
            {!!showPrice && index + 1 == formatedData?.length && (
              <View style={{ marginTop: wp(2) }}>
                <CustomText
                  accessibilityLabel={`consume_order_view_item_child_text-${
                    index + 1
                  }`}
                  style={styles.itemChildTitleText}
                >
                  {Strings["price"]}
                </CustomText>
                <CustomText
                  accessibilityLabel={`consume_order_view_item_child_value-${
                    index + 1
                  }`}
                  style={styles.itemChildValueText}
                >
                  {
                    symbol?symbol:getCurrencySymbol(currency)
                  
                   + price}
                </CustomText>
              </View>
            )}
          </View>
        );
      })}
      {from == "item_confirm" && <View style={styles.addButton} />}
      <AlertModal
        isShow={visable}
        customStyles={{
          width: "90%",
        }}
        didCloseModal={() => setVisable(!visable)}
      >
        {__renderCalander()}
      </AlertModal>
    </View>
    // </KeyboardAvoidingView>
  );
};
export default AddBatch;
