import React, { useEffect } from "react";
import {
  TouchableOpacity,
  View,
  StyleSheet,
  useWindowDimensions,
  Dimensions,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import { COLORS, SIZES, FONTS } from "../../Utils/theme";
import { ChevronRight } from "../../Utils/images";
import CustomText from "../CustomText";
import {
  findDateFormat,
} from "../../Utils/globalFunction";
//findDateFormat
interface NotificationProps {
  icon?: React.ReactNode;
  item: any;
  onPress?: () => void;
  dateFormate:any

}

const NotificationComponent = ({ icon, item, onPress,dateFormate }: NotificationProps) => (
  <TouchableOpacity style={styles.notificationContainer} onPress={onPress}>
    {icon}

    <View style={styles.contentContainer}>
      <View style={{ flex: 1, marginLeft: SIZES.radius }}>
        <CustomText
          style={[
            styles.titleText,
            { color: (item?.markedAsRead || item?.status == 2) ? COLORS.gray : COLORS.scienceBlue },
          ]}
          numberOfLines={1}
        >
          {item?.subject}
        </CustomText>
        {/* <CustomText style={styles.subjectText} numberOfLines={2}>
          {item?.body}
        </CustomText> */}
        {item?.createdDate && (
          <CustomText style={styles.timeText}>
            {moment(
              item?.createdDate
            ).format(dateFormate)}
          </CustomText>
        )}
      </View>

      <ChevronRight />
    </View>
  </TouchableOpacity>
);
const styles = StyleSheet.create({
  notificationContainer: {
    paddingRight: SIZES.padding,
    paddingVertical: SIZES.padding,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "center",
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray2,
  },
  contentContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  titleText: {
    ...FONTS.title,
    marginBottom: SIZES.base,
    width: SIZES.width * 0.8,
  },
  subjectText: {
    ...FONTS.body,
    color: COLORS.gray,
    marginBottom: SIZES.base,
    width: SIZES.width * 0.8,
  },
  timeText: {
    ...FONTS.body2,
    color: COLORS.gray,
  },
  flatlistContainer: {
    flexGrow: 1,
    marginBottom: SIZES.padding * 2,
    marginLeft: SIZES.padding,
  },
});

export default NotificationComponent;
