import React from "react";
import {
  TouchableOpacity,
  TextInput,
  View,
  StyleProp,
  ViewStyle,
} from "react-native";
import { useSelector } from "react-redux";
import ScannerButton from "../ScannerButton";
import { Search, CloseBlack } from "../../Utils/images";
import { COLORS, FONTS, ICONSIZE, SIZES } from "../../Utils/theme";
import styles from "./styles";
import CustomText from "../CustomText";
import { removeEmojis } from "../../Utils/globalFunction";

type SearchProps = {
  idLabel?: string;
  placeholder?: string;
  search: string;
  onSearch: (text: string) => void;
  cancel?: Boolean;
  isBarCodeVisible?: Boolean;
  containerStyle?: StyleProp<ViewStyle>;
  onBarcodeDetected?: (barcode: string) => void;
  onPressCancel?: any;
  returnKeyLabel?: any;
  returnKeyType?: any;
  from?: any;
  stockTransferData?: number;
  enableSearchBar?: boolean;
  scanBatch?: boolean;
};

const SearchBar: React.FC<SearchProps> = ({
  idLabel = "",
  placeholder,
  search,
  onSearch,
  cancel = false,
  isBarCodeVisible = true,
  containerStyle,
  onBarcodeDetected,
  onPressCancel,
  returnKeyLabel,
  returnKeyType,
  from,
  stockTransferData,
  enableSearchBar = true,
  scanBatch = false,
}) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const productDetailsLoading = useSelector(
    (state: any) => state.searchReducer?.productDetailsLoading
  );
  const productsData = useSelector(
    (state: any) => state.searchReducer?.searchList
  );
  const { isLoading, receiveDataList } = useSelector(
    (state: any) => state.receiveReducer
  );
  const isEmpty =
    from != "approvals" &&
    from != "login" &&
    from != "org" &&
    from != "reasoncode" &&
    from != "picount" &&
    !!search &&
    (from == "receive"
      ? !receiveDataList?.length && !isLoading
      : !productsData?.data?.length && !productDetailsLoading);
  const noDataFound = () => {
    return (
      <View
        style={styles.emptyContainer}
        accessible={true}
        accessibilityLabel={`${idLabel}-searchbar-no-data`}
      >
        <CustomText
          style={styles.emptyText}
          accessibilityLabel={`${idLabel}-searchbar-nodata-text`}
        >
          {Strings["no.records.found"]}
        </CustomText>
      </View>
    );
  };
  
  return (
    <View
      style={styles.outerContainer}
      accessible={true}
      accessibilityLabel={`${idLabel}-search-outer-container`}
    >
      <View
        style={[styles.mainContainer, containerStyle]}
        accessible={true}
        accessibilityLabel={`${idLabel}-searchbar-main-container`}
      >
        <View
          style={[
            styles.container,
            {
              borderWidth: cancel ? 0.8 : 0,
              backgroundColor: cancel ? COLORS.white : COLORS.gray3,
              borderColor: cancel ? COLORS.doveGray : COLORS.white,
            },
          ]}
          accessible={true}
          accessibilityLabel={`${idLabel}-searchbar-container`}
        >
          <Search height={ICONSIZE.h2} width={ICONSIZE.h2} />
          <TextInput
            allowFontScaling={false}
            style={styles.textInput}
            placeholder={placeholder}
            placeholderTextColor={COLORS.lightGray}
            value={removeEmojis(search)}
            onChangeText={onSearch}
            accessible={true}
            editable={enableSearchBar}
            accessibilityLabel={`${idLabel}-searchbar-text-input`}
            returnKeyLabel={returnKeyLabel}
            returnKeyType={returnKeyType}
          />
          {search.length > 0 && (
            <TouchableOpacity
              style={styles.closeBtnContainer}
              onPress={() => onSearch("")}
              accessible={true}
              accessibilityLabel={`${idLabel}-searchbar-close-btn`}
            >
              <CloseBlack style={styles.iconStyle} fill={COLORS.black} />
            </TouchableOpacity>
          )}
          {!!isBarCodeVisible && (
            <TouchableOpacity onPress={() => console.log("")}>
              <ScannerButton
                idLabel={idLabel}
                from="auth"
                scanBatch={scanBatch}
                onBarcodeDetected={onBarcodeDetected}
                onSearch={() => onSearch("")}
                disabled={!enableSearchBar}
              />
            </TouchableOpacity>
          )}
        </View>
        {cancel && (
          <TouchableOpacity
            onPress={() => onSearch("")}
            accessible={true}
            accessibilityLabel={`${idLabel}-searchbar-cancel-btn`}
          >
            <CustomText
              style={styles.cancelText}
              accessibilityLabel={`${idLabel}-searchbar-cancel-text`}
              onPressIn={onPressCancel}
            >
              {Strings["cancel"]}
            </CustomText>
          </TouchableOpacity>
        )}
      </View>
      {from == "stocktransfer" && stockTransferData == 0
        ? noDataFound()
        : from != "stocktransfer" && !!isEmpty && noDataFound()}
    </View>
  );
};

export default SearchBar;
