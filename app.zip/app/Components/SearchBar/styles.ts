import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS, ICONSIZE, SIZES } from "../../Utils/theme";
import { hp, isDeviceTablet, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  mainContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginVertical: SIZES.padding,
  },
  outerContainer: {
    alignItems: "center",
  },
  emptyContainer: { alignItems: "center", justifyContent: "center" },
  emptyText: {
    color: COLORS.lightGray,
    fontFamily: FONTFAMILY.averta_semibold,
    marginTop: wp(8),
  },

  container: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: isDeviceTablet() ? 50 : 40,
    paddingHorizontal: SIZES.base,
  },

  iconStyle: { height: ICONSIZE.h3, width: ICONSIZE.h3 },

  textInput: {
    flex: 1,
    ...FONTS.body,
    fontSize: FONTS.h1_9,
    paddingHorizontal: SIZES.base,
    color: COLORS.abbey,
  },

  closeBtnContainer: {
    padding: SIZES.base,
    marginHorizontal: hp(1),
  },

  cancelText: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
    marginLeft: SIZES.base,
  },
});

export default Styles;
