import React from "react";
import { View } from "react-native";
import CustomText from "../CustomText";
import { hp } from "../../Utils/globalFunction";
import { FONTFAMILY } from "../../Utils/theme";
import { Cloud, CrossIcon } from "../../Utils/images";
import styles from "./styles";

const OfflineToast = (props: any) => {
  return (
    <View
      style={[
        styles.mainView,
        props?.main,
        {
          flexDirection: "row",
        },
      ]}
      accessible={true}
      accessibilityLabel="offline-toast-content-container"
    >
      <View
        style={{
          height: hp(5),
          width: "15%",
          alignItems: "center",
          justifyContent: "center",
        }}
        accessible={true}
        accessibilityLabel="offline-toast-cross-Icon"
      >
        <Cloud />
        <CrossIcon
          style={{
            position: "absolute",
            zIndex: 100,
          }}
        />
      </View>

      <CustomText
        style={[styles.text, props?.text]}
        accessibilityLabel={"offline-toast-message-container"}
      >
        <CustomText
          style={{ fontFamily: FONTFAMILY.averta_semibold }}
          accessibilityLabel={"offline-toast-message"}
        >
          You are offline.
        </CustomText>{" "}
        {props?.login
          ? "Connect to the Internet in order to log in to Inventory Manager."
          : "You can consume and replenish in offline mode. Offline data will sync to Inventory Manager when connected to the Internet."}
      </CustomText>
    </View>
  );
};

export default OfflineToast;
