import { StyleSheet } from "react-native";

import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const styles = StyleSheet.create({
mainView:{
  borderWidth: 1,
  borderColor: "#e82707",
  width:wp(90),
  borderRadius: 5,
  paddingVertical: 10,
  marginTop: hp(1),
  backgroundColor:"#ffffff",
  paddingHorizontal:wp(1),
  alignItems:"center"
},
text:{
  color: "#333333",
  fontFamily:FONTFAMILY.averta_regular,
  fontSize:FONTS.h1_6,
  width:"85%"
}
});

export default styles;
