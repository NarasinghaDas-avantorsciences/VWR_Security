import React, { useState, useRef } from "react";
import {
  TouchableOpacity,
  View,
  StyleProp,
  ViewStyle,
  Keyboard,
} from "react-native";
import SearchBottomSheet from "../BottomSheet/SearchBottomSheet";
import TextInputComponent from "../TextInput";
import BottomSheetComponent from "../BottomSheet";
import MainButton from "../MainButton";
import { COLORS, FONTS, SIZES } from "../../Utils/theme";
import { hp } from "../../Utils/globalFunction";
import { CloseBlack, ArrowDown } from "../../Utils/images";
import styles from "./styles";
import { useDispatch, useSelector } from "react-redux";
import {
  setReasonCode,
  setCorrectStockList,
} from "../../Redux/Action/stockCorrection";
import { HalfLoader } from "../../Components/Loader";
import CustomText from "../CustomText";

type Props = {
  idLabel?: string;
  containerStyle?: StyleProp<ViewStyle>;
  item?: any;
  reasonCodeType: string;
  from?: string;
  reason?: any;
  setReason?: any;
  onChangeReasonCode?: any;
  showToast?: any;
  titleStyle?: any;
  reasonTextStyle?: any;
  textContainer?: any;
  handleReasonCode?: any;
  disabled?: boolean;
  required?: boolean;
  mainContainerstyle?: any;
};

const ReasonCode: React.FC<Props> = ({
  idLabel = "",
  containerStyle,
  item = "",
  reasonCodeType,
  from,
  reason,
  setReason,
  onChangeReasonCode,
  showToast,
  textContainer,
  reasonTextStyle,
  titleStyle,
  handleReasonCode,
  disabled = false,
  required,
  mainContainerstyle,
}) => {
  const [codeSelected, setCodeSelected] = useState<string>("");
  const [newReasonCode, setNewReasonCode] = useState<any>("");
  const reasonRef = useRef<any>(null);
  const addReasonRef = useRef<any>(null);
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { correctStockList, reasoncodes } = useSelector(
    (state: any) => state.stockCorrectionReducer
  );
  const { stockRoomDetail, org_details, addReasonCodePrivilege } = useSelector(
    (state: any) => state.userReducer
  );
  const dispatch = useDispatch<any>();
  const [loader, setLoader] = useState<any>(false);

  const reasonSuffix =
    stockRoomDetail?.stockroomType == "Regular"
      ? false
      : org_details?.showSapSetting;

  const saveCode = () => {
    if (newReasonCode?.length) {
      setNewReasonCode("");
      setLoader(true);
      const data = [
        {
          reasonCode: newReasonCode.trim(),
          codeType: reasonCodeType, // "stock.correction"
          dontSyncWithSap: "N",
          deleted: "N",
          isOverwrite: "N",
        },
      ];

      dispatch(
        setReasonCode(
          data,
          (res: string) => {
            setNewReasonCode(res);
            addReasonRef.current.close();
            setLoader(false);
            showToast?.(
              "Success",
              Strings["reasoncode.created"] ?? "Reason Code Created"
            );
          },
          (res: any) => {
            addReasonRef.current.close();
            setLoader(false);
            showToast?.(
              Strings["ime.scanner.error.occured.msg"],
              res?.errorMessage
            );
          },
          stockRoomDetail
        )
      );
    } else {
      addReasonRef.current.close();
      setLoader(false);
      showToast?.(
        Strings["error.occured"],
        "Reason code field should not be empty"
      );
    }
  };

  return (
    <>
      <View
        style={[containerStyle]}
        accessible={true}
        accessibilityLabel={`${idLabel}-view-container`}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            ...(required && { width: SIZES.width * 0.6 }),
            ...mainContainerstyle,
          }}
          accessible={true}
          accessibilityLabel={`${idLabel}-view-main-container`}
        >
          <CustomText
            testID={`${idLabel}-reasonCode-text`}
            accessibilityLabel={`${idLabel}-reasonCode-text`}
            allowFontScaling={false}
            style={[styles.reasonTitle, titleStyle]}
          >
            {Strings["reason.code"]||"reason.code"}
          </CustomText>
          {required && (
            <CustomText
              testID={`${idLabel}-reasonCode-requiredText`}
              accessibilityLabel={`${idLabel}-reasonCode-requiredText`}
              allowFontScaling={false}
              style={[styles.reasonTitle, styles.required]}
            >
              *{Strings["required"]||"required"}
            </CustomText>
          )}
        </View>
        <TouchableOpacity
          testID={`${idLabel}-reasonCode-button`}
          accessibilityLabel={`${idLabel}-reasonCode-button`}
          disabled={disabled}
          style={[
            styles.textContainer,
            textContainer,
            { borderColor: disabled ? COLORS.gray4 : COLORS.gray },
          ]}
          onPress={() => reasonRef.current.open()}
        >
          <CustomText
            allowFontScaling={false}
            style={[
              styles.reasonText,
              reasonTextStyle,
              { color: disabled ? COLORS.gray4 : COLORS.gray },
            ]}
          >
            {disabled
              ? Strings["select"]||"select"
              : from == "masterCode"
              ? reason?.code == null || reason?.code == ""
                ? Strings["select"]||"select"
                : reason?.code
              : item?.reasonCode?.code == "" ||
                item?.reasonCode?.code == undefined
              ? Strings["select"]||"select"
              : item?.reasonCode?.code}
          </CustomText>
          <ArrowDown />
        </TouchableOpacity>
      </View>

      <SearchBottomSheet
        idLabel={idLabel}
        from="reasoncode"
        bottomSheetRef={reasonRef}
        data={reasoncodes?.filter((item: any) => {
          if (reasonCodeType == "stock.correction")
            return item?.codeType == "stock.correction";
          else if (reasonCodeType == "recieve.stock")
            return item?.codeType == "recieve.stock";
          else return item;
        })}
        reasonSuffix={reasonSuffix}
        searchKeyword={"value"}
        title={Strings["reason.code"]}
        didCloseModal={() => Keyboard.dismiss()}
        isAnimatedSearch={true}
        renderBottomComponent={
          <>
            {addReasonCodePrivilege && (
              <MainButton
                accessibilityLabel={`${idLabel}-addReason-code-btn`}
                title={Strings["ime.add.reason.code"]||"ime.add.reason.code"}
                buttonTextStyle={[styles.buttonText]}
                buttonStyle={[styles.buttonStyle]}
                onChangeBtnPress={() => addReasonRef.current.open()}
              />
            )}

            <BottomSheetComponent
              bottomSheetRef={addReasonRef}
              height={SIZES.height * 0.3}
              didCloseModal={() => Keyboard.dismiss()}
            >
              <View
                style={styles.container}
                accessible={true}
                accessibilityLabel={`${idLabel}-reasonCode-sheet-container`}
              >
                <CustomText
                  accessibilityLabel={`${idLabel}-addReasonCode-text-btmsheet`}
                  allowFontScaling={false}
                  style={{ ...FONTS.heading, color: COLORS.gray }}
                >
                  {Strings["ime.add.reason.code"]}
                </CustomText>

                <TouchableOpacity
                  accessible={true}
                  accessibilityLabel={`${idLabel}-addReasonCode-cancel-btn-btmsheet`}
                  style={[styles.closeContainer]}
                  onPress={() => {
                    setNewReasonCode("");
                    addReasonRef.current.close();
                  }}
                >
                  <CustomText
                    allowFontScaling={false}
                    style={styles.closeText}
                    accessibilityLabel={`${idLabel}-addReasonCode-cancel-text-btmsheet`}
                  >
                    {Strings.cancel}
                  </CustomText>
                </TouchableOpacity>
              </View>

              <TextInputComponent
                charLimit={25}
                idLabel={`${idLabel}-add-reasonCode`}
                title={Strings["reason.code.name"]}
                placeholder={Strings["add.new.reason.code"]}
                onPressRightIcon={(isClear?: boolean) =>
                  isClear && setNewReasonCode("")
                }
                RightIcon={newReasonCode ? CloseBlack : null}
                value={newReasonCode}
                editable={true}
                onChangeText={(text) => setNewReasonCode(text)}
                main={[styles.stockTxtContainerStyle]}
                inputStyle={styles.inputStyle}
                inputMain={styles.inputMainStyle}
                rightIconWidth={hp(1.7)}
              />
              <MainButton
                accessibilityLabel={`${idLabel}-save-btn`}
                title={loader ? <HalfLoader /> : Strings.save}
                buttonTextStyle={[styles.buttonText]}
                buttonStyle={[styles.buttonStyle, { marginTop: SIZES.padding }]}
                onChangeBtnPress={() => saveCode()}
              />
            </BottomSheetComponent>
          </>
        }
        value={from == "masterCode" ? reason?.id : item?.reasonCode?.id}
        setSelected={
          from == "masterCode"
            ? async (val: any) => {
                let arr = correctStockList;
                arr.map((v: any) => Object.assign(v, { reasonCode: val }));
                await dispatch(setCorrectStockList(arr));
                setReason(val);
              }
            : from == "addToList"
            ? (val: any) => {
                setCodeSelected(val);
                item.reasonCode = val;
                handleReasonCode(item);
              }
            : async (val: any) => {
                let arr = correctStockList;
                let objIndex = arr.findIndex(
                  (obj: { id: any }) => obj?.id == item?.id
                );
                arr[objIndex].reasonCode = val;
                await dispatch(setCorrectStockList(arr));
              }
        }
        reasonCode={true}
      />
    </>
  );
};

export default ReasonCode;
