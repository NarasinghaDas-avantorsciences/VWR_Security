import { StyleSheet } from "react-native";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: SIZES.base,
    paddingBottom: SIZES.radius,
  },
 
  closeContainer: {
    position: "absolute",
    right: SIZES.base,
    paddingBottom: SIZES.radius,
    color: COLORS.scienceBlue,
    bottom: SIZES.tip * 0.3,
  },
  closeText: { ...FONTS.title, color: COLORS.scienceBlue },
  textContainer: {
    borderWidth: 1,
    borderColor: COLORS.gray,
    width: SIZES.width * 0.6,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: SIZES.base,
  },
  reasonTitle: {
    ...FONTS.body,
    color: COLORS.abbey,
    paddingBottom: SIZES.tip,
    fontFamily: FONTFAMILY.averta_semibold,
  },
  reasonText: { ...FONTS.title, color: COLORS.gray },
  buttonStyle: {
    width: SIZES.width - SIZES.padding * 2,
    marginLeft: SIZES.padding,
    marginBottom: SIZES.padding,
  },
  buttonText: {
    ...(SIZES.width > 350 ? FONTS.title : FONTS.title2),
    color: COLORS.white,
  },

  required: {
    color: COLORS.redFast,
    ...FONTS.body2,
    marginTop: SIZES.tip * 0.75,
  },

  inputStyle: {
    height: hp(6),
    fontSize: FONTS.h1_5,
    color: COLORS.abbey,
  },

  inputMainStyle: {
    height: hp(6),
    borderColor: COLORS.gray2,
    borderWidth: 0.8,
  },

  stockTxtContainerStyle: {
    width: wp(90),
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginTop: hp(2),
  },
});

export default styles;
