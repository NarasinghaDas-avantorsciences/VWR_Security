import React from "react";
import { render, fireEvent } from "@testing-library/react-native";
import ReasonCode from "./index";

describe("ReasonCode component", () => {
  test("renders correctly", () => {
    const { getByText } = render(<ReasonCode />);

    // Assert that the component renders without any errors
    expect(getByText("reason.code")).toBeTruthy();
  });

  test("selects a reason code", () => {
    const { getByText } = render(<ReasonCode />);

    // Simulate a button press to open the reason code selection modal
    fireEvent.press(getByText("Select"));

    // Assert that the reason code selection modal opens
    expect(getByText("Select Reason Code")).toBeTruthy();

    // Simulate a reason code selection
    fireEvent.press(getByText("Reason Code 1"));

    // Assert that the selected reason code is displayed
    expect(getByText("Reason Code 1")).toBeTruthy();
  });

  test("adds a new reason code", () => {
    const { getByText, getByPlaceholderText } = render(<ReasonCode />);

    // Simulate a button press to open the reason code selection modal
    fireEvent.press(getByText("Select"));

    // Simulate a button press to add a new reason code
    fireEvent.press(getByText("Add Reason Code"));

    // Assert that the add reason code modal opens
    expect(getByText("Add Reason Code")).toBeTruthy();

    // Simulate entering a new reason code
    fireEvent.changeText(
      getByPlaceholderText("Add new reason code"),
      "New Reason Code"
    );

    // Simulate a button press to save the new reason code
    fireEvent.press(getByText("Save"));

    // Assert that the new reason code is added and displayed
    expect(getByText("New Reason Code")).toBeTruthy();
  });
});
