import { StyleSheet } from "react-native";

import { FONTS, COLORS, FONTFAMILY, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    backgroundColor: COLORS.white,
    flexDirection: "row",
    paddingVertical: SIZES.padding,
    justifyContent: "space-between",
    paddingHorizontal: SIZES.radius,
    alignItems: "center",
    borderTopWidth: 1,
    borderColor: COLORS.gray2,
    position: "absolute",
    right: 0,
    bottom: hp(1),
    left: 0,
  },
  icon: {
    height: hp(2.6),
    width: hp(2.6),
  },
  title: {
    fontSize: FONTS.h2,
    color: COLORS.white,
    fontWeight: "700",
  },
  countTextContainer: {
    borderColor: COLORS.scienceBlue,
    paddingHorizontal: wp(3),
    paddingVertical: wp(0.5),
    borderRadius: wp(10),
    borderWidth: 1,
    marginRight: 8,

  },
  countText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_8,
  },
  countLabel: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_4,
  },
  tertiaryPressableContainer: {
    marginRight: wp(4),
    justifyContent: "center",
    alignItems: "center",
  },

  tertiaryPressableText: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_4,
  },

  countContainer: { flexDirection: "row", alignItems: "center", flex: 1 },

  btnWidth: {
    width: wp(28),
  },

  mainBtnText: { fontSize: FONTS.h1_5 },
});
