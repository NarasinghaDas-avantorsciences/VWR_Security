import React from "react";
import {
  View,
  StyleProp,
  ViewStyle,
  TouchableOpacity,
  TextStyle,
} from "react-native";
import { useSelector } from "react-redux";
import MainButton from "../MainButton";
import OutlinedButton from "../OutlinedButton";
import styles from "./styles";
import CustomText from "../CustomText";

interface FooterProps {
  count: string;
  label?: string;
  mainButtonDisabled?: boolean;
  secondaryButtonDisabled?: boolean;
  tertiaryryButtonDisabled?: boolean;
  mainbuttonTitle: string;
  secondaryButtonTitle?: string;
  tertiaryButtonTitle?: string;
  mainButtonStyle?: StyleProp<ViewStyle>;
  mainButtonTextStyle?: StyleProp<TextStyle>;
  mainContainerStyle?: StyleProp<ViewStyle>;
  outlinedBtnContainerStyle?: StyleProp<ViewStyle>;
  outlinedBtnTextStyle?: StyleProp<TextStyle>;
  tertiaryBtnContainerStyle?: StyleProp<ViewStyle>;
  tertiaryBtnTextStyle?: StyleProp<TextStyle>;
  countContainerStyle?: StyleProp<TextStyle>;
  onChangeSecondaryBtnPress?: () => void;
  onChangePrimaryBtnPress: () => void;
  onChangeTertiaryBtnPress?: () => void;
}

const Footer: React.FC<FooterProps> = ({
  mainbuttonTitle,
  count,
  label,
  mainButtonDisabled,
  secondaryButtonDisabled,
  tertiaryryButtonDisabled,
  secondaryButtonTitle = "",
  tertiaryButtonTitle = "",
  mainButtonStyle = {},
  mainButtonTextStyle = {},
  mainContainerStyle = {},
  outlinedBtnContainerStyle = {},
  outlinedBtnTextStyle = {},
  tertiaryBtnContainerStyle = {},
  tertiaryBtnTextStyle = {},
  countContainerStyle = {},
  onChangePrimaryBtnPress,
  onChangeSecondaryBtnPress,
  onChangeTertiaryBtnPress,
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);

  return (
    <View
      accessible={true}
      accessibilityLabel="footer_main_container"
      style={[styles.container, mainContainerStyle]}
    >
      <View
        accessible={true}
        accessibilityLabel="footer_labels_container"
        style={styles.countContainer}
      >
        <View style={[styles.countTextContainer, countContainerStyle]}>
          <CustomText
            accessibilityLabel="footer_count_value"
            allowFontScaling={false}
            style={styles.countText}
          >
            {count}
          </CustomText>
        </View>
        <CustomText allowFontScaling={false} style={styles.countLabel}>
          {label
            ? label
            : strings["ime.scanner.item.on.list"] ?? "Item(s) On List"}
        </CustomText>
      </View>
      {tertiaryButtonTitle !== "" && (
        <TouchableOpacity
          disabled={tertiaryryButtonDisabled}
          accessible={true}
          accessibilityLabel="tertiary_footer_button"
          style={[
            styles.tertiaryPressableContainer,
            tertiaryBtnContainerStyle,
            { opacity: !tertiaryryButtonDisabled ? 1 : 0.4 },
          ]}
          onPress={onChangeTertiaryBtnPress}
        >
          <CustomText
            accessibilityLabel="tertiary_footer_button_label"
            allowFontScaling={false}
            style={[styles.tertiaryPressableText, tertiaryBtnTextStyle]}
          >
            {tertiaryButtonTitle}
          </CustomText>
        </TouchableOpacity>
      )}
      {secondaryButtonTitle !== "" && (
        <OutlinedButton
          accessibilityLabel="footer_secondary_button"
          // title={secondaryButtonTitle}
          title={
            secondaryButtonTitle.length > 6
              ? secondaryButtonTitle.substring(0, 6) + "."
              : secondaryButtonTitle
          }
          onChangeBtnPress={onChangeSecondaryBtnPress}
          mainContainerStyle={[outlinedBtnContainerStyle]}
          mainTextStyle={[outlinedBtnTextStyle]}
          disabled={secondaryButtonDisabled}
        />
      )}

      <MainButton
        accessibilityLabel="footer_primary_button"
        title={mainbuttonTitle}
        buttonTextStyle={[styles.mainBtnText, mainButtonTextStyle]}
        buttonStyle={[styles.btnWidth, mainButtonStyle]}
        onChangeBtnPress={onChangePrimaryBtnPress}
        disabled={mainButtonDisabled}
      />
    </View>
  );
};
export default Footer;
