import React, { SetStateAction, useEffect, useState } from "react";
import {
  View,
  Image,
  TouchableOpacity,
  Platform,
  TextInput,
} from "react-native";
import { useSelector } from "react-redux";
import QtyController from "../QtyController";
import MainButton from "../MainButton";
import Header from "../Header";
import ConsumeDropdown from "../Consume/ConsumeDropDown";
import EmptyDivider from "../Common/EmptyDivider";
import { hp, wp } from "../../Utils/globalFunction";
import { COLORS } from "../../Utils/theme";
import { DefaultProductImage } from "../../Utils/images";
import styles from "./styles";
import CustomText from "../CustomText";

interface VWRProductModal {
  item: any;
  onPressAdd: (
    quantity: number,
    unitMeasureValue: string,
    uomCode: string,
    comment: string
  ) => void;
  productSheetRef: any;
  unitsOfMeasureArr: {}[];
  setUnitsOfMeasureArr: SetStateAction<any>;
}

const VWRProductModal: React.FC<VWRProductModal> = ({
  item,
  onPressAdd,
  productSheetRef,
  unitsOfMeasureArr,
  setUnitsOfMeasureArr,
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const { isPutAway } = useSelector((state: any) => state.userReducer);

  const [quantity, setQuantity] = useState(0);
  const [unitMeasureValue, setUnitMeasureValue] = useState(
    "Select Unit of Measure"
  );
  const [uomCode, setUomCode] = useState("");
  const [comment, setComment] = useState("");
  const [disabled, setDisabled] = useState(true);

  const onPressDropDownItem = (index: number) => {
    let newArray = [...unitsOfMeasureArr];
    newArray.map((element: any, idx) => {
      if (idx === index) {
        element.selected = true;
        setUnitMeasureValue(element.title);
        setUomCode(element.uomCode);
      } else {
        element.selected = false;
      }
    });

    setUnitsOfMeasureArr(newArray);
  };

  useEffect(() => {
    //DPIM 5350
    if (unitsOfMeasureArr?.length == 1) {
      onPressDropDownItem(0);
    }
    //-----------

    if (quantity !== 0 && unitMeasureValue !== "Select Unit of Measure")
      setDisabled(false);
    else setDisabled(true);
  }, [unitMeasureValue, quantity]);

  return (
    <>
      <Header
        title={
          item?.description.length > 20
            ? item?.description.slice(0, 19) + "..."
            : item?.description
        }
        titleStyle={styles.headerText}
        container={styles.headerContainer}
        onRightIconPress={() => productSheetRef.current?.close()}
        statusBar={true}
        statusBarContainerStyle={Platform.OS === "android" && { height: 0 }}
        statusBarColor={COLORS.white}
        iconLeft={false}
        iconRight={true}
        RightIcon={() => (
          <CustomText style={styles.closeBtn}>{strings["close"]}</CustomText>
        )}
      />
      <View style={styles.container}>
        <View style={styles.itemTop}>
          {item?.productThumbnailURL ? (
            <Image
              source={{
                uri: item.productThumbnailURL.replace("http://", "https://"),
              }}
              style={styles.itemImage}
            />
          ) : (
            <DefaultProductImage width={hp(9)} height={hp(9)} />
          )}
          <View style={styles.itemTopRight}>
            <CustomText style={styles.itemTitle}>
              {item?.description || ""}
            </CustomText>

            <CustomText style={styles.itemLabel}>
              {item?.unitOfMeasure}
            </CustomText>
          </View>
        </View>
        <View style={styles.itemBottom}>
          <View style={styles.itemBottomLeft}>
            <CustomText style={styles.labelStyle}>
              {strings["vendor"]}
            </CustomText>
            <CustomText style={styles.valueStyle}>
              {item?.supplierName || ""}
            </CustomText>
          </View>
          <EmptyDivider width={wp(2)} />
          <View style={styles.itemBottomRight}>
            <CustomText style={styles.labelStyle}>
              {strings["location"]}
            </CustomText>
            <CustomText style={styles.valueStyle}>
              {item?.location || ""}
            </CustomText>
          </View>
        </View>
        <View style={styles.commentContainer}>
          <CustomText
            allowFontScaling={false}
            style={[styles.title]}
            accessible={true}
            accessibilityLabel="vwr-comment"
          >
            {strings["comment"]}
          </CustomText>
          <View style={styles.inputMainStyle}>
            <TextInput
              value={comment}
              style={[styles.commentInput]}
              placeholder={
                strings["ime.scanner.enter.comment"] ?? "Enter comment"
              }
              placeholderTextColor={COLORS.gray4}
              accessible={true}
              accessibilityLabel="vwr-comment-input-component"
              onChangeText={(text) => setComment(text)}
            />
          </View>
        </View>

        <TouchableOpacity style={styles.unitContainer}>
          <CustomText style={styles.unitLabel}>
            {strings["unit.of.measure"]}
          </CustomText>
          <ConsumeDropdown
            type="uom"
            showTitle={false}
            title={
              strings["ime.scanner.select.uom"] ?? "Select Unit of Measure"
            }
            value={
              unitsOfMeasureArr?.length == 1
                ? unitsOfMeasureArr[0]?.title
                : unitMeasureValue
            }
            items={unitsOfMeasureArr}
            dropDownContainer={styles.unitButtonContainer}
            onPressItem={(index) => onPressDropDownItem(index)}
            showScanner={false}
            showInputScanner={false}
            allData={unitsOfMeasureArr}
          />
        </TouchableOpacity>
        <View style={styles.footer}>
          <QtyController
            inputStyle={styles.qtyContainer}
            onChange={(text: string) => setQuantity(parseInt(text))}
          />
          <MainButton
            disabled={disabled}
            title={strings["ime.add.to.order"] ?? "Add to Order"}
            onChangeBtnPress={() =>
              onPressAdd(quantity, unitMeasureValue, uomCode, comment)
            }
            buttonTextStyle={styles.buttonTextStyle}
            buttonStyle={disabled && styles.inactiveOpacity}
          />
        </View>
      </View>
    </>
  );
};

export default VWRProductModal;
