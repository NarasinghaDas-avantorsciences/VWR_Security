import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  container: {
    paddingHorizontal: wp(4),
  },

  headerContainer: {
    backgroundColor: COLORS.white,
    paddingVertical: 0,
  },

  headerText: {
    fontSize: FONTS.h2_3,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.scienceBlue,
    textAlign: "center",
  },

  closeBtn: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.scienceBlue,
    paddingLeft: wp(6),
    fontFamily: FONTFAMILY.averta_regular,
  },

  itemTop: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: hp(6),
  },
  itemImage: {
    width: hp(9),
    height: hp(9),
    resizeMode: "contain",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: COLORS.abbey,
  },
  itemTopRight: {
    marginLeft: wp(3),
    flex: 1,
  },
  itemTitle: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: hp(2.3),
  },
  itemLabel: {
    backgroundColor: COLORS.whiteSmoke,
    alignSelf: "flex-start",
    paddingHorizontal: wp(2),
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: hp(1.8),
    marginTop: hp(0.6),
  },
  itemBottom: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: hp(3),
  },
  itemBottomLeft: { flex: 1, height: hp(7) },
  itemBottomRight: { flex: 1, height: hp(7) },
  labelStyle: {
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: hp(1.9),
  },
  valueStyle: {
    fontFamily: FONTFAMILY.averta_regular,
    color: COLORS.abbey,
    fontSize: hp(1.9),
  },
  commentMain: {
    width: "100%",
    marginTop: hp(3),
  },
  commentInputMain: {
    borderWidth: 1,
    borderColor: COLORS.gray2,
    height: hp(4.5),
  },
  title: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_semibold,
    marginBottom: hp(1),
  },

  inputMainStyle: {
    height: hp(4),
    borderColor: COLORS.lightGray,
    borderWidth: 1,
    backgroundColor: COLORS.white,
    flexDirection: "row",
    alignItems: "center",
    paddingRight: wp(2),
    paddingHorizontal: wp(2),
  },

  commentContainer: {
    width: "100%",
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginTop: wp(5),
    marginBottom: wp(2),
  },

  commentInput: {
    height: hp(5),
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.abbey,
    fontFamily: FONTFAMILY.averta_regular,
    flex: 1,
    paddingHorizontal: wp(1),
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: hp(2),
  },
  buttonTextStyle: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: hp(2.1),
  },
  inactiveOpacity: {
    opacity: 0.5,
  },
  qtyContainer: {
    paddingVertical: hp(1),
    fontSize: hp(2),
  },
  unitContainer: {
    marginTop: hp(2),
  },
  unitLabel: {
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.abbey,
    fontSize: hp(1.9),
    marginBottom: hp(0.8),
  },
  unitButtonContainer: {
    flexDirection: "row",
    borderColor: COLORS.lightGray,
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: hp(1),
    paddingHorizontal: wp(3),
    width: wp(92),
  },
});

export default Styles;
