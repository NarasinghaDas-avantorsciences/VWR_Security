import React from "react";
import { View, TouchableOpacity } from "react-native";

import styles from "./styles";

type ListItemProps = {
  idLabel?: string;
  children?: React.ReactNode;
  leftIcon?: React.ReactNode;
  customStyles?: any;
  rightIcon?: React.ReactNode;
  headerContent?: React.ReactNode;
  onPress?: () => void;
  disabled?: boolean;
};

const ListItem: React.FC<ListItemProps> = ({
  children,
  customStyles,
  leftIcon,
  rightIcon,
  headerContent,
  onPress,
  disabled = false,
  idLabel = "",
}) => {
  return (
    <TouchableOpacity
      disabled={disabled}
      style={[customStyles?.container]}
      activeOpacity={0.8}
      onPress={onPress}
      accessible={true}
      accessibilityLabel={`${idLabel}-list-item-btn`}
    >
      <View
        style={[customStyles?.contentHeaderStyle, styles.contentHeaderStyle]}
        accessible={true}
        accessibilityLabel={`${idLabel}-list-item-btn-view-container`}
      >
        <View
          accessible={true}
          accessibilityLabel={`${idLabel}-list-item-left-icon`}
        >
          {leftIcon}
        </View>
        <View
          style={styles.headerContent}
          accessible={true}
          accessibilityLabel={`${idLabel}-list-item-header-content`}
        >
          {headerContent}
        </View>
        <View
          style={styles.rightIconStyle}
          accessible={true}
          accessibilityLabel={`${idLabel}-list-item-right-icon`}
        >
          {rightIcon}
        </View>
      </View>
      {children}
    </TouchableOpacity>
  );
};

export default ListItem;
