import { StyleSheet } from "react-native";

const Styles = StyleSheet.create({
  contentHeaderStyle: {
    flexDirection: "row",
  },

  headerContent: { flex: 4.5 },

  rightIconStyle: {
    flex: 0.5,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default Styles;
