import React, { useState } from "react";
import {
  View,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Platform,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import Header from "../Header";
import CustomText from "../CustomText";
import { Loader } from "../Loader";
import BottomSheetComponent from "../BottomSheet";
import VWRProductList from "../VWRProductList";
import { hp, removeEmojis } from "../../Utils/globalFunction";
import { COLORS } from "../../Utils/theme";
import { CloseBlack } from "../../Utils/images";
import {
  clearVwrSearchData,
  searchVwrProduct,
} from "../../Redux/Action/replenishAction";
import styles from "./styles";

type AddVwrProductProps = {
  refRBSheet_addVWR: any;
  productDetailsSheetRef: any;
  showToast?: any;
};

const AddVwrProduct: React.FC<AddVwrProductProps> = ({
  refRBSheet_addVWR,
  productDetailsSheetRef,
  showToast,
}) => {
  const dispatch = useDispatch<any>();
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const isProductsLoading = useSelector(
    (state: any) => state.replenishReducer?.isLoading
  );
  const [keyword, setKeyword] = useState("");
  const [catalogNo, setCatalogNo] = useState("");
  const [vendorCatalogNo, setvendorCatalogNo] = useState("");
  const [isSearched, setIsSearched] = useState(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(0);

  const clearInputs = () => {
    setKeyword("");
    setCatalogNo("");
    setvendorCatalogNo("");
    setIsSearched(false);
    setCurrentPage(0);
  };

  const fetchData = (offset: number) => {
    setIsLoading(true);
    setTimeout(async () => {
      await dispatch(
        searchVwrProduct(
          {
            catalogNo,
            vendorCatalogNo,
            keyword,
          },
          offset
        )
      );
      setIsLoading(false);
    }, 1000);
  };
  const handleScroll = (event: any) => {
    const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;
    // Check if the user has reached the end of the ScrollView
    if (
      layoutMeasurement.height + contentOffset.y >=
        contentSize.height - contentSize.height / 2 &&
      !isLoading
    ) {
      setCurrentPage(currentPage + 1);
      fetchData(currentPage + 1);
    }
  };

  return (
    <BottomSheetComponent
      customStyles={{ container: styles.bottomSheetContainerStyle }}
      height={hp(100)}
      bottomSheetRef={refRBSheet_addVWR}
      onOpen={() => clearInputs()}
    >
      <ScrollView
        overScrollMode="never"
        contentContainerStyle={styles.contentContainerStyle}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        accessible={true}
        accessibilityLabel="addVwr-scrollContainer"
        keyboardShouldPersistTaps="always"
      >
        <TouchableOpacity activeOpacity={1}>
          <Header
            title={strings["add.vwr.product"]}
            titleStyle={styles.headerText}
            container={styles.headerContainer}
            onRightIconPress={() => refRBSheet_addVWR.current?.close()}
            statusBar={true}
            statusBarColor={COLORS.white}
            statusBarContainerStyle={Platform.OS === "android" && { height: 0 }}
            iconLeft={false}
            iconRight={true}
            RightIcon={() => (
              <CustomText style={styles.closeBtn}>
                {strings["close"]}
              </CustomText>
            )}
          />

          <>
            <View
              style={styles.keywordContainer}
              accessible={true}
              accessibilityLabel="addVwr-catalog-container"
            >
              <CustomText
                style={styles.keywordLabel}
                accessibilityLabel="addVwr-catalog-label"
              >
                {strings["catalog.number"]}
              </CustomText>
              <View style={styles.keywordSubContainer}>
                <View style={styles.keywordInputContainer}>
                  <TextInput
                    allowFontScaling={false}
                    value={removeEmojis(catalogNo)}
                    onChangeText={setCatalogNo}
                    style={styles.keywordInput}
                    returnKeyType="search"
                    onSubmitEditing={async (e) => {
                      await dispatch(clearVwrSearchData());
                      setCurrentPage(0);
                      setIsSearched(true);
                      dispatch(
                        searchVwrProduct(
                          {
                            catalogNo,
                            vendorCatalogNo,
                            keyword,
                          },
                          0
                        )
                      );
                    }}
                  />
                  {catalogNo?.length > 0 ? (
                    <TouchableOpacity
                      onPress={() => {
                        setCatalogNo("");
                        setIsSearched(false);
                        setCurrentPage(0);
                      }}
                    >
                      <CloseBlack />
                    </TouchableOpacity>
                  ) : null}
                </View>
                {catalogNo?.length > 0 ? (
                  <TouchableOpacity
                    onPress={() => {
                      setCatalogNo("");
                      setIsSearched(false);
                      setCurrentPage(0);
                    }}
                  >
                    <CustomText style={styles.cancelKeywordText}>
                      {strings["cancel"]}
                    </CustomText>
                  </TouchableOpacity>
                ) : null}
              </View>
            </View>

            <View
              style={styles.keywordContainer}
              accessible={true}
              accessibilityLabel="addVwr-vendor-container"
            >
              <CustomText
                style={styles.keywordLabel}
                accessibilityLabel="addVwr-vendor-label"
              >
                {strings["vcn"]}
              </CustomText>
              <View style={styles.keywordSubContainer}>
                <View style={styles.keywordInputContainer}>
                  <TextInput
                    allowFontScaling={false}
                    value={removeEmojis(vendorCatalogNo)}
                    onChangeText={setvendorCatalogNo}
                    style={styles.keywordInput}
                    returnKeyType="search"
                    onSubmitEditing={async (e) => {
                      await dispatch(clearVwrSearchData());
                      setCurrentPage(0);
                      setIsSearched(true);
                      dispatch(
                        searchVwrProduct(
                          {
                            catalogNo,
                            vendorCatalogNo,
                            keyword,
                          },
                          0
                        )
                      );
                    }}
                  />
                  {vendorCatalogNo?.length > 0 ? (
                    <TouchableOpacity
                      onPress={() => {
                        setvendorCatalogNo("");
                        setIsSearched(false);
                        setCurrentPage(0);
                      }}
                    >
                      <CloseBlack />
                    </TouchableOpacity>
                  ) : null}
                </View>
                {vendorCatalogNo?.length > 0 ? (
                  <TouchableOpacity
                    onPress={() => {
                      setvendorCatalogNo("");
                      setIsSearched(false);
                      setCurrentPage(0);
                    }}
                  >
                    <CustomText style={styles.cancelKeywordText}>
                      {strings["cancel"]}
                    </CustomText>
                  </TouchableOpacity>
                ) : null}
              </View>
            </View>

            <View
              style={styles.keywordContainer}
              accessible={true}
              accessibilityLabel="addVwr-keyword-container"
            >
              <CustomText
                style={styles.keywordLabel}
                accessibilityLabel="addVwr-keyword-label"
              >
                {strings["keyword"]}
              </CustomText>
              <View style={styles.keywordSubContainer}>
                <View style={styles.keywordInputContainer}>
                  <TextInput
                    allowFontScaling={false}
                    value={removeEmojis(keyword)}
                    onChangeText={setKeyword}
                    style={styles.keywordInput}
                    returnKeyType="search"
                    onSubmitEditing={async (e) => {
                      await dispatch(clearVwrSearchData());
                      setCurrentPage(0);
                      setIsSearched(true);
                      dispatch(
                        searchVwrProduct(
                          {
                            catalogNo,
                            vendorCatalogNo,
                            keyword,
                          },
                          0
                        )
                      );
                    }}
                  />
                  {keyword?.length > 0 ? (
                    <TouchableOpacity
                      onPress={() => {
                        setKeyword("");
                        setIsSearched(false);
                        setCurrentPage(0);
                      }}
                    >
                      <CloseBlack />
                    </TouchableOpacity>
                  ) : null}
                </View>
                {keyword?.length > 0 ? (
                  <TouchableOpacity
                    onPress={() => {
                      setKeyword("");
                      setIsSearched(false);
                      setCurrentPage(0);
                    }}
                  >
                    <CustomText style={styles.cancelKeywordText}>
                      {strings["cancel"]}
                    </CustomText>
                  </TouchableOpacity>
                ) : null}
              </View>
            </View>
            {isSearched && (
              <VWRProductList
                keyword={keyword || catalogNo || vendorCatalogNo}
                productDetailsSheetRef={productDetailsSheetRef}
                clearInput={() => refRBSheet_addVWR.current?.close()}
                showToast={(isShow: boolean, data: any) => {
                  showToast(isShow, data);
                }}
              />
            )}
          </>
        </TouchableOpacity>
      </ScrollView>
      <Loader show={isProductsLoading} />
    </BottomSheetComponent>
  );
};

export default AddVwrProduct;
