import { StyleSheet } from "react-native";
import { FONTS, COLORS, FONTFAMILY } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

export default StyleSheet.create({
  bottomSheetContainerStyle: {
    borderTopLeftRadius: 1,
    borderTopRightRadius: 1,
  },

  contentContainerStyle: {
    flexGrow: 1,
    paddingBottom: hp(6),
  },

  headerContainer: {
    marginTop: hp(2),
    backgroundColor: COLORS.white,
    paddingVertical: 0,
  },

  headerText: {
    fontSize: FONTS.h2_3,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.scienceBlue,
    textAlign: "center",
  },

  closeBtn: {
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.scienceBlue,
    paddingLeft: wp(6),
    fontFamily: FONTFAMILY.averta_regular,
  },

  mainStyle: {
    width: wp(90),
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginTop: wp(5),
  },

  keywordContainer: {
    marginTop: hp(2),
    paddingHorizontal: wp(5),
  },

  keywordLabel: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_semibold,
    marginBottom: hp(1),
  },

  keywordSubContainer: {
    flexDirection: "row",
    alignItems: "center",
  },

  cancelKeywordText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_regular,
    marginLeft: wp(2),
    fontSize: hp(1.8),
  },

  keywordInputContainer: {
    flex: 1,
    flexDirection: "row",
    borderWidth: 1,
    borderColor: COLORS.gray2,
    alignItems: "center",
    paddingRight: wp(3),
  },

  keywordInput: {
    flex: 1,
    paddingHorizontal: wp(3),
    paddingVertical: hp(1),
    height: hp(5),
    color: COLORS.abbey,
  },
});
