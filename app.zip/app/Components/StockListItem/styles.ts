import { StyleSheet } from "react-native";
import { FONTS, COLORS, SIZES, FONTFAMILY } from "../../Utils/theme";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { isDeviceTablet } from "../../Utils/globalFunction";

export default StyleSheet.create({
  container: {
    paddingTop: SIZES.padding,
    paddingBottom: SIZES.radius,
    borderBottomColor: COLORS.whiteSmoke,
    marginHorizontal: SIZES.padding,
  },
  iconContainer: {
    justifyContent: "center",
    height: hp(6.5),
    width: wp(6.5),
    alignItems: "center",
  },
  rowContainer: { flexDirection: "row", alignItems: "flex-start" },
  image: {
    height: SIZES.width * 0.2,
    width: SIZES.width * 0.2,
    borderWidth: 1,
    borderColor: COLORS.gray2,
  },
  idText: {
    ...FONTS.body2,
    color: COLORS.gray,
    marginBottom: SIZES.base,
  },
  titleText: {
    ...FONTS.title,
    color: COLORS.scienceBlue,
    marginBottom: SIZES.base,
  },
  caseText: {
    ...FONTS.title2,
    color: COLORS.gray,
    marginBottom: SIZES.base,
    backgroundColor: COLORS.whiteSmoke,
    alignSelf: "flex-start",
  },
  itemText: {
    ...FONTS.title2,
    color: COLORS.gray,
    marginBottom: SIZES.tip,
    textTransform: "capitalize",
  },
  valueText: { ...FONTS.body, color: COLORS.gray },
  addBatchContainerStyle: {
    paddingBottom: 0,
  },
  reasonContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    marginTop: SIZES.base,
  },
  center: { alignItems: "center" },
  controllerInputStyle: {
    ...FONTS.body,
    paddingVertical: SIZES.base,
    paddingHorizontal: SIZES.tip,
  },
  commentMain: {
    width: "100%",
  },
  inputStyle: {
    width: "100%",
    paddingLeft: 0,
  },
  commentContainer: {
    width: "100%",
    marginTop: hp(2),
  },
  locationMain: {
    width: "50%",
    marginTop: hp(2),
  },
  batchAvailableQuantityContainer: {
    ...FONTS.body,
    paddingVertical: SIZES.base,
    paddingHorizontal: SIZES.tip,
    borderWidth: 1,
    marginHorizontal: wp(1),
    minWidth: isDeviceTablet() ? 60 : 40,
    maxWidth: isDeviceTablet() ? 80 : 60,
    marginVertical: 10,
    height: isDeviceTablet() ? 55 : 35,
    textAlign: "center",
    fontFamily: FONTFAMILY.averta_semibold,
    fontSize: FONTS.h1_5,
    borderColor: COLORS.gray4,
    color: COLORS.gray4,
  },
  // ListItem
  leftIconContainer: { marginRight: wp(4) },
  leftIcon: { width: wp(18), height: wp(18) },
  productDetailsImageStyle: { height: wp(20), width: wp(20) },
  catalogNumber: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_regular,
  },
  itemHeaderContent: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    paddingTop: hp(0.2),
  },
  qtyInfoContainer: { paddingVertical: hp(0.8) },
  itemSubHeaderStyle: {
    alignSelf: "flex-start",
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_bold,
    backgroundColor: COLORS.whiteSmoke,
    paddingHorizontal: wp(1),
    borderRadius: hp(1),
  },

  flexRowContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  itemChildContainer: {
    width: SIZES.width * 0.4,
    marginVertical: wp(0.5),
    paddingTop: SIZES.radius,
  },

  itemChildTitleText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_4,
    fontFamily: FONTFAMILY.averta_semibold,
  },

  itemChildValueText: {
    color: COLORS.abbey,
    fontSize: FONTS.h2_1,
    fontFamily: FONTFAMILY.averta_regular,
  },
  labelContainer: { flexDirection: "row", alignItems: "center" },
  label: {
    backgroundColor: COLORS.abbey,
    fontSize: FONTS.h1_1,
    paddingHorizontal: wp(2),
    paddingVertical: hp(0.8),
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.white,
  },
  labelSubContainer: {
    borderRadius: 200,
    marginEnd: wp(2),
    overflow: "hidden",
  },
});
