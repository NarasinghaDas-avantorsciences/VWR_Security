import React, { useCallback, useEffect, useState } from "react";
import {
  Image,
  View,
  StyleProp,
  ViewStyle,
  Pressable,
  TouchableOpacity,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { useFocusEffect } from "@react-navigation/native";
import { setProductLoader } from "../../Redux/Action/searchAction";
import styles from "./styles";
import { SIZES } from "../../Utils/theme";
import {
  checkifBatchEnabled,
  checkifExpiryEnabled,
  getMultiplier,
  hp,
  wp,
} from "../../Utils/globalFunction";
import { BlueMinus, BluePlus, DefaultProductImage } from "../../Utils/images";
import ReasonCode from "../ReasonCode";
import QtyController from "../QtyController";
import TextInputComponent from "../TextInput";
import ListItem from "../ListItem";
import AddBatch from "../AddBatch";
import CustomText from "../CustomText";

type Props = {
  item: any;
  id?: string;
  from?: string;
  reasonCodeType: string;
  handleOnSelect?: any;
  show?: boolean;
  freeze?: boolean;
  required?: boolean;
  location?: Boolean;
  comment?: Boolean;
  commentText?: string;
  bottomBorder?: Boolean;
  rightIcon?: any;
  containerStyle?: StyleProp<ViewStyle>;
  handleAvailQty?: any;
  showBatch?: boolean;
  showToast?: Function;
  handleReasonCode?: Function;
  handleBatch?: Function;
  handleBatchDelete?: any;
  updateCheckbox?: any;
  handleCommentBox?: any;
  disableListPress?: boolean;
  fromOffline?: boolean;
};

const StockListItem: React.FC<Props> = ({
  item,
  id,
  reasonCodeType,
  from,
  handleOnSelect,
  show = false,
  freeze = false,
  required = false,
  location = false,
  comment = false,
  commentText = "",
  bottomBorder = true,
  rightIcon = null,
  containerStyle,
  showBatch,
  showToast,
  handleReasonCode,
  handleAvailQty,
  handleBatch,
  handleBatchDelete,
  updateCheckbox,
  handleCommentBox,
  disableListPress = false,
  fromOffline = false,
}) => {
  const dispatch = useDispatch<any>();
  const [formatedData, setFormatedData] = useState<any>([]);
  const [qty, setQty] = useState(
    item?.actualQty
      ? `${item?.actualQty}`
      : item?.selectedQty
      ? `${item?.selectedQty}`
      : ""
  );
  const [variationQty, setVariationQty] = useState<any>();
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const { stockRoomDetail } = useSelector((state: any) => state.userReducer);

  useFocusEffect(
    useCallback(() => {
      if (item?.actualQty == undefined || item?.actualQty == null) {
        setVariationQty("");
      } else {
        if (qty.length == 0) {
          setVariationQty("");
        } else {
          setVariationQty(Number(qty) - item?.availableQty);
          setVariationQty(Number(qty) - item?.availableQty);
          setVariationQty(Number(qty) - item?.availableQty);
        }
      }
    }, [item?.actualQty])
  );
  useEffect(() => {
    fromOffline && setQty(item.actualQty);
  }, []);
  let newBatch = item?.batches ?? item?.new_batches;
  return (
    <View
      testID="stockListitem"
      accessibilityLabel="stockListitem"
      style={[
        styles.container,
        bottomBorder && { borderBottomWidth: bottomBorder ? 1 : 0 },
        containerStyle,
      ]}
    >
      <ListItem
        disabled={disableListPress}
        key={id}
        leftIcon={
          <View
            style={[
              styles.leftIconContainer,
              {
                marginTop:
                  show &&
                  (item?.expiryDateManagementenabled != 0 ||
                    item?.batchManagementEnabled != 0)
                    ? hp(2.5)
                    : 0,
              },
            ]}
          >
            {item?.imageURL ? (
              <Image
                source={{
                  uri: item?.imageURL.replace("http://", "https://"),
                }}
                style={styles.leftIcon}
                resizeMode={"contain"}
              />
            ) : (
              <DefaultProductImage width={wp(18)} height={wp(18)} />
            )}
          </View>
        }
        headerContent={
          <View>
            <CustomText style={styles.catalogNumber}>
              {item?.catalogNo}
            </CustomText>
            {((from ?? "") == "stockCorrection" ||
              (from ?? "") == "RepstockCorrection") &&
            !show ? (
              <CustomText style={styles.itemHeaderContent}>
                {item?.description}
              </CustomText>
            ) : (
              <TouchableOpacity
                disabled={from == "stockTransfer"}
                onPress={disableListPress ? handleOnSelect : null}
              >
                <CustomText style={styles.itemHeaderContent}>
                  {item?.description}
                </CustomText>
              </TouchableOpacity>
            )}

            <View style={styles.qtyInfoContainer}>
              <CustomText style={styles.itemSubHeaderStyle}>
                ({item?.uomId})
              </CustomText>
            </View>

            <View style={styles.labelContainer}>
              {stockRoomDetail?.isBatchManagementEnabled &&
                item?.batchManagementEnabled == 1 && (
                  <View style={styles.labelSubContainer}>
                    <CustomText style={styles.label}>
                      {strings["ime.batch.controlled"]}
                    </CustomText>
                  </View>
                )}
              {stockRoomDetail?.isExpiryManagementEnabled &&
                item?.expiryDateManagementenabled == 1 && (
                  <View style={styles.labelSubContainer}>
                    <CustomText style={styles.label}>
                      {strings["ime.expiry.date.controlled"]}
                    </CustomText>
                  </View>
                )}
            </View>
          </View>
        }
        onPress={() => (!disableListPress ? handleOnSelect() : {})}
        rightIcon={rightIcon}
      >
        <View style={styles.flexRowContainer}>
          <View style={[styles.itemChildContainer]}>
            <CustomText style={styles.itemChildTitleText}>
              {strings["ime.avail.qty"]}
            </CustomText>
            <CustomText style={styles.itemChildValueText}>
              {/* {item?.availableQty}  */}
              {`${item?.availableQty + " "}${
                getMultiplier(item) == null ? " " : getMultiplier(item)
              }`}
              {"  "}({item?.uomId})
            </CustomText>
          </View>
          <View style={[styles.itemChildContainer]}>
            <CustomText style={styles.itemChildTitleText}>
              {strings["vendor"]}
            </CustomText>
            <CustomText style={styles.itemChildValueText}>
              {item?.vendorName}
            </CustomText>
          </View>
        </View>
        {location && (
          <View style={styles.locationMain}>
            <CustomText style={styles.itemText}>
              {strings["location"]}
            </CustomText>
            <CustomText style={styles.valueText}>
              {item?.locationName ? item?.locationName : "Main Stockroom"}
            </CustomText>
          </View>
        )}
        {comment && (
          <View style={styles.commentContainer}>
            <CustomText style={styles.itemText}>
              {strings["ime.comment"]}
            </CustomText>
            <TextInputComponent
              title={""}
              editable={true}
              main={styles.commentMain}
              value={commentText}
              inputStyle={styles.inputStyle}
              required={false}
              placeholder={
                strings["ime.scanner.enter.comment"] ?? "Enter comment"
              }
              onChangeText={(e) => {
                handleCommentBox(e);
              }}
            />
          </View>
        )}
        {show && (
          <>
            <ReasonCode
              containerStyle={{
                marginTop: SIZES.radius,
              }}
              reasonCodeType={reasonCodeType}
              from={from}
              item={item}
              handleReasonCode={handleReasonCode}
              disabled={freeze}
              required={required}
              showToast={showToast}
            />
            <View style={styles.reasonContainer}>
              <View style={styles.center}>
                <CustomText
                  style={[styles.itemText, { marginBottom: SIZES.padding }]}
                >
                  {strings["ime.scanner.pre.qty"] ?? "Pre Qty"}
                </CustomText>
                <CustomText style={styles.valueText}>
                  {item?.availableQty}
                </CustomText>
              </View>

              <View style={[styles.center, { paddingTop: SIZES.padding }]}>
                <CustomText style={styles.itemText}>
                  {strings["ime.actual.qty"]}
                </CustomText>

                {showBatch ? (
                  <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <View style={styles.iconContainer}>
                      <BlueMinus opacity={0.5} />
                    </View>

                    <CustomText style={styles.batchAvailableQuantityContainer}>
                      {item?.actualQty ?? ""}{" "}
                      {/* 'qty' returns zero during intialisation */}
                    </CustomText>
                    <View style={styles.iconContainer}>
                      <BluePlus opacity={0.5} />
                    </View>
                  </View>
                ) : (
                  <QtyController
                    onChange={(val: React.SetStateAction<string>) => {
                      setQty(val);
                      item["actualQty"] = val;
                      handleAvailQty(val, item?.id);
                      from !== "addToList" && updateCheckbox(val);
                    }}
                    from={"stock.correction"}
                    showLabel={false}
                    inputStyle={styles.controllerInputStyle}
                    inputValue={qty}
                    disable={
                      freeze ||
                      checkifBatchEnabled(item, stockRoomDetail) ||
                      checkifExpiryEnabled(item, stockRoomDetail)
                    }
                  />
                )}
              </View>

              <View style={styles.center}>
                <CustomText
                  style={[styles.itemText, { marginBottom: SIZES.padding }]}
                >
                  {strings["variation"]}
                </CustomText>
                <CustomText style={styles.valueText}>
                  {variationQty ?? ""}
                </CustomText>
              </View>
            </View>

            {showBatch && (
              <AddBatch
                from={"stock.correction"}
                item={item}
                onChange={handleBatch}
                onDelete={handleBatchDelete}
                freeze={freeze}
                updateActualQty={(val: any) => {
                  setQty(val);
                  item["actualQty"] = val;
                  handleAvailQty(val, item?.id);
                  from !== "addToList" && updateCheckbox(val);
                }}
                formatedData={formatedData}
                setFormatedData={(res: any) => {
                  setFormatedData(res);
                }}
                setLoader={(val: boolean) => dispatch(setProductLoader(val))}
                data={newBatch?.map((i: any) => {
                  const { batchNo, actualQty, availableQty, id, expiryDate } =
                    i;
                  return {
                    batchNo,
                    actualQty,
                    availableQty,
                    id,
                    expiryDate,
                  };
                })}
                setVariationQty={(val: any) => setQty(val)}
                addBatchContainerStyle={styles.addBatchContainerStyle}
              />
            )}
          </>
        )}
      </ListItem>
    </View>
  );
};

export default StockListItem;
