import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  View,
  Platform,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import BottomSheetComponent from "../BottomSheet";
import Header from "../Header";
import CustomText from "../CustomText";
import { hp } from "../../Utils/globalFunction";
import { COLORS, SIZES } from "../../Utils/theme";
import { editConfirmationAndNote } from "../../Redux/Action/receiveAction";
import { Loader } from "../Loader";
import styles from "./styles";
import MainButton from "../MainButton";
import Toast from "react-native-toast-message";
import { ModalToast } from "../ModalToast";

interface EditProductProps {
  btmSheetRef: any;
  onClose: () => void;
  orderDetails: any;
  title: string;
  deliveryNote: string;
  setNotes: any;
  onSuccesfullyAddedNotes: any,
  itemID:any,
}

const EditProduct: React.FC<EditProductProps> = ({
  btmSheetRef,
  onClose,
  orderDetails,
  title,
  deliveryNote,
  setNotes,
  onSuccesfullyAddedNotes,
  itemID,
}) => {
  const [isShowToastRef, setIsShowToast] = useState(false);
  const [errorToastText, setErrorToastText] = useState("");
  const [errorToastTitle, setErrorToastTitle] = useState("");
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const getConfirmationText = (titleData: string) => {
    let titleParts = titleData.split(" - ").map((titlePart) => titlePart);
    if (titleParts.length > 1) {
      titleParts = titleParts.slice(0, -1); //remove last part
      return titleParts.join('');
    } else {
      return "";
    }
  };

  const dispatch = useDispatch<any>();
  const [confirmationText, setConfirmationText] = useState<any>(
    getConfirmationText(title)
  );
  const ref_to_input2 = useRef<any>();
  const { isLoading } = useSelector((state: any) => state.receiveReducer);
  const strings = useSelector((state: any) => state.languageReducer?.data);

  const mappedReceiveDetailsArr = () => {
    return orderDetails?.allOrderDetails.map((item: any) => {
      if (item.expiryDtFormat)
        return {
          productId: item.product?.id,
          replenishDetailId: item.id,
          expiryDt: item.expiryDt ?? item.expiryDtFormat ?? "",
          expectDeliveryDt: item.expectDeliveryDtFormat ?? "",
        };
    });
  };
  const saveButtonPressed = () => {
    setErrorToastTitle('')
    setErrorToastText("");
    let editParams = {
      text: confirmationText,
      note: deliveryNote,
    };
    handleSubmitEdit(editParams);
  };
  const handleSubmitEdit = (editParams: { text: string; note: string }) => {
    let apiParams = {
      vwrOrderNumber: editParams.text,
      deliveryNoteId:
        orderDetails?.userDeliveryNotes == null
          ? 0
          : orderDetails?.userDeliveryNotes?.id,
      deliveryNoteTxt: editParams.note ?? '',
      isOrderNumUpdate: true,
      receiveDetails: (orderDetails?.allOrderDetails != null) ? mappedReceiveDetailsArr() : [],
    };
    dispatch(
      editConfirmationAndNote(
        apiParams,
        orderDetails?.orderId ?? itemID,
        (res) => {
          if (res.status == 200) {
            let isOrdrNmbExist = (Strings["order.number.already.exists"] ?? "Order Number already exists") == res?.data?.status

            if (!isOrdrNmbExist) {
              setErrorToastTitle(Strings["success"])
              //Successfully updated the User Delivery Notes
              let msg = (res?.data?.status == null) ? 'Sucessfully added delivery note' : res?.data?.status
              setErrorToastText(msg);
              setIsShowToast(true);
              setTimeout(() => {
                setErrorToastTitle('')
                setErrorToastText("");
                setIsShowToast(false);
                btmSheetRef?.current?.close()
                onSuccesfullyAddedNotes()
              }, 2000);

            } else {
              setErrorToastTitle(Strings["ime.attention"])
              setErrorToastText(res?.data?.status);
              setIsShowToast(true);
              setTimeout(() => {
                setErrorToastTitle('')
                setErrorToastText("");
                setIsShowToast(false);
              }, 2000);
            }

          }
        },
        (error: any) => {
          setErrorToastTitle('')
          setErrorToastText(error?.errorMessage ?? error?.status ?? "Error");
          setIsShowToast(true);
          setTimeout(() => {
            setErrorToastTitle('')
            setErrorToastText("");
            setIsShowToast(false);
          }, 2000);
        }
      )
    );
  };

  return (
    <BottomSheetComponent
      customStyles={{
        container: {
          ...styles.btmSheetContainer,
        },
      }}
      height={hp(100)}
      bottomSheetRef={btmSheetRef}
      closeOnPressMask={true}
    >
      <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
        <View style={styles.contentContainer}>
          <Header
            title={title.length > 30 ? title.slice(0, 27) + "..." : title}
            titleStyle={styles.stockTitle}
            container={styles.headerContainer}
            onRightIconPress={() => {
              // setNotes("");
              onClose();
              setConfirmationText(getConfirmationText(title));
            }}
            statusBar={true}
            statusBarColor={COLORS.white}
            iconLeft={false}
            iconRight={true}
            RightIcon={() => (
              <CustomText style={styles.rightIcon}>
                {strings["close"]}
              </CustomText>
            )}
            statusBarContainerStyle={Platform.OS === "android" && { height: 0 }}
          />

          <View style={styles.orgTxtContainerStyle}>
            <CustomText
              allowFontScaling={false}
              style={[styles.title]}
              accessible={true}
              accessibilityLabel="text-input-title-text"
            >
              {strings["ime.scanner.confirm.no"] ?? "Confirmation Number"}
            </CustomText>
            <View style={styles.inputMainStyle}>
              <TextInput
                value={confirmationText ?? getConfirmationText(title)}
                allowFontScaling={false}
                style={[styles.inputStyle]}
                placeholderTextColor={COLORS.gray4}
                accessible={true}
                accessibilityLabel="main-text-input-component"
                returnKeyType="next"
                onChangeText={(text) => setConfirmationText(text)}
                underlineColorAndroid="transparent"
                onSubmitEditing={() => ref_to_input2?.current?.focus()}
              />
            </View>
          </View>

          <View style={styles.subContainer}>
            <CustomText style={styles.subText}>
              {strings["ime.scanner.order.no.msg"] ??
                "This will append to the Inventory Manager order number."}
            </CustomText>
          </View>
          {(orderDetails?.allOrderDetails != null) &&
          <>
            <View style={styles.orgTxtContainerStyle}>
              <CustomText
                allowFontScaling={false}
                style={[styles.title]}
                accessible={true}
                accessibilityLabel="text-input-title-text"
              >
                {strings["ime.scanner.notes"] ?? "Notes"}
              </CustomText>
              <View style={styles.inputMainStyle}>
                <TextInput
                  ref={ref_to_input2}
                  value={deliveryNote}
                  allowFontScaling={false}
                  style={[styles.inputStyle]}
                  placeholderTextColor={COLORS.gray4}
                  accessible={true}
                  accessibilityLabel="main-text-input-component"
                  onChangeText={(text) => setNotes(text)}
                  underlineColorAndroid="transparent"
                  returnKeyType="done"
                  returnKeyLabel="Save"
                  onSubmitEditing={(e) => {
                    let editParams = {
                      text: confirmationText,
                      note: e.nativeEvent.text,
                    };
                    handleSubmitEdit(editParams);
                  }}
                />
              </View>
            </View>
            <View style={styles.subContainer}>
            <CustomText style={styles.subText}>
              {strings["ime.scanner.general.notes.msg"] ??
                "Enter general notes for your order."}
            </CustomText>
          </View>
          </>
          }


          
          <MainButton
            accessibilityLabel="receive_edit_deliveryNote_save_button"
            title={Strings["save"] ?? "Save"}
            buttonStyle={styles.buttonStyle}
            onChangeBtnPress={() => saveButtonPressed()}
          />
        </View>
      </TouchableWithoutFeedback>
      {/* Toast */}
      <ModalToast
        isShow={isShowToastRef}
        onClose={() => setIsShowToast(false)}
        title={errorToastTitle}
        discription={errorToastText}
      />
      <Loader show={isLoading} />
    </BottomSheetComponent>
  );
};

export default EditProduct;
