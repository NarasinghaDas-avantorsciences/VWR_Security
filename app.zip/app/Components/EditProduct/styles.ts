import { StyleSheet } from "react-native";

import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";
import { wp, hp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  btmSheetContainer: {
    borderTopLeftRadius: wp(3),
    borderTopRightRadius: wp(3),
  },

  contentContainer: {
    flex: 1,
  },

  stockTitle: {
    color: COLORS.scienceBlue,
    fontSize: FONTS.h2,
    fontFamily: FONTFAMILY.averta_bold,
    textAlign: "center",
  },

  headerContainer: {
    backgroundColor: COLORS.white,
    paddingVertical: 0,
  },

  rightIcon: {
    fontSize: FONTS.h2,
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_regular,
  },

  subContainer: {
    width: wp(90),
    alignSelf: "center",
  },

  orgTxtContainerStyle: {
    width: wp(90),
    alignSelf: "center",
    backgroundColor: COLORS.white,
    marginTop: wp(5),
    marginBottom: wp(2),
  },
  buttonStyle: {
    alignSelf: "center",
    width: wp(90),
    marginBottom: wp(4),
    borderRadius: 4,
    marginTop: hp(2),
  },
  inputStyle: {
    height: hp(4),
    padding: 0,
    fontSize: FONTS.h2,
    color: COLORS.abbey,
    left: -wp(2),
    marginRight: wp(4),
    fontFamily: FONTFAMILY.averta_regular,
    flex: 1,
    paddingHorizontal: wp(1),
  },

  inputMainStyle: {
    height: hp(5),
    borderColor: COLORS.abbey,
    borderWidth: 1,
    width: "100%",
    alignSelf: "center",
    backgroundColor: COLORS.white,
    flexDirection: "row",
    alignItems: "center",
    paddingRight: wp(2),
    paddingLeft: wp(2),
    paddingHorizontal: wp(2),
  },

  subText: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_5,
    fontFamily: FONTFAMILY.averta_regular,
  },

  title: {
    color: COLORS.abbey,
    fontSize: FONTS.h1_6,
    fontFamily: FONTFAMILY.averta_semibold,
    marginBottom: hp(1),
  },
});

export default Styles;
