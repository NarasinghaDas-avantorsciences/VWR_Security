import { Dimensions, StyleSheet } from "react-native";
import { COLORS, FONTFAMILY, FONTS, SIZES } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const WIDTH = Dimensions.get("screen").width;

export default StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  notificationIndicator: {
    position: "absolute",
    backgroundColor: COLORS.green,
    borderWidth: 2,
    borderColor: COLORS.scienceBlue,
    left:hp(2.7),
    top: hp(1.5),
  },
  modalStyle: {
    width: "100%",
    height: "100%",
    padding: 0,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
  },

  main: {
    width: "100%",
  },

  container: {
    backgroundColor: COLORS.scienceBlue,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  menuTipContent: {
    width: wp(75),
  },

  iconLeft: {
    zIndex: 999,
    margin: hp(0.5),
    backgroundColor: COLORS.scienceBlue,
    height: hp(5),
    width: hp(5),
    justifyContent: "center",
    alignItems: "center",
  },

  iconRight: {
    flexDirection:'row',
    zIndex: 999,
    margin: hp(0.5),
    backgroundColor: COLORS.scienceBlue,
    height: hp(5),
    width: hp(5),
    justifyContent: "center",
    alignItems: "center",
  },

  title: {
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h2,
    color: COLORS.white,
  },

  rowContainer: {
    flexDirection: "row",
    backgroundColor: COLORS.white,
    height: hp(5),
    justifyContent: "center",
    paddingHorizontal: wp(2),
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray2,
    overflow: "hidden",
  },

  contentContainer: { flexGrow: 1 },

  titleContainer: {
    width: SIZES.width * 0.225,
    flexDirection: "column",
    justifyContent: "center",
  },

  titleText: {
    fontSize: FONTS.h1_1,
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.doveGray,
    textTransform: "uppercase",
  },

  valueContainer: {
    flex: SIZES.width * 0.75,
    flexDirection: "column",
    justifyContent: "center",
  },

  valueText: {
    fontSize: FONTS.h1_2,
    fontFamily: FONTFAMILY.averta_bold,
    color: COLORS.abbey,
  },

  spacer: { width: wp(22) },

  buttonContainer: {
    position: "absolute",
    justifyContent: "center",
    alignItems: "center",
    right: 0,
    top: 8,
    backgroundColor: "white",
  },

  changeTipContent: {
    width: wp(92),
    height: hp(14),
    left: wp(-2),
  },

  pressableContainerView: {
    backgroundColor: COLORS.white,
    height: hp(4.4),
    width: wp(20),
    justifyContent: "center",
    alignItems: "center",
    bottom: hp(0.6),
    paddingRight: 2,
  },

  pressableContainer: {
    borderWidth: 1,
    borderColor: COLORS.scienceBlue,
    backgroundColor: COLORS.white,
    height: hp(3),
    width: wp(16),
    justifyContent: "center",
    alignItems: "center",
  },

  pressableText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_bold,
    fontSize: FONTS.h1_2,
  },

  searchViewWrapper: { width: WIDTH },

  flatlist: {
    paddingVertical: hp(1),
  },

  kpiContainer: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "center",
    marginBottom: hp(2),
  },

  footerContainer: {
    paddingVertical: hp(2),
  },
});
