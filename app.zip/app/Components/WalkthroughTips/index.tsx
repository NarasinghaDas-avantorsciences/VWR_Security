import React, { useEffect, useState } from "react";
import {
  View,
  FlatList,
  TouchableOpacity,
  Pressable,
  ScrollView,
  Platform,
} from "react-native";
import { useSelector } from "react-redux";
import {
  SearchBar,
  AlertModal,
  MyStatusBar,
  InfoTooltip,
} from "../../Components";
import KPIBlock from "../../Components/Dashboard/KPIBlock";
import EmptyDivider from "../../Components/Common/EmptyDivider";
import DashboardItemCard from "../../Components/Dashboard/DashboardItemCard";
import { hp, isDeviceTablet, wp } from "../../Utils/globalFunction";

import {
  AccountIcon,
  ApprovalIcon,
  ConsumeIcon,
  HelpIcon,
  PiCountIcon,
  ReceiveIcon,
  RedWarning,
  ReplenishIcon,
  StockCorrectionIcon,
  StockTransferIcon,
  YellowWarning,
  Menu,
  Bell,
} from "../../Utils/images";
import { COLORS } from "../../Utils/theme";
import styles from "./styles";
import CustomText from "../CustomText";
import { checkUserPrivileges } from "../../Utils/globalFunction";
interface WalkthroughTipsProps {
  onFinish: () => void;
}

const WalkthroughTips: React.FC<WalkthroughTipsProps> = ({ onFinish }) => {
  const Strings = useSelector((state: any) => state.languageReducer?.data);
  const { selectedTitle, selectedSubTitle } = useSelector(
    (state: any) => state.userReducer
  );
  const { notificationCount, messagesCount, newsCount } = useSelector(
    (state: any) => state.communicationReducer
  );
  const { approvalCount } = useSelector((state: any) => state.approvalsReducer);
  const [search, setSearch] = useState("");
  const [showMenuTip, setShowMenuTip] = useState(false);
  const [showBellTip, setBellTip] = useState(false);
  const [showChangeTip, setChangeTip] = useState(false);
  const [showSearchTip, setSearchTip] = useState(false);
  const [showKpiTip, setKpiTip] = useState(false);
  const { userPrivilege } = useSelector((state: any) => state.userReducer);

  useEffect(() => {
    setTimeout(() => {
      setShowMenuTip(true);
      console.log("userPrivilege", userPrivilege);
    }, 400);
  }, []);
  const CardsDataFilter = () => {
    let data: any = [];
    checkUserPrivileges(userPrivilege, "consume.scanner") &&
      data.push({
        title: Strings["consume"],
        icon: ConsumeIcon,
      });
    checkUserPrivileges(userPrivilege, "replenish.scanner") &&
      data.push({
        title: Strings["replenish"],
        icon: ReplenishIcon,
      });
    checkUserPrivileges(userPrivilege, "receive.scanner") &&
      data.push({
        title: Strings["receive"],
        icon: ReceiveIcon,
      });
    checkUserPrivileges(userPrivilege, "stock.correction(scanner)") &&
      data.push({
        title: Strings["stock_correction"],
        icon: StockCorrectionIcon,
      });
    checkUserPrivileges(userPrivilege, "show.scanner.PI.Count") &&
      data.push({
        title: Strings["pi.count"],
        icon: PiCountIcon,
      });
    if (
      checkUserPrivileges(userPrivilege, "approval.scanner") &&
      approvalCount > 0
    ) {
      data.push({
        title: Strings["ime.scanner.approvals"] ?? "Approvals",
        icon: ApprovalIcon,
      });
    }
    checkUserPrivileges(userPrivilege, "stock.transfer.scanner") &&
      data.push({
        title: Strings["stock.transfer.scanner"] ?? "Stock Transfer",
        icon: StockTransferIcon,
      });
    return [...data, ...CardsData];
  };
  const CardsData = [
    {
      title: Strings["ime.account"],
      icon: AccountIcon,
    },
    {
      title: Strings["help"],
      icon: HelpIcon,
    },
  ];

  const renderHeader = () => (
    <View
      accessible={true}
      accessibilityLabel="header_container"
      style={styles.main}
    >
      <MyStatusBar
        backgroundColor={COLORS.scienceBlue}
        containerStyle={Platform.OS === "android" && { height: 0 }}
      />
      {Platform.OS === "ios" && (
        <View
          accessible={true}
          accessibilityLabel="top_space_view_ios"
          style={{ backgroundColor: COLORS.scienceBlue, height: hp(2.8) }}
        ></View>
      )}
      <View
        accessible={true}
        accessibilityLabel="alertmodal_close_button"
        style={[styles.container]}
      >
        <InfoTooltip
          isVisible={showMenuTip}
          mainTitle={Strings["ime.scanner.Main.Menu"] ?? "Main Menu"}
          tooltipContent={
            Strings[
              "ime.scanner.Easily.navigate.across.the.different.activities"
            ] ?? "Easily navigate across the different activities."
          }
          stepNo={1}
          onClose={onFinish}
          onPressNext={() => {
            setShowMenuTip(false);
            setBellTip(true);
          }}
          onFinish={onFinish}
          contentStlye={[
            styles.menuTipContent,
            Platform.OS === "ios" && { top: hp(2.5) }, // top: top*0.35
          ]}
          accessibilityLabel="main_menu_"
        >
          <TouchableOpacity
            accessible={true}
            accessibilityLabel="main_menu_button"
            style={[styles.iconLeft]}
          >
            <Menu
              accessible={true}
              accessibilityLabel="main_menu_button_icon"
            />
          </TouchableOpacity>
        </InfoTooltip>
        <CustomText accessibilityLabel="dashboard" style={[styles.title]}>
          Dashboard
        </CustomText>
        <InfoTooltip
          accessibilityLabel="get_notified_"
          isVisible={showBellTip}
          mainTitle={Strings["ime.scanner.Get.Notified"] ?? "Get Notified"}
          tooltipContent={
            Strings[
              "ime.scanner.Stay.up.to.date.in.our.communication.center."
            ] ?? "Stay up to date in our communication center."
          }
          stepNo={2}
          placement={"left"}
          onClose={onFinish}
          onPressNext={() => {
            setShowMenuTip(false);
            setBellTip(false);
            setChangeTip(true);
          }}
          onPressBack={() => {
            setShowMenuTip(true);
            setBellTip(false);
            setChangeTip(false);
          }}
          onFinish={onFinish}
          contentStlye={[
            styles.menuTipContent,
            Platform.OS === "ios" && { top: hp(2.5) },
          ]}
        >
          <View style={[styles.iconRight]}>
            <Bell
              height={isDeviceTablet() ? hp(4) : hp(3)}
              width={isDeviceTablet() ? hp(4) : hp(3)}
            />
            {notificationCount + messagesCount + newsCount > 0 && (
              <View
                style={[
                  styles.notificationIndicator,
                  {
                    height: isDeviceTablet() ? wp(2.5) : wp(2.5),
                    width: isDeviceTablet() ? wp(2.5) : wp(2.5),
                    borderRadius: isDeviceTablet() ? wp(2) : wp(2),
                  },
                ]}
              />
            )}
          </View>
        </InfoTooltip>
      </View>
    </View>
  );

  const renderSubheader = () => (
    <>
      <View
        accessible={true}
        accessibilityLabel="row_container"
        style={styles.rowContainer}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.contentContainer}
          accessible={true}
          accessibilityLabel="content_container"
        >
          <View
            accessible={true}
            accessibilityLabel="title_container"
            style={styles.titleContainer}
          >
            <CustomText accessibilityLabel="org_title" style={styles.titleText}>
              {Strings["organization"]}
            </CustomText>
            <CustomText
              accessible={true}
              accessibilityLabel="stkrm_title"
              style={styles.titleText}
            >
              {Strings["stockroom"]}
            </CustomText>
          </View>
          <View
            accessible={true}
            accessibilityLabel="value_container"
            style={styles.valueContainer}
          >
            <CustomText
              accessible={true}
              accessibilityLabel="org_value"
              style={styles.valueText}
            >
              {selectedTitle}
            </CustomText>
            <CustomText
              accessibilityLabel="stkrm_value"
              style={styles.valueText}
            >
              {selectedSubTitle}
            </CustomText>
          </View>
          <View
            accessible={true}
            accessibilityLabel="spacer"
            style={styles.spacer}
          />
        </ScrollView>
        <View
          accessible={true}
          accessibilityLabel="button_container"
          style={[styles.buttonContainer]}
        >
          <InfoTooltip
            accessibilityLabel="change_org_stkrm_"
            isVisible={showChangeTip}
            mainTitle={
              Strings["ime.scanner.Change.Organization.and.Stockroom"] ??
              "Change Organization and Stockroom"
            }
            tooltipContent={
              Strings[
                "ime.scanner.Changing.your.location.is.just.a.tap.away"
              ] ?? "Changing your location is just a tap away!"
            }
            stepNo={3}
            placement={"bottom"}
            onClose={onFinish}
            onPressNext={() => {
              setShowMenuTip(false);
              setBellTip(false);
              setChangeTip(false);
              setSearchTip(true);
            }}
            onPressBack={() => {
              setShowMenuTip(false);
              setBellTip(true);
              setChangeTip(false);
            }}
            onFinish={onFinish}
            contentStlye={[styles.changeTipContent]}
          >
            <View style={[styles.pressableContainerView]}>
              <Pressable
                accessible={true}
                accessibilityLabel="button_container"
                style={styles.pressableContainer}
              >
                <CustomText
                  accessibilityLabel="button_title"
                  style={styles.pressableText}
                >
                  {Strings["ime.scanner.change"] ?? "Change"}
                </CustomText>
              </Pressable>
            </View>
          </InfoTooltip>
        </View>
      </View>
    </>
  );

  return (
    <View
      accessible={true}
      accessibilityLabel="main_container"
      style={styles.mainContainer}
    >
      <AlertModal isShow={true} customStyles={styles.modalStyle}>
        {renderHeader()}

        {renderSubheader()}

        <InfoTooltip
          accessibilityLabel="search_"
          isVisible={showSearchTip}
          mainTitle={
            (
              Strings["ime.scanner.Search.or.Scan"] ?? "Search or Scan"
            )?.replaceAll(".", " ") ?? "Search or Scan"
          }
          tooltipContent={
            Strings["ime.scanner.Quickly.search.msg"] ??
            `Quickly search your stockroom for products or scan a barcode!`
          }
          stepNo={4}
          placement={"bottom"}
          onClose={onFinish}
          onPressNext={() => {
            setShowMenuTip(false);
            setBellTip(false);
            setChangeTip(false);
            setSearchTip(false);
            setKpiTip(true);
          }}
          onPressBack={() => {
            setShowMenuTip(false);
            setBellTip(false);
            setChangeTip(true);
            setSearchTip(false);
            setKpiTip(false);
          }}
          onFinish={onFinish}
          contentStlye={{ width: wp(90) }}
        >
          <View
            accessible={true}
            accessibilityLabel="search_view_wrapper"
            style={styles.searchViewWrapper}
          >
            <SearchBar
              search={search}
              onSearch={setSearch}
              placeholder={Strings["ime.scanner.search"] ?? "Search products"}
              containerStyle={{
                paddingHorizontal: wp(3),
                marginVertical: wp(1),
              }}
              enableSearchBar={false}
            />
          </View>
        </InfoTooltip>

        <FlatList
          accessible={true}
          accessibilityLabel="dashboard_items_list"
          data={CardsDataFilter()}
          keyExtractor={(item, index) => index.toString()}
          numColumns={2}
          renderItem={({ item, index }) => (
            <DashboardItemCard
              Icon={item.icon}
              title={item.title}
              count={item.count}
            />
          )}
          ItemSeparatorComponent={() => <EmptyDivider height={hp(1)} />}
          contentContainerStyle={styles.flatlist}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={() => {
            return (
              <InfoTooltip
                accessibilityLabel="stkrm_health_"
                isVisible={showKpiTip}
                mainTitle={
                  Strings["ime.scanner.Stockroom.Health"] ?? "Stockroom Health"
                }
                tooltipContent={
                  Strings["ime.scanner.reorder.quickly.replenish.stockroom"] ??
                  `Always know what products you need to reorder and quickly replenish your stockroom.`
                }
                stepNo={5}
                placement={"bottom"}
                onClose={onFinish}
                onPressNext={onFinish}
                onPressBack={() => {
                  setShowMenuTip(false);
                  setBellTip(false);
                  setChangeTip(false);
                  setSearchTip(true);
                  setKpiTip(false);
                }}
                onFinish={onFinish}
                contentStlye={{ width: wp(80) }}
              >
                <View
                  accessible={true}
                  accessibilityLabel="kpi_container"
                  style={[
                    styles.kpiContainer,
                    showKpiTip && { backgroundColor: COLORS.white },
                  ]}
                >
                  <KPIBlock
                    LeftIcon={RedWarning}
                    title={Strings?.["ime.out.of.stock"]}
                    value={4}
                  />
                  <EmptyDivider width={wp(3.2)} />
                  <KPIBlock
                    LeftIcon={YellowWarning}
                    title={Strings?.["ime.running.low"]}
                    value={8}
                  />
                </View>
              </InfoTooltip>
            );
          }}
          ListFooterComponent={() => (
            <View
              accessible={true}
              accessibilityLabel="footer_container"
              style={styles.footerContainer}
            />
          )}
        />
      </AlertModal>
    </View>
  );
};

export default WalkthroughTips;
