import { StyleSheet } from "react-native";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { COLORS, SIZES, FONTS } from "../../Utils/theme";

export default StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  center: {
    padding: SIZES.padding,
    width: wp("85%"),
    backgroundColor: COLORS.white,
    borderRadius: SIZES.base,
  },
  titleText: { ...FONTS.title, textAlign: "center", color: COLORS.black },
  descriptionText: {
    ...FONTS.body,
    textAlign: "center",
    marginTop: SIZES.radius,
    color: COLORS.black,
  },
  btnWrapper: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: SIZES.padding,
    paddingVertical: hp(1),
  },
  btnContainer: {
    // paddingVertical: SIZES.padding,
    paddingHorizontal: SIZES.padding * 1.3,
    height: hp(5),
    justifyContent: "center",
    alignItems: "center",
  },
  primaryText: { ...FONTS.title, color: COLORS.white },
  secondaryText: { ...FONTS.title, color: COLORS.black },
});
