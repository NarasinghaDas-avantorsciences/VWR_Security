import React from "react";
import { View, TouchableOpacity } from "react-native";
import Modal from "react-native-modal";
import styles from "./styles";
import { COLORS } from "../../Utils/theme";
import CustomText from "../CustomText";

const DecisionModal = (props: any) => {
  const {
    show,
    title,
    children,
    description,
    secondaryBtnText,
    primaryBtnText,
    primaryDisabled = false,
    onSecondaryPress,
    onPrimaryPress,
    btnContainer,
    btnWrapper,
    titleText,
  } = props;

  return (
    <Modal
      isVisible={show}
      animationIn="fadeIn"
      animationOut="fadeOut"
      useNativeDriverForBackdrop={true}
      hideModalContentWhileAnimating={true}
      backdropOpacity={0.4}
    >
      <View style={[styles.container]}>
        <View style={[styles.center]}>
          <CustomText style={[styles.titleText, titleText]}>{title}</CustomText>
          {children ? (
            children
          ) : (
            <CustomText style={styles.descriptionText}>
              {description}
            </CustomText>
          )}

          <View style={[styles.btnWrapper, btnWrapper]}>
            <TouchableOpacity
              style={[styles.btnContainer, btnContainer]}
              onPress={onSecondaryPress}
            >
              <CustomText style={styles.secondaryText}>
                {secondaryBtnText}
              </CustomText>
            </TouchableOpacity>
            <TouchableOpacity
              disabled={primaryDisabled}
              style={[
                styles.btnContainer,
                btnContainer,
                {
                  backgroundColor: primaryDisabled
                    ? COLORS.gray2
                    : COLORS.scienceBlue,
                },
              ]}
              onPress={onPrimaryPress}
            >
              <CustomText style={styles.primaryText}>
                {primaryBtnText}
              </CustomText>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default DecisionModal;
