import { StyleSheet } from "react-native";

import { hp, wp } from "../../Utils/globalFunction";
import { COLORS, FONTFAMILY, FONTS } from "../../Utils/theme";

export default StyleSheet.create({
  rendercomponentContainerInDetalModal: {
    paddingHorizontal: wp(4),
    flexGrow: 1,
  },

  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    height: hp(4),
    paddingHorizontal: wp(4),
  },

  productModalHeaderTitle: {
    fontSize: FONTS.h2_1,
    textAlign: "center",
    fontFamily: FONTFAMILY.averta_semibold,
    color: COLORS.scienceBlue,
    left: wp(6),
  },

  secondaryPressableContainer: {
    justifyContent: "center",
    alignItems: "center",
  },

  secondaryPressableText: {
    color: COLORS.scienceBlue,
    fontFamily: FONTFAMILY.averta_regular,
    fontSize: FONTS.h2_1,
    textAlign: "center",
  },

  detailsContainer: { marginBottom: wp(20) },

  productDetailsImageStyle: {
    height: wp(25),
    width: wp(25),
    marginTop: hp(2),
    resizeMode: "contain",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: COLORS.abbey,
  },
});
