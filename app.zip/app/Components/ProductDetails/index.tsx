import React from "react";
import {
  ScrollView,
  View,
  TouchableOpacity,
  Image,
  Platform,
} from "react-native";
import { useSelector } from "react-redux";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import BottomSheetComponent from "../BottomSheet";
import ProductModalDetailsItems from "../ProductModalDetailsItems";
import { getMultiplier, hp } from "../../Utils/globalFunction";
import { DefaultProductImage } from "../../Utils/images";

import styles from "./styles";
import { Loader } from "../Loader";
import CustomText from "../CustomText";

type ProductDetailsList = {
  description: string;
  imageURL: string | null;
  catalogNo: string;
  custCatalogNo: string;
  vendorName: string;
  locationName: string;
  purchasePrice: string;
  availableQty: string;
  batchManagementEnabled: number;
  expiryDateManagementenabled: number;
  reorderPoint: string;
  maxStockQty: number;
  backlogQty: number;
  maxStockQtyForDisplay?: any;
};

type ProductDetailsProps = {
  productDetailsList: ProductDetailsList;
  itemDetailsRef: any;
  isShowPrice?: boolean;
};

const ProductDetails: React.FC<ProductDetailsProps> = ({
  productDetailsList,
  itemDetailsRef,
  isShowPrice = true,
}) => {
  const strings = useSelector((state: any) => state.languageReducer?.data);
  const productDetailsLoading = useSelector(
    (state: any) => state.searchReducer?.productDetailsLoading
  );

  const { top } = useSafeAreaInsets();
  return (
    <BottomSheetComponent
      customStyles={{
        container: [Platform.OS === "ios" && { paddingTop: top - 20 }],
      }}
      height={hp(100)}
      bottomSheetRef={itemDetailsRef}
    >
      {productDetailsLoading ? (
        <Loader show={true} />
      ) : (
        <>
          <View style={styles.headerContainer}>
            <View />
            <CustomText
              style={styles.productModalHeaderTitle}
              numberOfLines={1}
              ellipsizeMode="tail"
            >
              {productDetailsList?.description.length > 20
                ? productDetailsList?.description.slice(0, 19) + "..."
                : productDetailsList?.description}
            </CustomText>
            <TouchableOpacity
              style={styles.secondaryPressableContainer}
              onPress={() => itemDetailsRef.current.close()}
            >
              <CustomText style={styles.secondaryPressableText}>
                {strings["close"]}
              </CustomText>
            </TouchableOpacity>
          </View>
          <ScrollView
            overScrollMode="never"
            contentContainerStyle={styles.rendercomponentContainerInDetalModal}
          >
            <TouchableOpacity activeOpacity={1}>
              <View style={styles.detailsContainer}>
                {productDetailsList?.imageURL == null ? (
                  <View style={styles.productDetailsImageStyle}>
                    <DefaultProductImage />
                  </View>
                ) : (
                  <Image
                    source={{
                      uri: productDetailsList?.imageURL.replace(
                        "http://",
                        "https://"
                      ),
                    }}
                    style={styles.productDetailsImageStyle}
                    resizeMode={"contain"}
                  />
                )}
                <ProductModalDetailsItems
                  title={strings["product.catalog.number"]}
                  value={productDetailsList?.catalogNo}
                />
                <ProductModalDetailsItems
                  title={strings["customer.catalog.number"]}
                  value={productDetailsList?.custCatalogNo}
                />
                <ProductModalDetailsItems
                  title={strings["desc"]}
                  value={productDetailsList?.description}
                />
                <ProductModalDetailsItems
                  title={strings["vendor"]}
                  value={productDetailsList?.vendorName}
                />
                <ProductModalDetailsItems
                  title={strings["location"]}
                  value={productDetailsList?.locationName}
                />
                {!!isShowPrice && (
                  <ProductModalDetailsItems
                    title={strings["price"]}
                    value={productDetailsList?.purchasePrice}
                  />
                )}
                <ProductModalDetailsItems
                  title={strings["available.quantity"]}
                  value={`${productDetailsList?.availableQty} ${
                    getMultiplier(productDetailsList) == null
                      ? " "
                      : getMultiplier(productDetailsList)
                  }`}
                />
                <ProductModalDetailsItems
                  title={strings["ime.batch.controlled"]}
                  value={
                    productDetailsList?.batchManagementEnabled === 1
                      ? "Yes"
                      : "No"
                  }
                />
                <ProductModalDetailsItems
                  title={strings["expiry.date"]}
                  value={
                    productDetailsList?.expiryDateManagementenabled === 1
                      ? "Yes"
                      : "No"
                  }
                />
                <ProductModalDetailsItems
                  title={strings["im.reorder.point"]}
                  value={productDetailsList?.reorderPoint}
                />
                <ProductModalDetailsItems
                  title={strings["maximum.quantity"]}
                  value={productDetailsList?.maxStockQty}
                />
                <ProductModalDetailsItems
                  title={strings["quantity.in.transit"]}
                  value={productDetailsList?.backlogQty}
                />
              </View>
            </TouchableOpacity>
          </ScrollView>
        </>
      )}
    </BottomSheetComponent>
  );
};

export default ProductDetails;
