import { StyleSheet } from "react-native";
import { COLORS, FONTFAMILY } from "../../Utils/theme";
import { hp, wp } from "../../Utils/globalFunction";

const Styles = StyleSheet.create({
  viewContainer: {
    backgroundColor: COLORS.white,
    width: wp(95),
    alignSelf: "center",
  },

  btnWrapper: { alignItems: "flex-end" },

  btnContainer: { padding: hp(1) },
});

export default Styles;
