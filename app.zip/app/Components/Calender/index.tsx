import React from "react";
import { Pressable, View } from "react-native";
import moment from "moment";
import { COLORS } from "../../Utils/theme";
import { Cross, LeftArrow, RightArrow } from "../../Utils/images";
import { hp, wp } from "../../Utils/globalFunction";
import styles from "./styles";
import CalendarPicker from "react-native-calendar-picker";

type CalendarProps = {
  todayDate?: string;
  focusedDate?: string;
  onClose?: any;
  increment?: () => void;
  changeDate?: any;
  selectedDate?: any;
};

const Calendar: React.FC<CalendarProps> = ({
  onClose,
  changeDate,
  selectedDate,
}) => {
  const LeftIcon = () => {
    return <LeftArrow height={hp(2)} width={hp(2)} />;
  };
  const RightIcon = () => {
    return (
      <RightArrow style={{ marginLeft: wp(2) }} height={hp(2)} width={hp(2)} />
    );
  };
  const onChange = (date: any) => {
    changeDate(date);
    onClose();
  };

  return (
    <View style={styles.viewContainer}>
      <View style={styles.btnWrapper}>
        <Pressable onPress={onClose} style={styles.btnContainer}>
          <Cross />
        </Pressable>
      </View>
      <CalendarPicker
        startFromMonday={false}
        allowRangeSelection={false}
        minDate={moment(new Date())}
        previousTitle={LeftIcon()}
        nextTitle={RightIcon()}
        selectMonthTitle={
          moment(selectedDate, "MM-DD-YYYY").format("MMMM") + " "
        }
        select
        todayBackgroundColor={COLORS.aliceBlue}
        selectedDayTextColor="#fff"
        todayTextStyle={{ color: COLORS.abbey }}
        selectedDayColor={COLORS.scienceBlue}
        scaleFactor={375}
        onDateChange={(date: any) => onChange(date)}
        selectedStartDate={moment(selectedDate, "MM-DD-YYYY").format(
          "YYYY-MM-DD"
        )}
        initialDate={moment(selectedDate, "MM-DD-YYYY").format("YYYY-MM-DD")}
        monthTitleStyle={{
          color: COLORS.abbey,
          paddingVertical: hp(1),
        }}
        yearTitleStyle={{
          color: COLORS.abbey,
          paddingVertical: hp(1),
        }}
      />
    </View>
  );
};

export default Calendar;
